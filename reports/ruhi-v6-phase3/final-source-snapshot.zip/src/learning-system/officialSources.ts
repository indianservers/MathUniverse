import { ingestCurriculumSource } from "./sourceIngestion";
import type { CurriculumSourceRecord, SourceSection } from "./types";

const retrievedAt = "2026-08-20T10:30:00+05:30";
export const officialCurriculumSources: CurriculumSourceRecord[] = [
  {
    id: "CBSE-2026-27-IX-MATH",
    authority: "Central Board of Secondary Education, Academic Unit",
    board: "CBSE",
    title: "Mathematics Class IX (2026–27)",
    academicYear: "2026-27",
    subject: "Mathematics",
    course: "Class IX Mathematics",
    medium: "English",
    officialUrl:
      "https://cbseacademic.nic.in/web_material/CurriculumMain27/SecPart1/Maths_SecP1IX_2026-27.pdf",
    documentType: "CURRICULUM",
    checksum:
      "932ea66d6fbfcefce8182f28ab921c886187f5dea674321088b5c7230bbe6c32",
    retrievedAt,
    effectiveFrom: "2026-04-01",
    pageCount: 13,
    ingestionVersion: "1",
    reviewStatus: "PARSED",
  },
  {
    id: "CBSE-2026-27-IX-MATH-ADV",
    authority: "Central Board of Secondary Education, Academic Unit",
    board: "CBSE",
    title: "Mathematics at Advanced Level Class IX (2026–27)",
    academicYear: "2026-27",
    subject: "Mathematics at Advanced Level",
    course: "Class IX Mathematics Advanced",
    medium: "English",
    officialUrl:
      "https://cbseacademic.nic.in/web_material/CurriculumMain27/SecPart1/MathsAd_SecP1_2026-27.pdf",
    documentType: "CURRICULUM",
    checksum:
      "24cb27010ff2c13832c58b3aaf4213537148a7396812982e34cb752e0a718cb4",
    retrievedAt,
    effectiveFrom: "2026-04-01",
    pageCount: 97,
    ingestionVersion: "1",
    reviewStatus: "HUMAN_REVIEW_REQUIRED",
  },
  {
    id: "CBSE-2026-27-X-MATH",
    authority: "Central Board of Secondary Education, Academic Unit",
    board: "CBSE",
    title: "Mathematics Class X (2026–27)",
    academicYear: "2026-27",
    subject: "Mathematics",
    course: "Class X Mathematics",
    medium: "English",
    officialUrl:
      "https://cbseacademic.nic.in/web_material/CurriculumMain27/SecPart1/Maths_SecP1X_2026-27.pdf",
    documentType: "CURRICULUM",
    checksum:
      "d773e7c12b99e0bd498067e2b8268c76d0496bf9cad1c9e41c8652ab68b412a5",
    retrievedAt,
    effectiveFrom: "2026-04-01",
    pageCount: 10,
    ingestionVersion: "1",
    reviewStatus: "HUMAN_REVIEW_REQUIRED",
  },
  {
    id: "CBSE-2026-27-XI-XII-MATH",
    authority: "Central Board of Secondary Education, Academic Unit",
    board: "CBSE",
    title: "Mathematics Classes XI–XII (2026–27)",
    academicYear: "2026-27",
    subject: "Mathematics",
    course: "Classes XI–XII Mathematics",
    medium: "English",
    officialUrl:
      "https://cbseacademic.nic.in/web_material/CurriculumMain27/SecPart2/Maths_SecP2_2026-27.pdf",
    documentType: "CURRICULUM",
    checksum:
      "5bf4105d4076189fe00b879fd6d41ffadec87a894a078a7fb912b2f219769572",
    retrievedAt,
    effectiveFrom: "2026-04-01",
    pageCount: 12,
    ingestionVersion: "1",
    reviewStatus: "HUMAN_REVIEW_REQUIRED",
  },
  {
    id: "CBSE-2026-27-XI-XII-APPLIED",
    authority: "Central Board of Secondary Education, Academic Unit",
    board: "CBSE",
    title: "Applied Mathematics Classes XI–XII (2026–27)",
    academicYear: "2026-27",
    subject: "Applied Mathematics",
    course: "Classes XI–XII Applied Mathematics",
    medium: "English",
    officialUrl:
      "https://cbseacademic.nic.in/web_material/CurriculumMain27/SecPart2/Applied_Mathematics_SecP2_2026-27.pdf",
    documentType: "CURRICULUM",
    checksum:
      "3125b1b6b00d8081bff34a1276d5f5203daa719af961d943380b4b0cb9d35a70",
    retrievedAt,
    effectiveFrom: "2026-04-01",
    pageCount: 19,
    ingestionVersion: "1",
    reviewStatus: "HUMAN_REVIEW_REQUIRED",
  },
];

const ixSections: Omit<SourceSection, "sourceId" | "reviewStatus">[] = [
  {
    id: "cbse-ix-unit-number",
    kind: "UNIT",
    title: "Number System",
    order: 1,
    pageOrSection: "PDF p.4, Course Structure Unit I",
    text: "Number System; 7 marks",
    confidence: 0.99,
  },
  {
    id: "cbse-ix-outcome-number",
    parentId: "cbse-ix-unit-number",
    kind: "OUTCOME",
    title: "Real-number reasoning",
    order: 1,
    pageOrSection: "PDF pp.2,4–5; C-1.1 and Unit I",
    text: "Represent rational numbers, reason about density and decimal representations, introduce irrational numbers, prove irrationality, and construct the square-root spiral.",
    confidence: 0.94,
  },
  {
    id: "cbse-ix-unit-algebra",
    kind: "UNIT",
    title: "Algebra",
    order: 2,
    pageOrSection: "PDF p.4, Course Structure Unit II",
    text: "Introduction to Polynomials; Sequences and Progressions; Algebraic Identities; Linear Equations in Two Variables; 20 marks",
    confidence: 0.99,
  },
  {
    id: "cbse-ix-unit-coordinate",
    kind: "UNIT",
    title: "Coordinate Geometry",
    order: 3,
    pageOrSection: "PDF p.4, Course Structure Unit III",
    text: "Coordinate Geometry; 4 marks",
    confidence: 0.99,
  },
  {
    id: "cbse-ix-unit-geometry",
    kind: "UNIT",
    title: "Geometry",
    order: 4,
    pageOrSection: "PDF p.4, Course Structure Unit IV",
    text: "Euclid’s Geometry; Lines and Angles; Triangles; Quadrilaterals; Circles; 25 marks",
    confidence: 0.99,
  },
  {
    id: "cbse-ix-unit-mensuration",
    kind: "UNIT",
    title: "Mensuration",
    order: 5,
    pageOrSection: "PDF p.4, Course Structure Unit V",
    text: "Area and Perimeter; Surface Area and Volume; 14 marks",
    confidence: 0.99,
  },
  {
    id: "cbse-ix-unit-stat-prob",
    kind: "UNIT",
    title: "Statistics and Probability",
    order: 6,
    pageOrSection: "PDF p.4, Course Structure Unit VI",
    text: "Statistics; Introduction to Probability; 10 marks",
    confidence: 0.99,
  },
  {
    id: "cbse-ix-assessment",
    kind: "ASSESSMENT_PATTERN",
    title: "Theory marks structure",
    order: 1,
    pageOrSection: "PDF p.4, Course Structure",
    text: "Six units total 80 marks; projects, activities and investigations are integral per the introduction.",
    confidence: 0.92,
  },
];
export const ingestedCurriculumBundles = [
  ingestCurriculumSource(officialCurriculumSources[0], ixSections),
  ...officialCurriculumSources
    .slice(1)
    .map((source) => ingestCurriculumSource(source, [])),
];
export const unavailableOfficialSources = [
  {
    board: "AP_BIE" as const,
    requested:
      "2026–27 Mathematics IA/IB/IIA/IIB syllabi and outcome-level structures",
    officialPortal: "https://bie.ap.gov.in/",
    availableEvidence: [
      "https://bie.ap.gov.in/modelpapers",
      "https://bie.ap.gov.in/blueprints",
    ],
    status: "OFFICIAL_DOCUMENT_UNAVAILABLE",
    note: "Current official model-paper and blueprint portals were located, but a checksumable official syllabus document was not safely retrievable. No formal mapping was inferred.",
  },
  {
    board: "TELANGANA_BIE" as const,
    requested:
      "Current Mathematics IA/IB/IIA/IIB syllabi, model papers and blueprints",
    officialPortal: "https://tgbie.cgg.gov.in/",
    availableEvidence: [],
    status: "OFFICIAL_DOCUMENT_UNAVAILABLE",
    note: "The official portal was located, but no checksumable syllabus document was exposed through the available interface. Telangana remains independent and unmapped.",
  },
  {
    board: "NCERT" as const,
    requested:
      "Complete 2026–27 Class 6–12 mathematics textbook structure and outcome references",
    officialPortal: "https://ncert.nic.in/textbook.php",
    availableEvidence: [
      "https://www.ncert.nic.in/rationalised-content.php?ln=en",
    ],
    status: "PARTIAL_DISCOVERY_ONLY",
    note: "Official textbook and rationalised-content portals were located. Full chapter-file ingestion and checksumming remains pending; CBSE curriculum evidence is not treated as NCERT textbook evidence.",
  },
];
