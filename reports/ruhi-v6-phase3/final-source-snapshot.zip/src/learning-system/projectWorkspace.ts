export type MathProject = {
  id: string;
  title: string;
  problemStatement: string;
  assumptions: string[];
  variables: Array<{ symbol: string; meaning: string; unit?: string }>;
  mathematicalNodeIds: string[];
  graphNodeIds: string[];
  geometryNodeIds: string[];
  tableNodeIds: string[];
  calculations: Array<{ nodeId: string; interpretation: string }>;
  interpretation: string;
  limitations: string[];
  reflection: string;
  sources: Array<{ title: string; url: string }>;
  reportSections: string[];
  rubric: {
    criteria: Array<{ id: string; description: string; maxMarks: number }>;
    reviewStatus: "DRAFT" | "HUMAN_REVIEW_REQUIRED" | "APPROVED";
  };
  workflowStatus: "DRAFT" | "REVIEW_REQUIRED" | "APPROVED";
};
export function validateProject(
  project: MathProject,
  validNodeIds: Set<string>,
) {
  const issues: string[] = [];
  if (!project.problemStatement.trim())
    issues.push("Problem statement required");
  for (const id of [
    ...project.mathematicalNodeIds,
    ...project.graphNodeIds,
    ...project.geometryNodeIds,
    ...project.tableNodeIds,
  ])
    if (!validNodeIds.has(id)) issues.push(`Unknown mathematical node ${id}`);
  if (
    project.workflowStatus === "APPROVED" &&
    project.rubric.reviewStatus !== "APPROVED"
  )
    issues.push("Approved project requires an approved rubric");
  return issues;
}
