import type { MasteryEvidence, MasterySummary } from "./types";

export function computeMastery(
  conceptId: string,
  evidence: MasteryEvidence[],
  now = new Date(),
): MasterySummary {
  const relevant = evidence
    .filter((entry) => entry.conceptId === conceptId)
    .sort((a, b) => a.attemptedAt.localeCompare(b.attemptedAt));
  if (!relevant.length)
    return {
      conceptId,
      state: "NOT_STARTED",
      confidence: 0,
      evidenceCount: 0,
      independentSuccesses: 0,
      assistedSuccesses: 0,
      misconceptions: [],
    };
  const weighted = relevant.map((entry) => {
    const assistance =
      Math.max(0.35, 1 - entry.hintsUsed * 0.12) *
      (entry.completion === "INDEPENDENT" ? 1 : 0.72);
    const difficulty = {
      FOUNDATION: 0.8,
      CORE: 1,
      ADVANCED: 1.12,
      CHALLENGE: 1.2,
    }[entry.difficulty];
    const retention = entry.retentionCheck ? 1.15 : 1;
    return entry.score * assistance * difficulty * retention;
  });
  const confidence = Math.max(
    0,
    Math.min(1, weighted.reduce((a, b) => a + b, 0) / weighted.length),
  );
  const independentSuccesses = relevant.filter(
    (entry) => entry.correct && entry.completion === "INDEPENDENT",
  ).length;
  const assistedSuccesses = relevant.filter(
    (entry) => entry.correct && entry.completion === "ASSISTED",
  ).length;
  const last = relevant.at(-1)!.attemptedAt;
  const days = (now.getTime() - new Date(last).getTime()) / 86400000;
  let state: MasterySummary["state"] =
    confidence < 0.35
      ? "EMERGING"
      : confidence < 0.58
        ? "DEVELOPING"
        : confidence < 0.78 || independentSuccesses < 2
          ? "PROFICIENT"
          : "SECURE";
  if (state === "SECURE" && days > 21) state = "REVIEW_DUE";
  const counts = new Map<string, number>();
  relevant
    .flatMap((entry) => entry.misconceptionTags)
    .forEach((tag) => counts.set(tag, (counts.get(tag) ?? 0) + 1));
  const nextReview = new Date(
    new Date(last).getTime() + (state === "SECURE" ? 21 : 7) * 86400000,
  ).toISOString();
  return {
    conceptId,
    state,
    confidence: Number(confidence.toFixed(3)),
    evidenceCount: relevant.length,
    independentSuccesses,
    assistedSuccesses,
    lastPractisedAt: last,
    nextReviewAt: nextReview,
    misconceptions: [...counts]
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count),
  };
}
export function remediationRecommendation(
  summary: MasterySummary,
  prerequisites: string[],
) {
  if (summary.state === "NOT_STARTED")
    return {
      reason: "No attempt evidence",
      steps: [
        "Open a short prerequisite check",
        "Try one foundation item",
        "Record the result before updating mastery",
      ],
    };
  const misconception = summary.misconceptions[0]?.tag;
  return {
    reason: misconception
      ? `Repeated misconception: ${misconception}`
      : `Low independent confidence (${summary.confidence})`,
    steps: [
      ...(prerequisites.length
        ? [`Check prerequisite ${prerequisites[0]}`]
        : []),
      "Read one targeted explanation",
      "Complete an easier guided activity without a timer",
      "Reassess with a different deterministic seed",
      "Return to the original pathway",
    ],
  };
}
