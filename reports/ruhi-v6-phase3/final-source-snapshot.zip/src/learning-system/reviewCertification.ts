import type {
  CertificationResult,
  CoursePathway,
  CurriculumSourceRecord,
  MathLesson,
  ReviewApproval,
  ReviewRole,
} from "./types";

const transitions: Record<
  MathLesson["workflowStatus"],
  MathLesson["workflowStatus"][]
> = {
  SCAFFOLD: ["DRAFT"],
  DRAFT: ["SME_REVIEW"],
  SME_REVIEW: ["TEACHER_REVIEW", "DRAFT"],
  TEACHER_REVIEW: ["ASSESSMENT_REVIEW", "DRAFT"],
  ASSESSMENT_REVIEW: ["ACCESSIBILITY_REVIEW", "DRAFT"],
  ACCESSIBILITY_REVIEW: ["QA_REVIEW", "DRAFT"],
  QA_REVIEW: ["APPROVED", "DRAFT"],
  APPROVED: ["CERTIFIED", "DRAFT", "RETIRED"],
  CERTIFIED: ["DRAFT", "RETIRED"],
  RETIRED: [],
};
export function transitionLesson(
  lesson: MathLesson,
  next: MathLesson["workflowStatus"],
) {
  if (!transitions[lesson.workflowStatus].includes(next))
    throw new Error(
      `Invalid review transition ${lesson.workflowStatus} → ${next}`,
    );
  if (next === "APPROVED") {
    const roles = new Set(
      lesson.review.approvals
        .filter((entry) => entry.decision === "APPROVE")
        .map((entry) => entry.role),
    );
    for (const required of [
      "MATH_SME",
      "BOARD_TEACHER",
      "QA_REVIEWER",
    ] as ReviewRole[])
      if (!roles.has(required))
        throw new Error(`Missing required approval ${required}`);
  }
  return { ...lesson, workflowStatus: next };
}
export function reopenAfterSourceChange(lesson: MathLesson, sourceId: string) {
  return {
    ...lesson,
    workflowStatus: "DRAFT" as const,
    review: {
      ...lesson.review,
      requestedChanges: [
        ...lesson.review.requestedChanges,
        `Source ${sourceId} changed; mappings and approvals require review.`,
      ],
    },
  };
}
export function certifyCourse(
  course: CoursePathway,
  sources: CurriculumSourceRecord[],
  lessons: MathLesson[],
  availableCapabilities: Set<string>,
  now = new Date(),
  releaseEvidence: {
    modelPaperDryRunPassed?: boolean;
    finalReviewApprovals?: ReviewApproval[];
    automatedValidationPassed?: boolean;
  } = {},
): CertificationResult {
  const blockers: CertificationResult["blockingIssues"] = [];
  const missingOutcomes: string[] = [];
  const missingEvidence: string[] = [];
  const expiredSources: string[] = [];
  const missingReviewers = new Set<ReviewRole>();
  const sourceMap = new Map(sources.map((entry) => [entry.id, entry]));
  if (!course.units.length)
    blockers.push({
      code: "NO_OFFICIAL_UNITS",
      message: "No official unit structure is mapped.",
      dimension: "textbookMapped",
    });
  for (const sourceId of course.sourceIds) {
    const source = sourceMap.get(sourceId);
    if (!source) {
      missingEvidence.push(sourceId);
      continue;
    }
    if (source.reviewStatus !== "VERIFIED")
      blockers.push({
        code: "SOURCE_NOT_VERIFIED",
        message: `Source ${sourceId} is ${source.reviewStatus}.`,
        dimension: "textbookMapped",
      });
    if (source.effectiveTo && new Date(source.effectiveTo) < now)
      expiredSources.push(sourceId);
  }
  for (const unit of course.units) {
    if (!unit.chapters.length)
      blockers.push({
        code: "EMPTY_UNIT",
        message: `Unit ${unit.title} has no official chapters.`,
        dimension: "catalogued",
      });
    for (const chapter of unit.chapters) {
      if (!chapter.outcomeIds.length) missingOutcomes.push(chapter.id);
      if (!chapter.lessonIds.length)
        blockers.push({
          code: "MISSING_EXPLANATION",
          message: `${chapter.title} has no linked lesson.`,
          dimension: "explained",
        });
      if (!chapter.practiceFamilyIds.length)
        blockers.push({
          code: "MISSING_PRACTICE",
          message: `${chapter.title} has no linked practice.`,
          dimension: "practised",
        });
      if (!chapter.assessmentBlueprintIds.length)
        blockers.push({
          code: "MISSING_ASSESSMENT",
          message: `${chapter.title} has no linked assessment.`,
          dimension: "assessed",
        });
      if (!chapter.projectIds.length)
        blockers.push({
          code: "MISSING_PROJECT_ACTIVITY",
          message: `${chapter.title} has no mapped project or investigation.`,
          dimension: "visualized",
        });
    }
  }
  const relevant = lessons.filter((lesson) =>
    lesson.curriculumMappings.some((mapping) => mapping.startsWith(course.id)),
  );
  for (const lesson of relevant) {
    if (!["APPROVED", "CERTIFIED"].includes(lesson.workflowStatus))
      blockers.push({
        code: "LESSON_NOT_APPROVED",
        message: `Lesson ${lesson.id} is ${lesson.workflowStatus}.`,
        dimension: "explained",
      });
    const approvals = lesson.review.approvals.filter(
      (entry) => entry.decision === "APPROVE" && !isExpired(entry, now),
    );
    for (const role of [
      "MATH_SME",
      "BOARD_TEACHER",
      "QA_REVIEWER",
    ] as ReviewRole[])
      if (!approvals.some((entry) => entry.role === role))
        missingReviewers.add(role);
  }
  const finalApprovals = releaseEvidence.finalReviewApprovals ?? [];
  if (
    !finalApprovals.some(
      (entry) =>
        entry.role === "INDEPENDENT_FINAL_REVIEWER" &&
        entry.decision === "APPROVE" &&
        !isExpired(entry, now),
    )
  )
    missingReviewers.add("INDEPENDENT_FINAL_REVIEWER");
  if (!releaseEvidence.modelPaperDryRunPassed)
    blockers.push({
      code: "MODEL_PAPER_DRY_RUN_REQUIRED",
      message: "A reviewed model-paper dry run has not passed.",
      dimension: "assessed",
    });
  if (!releaseEvidence.automatedValidationPassed)
    blockers.push({
      code: "AUTOMATED_VALIDATION_REQUIRED",
      message: "The release validation gate has not been recorded as passed.",
      dimension: "boardCertified",
    });
  const unsupported = [
    ...new Set(
      relevant
        .flatMap((lesson) =>
          lesson.interactiveActivities.flatMap((block) => block.capabilityIds),
        )
        .filter((id) => !availableCapabilities.has(id)),
    ),
  ];
  if (unsupported.length)
    blockers.push({
      code: "UNSUPPORTED_CAPABILITY",
      message: `Unsupported capabilities: ${unsupported.join(", ")}`,
      dimension: "computational",
    });
  if (expiredSources.length)
    blockers.push({
      code: "EXPIRED_SOURCE",
      message: `Expired sources: ${expiredSources.join(", ")}`,
      dimension: "boardCertified",
    });
  if (missingReviewers.size)
    blockers.push({
      code: "MISSING_REVIEWERS",
      message: `Missing genuine approvals: ${[...missingReviewers].join(", ")}`,
      dimension: "boardCertified",
    });
  const passed =
    !blockers.length && !missingOutcomes.length && !missingEvidence.length;
  return {
    courseId: course.id,
    passed,
    blockingIssues: blockers,
    warnings: course.knownGaps,
    coverage: {
      catalogued: course.units.length ? "VERIFIED" : "NOT_STARTED",
      explained: blockers.some((entry) => entry.dimension === "explained")
        ? "REVIEW_REQUIRED"
        : "VERIFIED",
      visualized: blockers.some((entry) => entry.dimension === "visualized")
        ? "REVIEW_REQUIRED"
        : "VERIFIED",
      computational: unsupported.length ? "REVIEW_REQUIRED" : "VERIFIED",
      practised: blockers.some((entry) => entry.dimension === "practised")
        ? "NOT_STARTED"
        : "VERIFIED",
      assessed: blockers.some((entry) => entry.dimension === "assessed")
        ? "NOT_STARTED"
        : "VERIFIED",
      textbookMapped: course.sourceIds.length
        ? blockers.some((entry) => entry.dimension === "textbookMapped")
          ? "REVIEW_REQUIRED"
          : "VERIFIED"
        : "NOT_STARTED",
      boardCertified: passed ? "VERIFIED" : "NOT_STARTED",
    },
    missingOutcomes,
    missingEvidence,
    missingReviewers: [...missingReviewers],
    expiredSources,
    unsupportedCapabilities: unsupported,
    certificationDate: passed ? now.toISOString() : undefined,
    expiryDate: passed
      ? new Date(now.getTime() + 365 * 86400000).toISOString()
      : undefined,
  };
}
function isExpired(approval: ReviewApproval, now: Date) {
  return approval.expiresAt ? new Date(approval.expiresAt) < now : false;
}
