import type {
  CurriculumSourceRecord,
  SourceAuditEvent,
  SourceSection,
} from "./types";

export type IngestionBundle = {
  source: CurriculumSourceRecord;
  sections: SourceSection[];
  audit: SourceAuditEvent[];
  parserVersion: string;
};

export function ingestCurriculumSource(
  source: CurriculumSourceRecord,
  sections: Omit<SourceSection, "sourceId" | "reviewStatus">[],
  parserVersion = "phase3-parser-1",
): IngestionBundle {
  const issues = validateSource(source);
  if (issues.length) throw new Error(issues.join("; "));
  const normalized = sections.map((section) => ({
    ...section,
    sourceId: source.id,
    reviewStatus:
      section.confidence < 0.85
        ? ("HUMAN_REVIEW_REQUIRED" as const)
        : ("PARSED" as const),
  }));
  return {
    source: {
      ...source,
      reviewStatus: normalized.some(
        (entry) => entry.reviewStatus === "HUMAN_REVIEW_REQUIRED",
      )
        ? "HUMAN_REVIEW_REQUIRED"
        : "PARSED",
    },
    sections: normalized,
    audit: [
      {
        id: `audit-${source.id}-ingest`,
        sourceId: source.id,
        at: source.retrievedAt,
        actorType: "PARSER",
        action: "INGEST",
        after: { checksum: source.checksum, pageCount: source.pageCount },
      },
      {
        id: `audit-${source.id}-parse`,
        sourceId: source.id,
        at: source.retrievedAt,
        actorType: "PARSER",
        action: "PARSE",
        after: { sectionCount: normalized.length, parserVersion },
      },
    ],
    parserVersion,
  };
}
export function validateSource(source: CurriculumSourceRecord) {
  const issues: string[] = [];
  if (!/^https:\/\//.test(source.officialUrl))
    issues.push("Official source URL must use HTTPS");
  if (!/^[a-f0-9]{64}$/.test(source.checksum))
    issues.push("Source checksum must be a SHA-256 hex digest");
  if (!/^\d{4}-\d{2}-\d{2}/.test(source.retrievedAt))
    issues.push("Retrieval date is required");
  if (!source.academicYear) issues.push("Academic year is required");
  return issues;
}
export function duplicateSourceIds(sources: CurriculumSourceRecord[]) {
  const seen = new Map<string, string>();
  const duplicates: string[] = [];
  for (const source of sources) {
    const key = `${source.board}|${source.officialUrl}|${source.checksum}`;
    if (seen.has(key)) duplicates.push(`${seen.get(key)}:${source.id}`);
    else seen.set(key, source.id);
  }
  return duplicates;
}
export function curriculumDiff(
  previous: IngestionBundle,
  current: IngestionBundle,
) {
  const before = new Map(previous.sections.map((entry) => [entry.id, entry]));
  const after = new Map(current.sections.map((entry) => [entry.id, entry]));
  return {
    sourceChanged: previous.source.checksum !== current.source.checksum,
    added: [...after.keys()].filter((id) => !before.has(id)),
    removed: [...before.keys()].filter((id) => !after.has(id)),
    changed: [...after.keys()].filter(
      (id) =>
        before.has(id) &&
        JSON.stringify(before.get(id)) !== JSON.stringify(after.get(id)),
    ),
  };
}
export function applyReviewerCorrection(
  bundle: IngestionBundle,
  sectionId: string,
  patch: Partial<Pick<SourceSection, "title" | "text" | "pageOrSection">>,
  reviewerId: string,
  at: string,
): IngestionBundle {
  const before = bundle.sections.find((entry) => entry.id === sectionId);
  if (!before) throw new Error(`Unknown source section ${sectionId}`);
  const after = { ...before, ...patch, reviewStatus: "VERIFIED" as const };
  return {
    ...bundle,
    sections: bundle.sections.map((entry) =>
      entry.id === sectionId ? after : entry,
    ),
    audit: [
      ...bundle.audit,
      {
        id: `audit-${sectionId}-${bundle.audit.length + 1}`,
        sourceId: bundle.source.id,
        at,
        actorType: "REVIEWER",
        actorId: reviewerId,
        action: "CORRECT_SECTION",
        before,
        after,
      },
    ],
  };
}
