import { describe, expect, it } from "vitest";
import {
  emptyLearnerState,
  loadLearnerState,
  recordMasteryEvidence,
  saveLearnerState,
  savePracticeSession,
} from "./learnerStore";
describe("local-first save and resume", () => {
  it("persists attempts and practice seeds but not page visits", () => {
    const memory = new Map<string, string>();
    const storage = {
      getItem: (key: string) => memory.get(key) ?? null,
      setItem: (key: string, value: string) => void memory.set(key, value),
    };
    let state = emptyLearnerState();
    state = savePracticeSession(state, {
      familyId: "practice-induction-sum",
      seed: 42,
      status: "IN_PROGRESS",
      hintLevel: 2,
      updatedAt: "2026-08-20",
    });
    state = recordMasteryEvidence(state, {
      id: "e",
      conceptId: "ALG.MATHEMATICAL_INDUCTION",
      attemptedAt: "2026-08-20",
      correct: false,
      score: 0,
      hintsUsed: 2,
      timeSeconds: 30,
      difficulty: "CORE",
      misconceptionTags: ["circular-step"],
      retentionCheck: false,
      assessmentType: "FORMATIVE",
      completion: "ASSISTED",
      seed: 42,
    });
    saveLearnerState(storage as Storage, state);
    expect(loadLearnerState(storage as Storage)).toEqual(state);
    expect(JSON.stringify(state)).not.toContain("pageVisit");
  });
});
