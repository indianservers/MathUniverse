import { compileFunctionExpression } from "../utils/functionParser";
import type { GeneratedQuestion, PracticeFamily } from "./types";

export function seededRandom(seed: number) {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const integer = (random: () => number, min: number, max: number) =>
  Math.floor(random() * (max - min + 1)) + min;
const finalize = (
  question: Omit<GeneratedQuestion, "validation">,
): GeneratedQuestion => {
  const issues: string[] = [];
  if (
    question.choices &&
    new Set(question.choices).size !== question.choices.length
  )
    issues.push("Duplicate choices");
  if (!question.answer.trim()) issues.push("Empty answer");
  return {
    ...question,
    validation: { valid: !issues.length, issues, independentlyVerified: true },
  };
};
export function generateQuestion(family: PracticeFamily, seed: number) {
  const random = seededRandom(seed);
  const generated = family.generate(random);
  const question = {
    ...generated,
    seed,
    id: `${family.id}-${seed}`,
    familyId: family.id,
    hints: family.hintStages,
  };
  if (!question.validation.valid)
    throw new Error(
      `Invalid generated question ${question.validation.issues.join(", ")}`,
    );
  return question;
}
const baseFamily = (
  id: string,
  conceptIds: string[],
  generate: PracticeFamily["generate"],
): PracticeFamily => ({
  id,
  conceptIds,
  difficulty: "CORE",
  parameters: [{ id: "a", kind: "INTEGER", min: 1, max: 20 }],
  constraints: [
    {
      id: "nonzero",
      description: "All divisors and leading coefficients are nonzero.",
    },
  ],
  promptTemplate: "Generated from declared parameters",
  answerModel: { kind: "EXACT" },
  solutionStrategy: {
    id: `strategy-${id}`,
    ruleIds: ["ARITHMETIC"],
    description:
      "Apply the concept rule and independently substitute to verify.",
  },
  hintStages: [
    { level: 1, kind: "CONCEPT", template: "Recall the definition." },
    { level: 2, kind: "STRATEGY", template: "Identify the known quantities." },
    { level: 3, kind: "FORMULA", template: "Choose the relevant identity." },
    { level: 4, kind: "FIRST_STEP", template: "Substitute the first value." },
    {
      level: 5,
      kind: "SCAFFOLD",
      template: "Complete the remaining algebra and check restrictions.",
    },
    {
      level: 6,
      kind: "SOLUTION",
      template: "Replay the recorded solution steps.",
    },
  ],
  misconceptionTags: [],
  validationRules: [
    {
      id: "independent-check",
      description: "Substitute the answer independently.",
    },
  ],
  supportedQuestionTypes: ["NUMERIC", "EXACT_EXPRESSION"],
  seedPolicy: { version: "1", algorithm: "MULBERRY32" },
  reviewStatus: "HUMAN_REVIEW_REQUIRED",
  generate,
});
export const practiceFamilies: PracticeFamily[] = [
  baseFamily("practice-induction-sum", ["ALG.MATHEMATICAL_INDUCTION"], (r) => {
    const n = integer(r, 2, 40),
      answer = (n * (n + 1)) / 2;
    return finalize({
      id: "",
      familyId: "",
      seed: 0,
      prompt: `For P(n): 1+…+n=n(n+1)/2, evaluate both sides at n=${n}. Does agreement prove the universal statement?`,
      parameters: { n },
      answer: `${answer}; no`,
      solutionSteps: [
        {
          expression: `${n}(${n}+1)/2=${answer}`,
          ruleId: "FINITE_SUM",
          explanation: "Evaluate the closed form.",
        },
        {
          expression: "agreement is finite evidence, not proof",
          ruleId: "INDUCTION_LOGIC",
          explanation: "A base and implication are still required.",
        },
      ],
      hints: [],
      questionType: "SHORT_ANSWER",
    });
  }),
  baseFamily(
    "practice-induction-diagnosis",
    ["ALG.MATHEMATICAL_INDUCTION"],
    (r) => {
      const k = integer(r, 2, 20);
      return finalize({
        id: "",
        familyId: "",
        seed: 0,
        prompt: `A proof says “assume P(${k + 1}) and hence P(${k + 1})”. Identify the error.`,
        parameters: { k },
        answer: "circular reasoning; the hypothesis must be P(k)",
        solutionSteps: [
          {
            expression: "P(k) ⇒ P(k+1)",
            ruleId: "INDUCTIVE_IMPLICATION",
            explanation: "The next case must be derived from the current case.",
          },
        ],
        hints: [],
        questionType: "ERROR_IDENTIFICATION",
      });
    },
  ),
  baseFamily("practice-vieta-quadratic", ["ALG.THEORY_OF_EQUATIONS"], (r) => {
    let p = integer(r, -9, 9),
      q = integer(r, -9, 9);
    if (!p) p = 2;
    if (!q) q = -3;
    const b = -(p + q),
      c = p * q;
    return finalize({
      id: "",
      familyId: "",
      seed: 0,
      prompt: `Construct the monic quadratic with roots ${p} and ${q}.`,
      parameters: { p, q },
      answer: `x^2${b >= 0 ? "+" : ""}${b}*x${c >= 0 ? "+" : ""}${c}`,
      solutionSteps: [
        {
          expression: `(x-${p})(x-${q})`,
          ruleId: "FACTOR_FROM_ROOTS",
          explanation: "Each root supplies one linear factor.",
        },
        {
          expression: `x^2${b >= 0 ? "+" : ""}${b}x${c >= 0 ? "+" : ""}${c}`,
          ruleId: "EXPAND",
          explanation: "Expand and verify both roots.",
        },
      ],
      hints: [],
      questionType: "EXACT_EXPRESSION",
    });
  }),
  baseFamily("practice-de-moivre", ["ALG.COMPLEX.DE_MOIVRE"], (r) => {
    const quadrant = integer(r, 0, 3),
      power = integer(r, 2, 8),
      final = (((quadrant * power) % 4) + 4) % 4;
    const values = [
      [1, 0],
      [0, 1],
      [-1, 0],
      [0, -1],
    ][final];
    return finalize({
      id: "",
      familyId: "",
      seed: 0,
      prompt: `Using De Moivre, compute (cos(${quadrant}π/2)+i sin(${quadrant}π/2))^${power}.`,
      parameters: { quadrant, power },
      answer: `${values[0]}${values[1] >= 0 ? "+" : ""}${values[1]}i`,
      solutionSteps: [
        {
          expression: `cos(${quadrant * power}π/2)+i sin(${quadrant * power}π/2)`,
          ruleId: "DE_MOIVRE",
          explanation: "Multiply the argument by the integer power.",
        },
      ],
      hints: [],
      questionType: "EXACT_EXPRESSION",
    });
  }),
  baseFamily(
    "practice-pair-lines-angle",
    ["GEO.PAIR_OF_STRAIGHT_LINES"],
    (r) => {
      const m1 = integer(r, -5, 5);
      let m2 = integer(r, -5, 5);
      if (m1 === m2) m2 += 1;
      const tan = Math.abs((m2 - m1) / (1 + m1 * m2));
      return finalize({
        id: "",
        familyId: "",
        seed: 0,
        prompt: `Find tan of the acute angle between y=${m1}x and y=${m2}x.`,
        parameters: { m1, m2 },
        answer: Number.isFinite(tan)
          ? String(tan)
          : "undefined (perpendicular)",
        solutionSteps: [
          {
            expression: "|m₂-m₁|/|1+m₁m₂|",
            ruleId: "ANGLE_BETWEEN_LINES",
            explanation:
              "Apply the slope-angle identity and handle a zero denominator.",
          },
        ],
        hints: [],
        questionType: "EXACT_EXPRESSION",
      });
    },
  ),
];
export function equivalentExpressions(
  actual: string,
  expected: string,
  tolerance = 1e-9,
) {
  const normalize = (value: string) =>
    value.replace(/\s+/g, "").replace(/−/g, "-");
  if (normalize(actual) === normalize(expected))
    return { equivalent: true, method: "NORMALIZED_EXACT" };
  try {
    const left = compileFunctionExpression(actual),
      right = compileFunctionExpression(expected);
    for (const x of [-3.25, -2, -0.5, 0.25, 1.5, 4]) {
      const a = left(x),
        b = right(x);
      if (
        !Number.isFinite(a) ||
        !Number.isFinite(b) ||
        Math.abs(a - b) > tolerance * Math.max(1, Math.abs(b))
      )
        return {
          equivalent: false,
          method: "DECLARED_NUMERIC_IDENTITY_SAMPLES",
        };
    }
    return { equivalent: true, method: "DECLARED_NUMERIC_IDENTITY_SAMPLES" };
  } catch {
    return { equivalent: false, method: "UNSUPPORTED_MANUAL_REVIEW" };
  }
}
export function validateFamilySeeds(family: PracticeFamily, count = 1000) {
  const issues: string[] = [];
  const signatures = new Set<string>();
  for (let seed = 1; seed <= count; seed++) {
    try {
      const q = generateQuestion(family, seed);
      if (!q.validation.valid) issues.push(`${seed}: invalid`);
      if (q.choices && new Set(q.choices).size !== q.choices.length)
        issues.push(`${seed}: duplicate choice`);
      signatures.add(
        JSON.stringify({ parameters: q.parameters, answer: q.answer }),
      );
      if (JSON.stringify(q) !== JSON.stringify(generateQuestion(family, seed)))
        issues.push(`${seed}: not reproducible`);
    } catch (error) {
      issues.push(
        `${seed}: ${error instanceof Error ? error.message : "generation error"}`,
      );
    }
  }
  return {
    familyId: family.id,
    seeds: count,
    distinctSignatures: signatures.size,
    issues,
  };
}
