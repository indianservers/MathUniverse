import { MathDependencyGraph } from "../math-foundation/dependencyGraph";
import type { LessonBlock, MathLesson } from "./types";

const block = (
  id: string,
  kind: LessonBlock["kind"],
  title: string,
  body: string,
  nodeIds: string[] = [],
): LessonBlock => ({
  id,
  kind,
  title,
  body,
  mathematicalNodeIds: nodeIds,
  capabilityIds: nodeIds.length ? ["reactive-dag"] : [],
  accessibilityDescription: `${title}. ${body}`,
  provenanceId: "phase3-authored-2026-08-20",
  reviewStatus: "DRAFT",
});
export function createInductionLessonBundle() {
  const graph = new MathDependencyGraph();
  graph.beginTransaction();
  graph.define("n=5", "induction-n");
  graph.define("lhs=n*(n+1)/2", "induction-lhs");
  graph.define("rhs=1+2+3+4+5", "induction-rhs");
  graph.commitTransaction();
  const lesson: MathLesson = {
    id: "lesson-induction-sum-first-n",
    version: "0.1.0",
    title: "Induction for the sum of the first n natural numbers",
    canonicalConceptIds: ["ALG.MATHEMATICAL_INDUCTION"],
    prerequisites: ["ALG.FUNCTIONS.DOMAIN_RANGE"],
    intendedLevels: ["AP IA candidate", "Telangana IA candidate"],
    curriculumMappings: [],
    objectives: [
      "Separate the base case, hypothesis and implication.",
      "Prove the inductive step without assuming the target statement.",
      "Diagnose a circular or incomplete induction argument.",
    ],
    priorKnowledgeCheck: [
      block(
        "induction-prior",
        "QUESTION",
        "Prior knowledge",
        "Evaluate a finite arithmetic sum and identify an indexed proposition.",
        ["induction-n", "induction-rhs"],
      ),
    ],
    explanation: [
      block(
        "induction-explanation",
        "EXPLANATION",
        "Why induction works",
        "A verified base case enters a chain of implications. The inductive step must establish P(k) implies P(k+1) for every admissible k; keywords alone do not establish that implication.",
      ),
    ],
    definitions: [
      block(
        "induction-definition",
        "DEFINITION",
        "Principle of induction",
        "If P(n₀) is true and P(k) implies P(k+1) for every k at least n₀, then P(n) is true for every integer n at least n₀.",
      ),
    ],
    notation: [
      block(
        "induction-notation",
        "FORMULA",
        "Proposition",
        "P(n): 1+2+…+n = n(n+1)/2.",
        ["induction-lhs"],
      ),
    ],
    conditionsAndRestrictions: [
      block(
        "induction-domain",
        "EXPLANATION",
        "Domain restriction",
        "The index n is an integer with n ≥ 1; a numerical check for finitely many n is evidence, not the proof.",
      ),
    ],
    workedExamples: [
      block(
        "induction-example-1",
        "WORKED_EXAMPLE",
        "Sum identity",
        "Base: P(1). Assume P(k). Then the sum through k+1 is k(k+1)/2+(k+1)=(k+1)(k+2)/2.",
      ),
      block(
        "induction-example-2",
        "WORKED_EXAMPLE",
        "Divisibility pattern",
        "To prove divisibility, expose the inductive expression as an old divisible term plus a new divisible term; state the integer domain explicitly.",
      ),
    ],
    nonExamples: [
      block(
        "induction-nonexample",
        "COUNTEREXAMPLE",
        "Checking examples is not induction",
        "Verifying n=1,2,3 does not prove a claim for all positive integers.",
      ),
    ],
    misconceptions: [
      block(
        "induction-misconception",
        "MISCONCEPTION",
        "Circular step",
        "Writing ‘assume P(k+1)’ is not an inductive hypothesis and makes the argument circular.",
      ),
    ],
    interactiveActivities: [
      block(
        "induction-live",
        "SLIDER_EXPERIMENT",
        "Finite evidence explorer",
        "Change n in the shared dependency graph and compare the closed form with a finite sum. The activity explicitly labels agreement as evidence rather than proof.",
        ["induction-n", "induction-lhs", "induction-rhs"],
      ),
    ],
    guidedPractice: [
      {
        familyId: "practice-induction-sum",
        difficulty: "CORE",
        minimumItems: 3,
      },
    ],
    independentPractice: [
      {
        familyId: "practice-induction-diagnosis",
        difficulty: "ADVANCED",
        minimumItems: 3,
      },
    ],
    assessmentReferences: ["assessment-induction-formative"],
    applications: [
      block(
        "induction-application",
        "APPLICATION",
        "Recursive algorithms",
        "Induction verifies that a recursively repeated step preserves an invariant for every iteration.",
      ),
    ],
    summary: [
      block(
        "induction-summary",
        "SUMMARY",
        "Summary",
        "Prove the base, state the hypothesis precisely, derive the next case, and conclude on the declared integer domain.",
      ),
    ],
    glossary: [
      {
        term: "base case",
        definition: "The first verified proposition in the induction chain.",
      },
      {
        term: "inductive hypothesis",
        definition: "The temporary assumption P(k) used only to derive P(k+1).",
      },
    ],
    remediation: [
      {
        conceptId: "ALG.FUNCTIONS.DOMAIN_RANGE",
        lessonId: "lesson-indexed-propositions",
        reason: "Review domains and indexed statements before proof structure.",
      },
    ],
    enrichment: [
      {
        lessonId: "lesson-strong-induction",
        reason: "Compare weak and strong induction.",
      },
    ],
    accessibility: {
      keyboard: true,
      screenReader: true,
      visibleFocus: true,
      reducedMotion: true,
      highContrast: true,
      nonVisualAlternatives: [
        "Exact value table",
        "Ordered proof-step text",
        "Live status message",
      ],
    },
    translations: [
      {
        locale: "en-IN",
        version: "0.1.0",
        reviewerState: "HUMAN_REVIEW_REQUIRED",
        terminologyAliases: {},
      },
      {
        locale: "te-IN",
        version: "0.0.1",
        reviewerState: "MACHINE_DRAFT",
        terminologyAliases: { induction: "గణిత ఆగమనం" },
      },
    ],
    workflowStatus: "DRAFT",
    provenance: {
      origin: "AUTHORED",
      sourceIds: [],
      createdAt: "2026-08-20T00:00:00+05:30",
      updatedAt: "2026-08-20T00:00:00+05:30",
      copyrightPolicyVersion: "phase3-original-content-1",
    },
    review: {
      comments: [],
      approvals: [],
      requestedChanges: [
        "Obtain mathematics SME and active board-teacher review after official AP/Telangana source ingestion.",
      ],
    },
  };
  return { graph, lesson };
}
export function validateLesson(
  lesson: MathLesson,
  validConceptIds: Set<string>,
  validNodeIds: Set<string>,
  practiceIds: Set<string>,
  assessmentIds: Set<string>,
) {
  const issues: string[] = [];
  for (const id of lesson.canonicalConceptIds)
    if (!validConceptIds.has(id)) issues.push(`Unknown concept ${id}`);
  for (const id of lesson.prerequisites)
    if (!validConceptIds.has(id)) issues.push(`Broken prerequisite ${id}`);
  const blocks = [
    ...lesson.priorKnowledgeCheck,
    ...lesson.explanation,
    ...lesson.definitions,
    ...lesson.notation,
    ...lesson.conditionsAndRestrictions,
    ...lesson.workedExamples,
    ...lesson.nonExamples,
    ...lesson.misconceptions,
    ...lesson.interactiveActivities,
    ...lesson.applications,
    ...(lesson.historyOrContext ?? []),
    ...lesson.summary,
  ];
  for (const item of blocks) {
    if (!item.accessibilityDescription.trim())
      issues.push(`Missing accessibility description ${item.id}`);
    for (const nodeId of item.mathematicalNodeIds)
      if (!validNodeIds.has(nodeId))
        issues.push(`Invalid mathematical node ${nodeId}`);
  }
  for (const reference of [
    ...lesson.guidedPractice,
    ...lesson.independentPractice,
  ])
    if (!practiceIds.has(reference.familyId))
      issues.push(`Invalid practice family ${reference.familyId}`);
  for (const id of lesson.assessmentReferences)
    if (!assessmentIds.has(id)) issues.push(`Invalid assessment ${id}`);
  if (["APPROVED", "CERTIFIED"].includes(lesson.workflowStatus)) {
    if (lesson.workedExamples.length < 2)
      issues.push("Approved lesson needs two worked examples");
    if (
      !lesson.nonExamples.length ||
      !lesson.misconceptions.length ||
      !lesson.guidedPractice.length ||
      !lesson.independentPractice.length ||
      !lesson.assessmentReferences.length
    )
      issues.push("Approved lesson is missing a required pedagogical section");
  }
  return issues;
}
