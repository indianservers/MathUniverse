import { advancedConceptLessons } from "../modules/lessons/catalog/advanced/advancedConceptLessons";
import { lessonCatalog } from "../modules/lessons/catalog/lessonCatalog";
import { schoolLessonCatalog } from "../modules/lessons/catalog/school/schoolSyllabusCatalog";
export type MigratedLessonRecord = {
  stableId: string;
  legacyNumericId: number;
  route: string;
  title: string;
  catalog: "CORE" | "SCHOOL" | "ADVANCED";
  classification:
    | "EMPTY"
    | "SCAFFOLD"
    | "DRAFT"
    | "REVIEW_REQUIRED"
    | "APPROVED"
    | "DEPRECATED"
    | "SUPERSEDED";
  phase3Workflow: "SCAFFOLD" | "DRAFT" | "SME_REVIEW" | "APPROVED";
  reason: string;
};
export const phase3LessonMigrationInventory: MigratedLessonRecord[] = [
  ...lessonCatalog.map((lesson) => ({
    stableId: `core-${lesson.id}`,
    legacyNumericId: lesson.id,
    route: lesson.route,
    title: lesson.title,
    catalog: "CORE" as const,
    classification: "REVIEW_REQUIRED" as const,
    phase3Workflow: "DRAFT" as const,
    reason:
      "Existing interaction/content is preserved, but no Phase 3 source mapping and reviewer chain exists.",
  })),
  ...schoolLessonCatalog.map((lesson) => ({
    stableId: lesson.id,
    legacyNumericId: lesson.numericId,
    route: lesson.route,
    title: lesson.title,
    catalog: "SCHOOL" as const,
    classification: "DRAFT" as const,
    phase3Workflow: "DRAFT" as const,
    reason:
      "Structured lesson content exists, but legacy broad board tags are not official outcome evidence.",
  })),
  ...advancedConceptLessons.map((lesson) => ({
    stableId: lesson.id,
    legacyNumericId: lesson.numericId,
    route: lesson.route,
    title: lesson.title,
    catalog: "ADVANCED" as const,
    classification: "DRAFT" as const,
    phase3Workflow: "DRAFT" as const,
    reason:
      "Substantial advanced draft exists, without a Phase 3 curriculum mapping or reviewer chain.",
  })),
];
export function lessonMigrationSummary() {
  return {
    total: phase3LessonMigrationInventory.length,
    core: phase3LessonMigrationInventory.filter(
      (entry) => entry.catalog === "CORE",
    ).length,
    school: phase3LessonMigrationInventory.filter(
      (entry) => entry.catalog === "SCHOOL",
    ).length,
    advanced: phase3LessonMigrationInventory.filter(
      (entry) => entry.catalog === "ADVANCED",
    ).length,
    approved: phase3LessonMigrationInventory.filter(
      (entry) => entry.classification === "APPROVED",
    ).length,
    certified: 0,
    duplicateStableIds: duplicates(
      phase3LessonMigrationInventory.map((entry) => entry.stableId),
    ),
    duplicateRoutes: duplicates(
      phase3LessonMigrationInventory.map((entry) => entry.route),
    ),
  };
}
function duplicates(values: string[]) {
  const seen = new Set<string>();
  const result = new Set<string>();
  values.forEach((value) =>
    seen.has(value) ? result.add(value) : seen.add(value),
  );
  return [...result];
}
