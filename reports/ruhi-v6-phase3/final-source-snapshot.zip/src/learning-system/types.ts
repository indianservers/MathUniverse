import type { Phase2ObjectType } from "../math-foundation/phase2Objects";

export type BoardId = "NCERT" | "CBSE" | "AP_BIE" | "TELANGANA_BIE";
export type PaperId = "IA" | "IB" | "IIA" | "IIB";
export type ReviewStatus =
  "INGESTED" | "PARSED" | "HUMAN_REVIEW_REQUIRED" | "VERIFIED" | "REJECTED";
export type CurriculumSourceRecord = {
  id: string;
  authority: string;
  board: BoardId;
  title: string;
  academicYear: string;
  subject?: string;
  course?: string;
  paper?: PaperId;
  medium?: string;
  officialUrl: string;
  documentType:
    | "CURRICULUM"
    | "SYLLABUS"
    | "TEXTBOOK"
    | "MODEL_PAPER"
    | "ASSESSMENT_BLUEPRINT"
    | "CIRCULAR";
  checksum: string;
  retrievedAt: string;
  effectiveFrom?: string;
  effectiveTo?: string;
  supersedes?: string;
  pageCount?: number;
  ingestionVersion: string;
  reviewStatus: ReviewStatus;
};
export type SourceSection = {
  id: string;
  sourceId: string;
  parentId?: string;
  kind:
    | "UNIT"
    | "CHAPTER"
    | "OUTCOME"
    | "ACTIVITY"
    | "PROJECT"
    | "ASSESSMENT_PATTERN";
  title: string;
  order: number;
  pageOrSection: string;
  text: string;
  confidence: number;
  reviewStatus: ReviewStatus;
};
export type SourceAuditEvent = {
  id: string;
  sourceId: string;
  at: string;
  actorType: "PARSER" | "REVIEWER";
  actorId?: string;
  action: string;
  before?: unknown;
  after?: unknown;
  note?: string;
};

export type CanonicalConcept = {
  id: string;
  name: string;
  description: string;
  prerequisites: string[];
  relatedConcepts: string[];
  mathematicalObjectTypes: Phase2ObjectType[];
  requiredCapabilities: string[];
  commonNotation: string[];
  alternativeTerminology: Record<string, string[]>;
  difficultyRange: [number, number];
  applicableGradesOrCourses: string[];
  misconceptions: string[];
  lessonIds: string[];
  practiceFamilyIds: string[];
  assessmentBlueprintIds: string[];
  officialCurriculumMappingIds: string[];
};
export type CoverageDimension =
  | "catalogued"
  | "explained"
  | "visualized"
  | "computational"
  | "practised"
  | "assessed"
  | "textbookMapped"
  | "boardCertified";
export type DimensionState =
  "NOT_STARTED" | "DRAFT" | "REVIEW_REQUIRED" | "VERIFIED" | "NOT_APPLICABLE";
export type CoursePathway = {
  id: string;
  board: BoardId;
  officialTitle: string;
  academicYear: string;
  course: string;
  paper?: PaperId;
  medium: string;
  sourceIds: string[];
  units: CourseUnit[];
  reviewStatus: "UNMAPPED" | "DRAFT" | "HUMAN_REVIEW_REQUIRED" | "VERIFIED";
  certificationState: "NOT_ELIGIBLE" | "PENDING" | "CERTIFIED" | "EXPIRED";
  knownGaps: string[];
};
export type CourseUnit = {
  id: string;
  title: string;
  order: number;
  pageOrSection: string;
  chapters: CourseChapter[];
};
export type CourseChapter = {
  id: string;
  title: string;
  order: number;
  outcomeIds: string[];
  canonicalConceptIds: string[];
  lessonIds: string[];
  practiceFamilyIds: string[];
  assessmentBlueprintIds: string[];
  projectIds: string[];
  marks?: number;
  questionTypes?: QuestionType[];
  reviewStatus: "DRAFT" | "HUMAN_REVIEW_REQUIRED" | "VERIFIED";
};

export type LessonBlockKind =
  | "LEARNING_OBJECTIVE"
  | "DEFINITION"
  | "THEOREM"
  | "FORMULA"
  | "EXPLANATION"
  | "WORKED_EXAMPLE"
  | "STEP_DERIVATION"
  | "PROOF"
  | "DIAGRAM"
  | "GRAPH_2D"
  | "DYNAMIC_GEOMETRY"
  | "TABLE"
  | "CAS_RESULT"
  | "SLIDER_EXPERIMENT"
  | "DATA_ACTIVITY"
  | "SIMULATION"
  | "QUESTION"
  | "HINT"
  | "MISCONCEPTION"
  | "COUNTEREXAMPLE"
  | "APPLICATION"
  | "HISTORICAL_CONTEXT"
  | "SUMMARY"
  | "REFLECTION"
  | "PROJECT"
  | "RUBRIC";
export type LessonBlock = {
  id: string;
  kind: LessonBlockKind;
  title: string;
  body: string;
  mathematicalNodeIds: string[];
  capabilityIds: string[];
  accessibilityDescription: string;
  provenanceId: string;
  reviewStatus: "SCAFFOLD" | "DRAFT" | "REVIEW_REQUIRED" | "APPROVED";
};
export type AccessibilityMetadata = {
  keyboard: boolean;
  screenReader: boolean;
  visibleFocus: boolean;
  reducedMotion: boolean;
  highContrast: boolean;
  nonVisualAlternatives: string[];
};
export type MathLesson = {
  id: string;
  version: string;
  title: string;
  canonicalConceptIds: string[];
  prerequisites: string[];
  intendedLevels: string[];
  curriculumMappings: string[];
  objectives: string[];
  priorKnowledgeCheck: LessonBlock[];
  explanation: LessonBlock[];
  definitions: LessonBlock[];
  notation: LessonBlock[];
  conditionsAndRestrictions: LessonBlock[];
  workedExamples: LessonBlock[];
  nonExamples: LessonBlock[];
  misconceptions: LessonBlock[];
  interactiveActivities: LessonBlock[];
  guidedPractice: PracticeReference[];
  independentPractice: PracticeReference[];
  assessmentReferences: string[];
  applications: LessonBlock[];
  historyOrContext?: LessonBlock[];
  summary: LessonBlock[];
  glossary: Array<{ term: string; definition: string }>;
  remediation: Array<{ conceptId: string; lessonId: string; reason: string }>;
  enrichment: Array<{ lessonId: string; reason: string }>;
  accessibility: AccessibilityMetadata;
  translations: TranslationReference[];
  workflowStatus:
    | "SCAFFOLD"
    | "DRAFT"
    | "SME_REVIEW"
    | "TEACHER_REVIEW"
    | "ASSESSMENT_REVIEW"
    | "ACCESSIBILITY_REVIEW"
    | "QA_REVIEW"
    | "APPROVED"
    | "CERTIFIED"
    | "RETIRED";
  provenance: ContentProvenance;
  review: ReviewMetadata;
};
export type PracticeReference = {
  familyId: string;
  difficulty: "FOUNDATION" | "CORE" | "ADVANCED";
  minimumItems: number;
};
export type TranslationReference = {
  locale: string;
  version: string;
  reviewerState: "MACHINE_DRAFT" | "HUMAN_REVIEW_REQUIRED" | "APPROVED";
  terminologyAliases: Record<string, string>;
};
export type ContentProvenance = {
  origin: "AUTHORED" | "AI_DRAFT" | "MIGRATED";
  authorId?: string;
  sourceIds: string[];
  createdAt: string;
  updatedAt: string;
  copyrightPolicyVersion: string;
};
export type ReviewMetadata = {
  comments: ReviewComment[];
  approvals: ReviewApproval[];
  requestedChanges: string[];
  lastReviewedAt?: string;
};
export type ReviewRole =
  | "CONTENT_AUTHOR"
  | "MATH_SME"
  | "BOARD_TEACHER"
  | "ASSESSMENT_REVIEWER"
  | "ACCESSIBILITY_REVIEWER"
  | "QA_REVIEWER"
  | "PUBLISHER_ADMIN"
  | "INDEPENDENT_FINAL_REVIEWER";
export type ReviewComment = {
  id: string;
  reviewerId: string;
  role: ReviewRole;
  at: string;
  body: string;
  resolution: "OPEN" | "RESOLVED";
};
export type ReviewApproval = {
  id: string;
  reviewerId: string;
  role: ReviewRole;
  at: string;
  decision: "APPROVE" | "REJECT" | "REQUEST_CHANGES";
  sourceVersion: string;
  expiresAt?: string;
  note?: string;
};

export type DifficultyLevel = "FOUNDATION" | "CORE" | "ADVANCED" | "CHALLENGE";
export type QuestionType =
  | "NUMERIC"
  | "EXACT_EXPRESSION"
  | "MULTIPLE_CHOICE"
  | "MULTIPLE_SELECT"
  | "TRUE_FALSE"
  | "ASSERTION_REASON"
  | "FILL_BLANK"
  | "MATCH"
  | "STEP_ORDERING"
  | "PROOF_COMPLETION"
  | "CONSTRUCTION"
  | "GRAPH_INTERPRETATION"
  | "GRAPH_CREATION"
  | "ERROR_IDENTIFICATION"
  | "CASE_STUDY"
  | "MODELLING"
  | "SHORT_ANSWER"
  | "LONG_ANSWER";
export type PracticeFamily = {
  id: string;
  conceptIds: string[];
  difficulty: DifficultyLevel;
  parameters: ParameterDefinition[];
  constraints: GenerationConstraint[];
  promptTemplate: string;
  answerModel: AnswerModel;
  solutionStrategy: SolutionStrategy;
  hintStages: HintStage[];
  misconceptionTags: string[];
  validationRules: ValidationRule[];
  supportedQuestionTypes: QuestionType[];
  seedPolicy: { version: string; algorithm: "MULBERRY32" };
  reviewStatus: "DRAFT" | "HUMAN_REVIEW_REQUIRED" | "APPROVED";
  generate: (random: () => number) => GeneratedQuestion;
};
export type ParameterDefinition = {
  id: string;
  kind: "INTEGER" | "RATIONAL" | "CHOICE";
  min?: number;
  max?: number;
  choices?: Array<string | number>;
};
export type GenerationConstraint = { id: string; description: string };
export type AnswerModel = {
  kind: "EXACT" | "NUMERIC" | "SET" | "MATRIX" | "INTERVAL" | "RUBRIC";
  tolerance?: number;
  domain?: string;
  units?: string;
};
export type SolutionStrategy = {
  id: string;
  ruleIds: string[];
  description: string;
};
export type HintStage = {
  level: 1 | 2 | 3 | 4 | 5 | 6;
  kind:
    "CONCEPT" | "STRATEGY" | "FORMULA" | "FIRST_STEP" | "SCAFFOLD" | "SOLUTION";
  template: string;
};
export type ValidationRule = { id: string; description: string };
export type GeneratedQuestion = {
  id: string;
  familyId: string;
  seed: number;
  prompt: string;
  parameters: Record<string, number | string>;
  answer: string;
  choices?: string[];
  solutionSteps: Array<{
    expression: string;
    ruleId: string;
    explanation: string;
  }>;
  hints: HintStage[];
  questionType: QuestionType;
  validation: {
    valid: boolean;
    issues: string[];
    independentlyVerified: boolean;
  };
};

export type AssessmentBlueprint = {
  id: string;
  board: BoardId;
  academicYear: string;
  course: string;
  paper?: PaperId;
  unitOrChapter: string;
  conceptIds: string[];
  questionTypes: QuestionType[];
  marks: number;
  difficultyDistribution: Record<DifficultyLevel, number>;
  cognitiveLevels: string[];
  expectedMethod: string[];
  timeMinutes: number;
  internalChoiceRules: string[];
  sourceEvidence: Array<{ sourceId: string; pageOrSection: string }>;
  reviewStatus: "DRAFT" | "HUMAN_REVIEW_REQUIRED" | "VERIFIED";
};
export type MasteryEvidence = {
  id: string;
  conceptId: string;
  attemptedAt: string;
  correct: boolean;
  score: number;
  hintsUsed: number;
  timeSeconds: number;
  difficulty: DifficultyLevel;
  misconceptionTags: string[];
  retentionCheck: boolean;
  assessmentType: string;
  completion: "INDEPENDENT" | "ASSISTED";
  seed?: number;
};
export type MasteryState =
  | "NOT_STARTED"
  | "EMERGING"
  | "DEVELOPING"
  | "PROFICIENT"
  | "SECURE"
  | "REVIEW_DUE";
export type MasterySummary = {
  conceptId: string;
  state: MasteryState;
  confidence: number;
  evidenceCount: number;
  independentSuccesses: number;
  assistedSuccesses: number;
  lastPractisedAt?: string;
  nextReviewAt?: string;
  misconceptions: Array<{ tag: string; count: number }>;
};

export type CertificationResult = {
  courseId: string;
  passed: boolean;
  blockingIssues: Array<{
    code: string;
    message: string;
    dimension?: CoverageDimension;
  }>;
  warnings: string[];
  coverage: Record<CoverageDimension, DimensionState>;
  missingOutcomes: string[];
  missingEvidence: string[];
  missingReviewers: ReviewRole[];
  expiredSources: string[];
  unsupportedCapabilities: string[];
  certificationDate?: string;
  expiryDate?: string;
};
