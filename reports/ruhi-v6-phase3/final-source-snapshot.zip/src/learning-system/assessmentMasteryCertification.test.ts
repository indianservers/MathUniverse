import { describe, expect, it } from "vitest";
import {
  assessmentBlueprints,
  evaluateAnswer,
  validateBlueprint,
} from "./assessmentEngine";
import { coursePathways } from "./courseStructures";
import { createInductionLessonBundle } from "./lessonSchema";
import { computeMastery, remediationRecommendation } from "./masteryEngine";
import { officialCurriculumSources } from "./officialSources";
import { certifyCourse, transitionLesson } from "./reviewCertification";
import type { MasteryEvidence, ReviewApproval } from "./types";
describe("assessment, mastery, review and certification", () => {
  it("evaluates exact, numeric, sets, matrices and unsafe manual review", () => {
    expect(
      evaluateAnswer("(x+1)^2", "x^2+2*x+1", { kind: "EXACT" }).status,
    ).toBe("CORRECT");
    expect(
      evaluateAnswer("3.1416", "3.14159", { kind: "NUMERIC", tolerance: 1e-4 })
        .status,
    ).toBe("CORRECT");
    expect(evaluateAnswer("{2,1}", "{1,2}", { kind: "SET" }).status).toBe(
      "CORRECT",
    );
    expect(
      evaluateAnswer("[1,2;3,4]", "[1,2;3,4]", { kind: "MATRIX" }).status,
    ).toBe("CORRECT");
    expect(evaluateAnswer("a proof", "rubric", { kind: "RUBRIC" }).status).toBe(
      "MANUAL_REVIEW",
    );
    expect(validateBlueprint(assessmentBlueprints[0])).toEqual([]);
  });
  it("bases mastery on evidence and discounts hints", () => {
    const evidence: MasteryEvidence[] = [
      attempt("a", true, 0, "INDEPENDENT", 0.95),
      attempt("b", true, 0, "INDEPENDENT", 0.9),
      attempt("c", true, 4, "ASSISTED", 0.9),
    ];
    const summary = computeMastery(
      "ALG.MATHEMATICAL_INDUCTION",
      evidence,
      new Date("2026-08-21"),
    );
    expect(summary.evidenceCount).toBe(3);
    expect(summary.independentSuccesses).toBe(2);
    expect(summary.confidence).toBeLessThan(0.95);
    expect(summary.state).not.toBe("NOT_STARTED");
    expect(
      remediationRecommendation(summary, ["ALG.FUNCTIONS.DOMAIN_RANGE"]).steps
        .length,
    ).toBeGreaterThan(2);
  });
  it("blocks approval without real role approvals and blocks certification on missing evidence", () => {
    const { lesson } = createInductionLessonBundle();
    expect(() =>
      transitionLesson({ ...lesson, workflowStatus: "QA_REVIEW" }, "APPROVED"),
    ).toThrow(/MATH_SME/);
    const approvals: ReviewApproval[] = [
      approval("s", "MATH_SME"),
      approval("t", "BOARD_TEACHER"),
      approval("q", "QA_REVIEWER"),
    ];
    expect(
      transitionLesson(
        {
          ...lesson,
          workflowStatus: "QA_REVIEW",
          review: { ...lesson.review, approvals },
        },
        "APPROVED",
      ).workflowStatus,
    ).toBe("APPROVED");
    const result = certifyCourse(
      coursePathways.find((entry) => entry.id === "CBSE_IX_MATHEMATICS")!,
      officialCurriculumSources,
      [],
      new Set(["reactive-dag"]),
      new Date("2026-08-20"),
    );
    expect(result.passed).toBe(false);
    expect(result.blockingIssues.map((entry) => entry.code)).toContain(
      "SOURCE_NOT_VERIFIED",
    );
  });
  it("supports a fully evidenced technical success path and rejects expired sources", () => {
    const approvals = [
      approval("s", "MATH_SME"),
      approval("t", "BOARD_TEACHER"),
      approval("q", "QA_REVIEWER"),
    ];
    const final = approval("f", "INDEPENDENT_FINAL_REVIEWER");
    const { lesson } = createInductionLessonBundle();
    const approved = {
      ...lesson,
      workflowStatus: "APPROVED" as const,
      curriculumMappings: ["TECH_COURSE:outcome-1"],
      review: { ...lesson.review, approvals },
    };
    const source = {
      ...officialCurriculumSources[0],
      id: "TECH_SOURCE",
      reviewStatus: "VERIFIED" as const,
    };
    const course = {
      ...coursePathways[0],
      id: "TECH_COURSE",
      sourceIds: [source.id],
      reviewStatus: "VERIFIED" as const,
      knownGaps: [],
      units: [
        {
          id: "u",
          title: "Unit",
          order: 1,
          pageOrSection: "p.1",
          chapters: [
            {
              id: "c",
              title: "Chapter",
              order: 1,
              outcomeIds: ["outcome-1"],
              canonicalConceptIds: ["ALG.MATHEMATICAL_INDUCTION"],
              lessonIds: [lesson.id],
              practiceFamilyIds: ["practice-induction-sum"],
              assessmentBlueprintIds: ["assessment-induction-formative"],
              projectIds: ["project-1"],
              reviewStatus: "VERIFIED" as const,
            },
          ],
        },
      ],
    };
    const release = {
      modelPaperDryRunPassed: true,
      automatedValidationPassed: true,
      finalReviewApprovals: [final],
    };
    expect(
      certifyCourse(
        course,
        [source],
        [approved],
        new Set(["reactive-dag"]),
        new Date("2026-08-20"),
        release,
      ).passed,
    ).toBe(true);
    const expired = { ...source, effectiveTo: "2026-01-01" };
    const result = certifyCourse(
      course,
      [expired],
      [approved],
      new Set(["reactive-dag"]),
      new Date("2026-08-20"),
      release,
    );
    expect(result.passed).toBe(false);
    expect(result.expiredSources).toEqual([source.id]);
  });
});
function attempt(
  id: string,
  correct: boolean,
  hintsUsed: number,
  completion: "INDEPENDENT" | "ASSISTED",
  score: number,
): MasteryEvidence {
  return {
    id,
    conceptId: "ALG.MATHEMATICAL_INDUCTION",
    attemptedAt: "2026-08-20T00:00:00Z",
    correct,
    score,
    hintsUsed,
    timeSeconds: 60,
    difficulty: "CORE",
    misconceptionTags: [],
    retentionCheck: false,
    assessmentType: "FORMATIVE",
    completion,
  };
}
function approval(id: string, role: ReviewApproval["role"]): ReviewApproval {
  return {
    id,
    reviewerId: `real-${id}`,
    role,
    at: "2026-08-20T00:00:00Z",
    decision: "APPROVE",
    sourceVersion: "1",
  };
}
