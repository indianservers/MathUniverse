import { equivalentExpressions } from "./practiceEngine";
import type {
  AnswerModel,
  AssessmentBlueprint,
  GeneratedQuestion,
} from "./types";

export const assessmentBlueprints: AssessmentBlueprint[] = [
  {
    id: "assessment-induction-formative",
    board: "AP_BIE",
    academicYear: "2026-27",
    course: "First Year Mathematics IA candidate",
    paper: "IA",
    unitOrChapter: "Mathematical Induction (source mapping pending)",
    conceptIds: ["ALG.MATHEMATICAL_INDUCTION"],
    questionTypes: [
      "PROOF_COMPLETION",
      "STEP_ORDERING",
      "ERROR_IDENTIFICATION",
    ],
    marks: 10,
    difficultyDistribution: {
      FOUNDATION: 20,
      CORE: 60,
      ADVANCED: 20,
      CHALLENGE: 0,
    },
    cognitiveLevels: ["understand", "apply", "reason"],
    expectedMethod: [
      "base case",
      "inductive hypothesis",
      "valid implication",
      "conclusion with domain",
    ],
    timeMinutes: 20,
    internalChoiceRules: [],
    sourceEvidence: [],
    reviewStatus: "DRAFT",
  },
];
export type EvaluationResult = {
  status: "CORRECT" | "INCORRECT" | "PARTIAL" | "MANUAL_REVIEW";
  score: number;
  feedback: string[];
  method: string;
  conditionsChecked: string[];
};
export function evaluateAnswer(
  actual: string,
  expected: string,
  model: AnswerModel,
): EvaluationResult {
  if (model.kind === "EXACT") {
    const result = equivalentExpressions(
      actual,
      expected,
      model.tolerance ?? 1e-9,
    );
    return result.equivalent
      ? {
          status: "CORRECT",
          score: 1,
          feedback: ["Equivalent mathematical form accepted."],
          method: result.method,
          conditionsChecked: model.domain ? [model.domain] : [],
        }
      : {
          status:
            result.method === "UNSUPPORTED_MANUAL_REVIEW"
              ? "MANUAL_REVIEW"
              : "INCORRECT",
          score: 0,
          feedback: [
            result.method === "UNSUPPORTED_MANUAL_REVIEW"
              ? "Automatic equivalence is unsafe; send for review."
              : "The expression is not equivalent on the declared verification samples.",
          ],
          method: result.method,
          conditionsChecked: [],
        };
  }
  if (model.kind === "NUMERIC") {
    const a = Number(actual),
      e = Number(expected),
      tol = model.tolerance ?? 1e-9;
    if (!Number.isFinite(a) || !Number.isFinite(e))
      return {
        status: "INCORRECT",
        score: 0,
        feedback: ["A finite numeric answer is required."],
        method: "NUMERIC_PARSE",
        conditionsChecked: [],
      };
    const okay = Math.abs(a - e) <= tol * Math.max(1, Math.abs(e));
    return {
      status: okay ? "CORRECT" : "INCORRECT",
      score: okay ? 1 : 0,
      feedback: [
        okay ? "Within the declared tolerance." : `Outside tolerance ${tol}.`,
      ],
      method: "RELATIVE_ABSOLUTE_TOLERANCE",
      conditionsChecked: model.units ? [`units:${model.units}`] : [],
    };
  }
  if (model.kind === "SET") {
    const set = (value: string) =>
      new Set(
        value
          .replace(/[{}]/g, "")
          .split(",")
          .map((entry) => entry.trim())
          .filter(Boolean),
      );
    const a = set(actual),
      e = set(expected),
      okay = a.size === e.size && [...a].every((entry) => e.has(entry));
    return {
      status: okay ? "CORRECT" : "INCORRECT",
      score: okay ? 1 : 0,
      feedback: [okay ? "Unordered set matches." : "Set elements differ."],
      method: "UNORDERED_SET",
      conditionsChecked: [],
    };
  }
  if (model.kind === "MATRIX") {
    const parse = (value: string) =>
      value
        .replaceAll("[", "")
        .replaceAll("]", "")
        .split(";")
        .map((row) => row.split(",").map(Number));
    const a = parse(actual),
      e = parse(expected),
      okay =
        a.length === e.length &&
        a.every(
          (row, i) =>
            row.length === e[i]?.length &&
            row.every(
              (entry, j) =>
                Math.abs(entry - e[i][j]) <= (model.tolerance ?? 1e-9),
            ),
        );
    return {
      status: okay ? "CORRECT" : "INCORRECT",
      score: okay ? 1 : 0,
      feedback: [
        okay ? "Matrix entries match." : "Matrix size or entries differ.",
      ],
      method: "ORDERED_MATRIX",
      conditionsChecked: [],
    };
  }
  return {
    status: "MANUAL_REVIEW",
    score: 0,
    feedback: [
      "This answer type requires a rubric, construction invariant, graph comparison, or teacher review.",
    ],
    method: "MANUAL_RUBRIC",
    conditionsChecked: [],
  };
}
export function scoreStepBased(
  question: GeneratedQuestion,
  submittedSteps: string[],
) {
  let matched = 0;
  const feedback = question.solutionSteps.map((expected, index) => {
    const actual = submittedSteps[index] ?? "";
    const result = equivalentExpressions(actual, expected.expression, 1e-7);
    if (result.equivalent) matched += 1;
    return {
      index,
      ruleId: expected.ruleId,
      matched: result.equivalent,
      method: result.method,
    };
  });
  return {
    score: question.solutionSteps.length
      ? matched / question.solutionSteps.length
      : 0,
    feedback,
    manualReview: feedback.some(
      (entry) => entry.method === "UNSUPPORTED_MANUAL_REVIEW",
    ),
  };
}
export function validateBlueprint(blueprint: AssessmentBlueprint) {
  const issues: string[] = [];
  const total = Object.values(blueprint.difficultyDistribution).reduce(
    (sum, value) => sum + value,
    0,
  );
  if (total !== 100) issues.push("Difficulty distribution must total 100");
  if (!blueprint.sourceEvidence.length && blueprint.reviewStatus === "VERIFIED")
    issues.push("Verified blueprint requires source evidence");
  if (blueprint.marks <= 0 || blueprint.timeMinutes <= 0)
    issues.push("Marks and time must be positive");
  return issues;
}
