import { describe, expect, it } from "vitest";
import {
  conicsStudio,
  deMoivre,
  differentialEquationStudio,
  hyperbolicStudio,
  integrationStudio,
  pairOfLines,
  priorityStudioRegistry,
  systemOfCircles,
  theoryOfEquations,
  transformAxes,
  verifyInduction,
} from "./priorityStudios";
describe("ten reusable priority studio kernels", () => {
  it("registers all ten requested studios", () =>
    expect(priorityStudioRegistry.map((entry) => entry.id)).toEqual([
      "mathematical-induction",
      "hyperbolic-functions",
      "transformation-of-axes",
      "pair-of-straight-lines",
      "system-of-circles",
      "complex-de-moivre",
      "theory-of-equations",
      "conics",
      "integration-methods",
      "differential-equations",
    ]));
  it("checks induction implications rather than keywords", () => {
    expect(
      verifyInduction({
        start: 1,
        end: 20,
        proposition: (n) => (n * (n + 1)) % 2 === 0,
        implication: (k) => k >= 1,
        mode: "WEAK",
      }).status,
    ).toBe("CANDIDATE");
    expect(
      verifyInduction({
        start: 1,
        end: 5,
        proposition: () => true,
        implication: (k) => k !== 3,
        mode: "WEAK",
      }).value?.counterexample,
    ).toBe(3);
  });
  it("computes hyperbolic identities, axes, lines, and circles", () => {
    expect(hyperbolicStudio(0.7).value?.identityResidual).toBeLessThan(1e-12);
    expect(
      transformAxes({
        A: 1,
        B: 2,
        C: 3,
        D: 4,
        E: 5,
        F: 6,
        translateX: 2,
        translateY: -1,
        rotateRadians: 0.4,
      }).residual,
    ).toBeLessThan(1e-9);
    expect(pairOfLines({ a: -2, h: -0.5, b: 1 }).value?.slopes.length).toBe(2);
    expect(
      systemOfCircles({ D: 0, E: 0, F: -4 }, { D: -2, E: 0, F: -3 }).value
        ?.radicalAxis.A,
    ).toBe(2);
  });
  it("computes complex powers, Vieta, conics, integrals and ODEs", () => {
    expect(
      deMoivre({ real: 0, imaginary: 1, power: 2 }).value?.real,
    ).toBeCloseTo(-1, 10);
    expect(theoryOfEquations([1, -5, 6]).value).toMatchObject({
      sumOfRoots: 5,
      productOfRoots: 6,
    });
    expect(conicsStudio([1, 0, 1, 0, 0, -1]).value?.type).toBe(
      "ELLIPSE_OR_CIRCLE",
    );
    expect(integrationStudio((x) => x * x, 0, 1).value?.value).toBeCloseTo(
      1 / 3,
      8,
    );
    expect(
      differentialEquationStudio({
        f: (_x, y) => y,
        x0: 0,
        y0: 1,
        x1: 1,
        steps: 100,
        candidate: Math.exp,
      }).value?.y,
    ).toBeCloseTo(Math.E, 7);
  });
});
