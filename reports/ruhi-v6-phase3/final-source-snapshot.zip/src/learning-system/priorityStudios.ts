import {
  applyAffine,
  rotationMatrix,
  translationMatrix,
} from "../math-foundation/geometryPhase2";
import { point } from "../workspace/geometry2dKernel";

export type StudioResult<T> = {
  status: "VERIFIED_NUMERIC" | "VERIFIED_ALGEBRAIC" | "CANDIDATE" | "INVALID";
  value?: T;
  method: string;
  residual?: number;
  diagnostics: string[];
};

export function verifyInduction(input: {
  start: number;
  end: number;
  proposition: (n: number) => boolean;
  implication: (k: number) => boolean;
  mode: "WEAK" | "STRONG";
}): StudioResult<{
  base: boolean;
  checkedImplications: number;
  counterexample?: number;
}> {
  if (!Number.isInteger(input.start) || input.end < input.start)
    return {
      status: "INVALID",
      method: "BOUNDED_LOGICAL_CHECK",
      diagnostics: ["Integer bounds with end ≥ start are required."],
    };
  const base = input.proposition(input.start);
  if (!base)
    return {
      status: "INVALID",
      value: { base, checkedImplications: 0, counterexample: input.start },
      method: "BOUNDED_LOGICAL_CHECK",
      diagnostics: ["Base case failed."],
    };
  let checked = 0;
  for (let k = input.start; k < input.end; k++) {
    if (!input.implication(k))
      return {
        status: "INVALID",
        value: { base, checkedImplications: checked, counterexample: k },
        method: "BOUNDED_LOGICAL_CHECK",
        diagnostics: [
          `The implication failed at k=${k}; finite checking diagnoses errors but is not a universal proof.`,
        ],
      };
    checked++;
  }
  return {
    status: "CANDIDATE",
    value: { base, checkedImplications: checked },
    method: "BOUNDED_LOGICAL_CHECK",
    diagnostics: [
      "Finite implication checks support debugging only; a symbolic universal justification is still required.",
    ],
  };
}
export function hyperbolicStudio(
  x: number,
): StudioResult<{
  sinh: number;
  cosh: number;
  tanh: number;
  sech: number;
  csch?: number;
  coth?: number;
  identityResidual: number;
  derivatives: Record<string, string>;
}> {
  const exp = Math.exp(x),
    inverse = Math.exp(-x),
    sinh = (exp - inverse) / 2,
    cosh = (exp + inverse) / 2,
    tanh = sinh / cosh,
    residual = Math.abs(cosh * cosh - sinh * sinh - 1);
  return {
    status: "VERIFIED_NUMERIC",
    value: {
      sinh,
      cosh,
      tanh,
      sech: 1 / cosh,
      csch: Math.abs(sinh) > 1e-14 ? 1 / sinh : undefined,
      coth: Math.abs(sinh) > 1e-14 ? cosh / sinh : undefined,
      identityResidual: residual,
      derivatives: { sinh: "cosh(x)", cosh: "sinh(x)", tanh: "sech(x)^2" },
    },
    method: "EXPONENTIAL_DEFINITIONS",
    residual,
    diagnostics:
      Math.abs(sinh) <= 1e-14 ? ["csch and coth are undefined at x=0."] : [],
  };
}
export function transformAxes(input: {
  A: number;
  B: number;
  C: number;
  D: number;
  E: number;
  F: number;
  translateX: number;
  translateY: number;
  rotateRadians: number;
}): StudioResult<{
  transformed: [number, number, number, number, number, number];
  crossTerm: number;
  linearTerms: [number, number];
  sampleVerification: number;
}> {
  const {
      A,
      B,
      C,
      D,
      E,
      F,
      translateX: h,
      translateY: k,
      rotateRadians: t,
    } = input,
    c = Math.cos(t),
    s = Math.sin(t);
  const q11 = A * c * c + B * c * s + C * s * s,
    q12 = 2 * (C - A) * s * c + B * (c * c - s * s),
    q22 = A * s * s - B * s * c + C * c * c;
  const l1 = (2 * A * h + B * k + D) * c + (B * h + 2 * C * k + E) * s,
    l2 = -(2 * A * h + B * k + D) * s + (B * h + 2 * C * k + E) * c;
  const constant = A * h * h + B * h * k + C * k * k + D * h + E * k + F;
  const sample = point(0.73, -1.12),
    original = applyAffine(
      translationMatrix(h, k),
      applyAffine(rotationMatrix(t), sample),
    ),
    before =
      A * original.x ** 2 +
      B * original.x * original.y +
      C * original.y ** 2 +
      D * original.x +
      E * original.y +
      F,
    after =
      q11 * sample.x ** 2 +
      q12 * sample.x * sample.y +
      q22 * sample.y ** 2 +
      l1 * sample.x +
      l2 * sample.y +
      constant,
    residual = Math.abs(before - after);
  return {
    status: residual < 1e-8 ? "VERIFIED_ALGEBRAIC" : "CANDIDATE",
    value: {
      transformed: [q11, q12, q22, l1, l2, constant],
      crossTerm: q12,
      linearTerms: [l1, l2],
      sampleVerification: residual,
    },
    method: "QUADRATIC_FORM_AFFINE_SUBSTITUTION",
    residual,
    diagnostics: [],
  };
}
export function pairOfLines(input: {
  a: number;
  h: number;
  b: number;
}): StudioResult<{
  slopes: [number, number];
  angleRadians: number;
  classification: string;
}> {
  const { a, h, b } = input;
  if (Math.abs(b) < 1e-12) {
    if (Math.abs(h) < 1e-12)
      return {
        status: "INVALID",
        method: "HOMOGENEOUS_QUADRATIC",
        diagnostics: ["The equation does not define two finite-slope lines."],
      };
    const slopes: [number, number] = [0, -a / (2 * h)];
    return lineResult(slopes);
  }
  const disc = h * h - a * b;
  if (disc < 0)
    return {
      status: "INVALID",
      method: "HOMOGENEOUS_QUADRATIC_DISCRIMINANT",
      diagnostics: ["h²-ab<0, so the pair is not two real lines."],
    };
  return lineResult([(-h + Math.sqrt(disc)) / b, (-h - Math.sqrt(disc)) / b]);
}
function lineResult(
  slopes: [number, number],
): StudioResult<{
  slopes: [number, number];
  angleRadians: number;
  classification: string;
}> {
  const denominator = 1 + slopes[0] * slopes[1],
    angle =
      Math.abs(denominator) < 1e-12
        ? Math.PI / 2
        : Math.atan(Math.abs((slopes[1] - slopes[0]) / denominator));
  return {
    status: "VERIFIED_ALGEBRAIC",
    value: {
      slopes,
      angleRadians: angle,
      classification:
        Math.abs(slopes[0] - slopes[1]) < 1e-10
          ? "coincident"
          : Math.abs(denominator) < 1e-10
            ? "perpendicular"
            : "intersecting",
    },
    method: "SLOPE_QUADRATIC",
    residual: 0,
    diagnostics: [],
  };
}
export function systemOfCircles(
  first: { D: number; E: number; F: number },
  second: { D: number; E: number; F: number },
): StudioResult<{
  radicalAxis: { A: number; B: number; C: number };
  centres: [[number, number], [number, number]];
  orthogonal: boolean;
}> {
  const axis = {
    A: first.D - second.D,
    B: first.E - second.E,
    C: first.F - second.F,
  };
  if (Math.hypot(axis.A, axis.B) < 1e-12)
    return {
      status: Math.abs(axis.C) < 1e-12 ? "INVALID" : "VERIFIED_ALGEBRAIC",
      method: "SUBTRACT_CIRCLE_EQUATIONS",
      diagnostics: [
        Math.abs(axis.C) < 1e-12
          ? "Coincident circles have no unique radical axis."
          : "Concentric unequal circles have no finite common-power locus.",
      ],
    };
  const c1: [number, number] = [-first.D / 2, -first.E / 2],
    c2: [number, number] = [-second.D / 2, -second.E / 2],
    r1sq = (first.D ** 2 + first.E ** 2) / 4 - first.F,
    r2sq = (second.D ** 2 + second.E ** 2) / 4 - second.F,
    d2 = (c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2;
  return {
    status: "VERIFIED_ALGEBRAIC",
    value: {
      radicalAxis: axis,
      centres: [c1, c2],
      orthogonal: Math.abs(d2 - r1sq - r2sq) < 1e-8,
    },
    method: "POWER_DIFFERENCE",
    residual: Math.abs(d2 - r1sq - r2sq),
    diagnostics: [],
  };
}
export function deMoivre(input: {
  real: number;
  imaginary: number;
  power: number;
}): StudioResult<{
  modulus: number;
  argument: number;
  real: number;
  imaginary: number;
  rootBranches?: Array<{ real: number; imaginary: number }>;
}> {
  if (!Number.isInteger(input.power))
    return {
      status: "INVALID",
      method: "POLAR_POWER",
      diagnostics: ["This implementation requires an integer power."],
    };
  const modulus = Math.hypot(input.real, input.imaginary),
    argument = Math.atan2(input.imaginary, input.real),
    powered = modulus ** input.power,
    angle = argument * input.power,
    real = powered * Math.cos(angle),
    imaginary = powered * Math.sin(angle);
  const branches =
    input.power > 1
      ? Array.from({ length: input.power }, (_, k) => ({
          real:
            modulus ** (1 / input.power) *
            Math.cos((argument + 2 * Math.PI * k) / input.power),
          imaginary:
            modulus ** (1 / input.power) *
            Math.sin((argument + 2 * Math.PI * k) / input.power),
        }))
      : undefined;
  return {
    status: "VERIFIED_NUMERIC",
    value: { modulus, argument, real, imaginary, rootBranches: branches },
    method: "DE_MOIVRE_POLAR",
    residual: 0,
    diagnostics: branches
      ? ["Root arguments are multi-valued; all declared branches are returned."]
      : [],
  };
}
export function theoryOfEquations(
  coefficients: number[],
): StudioResult<{
  degree: number;
  sumOfRoots?: number;
  productOfRoots?: number;
  normalized: number[];
}> {
  if (coefficients.length < 2 || Math.abs(coefficients[0]) < 1e-14)
    return {
      status: "INVALID",
      method: "VIETA",
      diagnostics: ["A nonzero leading coefficient is required."],
    };
  const normalized = coefficients.map((value) => value / coefficients[0]),
    degree = coefficients.length - 1;
  return {
    status: "VERIFIED_ALGEBRAIC",
    value: {
      degree,
      sumOfRoots: -normalized[1],
      productOfRoots: (degree % 2 ? -1 : 1) * normalized.at(-1)!,
      normalized,
    },
    method: "VIETA_COEFFICIENT_RELATIONS",
    residual: 0,
    diagnostics:
      degree > 4
        ? [
            "General explicit root formulas are not attempted; numeric roots require a separate solver.",
          ]
        : [],
  };
}
export function conicsStudio(
  coefficients: [number, number, number, number, number, number],
): StudioResult<{
  type: "ELLIPSE_OR_CIRCLE" | "PARABOLA" | "HYPERBOLA" | "DEGENERATE_CANDIDATE";
  discriminant: number;
  centre?: { x: number; y: number };
}> {
  const [A, B, C, D, E] = coefficients,
    disc = B * B - 4 * A * C,
    det = 4 * A * C - B * B;
  if (Math.abs(A) + Math.abs(B) + Math.abs(C) < 1e-14)
    return {
      status: "INVALID",
      method: "CONIC_DISCRIMINANT",
      diagnostics: ["Second-degree coefficients are required."],
    };
  const type =
    Math.abs(disc) < 1e-10
      ? "PARABOLA"
      : disc < 0
        ? "ELLIPSE_OR_CIRCLE"
        : "HYPERBOLA";
  const centre =
    Math.abs(det) > 1e-12
      ? { x: (B * E - 2 * C * D) / det, y: (B * D - 2 * A * E) / det }
      : undefined;
  return {
    status: "CANDIDATE",
    value: { type, discriminant: disc, centre },
    method: "GENERAL_QUADRATIC_DISCRIMINANT",
    diagnostics: [
      "Discriminant classifies the non-degenerate family; degeneracy needs the full conic determinant.",
    ],
  };
}
export function integrationStudio(
  fn: (x: number) => number,
  a: number,
  b: number,
  intervals = 400,
): StudioResult<{
  value: number;
  methodSuggestion: string;
  intervals: number;
}> {
  if (intervals < 2 || intervals % 2) intervals = Math.max(2, intervals + 1);
  const h = (b - a) / intervals;
  let sum = fn(a) + fn(b);
  for (let i = 1; i < intervals; i++) sum += (i % 2 ? 4 : 2) * fn(a + i * h);
  const value = (sum * h) / 3;
  if (!Number.isFinite(value))
    return {
      status: "INVALID",
      method: "COMPOSITE_SIMPSON",
      diagnostics: ["The integrand was not finite on sampled nodes."],
    };
  return {
    status: "VERIFIED_NUMERIC",
    value: {
      value,
      methodSuggestion:
        "Try symbolic substitution/parts/partial fractions when structure supports it; Simpson provides a labelled numerical check.",
      intervals,
    },
    method: "COMPOSITE_SIMPSON",
    diagnostics: [
      "Numerical verification is not a symbolic antiderivative proof.",
    ],
  };
}
export function differentialEquationStudio(input: {
  f: (x: number, y: number) => number;
  x0: number;
  y0: number;
  x1: number;
  steps: number;
  candidate?: (x: number) => number;
}): StudioResult<{
  x: number;
  y: number;
  directionField: Array<{ x: number; y: number; slope: number }>;
  candidateResidual?: number;
}> {
  if (input.steps < 1)
    return {
      status: "INVALID",
      method: "RK4",
      diagnostics: ["At least one integration step is required."],
    };
  const h = (input.x1 - input.x0) / input.steps;
  let x = input.x0,
    y = input.y0;
  for (let i = 0; i < input.steps; i++) {
    const k1 = input.f(x, y),
      k2 = input.f(x + h / 2, y + (h * k1) / 2),
      k3 = input.f(x + h / 2, y + (h * k2) / 2),
      k4 = input.f(x + h, y + h * k3);
    y += (h * (k1 + 2 * k2 + 2 * k3 + k4)) / 6;
    x += h;
  }
  const field = [];
  for (let ix = -2; ix <= 2; ix++)
    for (let iy = -2; iy <= 2; iy++)
      field.push({
        x: input.x0 + ix,
        y: input.y0 + iy,
        slope: input.f(input.x0 + ix, input.y0 + iy),
      });
  let residual: number | undefined;
  if (input.candidate) {
    const eps = 1e-5,
      derivative =
        (input.candidate(input.x1 + eps) - input.candidate(input.x1 - eps)) /
        (2 * eps);
    residual = Math.abs(
      derivative - input.f(input.x1, input.candidate(input.x1)),
    );
  }
  return {
    status: "VERIFIED_NUMERIC",
    value: { x, y, directionField: field, candidateResidual: residual },
    method: "RUNGE_KUTTA_4_AND_CENTRAL_DIFFERENCE_VERIFICATION",
    residual,
    diagnostics: [
      "Numerical trajectory and residual use declared finite step sizes.",
    ],
  };
}

export const priorityStudioRegistry = [
  {
    id: "mathematical-induction",
    conceptIds: ["ALG.MATHEMATICAL_INDUCTION"],
    engine: verifyInduction,
  },
  {
    id: "hyperbolic-functions",
    conceptIds: ["TRIG.HYPERBOLIC_FUNCTIONS"],
    engine: hyperbolicStudio,
  },
  {
    id: "transformation-of-axes",
    conceptIds: ["GEO.TRANSFORMATION_OF_AXES"],
    engine: transformAxes,
  },
  {
    id: "pair-of-straight-lines",
    conceptIds: ["GEO.PAIR_OF_STRAIGHT_LINES"],
    engine: pairOfLines,
  },
  {
    id: "system-of-circles",
    conceptIds: ["GEO.SYSTEM_OF_CIRCLES"],
    engine: systemOfCircles,
  },
  {
    id: "complex-de-moivre",
    conceptIds: ["ALG.COMPLEX.DE_MOIVRE"],
    engine: deMoivre,
  },
  {
    id: "theory-of-equations",
    conceptIds: ["ALG.THEORY_OF_EQUATIONS"],
    engine: theoryOfEquations,
  },
  {
    id: "conics",
    conceptIds: [
      "GEO.CONICS.PARABOLA",
      "GEO.CONICS.ELLIPSE",
      "GEO.CONICS.HYPERBOLA",
    ],
    engine: conicsStudio,
  },
  {
    id: "integration-methods",
    conceptIds: ["CALC.INTEGRATION.DEFINITE"],
    engine: integrationStudio,
  },
  {
    id: "differential-equations",
    conceptIds: ["CALC.ODE.FIRST_ORDER"],
    engine: differentialEquationStudio,
  },
] as const;
