export type TopicDifficulty = "Foundational" | "Intermediate" | "Advanced";

export type Topic = {
  id: string;
  title: string;
  route: string;
  isExternal?: boolean;
  iconName: string;
  description: string;
  concepts: string[];
  difficulty: TopicDifficulty;
  estimatedMinutes: number;
  colorGradient: string;
  labCount: number;
};

export const topics: Topic[] = [
  {
    id: "algebra",
    title: "Algebra Studio",
    route: "/algebra",
    iconName: "Calculator",
    description:
      "Explore equations, slopes, parabolas, roots, and transformations through live graphs.",
    concepts: ["Linear equations", "Quadratics", "Roots", "Transformations"],
    difficulty: "Foundational",
    estimatedMinutes: 35,
    colorGradient: "from-cyan-500 to-blue-600",
    labCount: 6,
  },
  {
    id: "geometry",
    title: "Geometry Studio",
    route: "/geometry",
    iconName: "Shapes",
    description:
      "Measure shapes, angles, areas, circles, and spatial relationships visually.",
    concepts: ["Triangles", "Circles", "Area", "Coordinate geometry"],
    difficulty: "Foundational",
    estimatedMinutes: 40,
    colorGradient: "from-emerald-400 to-cyan-600",
    labCount: 7,
  },
  {
    id: "number-systems",
    title: "Number Systems",
    route: "/number-systems",
    iconName: "Hash",
    description:
      "Visualize rational numbers, irrational numbers, real-number hierarchy, decimals, surds, and density on the number line.",
    concepts: ["Rational numbers", "Irrational numbers", "Real line", "Surds"],
    difficulty: "Foundational",
    estimatedMinutes: 35,
    colorGradient: "from-sky-500 to-emerald-600",
    labCount: 8,
  },
  {
    id: "trigonometry",
    title: "Trigonometry Studio",
    route: "/trigonometry",
    iconName: "Waves",
    description:
      "Connect unit circles, sine waves, phase, amplitude, and real signals.",
    concepts: ["Unit circle", "Sine", "Cosine", "Wave motion"],
    difficulty: "Intermediate",
    estimatedMinutes: 45,
    colorGradient: "from-violet-500 to-fuchsia-600",
    labCount: 7,
  },
  {
    id: "calculus",
    title: "Calculus Explorer",
    route: "/calculus",
    iconName: "Sigma",
    description:
      "Build intuition for limits, slopes, derivatives, integrals, and accumulation.",
    concepts: ["Limits", "Derivatives", "Integrals", "Motion"],
    difficulty: "Advanced",
    estimatedMinutes: 55,
    colorGradient: "from-orange-400 to-rose-600",
    labCount: 18,
  },
  {
    id: "differential-equations",
    title: "Differential Equations",
    route: "/differential-equations",
    iconName: "Waves",
    description:
      "Model change, solve equations, visualize solution families, and connect mathematics to engineering systems.",
    concepts: ["Slope fields", "Exact equations", "Integrating factors", "Numerical methods"],
    difficulty: "Advanced",
    estimatedMinutes: 50,
    colorGradient: "from-teal-500 to-cyan-600",
    labCount: 22,
  },
  {
    id: "complex",
    title: "Complex Numbers Studio",
    route: "/complex-numbers",
    iconName: "Atom",
    description:
      "Move between rectangular and polar form and see Euler's identity on the plane.",
    concepts: ["Complex plane", "Polar form", "Euler formula", "Rotation"],
    difficulty: "Advanced",
    estimatedMinutes: 50,
    colorGradient: "from-indigo-500 to-cyan-500",
    labCount: 6,
  },
  {
    id: "algebraic-structures",
    title: "Algebraic Structures",
    route: "/algebraic-structures",
    iconName: "GitFork",
    description:
      "Validate binary operations, classify semigroups and monoids, explore lattices, and simplify Boolean algebra.",
    concepts: ["Cayley tables", "Monoids", "Lattices", "Boolean algebra"],
    difficulty: "Advanced",
    estimatedMinutes: 70,
    colorGradient: "from-fuchsia-500 to-cyan-600",
    labCount: 9,
  },
  {
    id: "mathematical-logic",
    title: "Mathematical Logic",
    route: "/mathematical-logic",
    iconName: "Binary",
    description:
      "Build statements, truth tables, normal forms, inference proofs, and predicate models visually.",
    concepts: ["Statements", "Connectives", "CNF/DNF", "Predicate calculus"],
    difficulty: "Advanced",
    estimatedMinutes: 55,
    colorGradient: "from-emerald-500 to-cyan-600",
    labCount: 8,
  },
  {
    id: "combinatorics",
    title: "Combinatorics",
    route: "/combinatorics",
    iconName: "Grid3X3",
    description:
      "Animate counting trees, permutations, combinations, Pascal coefficients, expansions, and inclusion-exclusion.",
    concepts: [
      "Counting",
      "Permutations",
      "Binomial theorem",
      "Inclusion-exclusion",
    ],
    difficulty: "Advanced",
    estimatedMinutes: 65,
    colorGradient: "from-amber-400 to-cyan-600",
    labCount: 9,
  },
  {
    id: "set-theory",
    title: "Set Theory and Relations",
    route: "/set-theory",
    iconName: "Network",
    description:
      "Create sets, animate Venn diagrams, inspect relations, draw Hasse diagrams, and test functions.",
    concepts: ["Sets", "Relations", "Functions", "Partial orders"],
    difficulty: "Advanced",
    estimatedMinutes: 60,
    colorGradient: "from-cyan-500 to-emerald-600",
    labCount: 10,
  },
  {
    id: "graph-theory",
    title: "Graph Theory",
    route: "/graph-theory",
    iconName: "Network",
    description:
      "Edit graphs, animate traversal and MST algorithms, inspect circuits, planarity, and coloring.",
    concepts: ["BFS/DFS", "Trees", "Euler circuits", "Coloring"],
    difficulty: "Advanced",
    estimatedMinutes: 80,
    colorGradient: "from-sky-500 to-emerald-600",
    labCount: 12,
  },
  {
    id: "discrete-world",
    title: "Number & Discrete Mathematics Studio",
    route: "/discrete-world",
    iconName: "Workflow",
    description:
      "Connect logic, sets, combinatorics, graph theory, automata, grammars, and Turing machines in one browser-only lab.",
    concepts: [
      "Automata",
      "Grammars",
      "Turing machines",
      "Discrete structures",
    ],
    difficulty: "Advanced",
    estimatedMinutes: 95,
    colorGradient: "from-cyan-500 to-violet-600",
    labCount: 7,
  },
  {
    id: "statistics",
    title: "Statistics & Probability Studio",
    route: "/probability-statistics",
    iconName: "BarChart3",
    description:
      "Explore native statistics, distributions, variation, regression, probability, and uncertainty labs.",
    concepts: ["Statistics", "Probability", "Distributions", "Regression"],
    difficulty: "Intermediate",
    estimatedMinutes: 45,
    colorGradient: "from-teal-400 to-lime-500",
    labCount: 4,
  },
  {
    id: "linear-algebra",
    title: "Linear Algebra Studio",
    route: "/linear-algebra",
    iconName: "Grid3X3",
    description:
      "Visualize vectors, matrices, transformations, rotations, scaling, and shearing.",
    concepts: ["Vectors", "Matrices", "Transforms", "Basis"],
    difficulty: "Advanced",
    estimatedMinutes: 60,
    colorGradient: "from-sky-500 to-violet-600",
    labCount: 17,
  },
  {
    id: "matrices",
    title: "Matrices and Linear Algebra",
    route: "/matrices",
    iconName: "Grid3X3",
    description:
      "Master matrix basics, arithmetic, determinants, inverse, rank, row operations, systems, eigenvectors, and transformations.",
    concepts: ["Matrix basics", "Operations", "Determinants", "Linear systems"],
    difficulty: "Advanced",
    estimatedMinutes: 75,
    colorGradient: "from-cyan-500 to-violet-600",
    labCount: 14,
  },
  {
    id: "advanced-concept-studios",
    title: "Advanced Concept Studios",
    route: "/math-lab/continued-fractions",
    iconName: "Sigma",
    description:
      "Explore continued fractions, famous math problems, statistical inference, differential equations, and special functions.",
    concepts: [
      "Continued fractions",
      "Famous problems",
      "Inference",
      "Differential equations",
      "Special functions",
    ],
    difficulty: "Advanced",
    estimatedMinutes: 70,
    colorGradient: "from-teal-500 to-rose-500",
    labCount: 5,
  },
  {
    id: "ai",
    title: "Math in AI & Real Life",
    route: "/ai-applications",
    iconName: "BrainCircuit",
    description:
      "See how mathematical structures power AI, robotics, graphics, security, and signals.",
    concepts: ["Neural networks", "Optimization", "Signals", "Robotics"],
    difficulty: "Intermediate",
    estimatedMinutes: 40,
    colorGradient: "from-purple-500 to-pink-500",
    labCount: 6,
  },
  {
    id: "quiz",
    title: "Quiz Zone",
    route: "/quiz",
    iconName: "CircleHelp",
    description:
      "Practice core ideas and store your local score history as the course grows.",
    concepts: ["Concept checks", "Feedback", "Review", "Progress"],
    difficulty: "Foundational",
    estimatedMinutes: 20,
    colorGradient: "from-amber-400 to-orange-600",
    labCount: 4,
  },
];
