export type FormulaLibraryItem = {
  title: string;
  formula: string;
  note: string;
};

export type FormulaCategory = {
  id: string;
  title: string;
  description: string;
  formulas: FormulaLibraryItem[];
};

export const formulaCategories: FormulaCategory[] = [
  {
    id: "algebra",
    title: "Algebra",
    description:
      "Core identities, equations, powers, roots, and factorization formulas.",
    formulas: [
      {
        title: "Linear equation",
        formula: "ax+b=0 \\Rightarrow x=-\\frac{b}{a}",
        note: "For a non-zero coefficient a.",
      },
      {
        title: "Quadratic formula",
        formula: "ax^2+bx+c=0 \\Rightarrow x=\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}",
        note: "Solves any quadratic equation.",
      },
      {
        title: "Discriminant",
        formula: "\\Delta=b^2-4ac",
        note: "Controls the nature of quadratic roots.",
      },
      {
        title: "Difference of squares",
        formula: "a^2-b^2=(a-b)(a+b)",
        note: "A standard factorization pattern.",
      },
      {
        title: "Perfect square expansion",
        formula: "(a\\pm b)^2=a^2\\pm2ab+b^2",
        note: "Useful for expansion and completing the square.",
      },
      {
        title: "Cube expansion",
        formula: "(a\\pm b)^3=a^3\\pm3a^2b+3ab^2\\pm b^3",
        note: "Sign follows the middle operation.",
      },
      {
        title: "Sum and difference of cubes",
        formula: "a^3\\pm b^3=(a\\pm b)(a^2\\mp ab+b^2)",
        note: "Choose the matching sign in the first factor.",
      },
      {
        title: "Arithmetic with exponents",
        formula:
          "a^m a^n=a^{m+n},\\quad \\frac{a^m}{a^n}=a^{m-n},\\quad (a^m)^n=a^{mn}",
        note: "For valid non-zero bases where division appears.",
      },
    ],
  },
  {
    id: "number-systems",
    title: "Number Systems",
    description:
      "Ratios, indices, radicals, logarithms, absolute value, and modular arithmetic.",
    formulas: [
      {
        title: "Rational number form",
        formula: "x=\\frac{p}{q},\\quad p,q\\in\\mathbb{Z},\\quad q\\ne0",
        note: "Defines rational numbers.",
      },
      {
        title: "Absolute value",
        formula: "|x|=\\begin{cases}x,&x\\ge0\\\\-x,&x<0\\end{cases}",
        note: "Distance from zero on the number line.",
      },
      {
        title: "Radical exponent",
        formula: "\\sqrt[n]{a}=a^{1/n}",
        note: "Connects roots with fractional powers.",
      },
      {
        title: "Scientific notation",
        formula: "N=a\\times10^n,\\quad 1\\le |a|<10",
        note: "Standard form for very large or small numbers.",
      },
      {
        title: "Log definition",
        formula: "\\log_b a=x \\Leftrightarrow b^x=a",
        note: "Requires b positive and b not equal to 1.",
      },
      {
        title: "Log product and quotient",
        formula:
          "\\log_b(xy)=\\log_b x+\\log_b y,\\quad \\log_b\\frac{x}{y}=\\log_b x-\\log_b y",
        note: "Works for positive x and y.",
      },
      {
        title: "Change of base",
        formula: "\\log_b a=\\frac{\\log_c a}{\\log_c b}",
        note: "Useful when calculators use a different base.",
      },
      {
        title: "Modular congruence",
        formula: "a\\equiv b\\pmod n \\Leftrightarrow n\\mid(a-b)",
        note: "Means a and b leave the same remainder modulo n.",
      },
    ],
  },
  {
    id: "trigonometry",
    title: "Trigonometry",
    description:
      "Ratios, identities, angle transformations, inverse relations, and triangle laws.",
    formulas: [
      {
        title: "Basic ratios",
        formula:
          "\\sin\\theta=\\frac{opposite}{hypotenuse},\\quad \\cos\\theta=\\frac{adjacent}{hypotenuse},\\quad \\tan\\theta=\\frac{opposite}{adjacent}",
        note: "Right-triangle definitions.",
      },
      {
        title: "Reciprocal identities",
        formula:
          "\\sec\\theta=\\frac{1}{\\cos\\theta},\\quad \\csc\\theta=\\frac{1}{\\sin\\theta},\\quad \\cot\\theta=\\frac{1}{\\tan\\theta}",
        note: "Pairs each trig function with its reciprocal.",
      },
      {
        title: "Pythagorean identities",
        formula:
          "\\sin^2\\theta+\\cos^2\\theta=1,\\quad 1+\\tan^2\\theta=\\sec^2\\theta,\\quad 1+\\cot^2\\theta=\\csc^2\\theta",
        note: "Foundation for simplification.",
      },
      {
        title: "Angle sum",
        formula: "\\sin(a+b)=\\sin a\\cos b+\\cos a\\sin b",
        note: "Expands sine of a combined angle.",
      },
      {
        title: "Cosine angle sum",
        formula: "\\cos(a+b)=\\cos a\\cos b-\\sin a\\sin b",
        note: "Sign changes for cosine.",
      },
      {
        title: "Double angle",
        formula: "\\sin2x=2\\sin x\\cos x,\\quad \\cos2x=\\cos^2x-\\sin^2x",
        note: "Useful in identities and integration.",
      },
      {
        title: "Sine rule",
        formula: "\\frac{a}{\\sin A}=\\frac{b}{\\sin B}=\\frac{c}{\\sin C}",
        note: "Solves non-right triangles.",
      },
      {
        title: "Cosine rule",
        formula: "c^2=a^2+b^2-2ab\\cos C",
        note: "Generalizes Pythagoras.",
      },
    ],
  },
  {
    id: "geometry",
    title: "Geometry",
    description:
      "Plane shapes, solids, area, volume, and common geometric measures.",
    formulas: [
      {
        title: "Triangle area",
        formula: "A=\\frac{1}{2}bh",
        note: "Base times perpendicular height.",
      },
      {
        title: "Heron's formula",
        formula: "A=\\sqrt{s(s-a)(s-b)(s-c)},\\quad s=\\frac{a+b+c}{2}",
        note: "Area from three side lengths.",
      },
      {
        title: "Pythagorean theorem",
        formula: "a^2+b^2=c^2",
        note: "For right triangles.",
      },
      {
        title: "Circle circumference",
        formula: "C=2\\pi r",
        note: "Distance around a circle.",
      },
      {
        title: "Circle area",
        formula: "A=\\pi r^2",
        note: "Area enclosed by a circle.",
      },
      {
        title: "Sector area",
        formula: "A=\\frac{\\theta}{360}\\pi r^2",
        note: "Theta is measured in degrees.",
      },
      {
        title: "Cylinder volume",
        formula: "V=\\pi r^2h",
        note: "Base area times height.",
      },
      {
        title: "Sphere surface and volume",
        formula: "S=4\\pi r^2,\\quad V=\\frac{4}{3}\\pi r^3",
        note: "Common solid geometry formulas.",
      },
    ],
  },
  {
    id: "fractals-solid-views",
    title: "Fractals and Solid Views",
    description:
      "Sierpinski carpet counts, retained area, removed area, and cube-stack projection rules.",
    formulas: [
      {
        title: "Sierpinski retained squares",
        formula: "R_n=8^n",
        note: "After n iterations, each retained square has produced 8 smaller retained squares.",
      },
      {
        title: "Sierpinski newly removed squares",
        formula: "N_n=8^{n-1}\\quad(n\\ge1)",
        note: "At step n, one center square is removed from each of the 8^(n-1) retained squares from the previous step.",
      },
      {
        title: "Sierpinski cumulative removed squares",
        formula: "C_n=1+8+8^2+\\cdots+8^{n-1}=\\frac{8^n-1}{7}",
        note: "A finite geometric sum counts all removed squares up to iteration n.",
      },
      {
        title: "Smallest side scale",
        formula: "s_n=\\frac{1}{3^n}",
        note: "Every iteration divides side length by 3.",
      },
      {
        title: "Smallest square area",
        formula: "a_n=\\frac{1}{9^n}",
        note: "Area scale is the square of side scale.",
      },
      {
        title: "Retained area fraction",
        formula: "A_n=\\left(\\frac{8}{9}\\right)^n=\\frac{8^n}{9^n}",
        note: "Each iteration keeps 8 of 9 equal area parts.",
      },
      {
        title: "Removed area fraction",
        formula: "M_n=1-\\left(\\frac{8}{9}\\right)^n",
        note: "Removed area is the complement of retained area.",
      },
      {
        title: "Top projection rule",
        formula: "T_{r,c}=1\\;\\text{if}\\;h_{r,c}>0",
        note: "The top view records whether a stack exists in each footprint cell.",
      },
      {
        title: "Front projection rule",
        formula: "F_c=\\max_r h_{r,c}",
        note: "The front view keeps the tallest stack in each column.",
      },
      {
        title: "Side projection rule",
        formula: "L_r=\\max_c h_{r,c}",
        note: "The side view keeps the tallest stack in each row.",
      },
    ],
  },
  {
    id: "proportional-reasoning-2",
    title: "Proportional Reasoning-2",
    description:
      "Grade 8 Part II formulas for equivalent ratios, map scale, representative fraction, multi-term sharing, pie charts, and direct/inverse proportion.",
    formulas: [
      {
        title: "Equivalent ratios",
        formula: "\\frac{a}{b}=\\frac{c}{d}",
        note: "Two ratios are equivalent when they simplify to the same ratio.",
      },
      {
        title: "Cross multiplication",
        formula: "\\frac{a}{b}=\\frac{c}{d}\\iff ad=bc",
        note: "For non-zero b and d, equal ratios have equal cross-products.",
      },
      {
        title: "Missing fourth term",
        formula: "d=\\frac{bc}{a}",
        note: "Use when a/b=c/d and d is unknown.",
      },
      {
        title: "Representative fraction",
        formula: "RF=\\frac{\\text{map distance}}{\\text{actual distance}}",
        note: "Convert both distances to the same unit before forming the ratio.",
      },
      {
        title: "Scale 1:n to actual distance",
        formula: "\\text{actual}=\\text{map}\\times n",
        note: "A map scale of 1:n means one map unit represents n actual units.",
      },
      {
        title: "Scale 1:n to map distance",
        formula: "\\text{map}=\\frac{\\text{actual}}{n}",
        note: "Convert actual distance into the map unit first.",
      },
      {
        title: "Multi-term ratio share",
        formula: "\\text{share}_i=\\frac{r_i}{r_1+r_2+\\cdots+r_k}\\times T",
        note: "Each part receives its fraction of the total.",
      },
      {
        title: "Ratio to percentage",
        formula: "\\text{percent}_i=\\frac{r_i}{r_1+r_2+\\cdots+r_k}\\times100",
        note: "Useful when comparing each part of a whole.",
      },
      {
        title: "Ratio to pie angle",
        formula: "\\theta_i=\\frac{r_i}{r_1+r_2+\\cdots+r_k}\\times360^\\circ",
        note: "Pie chart angles must add to 360 degrees.",
      },
      {
        title: "Direct proportion",
        formula: "y=kx,\\quad \\frac{y}{x}=k",
        note: "The ratio y/x stays constant.",
      },
      {
        title: "Inverse proportion",
        formula: "xy=k,\\quad y=\\frac{k}{x}",
        note: "The product xy stays constant.",
      },
      {
        title: "Direct versus inverse check",
        formula:
          "\\frac{y_1}{x_1}=\\frac{y_2}{x_2}\\quad\\text{or}\\quad x_1y_1=x_2y_2",
        note: "Use constant ratio for direct proportion and constant product for inverse proportion.",
      },
    ],
  },
  {
    id: "coordinate-geometry",
    title: "Coordinate Geometry",
    description:
      "Lines, distances, sections, circles, conics, and coordinate transformations.",
    formulas: [
      {
        title: "Distance formula",
        formula: "d=\\sqrt{(x_2-x_1)^2+(y_2-y_1)^2}",
        note: "Distance between two points.",
      },
      {
        title: "Midpoint",
        formula: "M=\\left(\\frac{x_1+x_2}{2},\\frac{y_1+y_2}{2}\\right)",
        note: "Point halfway between two points.",
      },
      {
        title: "Slope",
        formula: "m=\\frac{y_2-y_1}{x_2-x_1}",
        note: "Rise over run.",
      },
      {
        title: "Point-slope line",
        formula: "y-y_1=m(x-x_1)",
        note: "Line through a point with slope m.",
      },
      {
        title: "General line",
        formula: "Ax+By+C=0",
        note: "Standard equation of a line.",
      },
      {
        title: "Circle",
        formula: "(x-h)^2+(y-k)^2=r^2",
        note: "Center is (h,k), radius is r.",
      },
      {
        title: "Parabola",
        formula: "y^2=4ax,\\quad x^2=4ay",
        note: "Standard forms with vertex at origin.",
      },
      {
        title: "Ellipse",
        formula: "\\frac{x^2}{a^2}+\\frac{y^2}{b^2}=1",
        note: "Centered at origin with semi-axes a and b.",
      },
    ],
  },
  {
    id: "limits-continuity",
    title: "Limits and Continuity",
    description:
      "Limit laws, standard limits, continuity tests, and asymptotic behavior.",
    formulas: [
      {
        title: "Limit sum law",
        formula:
          "\\lim_{x\\to a}[f(x)+g(x)]=\\lim_{x\\to a}f(x)+\\lim_{x\\to a}g(x)",
        note: "Provided both limits exist.",
      },
      {
        title: "Limit product law",
        formula:
          "\\lim_{x\\to a}[f(x)g(x)]=\\left(\\lim_{x\\to a}f(x)\\right)\\left(\\lim_{x\\to a}g(x)\\right)",
        note: "Multiplication respects limits.",
      },
      {
        title: "Continuity at a point",
        formula: "\\lim_{x\\to a}f(x)=f(a)",
        note: "The value and limiting value must match.",
      },
      {
        title: "Standard sine limit",
        formula: "\\lim_{x\\to0}\\frac{\\sin x}{x}=1",
        note: "Angle x is in radians.",
      },
      {
        title: "Standard cosine limit",
        formula: "\\lim_{x\\to0}\\frac{1-\\cos x}{x}=0",
        note: "Useful for derivative proofs.",
      },
      {
        title: "Exponential limit",
        formula: "\\lim_{x\\to0}\\frac{e^x-1}{x}=1",
        note: "Connects e to rates of change.",
      },
      {
        title: "L'Hopital form",
        formula: "\\lim\\frac{f(x)}{g(x)}=\\lim\\frac{f'(x)}{g'(x)}",
        note: "For valid indeterminate forms.",
      },
      {
        title: "Squeeze theorem",
        formula:
          "g(x)\\le f(x)\\le h(x),\\quad \\lim g=\\lim h=L \\Rightarrow \\lim f=L",
        note: "Traps a function between two known limits.",
      },
    ],
  },
  {
    id: "derivatives",
    title: "Derivatives",
    description:
      "Differentiation rules for elementary, trigonometric, exponential, and composite functions.",
    formulas: [
      {
        title: "Definition",
        formula: "f'(x)=\\lim_{h\\to0}\\frac{f(x+h)-f(x)}{h}",
        note: "Instantaneous rate of change.",
      },
      {
        title: "Power rule",
        formula: "\\frac{d}{dx}x^n=nx^{n-1}",
        note: "For real powers where defined.",
      },
      {
        title: "Product rule",
        formula: "(uv)'=u'v+uv'",
        note: "Derivative of a product.",
      },
      {
        title: "Quotient rule",
        formula: "\\left(\\frac{u}{v}\\right)'=\\frac{u'v-uv'}{v^2}",
        note: "For v not equal to zero.",
      },
      {
        title: "Chain rule",
        formula: "\\frac{d}{dx}f(g(x))=f'(g(x))g'(x)",
        note: "Derivative of a composite function.",
      },
      {
        title: "Trig derivatives",
        formula:
          "\\frac{d}{dx}\\sin x=\\cos x,\\quad \\frac{d}{dx}\\cos x=-\\sin x",
        note: "Angles are in radians.",
      },
      {
        title: "Exponential derivative",
        formula: "\\frac{d}{dx}e^x=e^x,\\quad \\frac{d}{dx}a^x=a^x\\ln a",
        note: "For positive a.",
      },
      {
        title: "Log derivative",
        formula: "\\frac{d}{dx}\\ln x=\\frac{1}{x}",
        note: "For x greater than zero.",
      },
    ],
  },
  {
    id: "integrals",
    title: "Integrals",
    description:
      "Antiderivatives, definite integrals, substitution, parts, and standard integrals.",
    formulas: [
      {
        title: "Power integral",
        formula: "\\int x^n\\,dx=\\frac{x^{n+1}}{n+1}+C,\\quad n\\ne-1",
        note: "Reverse of the power rule.",
      },
      {
        title: "Log integral",
        formula: "\\int \\frac{1}{x}\\,dx=\\ln|x|+C",
        note: "Special case when n equals -1.",
      },
      {
        title: "Exponential integral",
        formula: "\\int e^x\\,dx=e^x+C",
        note: "e to the x is its own antiderivative.",
      },
      {
        title: "Sine and cosine integrals",
        formula:
          "\\int \\sin x\\,dx=-\\cos x+C,\\quad \\int \\cos x\\,dx=\\sin x+C",
        note: "Basic trigonometric antiderivatives.",
      },
      {
        title: "Substitution",
        formula: "\\int f(g(x))g'(x)\\,dx=\\int f(u)\\,du",
        note: "Let u equal g(x).",
      },
      {
        title: "Integration by parts",
        formula: "\\int u\\,dv=uv-\\int v\\,du",
        note: "Product rule in reverse.",
      },
      {
        title: "Fundamental theorem",
        formula: "\\int_a^b f(x)\\,dx=F(b)-F(a),\\quad F'=f",
        note: "Links area and antiderivatives.",
      },
      {
        title: "Area between curves",
        formula: "A=\\int_a^b [f(x)-g(x)]\\,dx",
        note: "Use top curve minus bottom curve.",
      },
    ],
  },
  {
    id: "differential-equations",
    title: "Differential Equations",
    description:
      "First-order equations, separable models, linear equations, and growth laws.",
    formulas: [
      {
        title: "Separable form",
        formula:
          "\\frac{dy}{dx}=g(x)h(y) \\Rightarrow \\int\\frac{1}{h(y)}\\,dy=\\int g(x)\\,dx",
        note: "Separate y terms and x terms.",
      },
      {
        title: "First-order linear",
        formula: "\\frac{dy}{dx}+P(x)y=Q(x)",
        note: "Use an integrating factor.",
      },
      {
        title: "Integrating factor",
        formula: "IF=e^{\\int P(x)\\,dx}",
        note: "Multiplies the whole equation.",
      },
      {
        title: "Linear solution",
        formula: "y\\cdot IF=\\int Q(x)IF\\,dx+C",
        note: "General solution after multiplying by IF.",
      },
      {
        title: "Exponential growth",
        formula: "\\frac{dy}{dt}=ky \\Rightarrow y=Ce^{kt}",
        note: "Positive k gives growth, negative k gives decay.",
      },
      {
        title: "Logistic model",
        formula: "\\frac{dy}{dt}=ky\\left(1-\\frac{y}{L}\\right)",
        note: "Growth with carrying capacity L.",
      },
      {
        title: "Second-order constant coefficient",
        formula: "ay''+by'+cy=0",
        note: "Solved through an auxiliary equation.",
      },
      {
        title: "Auxiliary equation",
        formula: "ar^2+br+c=0",
        note: "Roots determine the solution form.",
      },
    ],
  },
  {
    id: "matrices",
    title: "Matrices",
    description:
      "Matrix arithmetic, products, inverses, transpose, rank, and systems.",
    formulas: [
      {
        title: "Matrix addition",
        formula: "(A+B)_{ij}=a_{ij}+b_{ij}",
        note: "Matrices must have the same order.",
      },
      {
        title: "Scalar multiplication",
        formula: "(kA)_{ij}=ka_{ij}",
        note: "Multiply every entry by k.",
      },
      {
        title: "Matrix multiplication",
        formula: "(AB)_{ij}=\\sum_{k=1}^{n}a_{ik}b_{kj}",
        note: "Rows of A combine with columns of B.",
      },
      {
        title: "Transpose",
        formula: "(A^T)_{ij}=A_{ji}",
        note: "Rows become columns.",
      },
      {
        title: "Inverse definition",
        formula: "AA^{-1}=A^{-1}A=I",
        note: "Only square non-singular matrices have inverses.",
      },
      {
        title: "Inverse by adjoint",
        formula: "A^{-1}=\\frac{1}{|A|}\\operatorname{adj}(A)",
        note: "Requires determinant not equal to zero.",
      },
      {
        title: "System form",
        formula: "AX=B \\Rightarrow X=A^{-1}B",
        note: "When A is invertible.",
      },
      {
        title: "Trace",
        formula: "\\operatorname{tr}(A)=\\sum_i a_{ii}",
        note: "Sum of diagonal entries.",
      },
    ],
  },
  {
    id: "determinants",
    title: "Determinants",
    description:
      "Determinant evaluation, area scaling, cofactors, adjoints, and Cramer's rule.",
    formulas: [
      {
        title: "Two by two determinant",
        formula: "\\begin{vmatrix}a&b\\\\c&d\\end{vmatrix}=ad-bc",
        note: "Area scaling factor for a 2D transformation.",
      },
      {
        title: "Three by three expansion",
        formula: "|A|=a_{11}C_{11}+a_{12}C_{12}+a_{13}C_{13}",
        note: "Expansion along first row.",
      },
      {
        title: "Minor",
        formula:
          "M_{ij}=\\text{determinant after deleting row }i\\text{ and column }j",
        note: "Used to build cofactors.",
      },
      {
        title: "Cofactor",
        formula: "C_{ij}=(-1)^{i+j}M_{ij}",
        note: "Applies the checkerboard sign pattern.",
      },
      {
        title: "Adjoint",
        formula: "\\operatorname{adj}(A)=[C_{ij}]^T",
        note: "Transpose of the cofactor matrix.",
      },
      {
        title: "Product determinant",
        formula: "|AB|=|A||B|",
        note: "Determinants multiply.",
      },
      {
        title: "Singular matrix",
        formula: "|A|=0 \\Rightarrow A^{-1}\\text{ does not exist}",
        note: "Rows or columns are dependent.",
      },
      {
        title: "Cramer's rule",
        formula: "x_i=\\frac{\\Delta_i}{\\Delta}",
        note: "For linear systems with non-zero main determinant.",
      },
    ],
  },
  {
    id: "vectors",
    title: "Vectors",
    description:
      "Vector magnitude, products, projection, direction cosines, and geometric equations.",
    formulas: [
      {
        title: "Magnitude",
        formula: "|\\vec a|=\\sqrt{a_1^2+a_2^2+a_3^2}",
        note: "Length of a vector in 3D.",
      },
      {
        title: "Dot product",
        formula: "\\vec a\\cdot\\vec b=|\\vec a||\\vec b|\\cos\\theta",
        note: "Measures directional alignment.",
      },
      {
        title: "Component dot product",
        formula: "\\vec a\\cdot\\vec b=a_1b_1+a_2b_2+a_3b_3",
        note: "Algebraic form.",
      },
      {
        title: "Cross product magnitude",
        formula: "|\\vec a\\times\\vec b|=|\\vec a||\\vec b|\\sin\\theta",
        note: "Area of the parallelogram.",
      },
      {
        title: "Projection",
        formula:
          "\\operatorname{proj}_{\\vec b}\\vec a=\\frac{\\vec a\\cdot\\vec b}{|\\vec b|^2}\\vec b",
        note: "Shadow of a on b.",
      },
      {
        title: "Unit vector",
        formula: "\\hat a=\\frac{\\vec a}{|\\vec a|}",
        note: "Vector with length 1.",
      },
      {
        title: "Scalar triple product",
        formula:
          "[\\vec a\\ \\vec b\\ \\vec c]=\\vec a\\cdot(\\vec b\\times\\vec c)",
        note: "Volume of a parallelepiped.",
      },
      {
        title: "Angle between vectors",
        formula:
          "\\cos\\theta=\\frac{\\vec a\\cdot\\vec b}{|\\vec a||\\vec b|}",
        note: "Finds the angle from the dot product.",
      },
    ],
  },
  {
    id: "three-d-geometry",
    title: "3D Geometry",
    description:
      "Lines, planes, distances, angles, and vector equations in three dimensions.",
    formulas: [
      {
        title: "Line vector form",
        formula: "\\vec r=\\vec a+\\lambda\\vec b",
        note: "Point a plus scalar direction b.",
      },
      {
        title: "Line symmetric form",
        formula: "\\frac{x-x_1}{a}=\\frac{y-y_1}{b}=\\frac{z-z_1}{c}",
        note: "Direction ratios are a, b, c.",
      },
      {
        title: "Plane vector form",
        formula: "\\vec r\\cdot\\vec n=d",
        note: "Normal vector n determines the plane orientation.",
      },
      {
        title: "Plane Cartesian form",
        formula: "Ax+By+Cz+D=0",
        note: "General equation of a plane.",
      },
      {
        title: "Distance from point to plane",
        formula: "d=\\frac{|Ax_1+By_1+Cz_1+D|}{\\sqrt{A^2+B^2+C^2}}",
        note: "Perpendicular distance.",
      },
      {
        title: "Angle between planes",
        formula:
          "\\cos\\theta=\\frac{|\\vec n_1\\cdot\\vec n_2|}{|\\vec n_1||\\vec n_2|}",
        note: "Use the normals of the planes.",
      },
      {
        title: "Angle between line and plane",
        formula:
          "\\sin\\theta=\\frac{|\\vec b\\cdot\\vec n|}{|\\vec b||\\vec n|}",
        note: "Direction vector b and plane normal n.",
      },
      {
        title: "Shortest distance between skew lines",
        formula:
          "d=\\frac{|(\\vec a_2-\\vec a_1)\\cdot(\\vec b_1\\times\\vec b_2)|}{|\\vec b_1\\times\\vec b_2|}",
        note: "For non-parallel non-intersecting lines.",
      },
    ],
  },
  {
    id: "complex-numbers",
    title: "Complex Numbers",
    description:
      "Complex arithmetic, modulus, arguments, polar form, roots, and Euler forms.",
    formulas: [
      {
        title: "Standard form",
        formula: "z=a+bi",
        note: "a is real part and b is imaginary part.",
      },
      {
        title: "Modulus",
        formula: "|z|=\\sqrt{a^2+b^2}",
        note: "Distance from origin in the complex plane.",
      },
      {
        title: "Conjugate",
        formula: "\\overline{z}=a-bi",
        note: "Reflects across the real axis.",
      },
      {
        title: "Division",
        formula: "\\frac{z_1}{z_2}=\\frac{z_1\\overline{z_2}}{|z_2|^2}",
        note: "Multiply by conjugate of denominator.",
      },
      {
        title: "Polar form",
        formula: "z=r(\\cos\\theta+i\\sin\\theta)",
        note: "Uses modulus r and argument theta.",
      },
      {
        title: "Euler form",
        formula: "e^{i\\theta}=\\cos\\theta+i\\sin\\theta",
        note: "Connects exponentials and rotation.",
      },
      {
        title: "De Moivre's theorem",
        formula:
          "[r(\\cos\\theta+i\\sin\\theta)]^n=r^n(\\cos n\\theta+i\\sin n\\theta)",
        note: "Powers in polar form.",
      },
      {
        title: "nth roots",
        formula:
          "z_k=r^{1/n}\\left(\\cos\\frac{\\theta+2k\\pi}{n}+i\\sin\\frac{\\theta+2k\\pi}{n}\\right)",
        note: "For k from 0 to n-1.",
      },
    ],
  },
  {
    id: "sequences-series",
    title: "Sequences and Series",
    description:
      "Arithmetic, geometric, harmonic, binomial, and infinite-series formulas.",
    formulas: [
      {
        title: "Arithmetic nth term",
        formula: "a_n=a+(n-1)d",
        note: "First term a and common difference d.",
      },
      {
        title: "Arithmetic sum",
        formula: "S_n=\\frac{n}{2}[2a+(n-1)d]",
        note: "Sum of first n terms.",
      },
      {
        title: "Geometric nth term",
        formula: "a_n=ar^{n-1}",
        note: "First term a and common ratio r.",
      },
      {
        title: "Geometric sum",
        formula: "S_n=a\\frac{1-r^n}{1-r}",
        note: "For r not equal to 1.",
      },
      {
        title: "Infinite geometric sum",
        formula: "S_\\infty=\\frac{a}{1-r},\\quad |r|<1",
        note: "Converges only when absolute ratio is less than 1.",
      },
      {
        title: "Sum of first n natural numbers",
        formula: "1+2+\\cdots+n=\\frac{n(n+1)}{2}",
        note: "Triangular number formula.",
      },
      {
        title: "Sum of squares",
        formula: "1^2+2^2+\\cdots+n^2=\\frac{n(n+1)(2n+1)}{6}",
        note: "Standard power sum.",
      },
      {
        title: "Binomial theorem",
        formula: "(a+b)^n=\\sum_{r=0}^{n}\\binom{n}{r}a^{n-r}b^r",
        note: "Expansion for non-negative integer n.",
      },
    ],
  },
  {
    id: "combinatorics",
    title: "Combinatorics",
    description:
      "Counting arrangements, selections, binomial coefficients, and inclusion-exclusion.",
    formulas: [
      {
        title: "Factorial",
        formula: "n!=n(n-1)(n-2)\\cdots1",
        note: "Number of ways to arrange n distinct objects.",
      },
      {
        title: "Permutation",
        formula: "{}^nP_r=\\frac{n!}{(n-r)!}",
        note: "Ordered selection of r objects.",
      },
      {
        title: "Combination",
        formula: "{}^nC_r=\\frac{n!}{r!(n-r)!}",
        note: "Unordered selection of r objects.",
      },
      {
        title: "Relation between P and C",
        formula: "{}^nP_r={}^nC_r\\,r!",
        note: "Order turns combinations into permutations.",
      },
      {
        title: "Circular permutations",
        formula: "(n-1)!",
        note: "Arrangements around a circle.",
      },
      {
        title: "Permutations with repetition",
        formula: "\\frac{n!}{p_1!p_2!\\cdots p_k!}",
        note: "For repeated identical objects.",
      },
      {
        title: "Pascal identity",
        formula: "\\binom{n}{r}=\\binom{n-1}{r}+\\binom{n-1}{r-1}",
        note: "Builds Pascal's triangle.",
      },
      {
        title: "Inclusion-exclusion",
        formula: "|A\\cup B|=|A|+|B|-|A\\cap B|",
        note: "Avoids double counting.",
      },
    ],
  },
  {
    id: "set-theory-logic",
    title: "Set Theory and Logic",
    description:
      "Set operations, cardinality laws, relations, implications, and logic equivalences.",
    formulas: [
      {
        title: "Union",
        formula: "A\\cup B=\\{x:x\\in A\\text{ or }x\\in B\\}",
        note: "Elements in either set.",
      },
      {
        title: "Intersection",
        formula: "A\\cap B=\\{x:x\\in A\\text{ and }x\\in B\\}",
        note: "Elements common to both sets.",
      },
      {
        title: "Difference",
        formula: "A-B=\\{x:x\\in A\\text{ and }x\\notin B\\}",
        note: "Elements in A but not B.",
      },
      {
        title: "Complement",
        formula: "A'=U-A",
        note: "Everything in the universal set outside A.",
      },
      {
        title: "De Morgan laws",
        formula: "(A\\cup B)'=A'\\cap B',\\quad (A\\cap B)'=A'\\cup B'",
        note: "Complements reverse union and intersection.",
      },
      {
        title: "Cartesian product",
        formula: "A\\times B=\\{(a,b):a\\in A,b\\in B\\}",
        note: "Ordered pairs from two sets.",
      },
      {
        title: "Implication equivalence",
        formula: "p\\Rightarrow q\\equiv \\neg p\\vee q",
        note: "Useful in proof logic.",
      },
      {
        title: "Contrapositive",
        formula: "p\\Rightarrow q\\equiv \\neg q\\Rightarrow \\neg p",
        note: "A logically equivalent statement.",
      },
    ],
  },
  {
    id: "linear-programming",
    title: "Linear Programming",
    description:
      "Objective functions, constraints, feasible regions, and optimization conditions.",
    formulas: [
      {
        title: "Objective function",
        formula: "Z=ax+by",
        note: "Quantity to maximize or minimize.",
      },
      {
        title: "Linear constraint",
        formula: "a_1x+b_1y\\le c_1",
        note: "Each inequality creates a half-plane.",
      },
      {
        title: "Non-negativity",
        formula: "x\\ge0,\\quad y\\ge0",
        note: "Common real-world restriction.",
      },
      {
        title: "Feasible region",
        formula: "\\{(x,y):a_ix+b_iy\\le c_i\\text{ for all }i\\}",
        note: "All points satisfying every constraint.",
      },
      {
        title: "Corner-point principle",
        formula:
          "Z_{max/min}\\text{ occurs at a vertex of the feasible region}",
        note: "For bounded linear programs.",
      },
      {
        title: "Iso-profit line",
        formula: "ax+by=k",
        note: "Parallel objective lines.",
      },
      {
        title: "Slack variable",
        formula: "a_ix+b_iy+s_i=c_i,\\quad s_i\\ge0",
        note: "Turns a less-than constraint into an equation.",
      },
      {
        title: "Standard maximization form",
        formula: "\\max Z=c^Tx,\\quad Ax\\le b,\\quad x\\ge0",
        note: "Compact matrix notation.",
      },
    ],
  },
  {
    id: "relations-functions",
    title: "Relations and Functions",
    description:
      "Domains, ranges, composition, inverse functions, one-one and onto conditions.",
    formulas: [
      {
        title: "Function notation",
        formula: "f:A\\to B",
        note: "Maps each element of A to exactly one element of B.",
      },
      {
        title: "Domain and range",
        formula:
          "\\operatorname{Dom}(f)=A,\\quad \\operatorname{Range}(f)=\\{f(x):x\\in A\\}",
        note: "Input set and output set.",
      },
      {
        title: "Composition",
        formula: "(f\\circ g)(x)=f(g(x))",
        note: "Apply g first, then f.",
      },
      {
        title: "Identity function",
        formula: "I_A(x)=x",
        note: "Leaves every input unchanged.",
      },
      {
        title: "Inverse function",
        formula: "f^{-1}(y)=x \\Leftrightarrow f(x)=y",
        note: "Reverses a one-one onto function.",
      },
      {
        title: "Inverse composition",
        formula: "f^{-1}\\circ f=I_A,\\quad f\\circ f^{-1}=I_B",
        note: "Defines inverse behavior.",
      },
      {
        title: "One-one test",
        formula: "f(x_1)=f(x_2)\\Rightarrow x_1=x_2",
        note: "Different inputs give different outputs.",
      },
      {
        title: "Onto test",
        formula: "\\forall y\\in B,\\exists x\\in A\\text{ such that }f(x)=y",
        note: "Every codomain element is hit.",
      },
    ],
  },
  {
    id: "mensuration-units",
    title: "Mensuration and Units",
    description:
      "Perimeter, surface area, volume, unit conversion, and measurement formulas.",
    formulas: [
      {
        title: "Rectangle",
        formula: "A=lw,\\quad P=2(l+w)",
        note: "Area and perimeter.",
      },
      {
        title: "Parallelogram",
        formula: "A=bh",
        note: "Base times perpendicular height.",
      },
      {
        title: "Trapezium",
        formula: "A=\\frac{1}{2}(a+b)h",
        note: "Average of parallel sides times height.",
      },
      {
        title: "Cube",
        formula: "V=a^3,\\quad S=6a^2",
        note: "Volume and surface area.",
      },
      {
        title: "Cuboid",
        formula: "V=lwh,\\quad S=2(lw+wh+hl)",
        note: "Rectangular prism measures.",
      },
      {
        title: "Cone",
        formula: "V=\\frac{1}{3}\\pi r^2h,\\quad CSA=\\pi rl",
        note: "Curved surface uses slant height l.",
      },
      {
        title: "Frustum",
        formula: "V=\\frac{1}{3}\\pi h(R^2+r^2+Rr)",
        note: "Volume of a truncated cone.",
      },
      {
        title: "Unit conversion",
        formula:
          "1\\text{ m}=100\\text{ cm},\\quad 1\\text{ m}^2=10^4\\text{ cm}^2,\\quad 1\\text{ m}^3=10^6\\text{ cm}^3",
        note: "Powers change with dimension.",
      },
    ],
  },
];

const expandedFormulaItems: Record<string, FormulaLibraryItem[]> = {
  algebra: [
    { title: "Zero exponent", formula: "a^0=1", note: "For non-zero a." },
    {
      title: "Negative exponent",
      formula: "a^{-n}=\\frac{1}{a^n}",
      note: "For non-zero a.",
    },
    {
      title: "Product power",
      formula: "(ab)^n=a^n b^n",
      note: "Distributes powers over multiplication.",
    },
    {
      title: "Quotient power",
      formula: "\\left(\\frac{a}{b}\\right)^n=\\frac{a^n}{b^n}",
      note: "For non-zero b.",
    },
    {
      title: "Completing square",
      formula: "ax^2+bx+c=a\\left(x+\\frac{b}{2a}\\right)^2+c-\\frac{b^2}{4a}",
      note: "Converts quadratic to vertex form.",
    },
    {
      title: "Vertex of quadratic",
      formula: "x_v=-\\frac{b}{2a}",
      note: "Axis of symmetry for ax^2+bx+c.",
    },
    {
      title: "Quadratic root sum",
      formula: "\\alpha+\\beta=-\\frac{b}{a}",
      note: "For roots of ax^2+bx+c=0.",
    },
    {
      title: "Quadratic root product",
      formula: "\\alpha\\beta=\\frac{c}{a}",
      note: "For roots of ax^2+bx+c=0.",
    },
    {
      title: "Polynomial remainder theorem",
      formula: "f(a)=\\text{remainder when }f(x)\\text{ is divided by }x-a",
      note: "Tests remainders quickly.",
    },
    {
      title: "Factor theorem",
      formula: "f(a)=0\\Leftrightarrow (x-a)\\text{ is a factor of }f(x)",
      note: "Detects linear factors.",
    },
  ],
  "number-systems": [
    {
      title: "HCF LCM relation",
      formula: "\\operatorname{HCF}(a,b)\\operatorname{LCM}(a,b)=ab",
      note: "For positive integers a and b.",
    },
    {
      title: "Euclid division lemma",
      formula: "a=bq+r,\\quad 0\\le r<b",
      note: "Foundation of the Euclidean algorithm.",
    },
    {
      title: "Rational decimal termination",
      formula: "q=2^m5^n\\Rightarrow \\frac{p}{q}\\text{ terminates}",
      note: "After reducing p/q.",
    },
    {
      title: "Prime factorization",
      formula: "n=p_1^{a_1}p_2^{a_2}\\cdots p_k^{a_k}",
      note: "Unique factorization form.",
    },
    {
      title: "Number of divisors",
      formula: "d(n)=(a_1+1)(a_2+1)\\cdots(a_k+1)",
      note: "Uses prime powers.",
    },
    {
      title: "Sum of divisors",
      formula: "\\sigma(n)=\\prod_i\\frac{p_i^{a_i+1}-1}{p_i-1}",
      note: "For prime factorization of n.",
    },
    {
      title: "Log power rule",
      formula: "\\log_b(x^r)=r\\log_b x",
      note: "Pulls exponent down.",
    },
    {
      title: "Natural log base",
      formula: "\\ln x=\\log_e x",
      note: "Logarithm with base e.",
    },
    {
      title: "Absolute value product",
      formula: "|xy|=|x||y|",
      note: "Magnitude distributes over multiplication.",
    },
    {
      title: "Triangle inequality",
      formula: "|x+y|\\le |x|+|y|",
      note: "Distance inequality.",
    },
  ],
  trigonometry: [
    {
      title: "Sine ratio",
      formula: "\\sin\\theta=\\frac{opposite}{hypotenuse}",
      note: "Right-triangle sine.",
    },
    {
      title: "Cosine ratio",
      formula: "\\cos\\theta=\\frac{adjacent}{hypotenuse}",
      note: "Right-triangle cosine.",
    },
    {
      title: "Tangent ratio",
      formula: "\\tan\\theta=\\frac{opposite}{adjacent}",
      note: "Right-triangle tangent.",
    },
    {
      title: "Tangent quotient",
      formula: "\\tan\\theta=\\frac{\\sin\\theta}{\\cos\\theta}",
      note: "Links tangent to sine and cosine.",
    },
    {
      title: "Cotangent quotient",
      formula: "\\cot\\theta=\\frac{\\cos\\theta}{\\sin\\theta}",
      note: "Reciprocal of tangent.",
    },
    {
      title: "Sine difference",
      formula: "\\sin(a-b)=\\sin a\\cos b-\\cos a\\sin b",
      note: "Sine of angle difference.",
    },
    {
      title: "Cosine difference",
      formula: "\\cos(a-b)=\\cos a\\cos b+\\sin a\\sin b",
      note: "Cosine of angle difference.",
    },
    {
      title: "Tangent sum",
      formula: "\\tan(a+b)=\\frac{\\tan a+\\tan b}{1-\\tan a\\tan b}",
      note: "Combined tangent formula.",
    },
    {
      title: "Tangent difference",
      formula: "\\tan(a-b)=\\frac{\\tan a-\\tan b}{1+\\tan a\\tan b}",
      note: "Difference tangent formula.",
    },
    {
      title: "Cosine double angle alternate",
      formula: "\\cos2x=2\\cos^2x-1",
      note: "Cosine in terms of cos x.",
    },
    {
      title: "Cosine double angle sine form",
      formula: "\\cos2x=1-2\\sin^2x",
      note: "Cosine in terms of sin x.",
    },
    {
      title: "Tangent double angle",
      formula: "\\tan2x=\\frac{2\\tan x}{1-\\tan^2x}",
      note: "Double-angle tangent.",
    },
    {
      title: "Half-angle sine",
      formula: "\\sin^2\\frac{x}{2}=\\frac{1-\\cos x}{2}",
      note: "Half-angle identity.",
    },
    {
      title: "Half-angle cosine",
      formula: "\\cos^2\\frac{x}{2}=\\frac{1+\\cos x}{2}",
      note: "Half-angle identity.",
    },
    {
      title: "Product to sum sine cosine",
      formula: "2\\sin a\\cos b=\\sin(a+b)+\\sin(a-b)",
      note: "Converts product to sum.",
    },
    {
      title: "Sum to product sine",
      formula: "\\sin a+\\sin b=2\\sin\\frac{a+b}{2}\\cos\\frac{a-b}{2}",
      note: "Converts sum to product.",
    },
  ],
  geometry: [
    { title: "Rectangle area", formula: "A=lb", note: "Length times breadth." },
    {
      title: "Rectangle perimeter",
      formula: "P=2(l+b)",
      note: "Boundary length.",
    },
    { title: "Square area", formula: "A=a^2", note: "Side squared." },
    {
      title: "Square diagonal",
      formula: "d=a\\sqrt2",
      note: "From Pythagoras.",
    },
    {
      title: "Equilateral triangle area",
      formula: "A=\\frac{\\sqrt3}{4}a^2",
      note: "For side a.",
    },
    {
      title: "Rhombus area",
      formula: "A=\\frac{1}{2}d_1d_2",
      note: "Half product of diagonals.",
    },
    {
      title: "Regular polygon area",
      formula: "A=\\frac{ns^2}{4\\tan(\\pi/n)}",
      note: "For n sides of length s.",
    },
    {
      title: "Arc length degrees",
      formula: "L=\\frac{\\theta}{360}\\cdot2\\pi r",
      note: "Theta in degrees.",
    },
    {
      title: "Arc length radians",
      formula: "L=r\\theta",
      note: "Theta in radians.",
    },
    {
      title: "Cyclic quadrilateral",
      formula: "\\angle A+\\angle C=180^\\circ",
      note: "Opposite angles are supplementary.",
    },
  ],
  "coordinate-geometry": [
    {
      title: "Section formula internal",
      formula: "P=\\left(\\frac{mx_2+nx_1}{m+n},\\frac{my_2+ny_1}{m+n}\\right)",
      note: "Point dividing segment in m:n internally.",
    },
    {
      title: "Section formula external",
      formula: "P=\\left(\\frac{mx_2-nx_1}{m-n},\\frac{my_2-ny_1}{m-n}\\right)",
      note: "External division.",
    },
    {
      title: "Area of triangle coordinates",
      formula: "A=\\frac{1}{2}|x_1(y_2-y_3)+x_2(y_3-y_1)+x_3(y_1-y_2)|",
      note: "Uses coordinates of vertices.",
    },
    {
      title: "Two intercept form",
      formula: "\\frac{x}{a}+\\frac{y}{b}=1",
      note: "Line with intercepts a and b.",
    },
    {
      title: "Normal form of line",
      formula: "x\\cos\\alpha+y\\sin\\alpha=p",
      note: "p is perpendicular distance from origin.",
    },
    {
      title: "Distance from point to line",
      formula: "d=\\frac{|Ax_1+By_1+C|}{\\sqrt{A^2+B^2}}",
      note: "Perpendicular distance.",
    },
    {
      title: "Pair of parallel lines distance",
      formula: "d=\\frac{|C_1-C_2|}{\\sqrt{A^2+B^2}}",
      note: "For Ax+By+C_1=0 and Ax+By+C_2=0.",
    },
    {
      title: "Hyperbola",
      formula: "\\frac{x^2}{a^2}-\\frac{y^2}{b^2}=1",
      note: "Standard horizontal hyperbola.",
    },
    {
      title: "Conic eccentricity",
      formula: "e=\\frac{c}{a}",
      note: "Defines shape spread.",
    },
    {
      title: "Circle tangent",
      formula: "xx_1+yy_1=r^2",
      note: "Tangent at (x_1,y_1) to x^2+y^2=r^2.",
    },
  ],
  "limits-continuity": [
    {
      title: "Limit quotient law",
      formula:
        "\\lim_{x\\to a}\\frac{f(x)}{g(x)}=\\frac{\\lim f(x)}{\\lim g(x)}",
      note: "Denominator limit must be non-zero.",
    },
    {
      title: "Power limit",
      formula: "\\lim_{x\\to a}[f(x)]^n=[\\lim_{x\\to a}f(x)]^n",
      note: "For fixed n.",
    },
    {
      title: "Left hand limit",
      formula: "\\lim_{x\\to a^-}f(x)=L",
      note: "Approach from smaller x.",
    },
    {
      title: "Right hand limit",
      formula: "\\lim_{x\\to a^+}f(x)=L",
      note: "Approach from larger x.",
    },
    {
      title: "Two-sided limit",
      formula:
        "\\lim_{x\\to a}f(x)=L\\Leftrightarrow \\lim_{x\\to a^-}f(x)=\\lim_{x\\to a^+}f(x)=L",
      note: "Both sides must agree.",
    },
    {
      title: "Infinite limit",
      formula: "\\lim_{x\\to a}f(x)=\\infty",
      note: "Values grow without bound.",
    },
    {
      title: "Limit at infinity",
      formula: "\\lim_{x\\to\\infty}f(x)=L",
      note: "End behavior.",
    },
    {
      title: "Euler limit",
      formula: "\\lim_{n\\to\\infty}\\left(1+\\frac{1}{n}\\right)^n=e",
      note: "Defines e through compound growth.",
    },
  ],
  derivatives: [
    {
      title: "Constant derivative",
      formula: "\\frac{d}{dx}c=0",
      note: "A constant has zero rate of change.",
    },
    {
      title: "Constant multiple rule",
      formula: "\\frac{d}{dx}[cf(x)]=cf'(x)",
      note: "Constants factor out.",
    },
    {
      title: "Sum rule",
      formula: "\\frac{d}{dx}[f(x)+g(x)]=f'(x)+g'(x)",
      note: "Differentiate term by term.",
    },
    {
      title: "Derivative of tangent",
      formula: "\\frac{d}{dx}\\tan x=\\sec^2x",
      note: "Radians only.",
    },
    {
      title: "Derivative of cotangent",
      formula: "\\frac{d}{dx}\\cot x=-\\csc^2x",
      note: "Radians only.",
    },
    {
      title: "Derivative of secant",
      formula: "\\frac{d}{dx}\\sec x=\\sec x\\tan x",
      note: "Trig derivative.",
    },
    {
      title: "Derivative of cosecant",
      formula: "\\frac{d}{dx}\\csc x=-\\csc x\\cot x",
      note: "Trig derivative.",
    },
    {
      title: "Implicit derivative",
      formula: "\\frac{dy}{dx}=-\\frac{F_x}{F_y}",
      note: "For F(x,y)=0 when F_y is non-zero.",
    },
    {
      title: "Second derivative",
      formula: "f''(x)=\\frac{d}{dx}f'(x)",
      note: "Rate of change of slope.",
    },
    {
      title: "Tangent line",
      formula: "y-f(a)=f'(a)(x-a)",
      note: "Line tangent at x=a.",
    },
  ],
  integrals: [
    {
      title: "Integral linearity",
      formula: "\\int[af(x)+bg(x)]\\,dx=a\\int f(x)\\,dx+b\\int g(x)\\,dx",
      note: "Integrate term by term.",
    },
    {
      title: "Integral of tangent",
      formula: "\\int\\tan x\\,dx=\\ln|\\sec x|+C",
      note: "Standard trigonometric integral.",
    },
    {
      title: "Integral of cotangent",
      formula: "\\int\\cot x\\,dx=\\ln|\\sin x|+C",
      note: "Standard trigonometric integral.",
    },
    {
      title: "Integral of sec squared",
      formula: "\\int\\sec^2x\\,dx=\\tan x+C",
      note: "Reverse of tangent derivative.",
    },
    {
      title: "Integral of cosec squared",
      formula: "\\int\\csc^2x\\,dx=-\\cot x+C",
      note: "Reverse of cotangent derivative.",
    },
    {
      title: "Integral of sec tan",
      formula: "\\int\\sec x\\tan x\\,dx=\\sec x+C",
      note: "Reverse of secant derivative.",
    },
    {
      title: "Integral of csc cot",
      formula: "\\int\\csc x\\cot x\\,dx=-\\csc x+C",
      note: "Reverse of cosecant derivative.",
    },
    {
      title: "Definite integral additivity",
      formula: "\\int_a^c f(x)\\,dx=\\int_a^b f(x)\\,dx+\\int_b^c f(x)\\,dx",
      note: "Split intervals.",
    },
    {
      title: "Even function integral",
      formula: "\\int_{-a}^{a}f(x)\\,dx=2\\int_0^a f(x)\\,dx",
      note: "For even f.",
    },
    {
      title: "Odd function integral",
      formula: "\\int_{-a}^{a}f(x)\\,dx=0",
      note: "For odd f.",
    },
  ],
  "differential-equations": [
    {
      title: "Exact differential equation",
      formula: "M(x,y)dx+N(x,y)dy=0",
      note: "Exact when M_y=N_x.",
    },
    {
      title: "Exactness condition",
      formula:
        "\\frac{\\partial M}{\\partial y}=\\frac{\\partial N}{\\partial x}",
      note: "Test for exact equations.",
    },
    {
      title: "Homogeneous substitution",
      formula: "y=vx",
      note: "Used for homogeneous first-order equations.",
    },
    {
      title: "Characteristic roots distinct",
      formula: "y=C_1e^{r_1x}+C_2e^{r_2x}",
      note: "For two distinct real roots.",
    },
    {
      title: "Characteristic roots repeated",
      formula: "y=(C_1+C_2x)e^{rx}",
      note: "For repeated root r.",
    },
    {
      title: "Complex roots solution",
      formula: "y=e^{\\alpha x}(C_1\\cos\\beta x+C_2\\sin\\beta x)",
      note: "For roots alpha plus/minus beta i.",
    },
    {
      title: "Newton cooling",
      formula: "\\frac{dT}{dt}=-k(T-T_s)",
      note: "Temperature difference model.",
    },
    {
      title: "Simple harmonic motion",
      formula: "\\frac{d^2x}{dt^2}+\\omega^2x=0",
      note: "Oscillation model.",
    },
  ],
  matrices: [
    {
      title: "Associative multiplication",
      formula: "A(BC)=(AB)C",
      note: "Matrix multiplication is associative.",
    },
    {
      title: "Distributive law",
      formula: "A(B+C)=AB+AC",
      note: "Multiplication distributes over addition.",
    },
    {
      title: "Transpose of sum",
      formula: "(A+B)^T=A^T+B^T",
      note: "Transpose distributes over addition.",
    },
    {
      title: "Transpose of product",
      formula: "(AB)^T=B^TA^T",
      note: "Order reverses.",
    },
    {
      title: "Inverse of product",
      formula: "(AB)^{-1}=B^{-1}A^{-1}",
      note: "Order reverses for inverses.",
    },
    {
      title: "Symmetric matrix",
      formula: "A^T=A",
      note: "Equal to its transpose.",
    },
    {
      title: "Skew-symmetric matrix",
      formula: "A^T=-A",
      note: "Diagonal entries are zero.",
    },
    {
      title: "Orthogonal matrix",
      formula: "A^TA=I",
      note: "Columns are orthonormal.",
    },
  ],
  determinants: [
    {
      title: "Row interchange sign",
      formula: "R_i\\leftrightarrow R_j\\Rightarrow |A|\\to-|A|",
      note: "Swapping rows changes sign.",
    },
    {
      title: "Scalar row factor",
      formula: "R_i\\to kR_i\\Rightarrow |A|\\to k|A|",
      note: "Scaling one row scales determinant.",
    },
    {
      title: "Identical rows",
      formula: "R_i=R_j\\Rightarrow |A|=0",
      note: "Dependent rows give zero determinant.",
    },
    {
      title: "Triangular determinant",
      formula: "|A|=a_{11}a_{22}\\cdots a_{nn}",
      note: "For triangular matrices.",
    },
    {
      title: "Transpose determinant",
      formula: "|A^T|=|A|",
      note: "Transpose preserves determinant.",
    },
    {
      title: "Inverse determinant",
      formula: "|A^{-1}|=\\frac{1}{|A|}",
      note: "For non-singular A.",
    },
    {
      title: "Scalar matrix determinant",
      formula: "|kA|=k^n|A|",
      note: "For n by n matrix A.",
    },
    {
      title: "Area scale",
      formula: "\\text{area scale}=|\\det A|",
      note: "For 2D linear transformations.",
    },
  ],
  vectors: [
    {
      title: "Vector addition",
      formula:
        "\\vec a+\\vec b=(a_1+b_1)\\hat i+(a_2+b_2)\\hat j+(a_3+b_3)\\hat k",
      note: "Add components.",
    },
    {
      title: "Scalar multiplication",
      formula: "k\\vec a=(ka_1)\\hat i+(ka_2)\\hat j+(ka_3)\\hat k",
      note: "Scale every component.",
    },
    {
      title: "Direction cosines",
      formula:
        "l=\\frac{a_1}{|\\vec a|},\\quad m=\\frac{a_2}{|\\vec a|},\\quad n=\\frac{a_3}{|\\vec a|}",
      note: "Cosines with coordinate axes.",
    },
    {
      title: "Direction cosine identity",
      formula: "l^2+m^2+n^2=1",
      note: "For a non-zero vector.",
    },
    {
      title: "Cross product determinant",
      formula:
        "\\vec a\\times\\vec b=\\begin{vmatrix}\\hat i&\\hat j&\\hat k\\\\a_1&a_2&a_3\\\\b_1&b_2&b_3\\end{vmatrix}",
      note: "Component formula.",
    },
    {
      title: "Parallel vectors",
      formula: "\\vec a\\times\\vec b=\\vec0",
      note: "Non-zero parallel vectors have zero cross product.",
    },
    {
      title: "Perpendicular vectors",
      formula: "\\vec a\\cdot\\vec b=0",
      note: "Orthogonal vectors.",
    },
    {
      title: "Vector area triangle",
      formula: "A=\\frac{1}{2}|\\vec a\\times\\vec b|",
      note: "Area from two side vectors.",
    },
  ],
  "three-d-geometry": [
    {
      title: "Distance between 3D points",
      formula: "d=\\sqrt{(x_2-x_1)^2+(y_2-y_1)^2+(z_2-z_1)^2}",
      note: "3D distance formula.",
    },
    {
      title: "Direction ratios",
      formula: "a=x_2-x_1,\\quad b=y_2-y_1,\\quad c=z_2-z_1",
      note: "For a line through two points.",
    },
    {
      title: "Direction cosines of line",
      formula: "l=\\frac{a}{\\sqrt{a^2+b^2+c^2}}",
      note: "Similarly for m and n.",
    },
    {
      title: "Plane through point normal",
      formula: "A(x-x_1)+B(y-y_1)+C(z-z_1)=0",
      note: "Normal vector is (A,B,C).",
    },
    {
      title: "Angle between lines",
      formula:
        "\\cos\\theta=\\frac{|a_1a_2+b_1b_2+c_1c_2|}{\\sqrt{a_1^2+b_1^2+c_1^2}\\sqrt{a_2^2+b_2^2+c_2^2}}",
      note: "Uses direction ratios.",
    },
    {
      title: "Parallel planes",
      formula: "\\frac{A_1}{A_2}=\\frac{B_1}{B_2}=\\frac{C_1}{C_2}",
      note: "Normals are parallel.",
    },
    {
      title: "Perpendicular planes",
      formula: "A_1A_2+B_1B_2+C_1C_2=0",
      note: "Normals are perpendicular.",
    },
    {
      title: "Sphere equation",
      formula: "(x-a)^2+(y-b)^2+(z-c)^2=r^2",
      note: "Center is (a,b,c).",
    },
  ],
  "complex-numbers": [
    {
      title: "Real part",
      formula: "\\operatorname{Re}(a+bi)=a",
      note: "Horizontal coordinate.",
    },
    {
      title: "Imaginary part",
      formula: "\\operatorname{Im}(a+bi)=b",
      note: "Vertical coordinate coefficient.",
    },
    {
      title: "Conjugate product",
      formula: "z\\overline z=|z|^2",
      note: "Product with conjugate gives squared modulus.",
    },
    {
      title: "Argument",
      formula: "\\arg z=\\tan^{-1}\\frac{b}{a}",
      note: "Adjust quadrant as needed.",
    },
    {
      title: "Complex multiplication polar",
      formula:
        "r_1e^{i\\theta_1}r_2e^{i\\theta_2}=r_1r_2e^{i(\\theta_1+\\theta_2)}",
      note: "Moduli multiply and arguments add.",
    },
    {
      title: "Complex division polar",
      formula:
        "\\frac{r_1e^{i\\theta_1}}{r_2e^{i\\theta_2}}=\\frac{r_1}{r_2}e^{i(\\theta_1-\\theta_2)}",
      note: "Arguments subtract.",
    },
    {
      title: "Euler identity",
      formula: "e^{i\\pi}+1=0",
      note: "Special case of Euler formula.",
    },
    {
      title: "Complex exponential",
      formula: "e^{a+bi}=e^a(\\cos b+i\\sin b)",
      note: "Splits growth and rotation.",
    },
  ],
  "sequences-series": [
    {
      title: "Arithmetic mean",
      formula: "A=\\frac{a+b}{2}",
      note: "Mean between two numbers.",
    },
    {
      title: "Geometric mean",
      formula: "G=\\sqrt{ab}",
      note: "Positive numbers a and b.",
    },
    {
      title: "Harmonic mean",
      formula: "H=\\frac{2ab}{a+b}",
      note: "Reciprocal average.",
    },
    {
      title: "AM GM inequality",
      formula: "\\frac{a+b}{2}\\ge\\sqrt{ab}",
      note: "For non-negative a and b.",
    },
    {
      title: "Sum of cubes",
      formula: "1^3+2^3+\\cdots+n^3=\\left(\\frac{n(n+1)}{2}\\right)^2",
      note: "Square of triangular number.",
    },
    {
      title: "Harmonic series",
      formula: "\\sum_{n=1}^{\\infty}\\frac{1}{n}\\text{ diverges}",
      note: "Classic divergent series.",
    },
    {
      title: "p-series test",
      formula: "\\sum_{n=1}^{\\infty}\\frac{1}{n^p}\\text{ converges if }p>1",
      note: "Diverges for p less than or equal to 1.",
    },
    {
      title: "Taylor series",
      formula: "f(x)=\\sum_{n=0}^{\\infty}\\frac{f^{(n)}(a)}{n!}(x-a)^n",
      note: "Expansion around a.",
    },
  ],
  combinatorics: [
    {
      title: "Combination symmetry",
      formula: "\\binom{n}{r}=\\binom{n}{n-r}",
      note: "Choosing r equals leaving n-r.",
    },
    {
      title: "Binomial coefficient factorial",
      formula: "\\binom{n}{r}=\\frac{n!}{r!(n-r)!}",
      note: "Combination formula.",
    },
    {
      title: "Total subsets",
      formula: "|\\mathcal P(A)|=2^n",
      note: "For a set with n elements.",
    },
    {
      title: "Non-empty subsets",
      formula: "2^n-1",
      note: "Exclude the empty set.",
    },
    {
      title: "Multiplication principle",
      formula: "N=n_1n_2\\cdots n_k",
      note: "Independent stages multiply.",
    },
    {
      title: "Addition principle",
      formula: "N=n_1+n_2+\\cdots+n_k",
      note: "Mutually exclusive choices add.",
    },
    {
      title: "Derangement approximation",
      formula: "!n\\approx\\frac{n!}{e}",
      note: "Permutations with no fixed points.",
    },
    {
      title: "Stars and bars",
      formula: "\\binom{n+r-1}{r-1}",
      note: "Non-negative solutions to x_1+...+x_r=n.",
    },
  ],
  "set-theory-logic": [
    {
      title: "Double complement",
      formula: "(A')'=A",
      note: "Complement twice returns original set.",
    },
    {
      title: "Idempotent union",
      formula: "A\\cup A=A",
      note: "Set union with itself.",
    },
    {
      title: "Idempotent intersection",
      formula: "A\\cap A=A",
      note: "Set intersection with itself.",
    },
    {
      title: "Distributive union",
      formula: "A\\cup(B\\cap C)=(A\\cup B)\\cap(A\\cup C)",
      note: "Union distributes over intersection.",
    },
    {
      title: "Distributive intersection",
      formula: "A\\cap(B\\cup C)=(A\\cap B)\\cup(A\\cap C)",
      note: "Intersection distributes over union.",
    },
    {
      title: "Biconditional equivalence",
      formula:
        "p\\Leftrightarrow q\\equiv(p\\Rightarrow q)\\land(q\\Rightarrow p)",
      note: "Both implications.",
    },
    {
      title: "Negated implication",
      formula: "\\neg(p\\Rightarrow q)\\equiv p\\land\\neg q",
      note: "Only false implication case.",
    },
    { title: "Truth table rows", formula: "2^n", note: "For n propositions." },
  ],
  "linear-programming": [
    {
      title: "Matrix objective",
      formula: "Z=c^Tx",
      note: "Compact objective notation.",
    },
    {
      title: "Feasible set matrix form",
      formula: "S=\\{x:Ax\\le b,x\\ge0\\}",
      note: "All feasible vectors.",
    },
    {
      title: "Binding constraint",
      formula: "a_ix=b_i",
      note: "Active at a boundary point.",
    },
    {
      title: "Surplus variable",
      formula: "a_ix-s_i=b_i",
      note: "For greater-than constraints.",
    },
    {
      title: "Simplex reduced cost",
      formula: "\\bar c_j=c_j-c_B^TB^{-1}A_j",
      note: "Optimization diagnostic.",
    },
    {
      title: "Basic solution",
      formula: "x_B=B^{-1}b",
      note: "For a chosen basis B.",
    },
    {
      title: "Dual standard form",
      formula: "\\min b^Ty,\\quad A^Ty\\ge c",
      note: "Dual of max Ax<=b form.",
    },
    {
      title: "Weak duality",
      formula: "c^Tx\\le b^Ty",
      note: "For primal feasible x and dual feasible y.",
    },
  ],
  "relations-functions": [
    {
      title: "Reflexive relation",
      formula: "(a,a)\\in R\\text{ for all }a\\in A",
      note: "Every element relates to itself.",
    },
    {
      title: "Symmetric relation",
      formula: "(a,b)\\in R\\Rightarrow(b,a)\\in R",
      note: "Relation reverses.",
    },
    {
      title: "Transitive relation",
      formula: "(a,b),(b,c)\\in R\\Rightarrow(a,c)\\in R",
      note: "Relation chains.",
    },
    {
      title: "Equivalence relation",
      formula: "R\\text{ is reflexive, symmetric, and transitive}",
      note: "Creates equivalence classes.",
    },
    {
      title: "Function equality",
      formula:
        "f=g\\Leftrightarrow f(x)=g(x)\\text{ for all }x\\in\\operatorname{Dom}",
      note: "Same output for every input.",
    },
    {
      title: "Even function",
      formula: "f(-x)=f(x)",
      note: "Symmetric about y-axis.",
    },
    {
      title: "Odd function",
      formula: "f(-x)=-f(x)",
      note: "Symmetric about origin.",
    },
    { title: "Periodicity", formula: "f(x+T)=f(x)", note: "T is a period." },
  ],
  "mensuration-units": [
    { title: "Triangle perimeter", formula: "P=a+b+c", note: "Sum of sides." },
    {
      title: "Circle diameter",
      formula: "d=2r",
      note: "Diameter is twice radius.",
    },
    {
      title: "Circle sector perimeter",
      formula: "P=2r+\\frac{\\theta}{360}\\cdot2\\pi r",
      note: "Two radii plus arc.",
    },
    {
      title: "Hemisphere curved area",
      formula: "CSA=2\\pi r^2",
      note: "Curved surface only.",
    },
    {
      title: "Hemisphere total area",
      formula: "TSA=3\\pi r^2",
      note: "Includes circular base.",
    },
    {
      title: "Hemisphere volume",
      formula: "V=\\frac{2}{3}\\pi r^3",
      note: "Half sphere volume.",
    },
    {
      title: "Cylinder curved area",
      formula: "CSA=2\\pi rh",
      note: "Lateral surface area.",
    },
    {
      title: "Cone slant height",
      formula: "l=\\sqrt{r^2+h^2}",
      note: "Right circular cone.",
    },
    {
      title: "Sphere volume",
      formula: "V=\\frac{4}{3}\\pi r^3",
      note: "Volume of a sphere.",
    },
    {
      title: "Torus volume",
      formula: "V=2\\pi^2Rr^2",
      note: "Major radius R and minor radius r.",
    },
  ],
};

const advancedFormulaCategories: FormulaCategory[] = [
  {
    id: "early-number-sense",
    title: "Early Number Sense",
    description:
      "KG to primary formulas and rules for counting, place value, comparison, and simple arithmetic.",
    formulas: [
      {
        title: "Counting forward",
        formula: "n,next=n+1",
        note: "The next counting number is one more.",
      },
      {
        title: "Counting backward",
        formula: "n,previous=n-1",
        note: "The previous counting number is one less.",
      },
      {
        title: "Place value",
        formula: "N=100h+10t+u",
        note: "Hundreds, tens, and ones.",
      },
      {
        title: "Expanded form",
        formula: "345=300+40+5",
        note: "Breaks a number by place value.",
      },
      {
        title: "Addition commutative",
        formula: "a+b=b+a",
        note: "Order does not change a sum.",
      },
      {
        title: "Multiplication commutative",
        formula: "ab=ba",
        note: "Order does not change a product.",
      },
      {
        title: "Addition identity",
        formula: "a+0=a",
        note: "Zero does not change a number.",
      },
      {
        title: "Multiplication identity",
        formula: "a\\times1=a",
        note: "One does not change a product.",
      },
      {
        title: "Repeated addition",
        formula: "a+a+\\cdots+a=na",
        note: "n equal groups of a.",
      },
      {
        title: "Number comparison",
        formula: "a>b\\Leftrightarrow a-b>0",
        note: "Compare by the sign of the difference.",
      },
    ],
  },
  {
    id: "fractions-decimals-percent",
    title: "Fractions, Decimals, Percent",
    description:
      "Primary and middle-school rules for fraction arithmetic, decimal movement, ratios, and percentage change.",
    formulas: [
      {
        title: "Equivalent fractions",
        formula: "\\frac{a}{b}=\\frac{ka}{kb}",
        note: "k is non-zero.",
      },
      {
        title: "Fraction addition",
        formula: "\\frac{a}{b}+\\frac{c}{d}=\\frac{ad+bc}{bd}",
        note: "Use common denominator bd.",
      },
      {
        title: "Fraction subtraction",
        formula: "\\frac{a}{b}-\\frac{c}{d}=\\frac{ad-bc}{bd}",
        note: "Use common denominator bd.",
      },
      {
        title: "Fraction multiplication",
        formula: "\\frac{a}{b}\\cdot\\frac{c}{d}=\\frac{ac}{bd}",
        note: "Multiply numerators and denominators.",
      },
      {
        title: "Fraction division",
        formula: "\\frac{a}{b}\\div\\frac{c}{d}=\\frac{a}{b}\\cdot\\frac{d}{c}",
        note: "Multiply by reciprocal.",
      },
      {
        title: "Decimal to percent",
        formula: "p=100d\\%",
        note: "Multiply the decimal by 100.",
      },
      {
        title: "Percent to decimal",
        formula: "d=\\frac{p}{100}",
        note: "Divide percent number by 100.",
      },
      {
        title: "Percent of a number",
        formula: "p\\%\\text{ of }N=\\frac{p}{100}N",
        note: "Basic percentage amount.",
      },
      {
        title: "Percentage change",
        formula: "\\%\\Delta=\\frac{new-old}{old}\\times100\\%",
        note: "Increase or decrease relative to old value.",
      },
      {
        title: "Ratio equality",
        formula: "a:b=c:d\\Leftrightarrow ad=bc",
        note: "Cross product test for proportions.",
      },
    ],
  },
  {
    id: "commercial-math",
    title: "Commercial Math",
    description:
      "Profit, loss, discounts, tax, interest, installment, and growth formulas.",
    formulas: [
      {
        title: "Profit",
        formula: "Profit=SP-CP",
        note: "Selling price minus cost price.",
      },
      {
        title: "Loss",
        formula: "Loss=CP-SP",
        note: "Cost price minus selling price.",
      },
      {
        title: "Profit percent",
        formula: "Profit\\%=\\frac{Profit}{CP}\\times100\\%",
        note: "Profit as percent of cost.",
      },
      {
        title: "Loss percent",
        formula: "Loss\\%=\\frac{Loss}{CP}\\times100\\%",
        note: "Loss as percent of cost.",
      },
      {
        title: "Discount",
        formula: "Discount=MP-SP",
        note: "Marked price minus selling price.",
      },
      {
        title: "Discount percent",
        formula: "Discount\\%=\\frac{Discount}{MP}\\times100\\%",
        note: "Discount as percent of marked price.",
      },
      {
        title: "Simple interest",
        formula: "SI=\\frac{PRT}{100}",
        note: "Principal P, rate R percent, time T years.",
      },
      {
        title: "Compound amount",
        formula: "A=P\\left(1+\\frac{r}{n}\\right)^{nt}",
        note: "n compoundings per year.",
      },
      {
        title: "Compound interest",
        formula: "CI=A-P",
        note: "Interest earned after compounding.",
      },
      {
        title: "Tax-inclusive price",
        formula: "Final=Base\\left(1+\\frac{tax}{100}\\right)",
        note: "Adds tax percentage.",
      },
    ],
  },
  {
    id: "competitive-speed-time-work",
    title: "Competitive Speed Time Distance and Work",
    description:
      "Quantitative aptitude formulas for speed, distance, relative motion, trains, boats, races, time and work, pipes, cisterns, and efficiency.",
    formulas: [
      {
        title: "Speed",
        formula: "S=\\frac{D}{T}",
        note: "Speed equals distance divided by time.",
      },
      {
        title: "Distance",
        formula: "D=ST",
        note: "Distance equals speed times time.",
      },
      {
        title: "Time",
        formula: "T=\\frac{D}{S}",
        note: "Time equals distance divided by speed.",
      },
      {
        title: "Unit speed conversion",
        formula: "1\\,m/s=\\frac{18}{5}\\,km/h",
        note: "Multiply meters per second by 18/5.",
      },
      {
        title: "Unit speed conversion inverse",
        formula: "1\\,km/h=\\frac{5}{18}\\,m/s",
        note: "Multiply kilometers per hour by 5/18.",
      },
      {
        title: "Average speed",
        formula: "S_{avg}=\\frac{total\\ distance}{total\\ time}",
        note: "Use total distance over total time, not the average of speeds.",
      },
      {
        title: "Average speed equal distances",
        formula: "S_{avg}=\\frac{2uv}{u+v}",
        note: "For two equal-distance parts at speeds u and v.",
      },
      {
        title: "Average speed three equal distances",
        formula: "S_{avg}=\\frac{3uvw}{uv+vw+wu}",
        note: "For three equal-distance parts at speeds u, v, and w.",
      },
      {
        title: "Average speed equal times",
        formula: "S_{avg}=\\frac{u+v}{2}",
        note: "For two equal-time parts at speeds u and v.",
      },
      {
        title: "Relative speed opposite direction",
        formula: "S_{rel}=u+v",
        note: "Objects moving toward each other or in opposite directions.",
      },
      {
        title: "Relative speed same direction",
        formula: "S_{rel}=|u-v|",
        note: "Objects moving in the same direction.",
      },
      {
        title: "Catch-up time",
        formula: "T=\\frac{gap}{u-v}",
        note: "Faster object at speed u catches slower object at speed v.",
      },
      {
        title: "Head start distance",
        formula: "gap=s\\times t",
        note: "Initial lead produced by speed s for time t.",
      },
      {
        title: "Race lead by distance",
        formula: "lead=D\\left(1-\\frac{v}{u}\\right)",
        note: "When faster speed u finishes distance D while slower speed is v.",
      },
      {
        title: "Race time beat",
        formula: "time\\ beat=\\frac{D}{v}-\\frac{D}{u}",
        note: "Difference in finishing times for distance D.",
      },
      {
        title: "Circular track first meeting same direction",
        formula: "T=\\frac{L}{|u-v|}",
        note: "L is track length.",
      },
      {
        title: "Circular track first meeting opposite direction",
        formula: "T=\\frac{L}{u+v}",
        note: "First meeting on a circular track from the same point.",
      },
      {
        title: "Train crosses pole",
        formula: "T=\\frac{L_{train}}{S}",
        note: "Only train length must pass the pole.",
      },
      {
        title: "Train crosses platform",
        formula: "T=\\frac{L_{train}+L_{platform}}{S}",
        note: "Train plus platform length must pass.",
      },
      {
        title: "Two trains crossing opposite direction",
        formula: "T=\\frac{L_1+L_2}{u+v}",
        note: "Use sum of train lengths and sum of speeds.",
      },
      {
        title: "Two trains crossing same direction",
        formula: "T=\\frac{L_1+L_2}{|u-v|}",
        note: "Use sum of train lengths and relative speed.",
      },
      {
        title: "Boat downstream speed",
        formula: "D_s=b+c",
        note: "Boat speed in still water b plus stream speed c.",
      },
      {
        title: "Boat upstream speed",
        formula: "U_s=b-c",
        note: "Boat speed in still water b minus stream speed c.",
      },
      {
        title: "Boat still-water speed",
        formula: "b=\\frac{D_s+U_s}{2}",
        note: "Average of downstream and upstream speeds.",
      },
      {
        title: "Stream speed",
        formula: "c=\\frac{D_s-U_s}{2}",
        note: "Half the difference of downstream and upstream speeds.",
      },
      {
        title: "Downstream time",
        formula: "T_d=\\frac{D}{b+c}",
        note: "Time downstream for distance D.",
      },
      {
        title: "Upstream time",
        formula: "T_u=\\frac{D}{b-c}",
        note: "Time upstream for distance D.",
      },
      {
        title: "Escalator effective speed",
        formula: "S_{eff}=S_{person}\\pm S_{stairs}",
        note: "Add when moving with escalator, subtract against it.",
      },
      {
        title: "Work rate",
        formula: "R=\\frac{1}{T}",
        note: "If a person finishes work in T days.",
      },
      { title: "Work done", formula: "W=RT", note: "Rate times time." },
      {
        title: "Combined work rate",
        formula: "R_{total}=R_1+R_2+\\cdots+R_n",
        note: "Add individual work rates.",
      },
      {
        title: "Two-person work time",
        formula: "T=\\frac{xy}{x+y}",
        note: "If A alone takes x days and B alone takes y days.",
      },
      {
        title: "Three-person work time",
        formula: "T=\\frac{xyz}{xy+yz+zx}",
        note: "If three people alone take x, y, and z days.",
      },
      {
        title: "Work from efficiency",
        formula: "T\\propto\\frac{1}{E}",
        note: "Time is inversely proportional to efficiency.",
      },
      {
        title: "Efficiency ratio from time",
        formula: "E_1:E_2=T_2:T_1",
        note: "Efficiency ratio is inverse of time ratio.",
      },
      {
        title: "Man-day work",
        formula: "M_1D_1H_1E_1=M_2D_2H_2E_2",
        note: "Men, days, hours, and efficiency relation for same work.",
      },
      {
        title: "Work with wages",
        formula:
          "Wage\\ share=Total\\ wage\\times\\frac{work\\ done}{total\\ work}",
        note: "Distribute wages in proportion to work.",
      },
      {
        title: "Pipe filling rate",
        formula: "R_f=\\frac{1}{T_f}",
        note: "A filling pipe that fills in T_f hours.",
      },
      {
        title: "Pipe emptying rate",
        formula: "R_e=-\\frac{1}{T_e}",
        note: "An emptying pipe that empties in T_e hours.",
      },
      {
        title: "Pipes net rate",
        formula: "R_{net}=\\sum R_f-\\sum\\frac{1}{T_e}",
        note: "Fill rates minus leak or emptying rates.",
      },
      {
        title: "Tank filling time",
        formula: "T=\\frac{1}{R_{net}}",
        note: "Reciprocal of net pipe rate.",
      },
      {
        title: "Leak time relation",
        formula: "\\frac{1}{T_{net}}=\\frac{1}{T_{fill}}-\\frac{1}{T_{leak}}",
        note: "One fill pipe and one leak.",
      },
      {
        title: "Fractional work remaining",
        formula: "W_{left}=1-W_{done}",
        note: "Total job is treated as one whole.",
      },
      {
        title: "Alternate-day work two workers",
        formula: "work\\ per\\ cycle=\\frac{1}{x}+\\frac{1}{y}",
        note: "Use cycle work, then handle leftover days.",
      },
      {
        title: "Direct variation",
        formula: "\\frac{x_1}{y_1}=\\frac{x_2}{y_2}",
        note: "For x proportional to y.",
      },
      {
        title: "Inverse variation",
        formula: "x_1y_1=x_2y_2",
        note: "For x inversely proportional to y.",
      },
      {
        title: "Rate unit cost",
        formula: "unit\\ cost=\\frac{total\\ cost}{quantity}",
        note: "Useful for comparison questions.",
      },
      {
        title: "Quantity from rate",
        formula: "quantity=rate\\times time",
        note: "Generic rate-time model.",
      },
      {
        title: "Productivity index",
        formula: "P=\\frac{output}{time}",
        note: "Output produced per unit time.",
      },
      {
        title: "Speed percentage change time",
        formula: "T_{new}=\\frac{T_{old}}{1+\\frac{p}{100}}",
        note: "If speed increases by p percent for same distance.",
      },
      {
        title: "Speed decrease time",
        formula: "T_{new}=\\frac{T_{old}}{1-\\frac{p}{100}}",
        note: "If speed decreases by p percent for same distance.",
      },
      {
        title: "Late early speed relation",
        formula: "D\\left(\\frac{1}{s_1}-\\frac{1}{s_2}\\right)=\\Delta T",
        note: "Difference in arrival time for two speeds over same distance.",
      },
    ],
  },
  {
    id: "mental-math",
    title: "Mental Math and Vedic Tricks",
    description:
      "Fast arithmetic identities, estimation rules, and common calculation shortcuts.",
    formulas: [
      {
        title: "Square near base",
        formula: "(a+b)^2=a^2+2ab+b^2",
        note: "Useful for mental squaring.",
      },
      {
        title: "Difference near base",
        formula: "(a+b)(a-b)=a^2-b^2",
        note: "Fast product around a center.",
      },
      {
        title: "Ending in 5 square",
        formula: "(10a+5)^2=100a(a+1)+25",
        note: "Example: 35 squared equals 1225.",
      },
      {
        title: "Multiplying by 9",
        formula: "9n=10n-n",
        note: "Subtract once from ten times.",
      },
      {
        title: "Multiplying by 11",
        formula: "11n=10n+n",
        note: "Add n to ten times n.",
      },
      {
        title: "Average from assumed mean",
        formula: "\\bar x=A+\\frac{\\sum d_i}{n}",
        note: "d_i are deviations from assumed mean A.",
      },
      {
        title: "Rounding estimate",
        formula: "x\\approx nearest\\ place\\ value",
        note: "Estimate by rounding to useful precision.",
      },
      {
        title: "Complement to 100",
        formula: "a+(100-a)=100",
        note: "Useful for subtraction and percent.",
      },
      {
        title: "Product adjustment",
        formula: "(a+r)b=ab+rb",
        note: "Distribute a small adjustment.",
      },
      {
        title: "Half and double",
        formula: "ab=\\left(\\frac{a}{2}\\right)(2b)",
        note: "Simplifies products when one factor is even.",
      },
    ],
  },
  {
    id: "pre-algebra",
    title: "Pre-Algebra",
    description:
      "Middle-school bridge from arithmetic to variables, expressions, equations, and inequalities.",
    formulas: [
      {
        title: "Order of operations",
        formula:
          "Brackets\\rightarrow Powers\\rightarrow Multiply/Divide\\rightarrow Add/Subtract",
        note: "Standard evaluation priority.",
      },
      {
        title: "Distributive property",
        formula: "a(b+c)=ab+ac",
        note: "Expands grouped terms.",
      },
      {
        title: "Collect like terms",
        formula: "ax+bx=(a+b)x",
        note: "Combine same variable powers.",
      },
      {
        title: "One-step equation",
        formula: "x+a=b\\Rightarrow x=b-a",
        note: "Undo addition.",
      },
      {
        title: "Two-step equation",
        formula: "ax+b=c\\Rightarrow x=\\frac{c-b}{a}",
        note: "Undo addition then multiplication.",
      },
      {
        title: "Inequality flip",
        formula: "a<b\\Rightarrow -a>-b",
        note: "Multiplying by a negative reverses direction.",
      },
      {
        title: "Ratio to fraction",
        formula: "a:b=\\frac{a}{b}",
        note: "A ratio can be written as a fraction.",
      },
      {
        title: "Direct proportion",
        formula: "y=kx",
        note: "Constant ratio y over x.",
      },
      {
        title: "Inverse proportion",
        formula: "xy=k",
        note: "Product stays constant.",
      },
      {
        title: "Unit rate",
        formula: "rate=\\frac{quantity}{unit}",
        note: "Amount per one unit.",
      },
    ],
  },
  {
    id: "polynomials",
    title: "Polynomials",
    description:
      "Polynomial operations, roots, factor theorems, symmetric sums, and standard identities.",
    formulas: [
      {
        title: "Polynomial degree",
        formula: "P(x)=a_nx^n+\\cdots+a_0",
        note: "n is the degree when a_n is non-zero.",
      },
      {
        title: "Remainder theorem",
        formula: "remainder=P(a)\\text{ when divided by }x-a",
        note: "Evaluate at the divisor root.",
      },
      {
        title: "Factor theorem",
        formula: "P(a)=0\\Leftrightarrow (x-a)\\text{ is a factor}",
        note: "Tests linear factors.",
      },
      {
        title: "Quadratic root sum",
        formula: "\\alpha+\\beta=-\\frac{b}{a}",
        note: "For ax^2+bx+c.",
      },
      {
        title: "Quadratic root product",
        formula: "\\alpha\\beta=\\frac{c}{a}",
        note: "For ax^2+bx+c.",
      },
      {
        title: "Cubic root sum",
        formula: "\\alpha+\\beta+\\gamma=-\\frac{b}{a}",
        note: "For ax^3+bx^2+cx+d.",
      },
      {
        title: "Cubic pair sum",
        formula: "\\alpha\\beta+\\beta\\gamma+\\gamma\\alpha=\\frac{c}{a}",
        note: "Second symmetric sum.",
      },
      {
        title: "Cubic root product",
        formula: "\\alpha\\beta\\gamma=-\\frac{d}{a}",
        note: "Product of roots.",
      },
      {
        title: "Binomial theorem",
        formula: "(x+y)^n=\\sum_{r=0}^{n}\\binom nr x^{n-r}y^r",
        note: "Expansion for non-negative integer n.",
      },
      {
        title: "Finite differences",
        formula: "\\Delta P(n)=P(n+1)-P(n)",
        note: "Degree drops by one for polynomials.",
      },
    ],
  },
  {
    id: "inequalities",
    title: "Inequalities",
    description:
      "Absolute value, AM-GM, Cauchy, Jensen, Holder, and olympiad inequality tools.",
    formulas: [
      {
        title: "Absolute inequality",
        formula: "|x|<a\\Leftrightarrow -a<x<a",
        note: "For a positive.",
      },
      {
        title: "Triangle inequality",
        formula: "|x+y|\\le |x|+|y|",
        note: "Core distance inequality.",
      },
      {
        title: "Reverse triangle inequality",
        formula: "\\big||x|-|y|\\big|\\le |x-y|",
        note: "Lower bound for distances.",
      },
      {
        title: "AM-GM",
        formula: "\\frac{x_1+\\cdots+x_n}{n}\\ge \\sqrt[n]{x_1\\cdots x_n}",
        note: "For non-negative values.",
      },
      {
        title: "Cauchy-Schwarz",
        formula:
          "\\left(\\sum a_ib_i\\right)^2\\le\\left(\\sum a_i^2\\right)\\left(\\sum b_i^2\\right)",
        note: "Inner-product inequality.",
      },
      {
        title: "Titu Andreescu lemma",
        formula: "\\sum\\frac{x_i^2}{a_i}\\ge\\frac{(\\sum x_i)^2}{\\sum a_i}",
        note: "For positive a_i.",
      },
      {
        title: "Jensen inequality",
        formula: "f\\left(\\sum w_ix_i\\right)\\le\\sum w_if(x_i)",
        note: "For convex f and weights summing to 1.",
      },
      {
        title: "Holder inequality",
        formula:
          "\\sum a_ib_ic_i\\le\\left(\\sum a_i^p\\right)^{1/p}\\left(\\sum b_i^q\\right)^{1/q}\\left(\\sum c_i^r\\right)^{1/r}",
        note: "Generalized product bound.",
      },
      {
        title: "Bernoulli inequality",
        formula: "(1+x)^r\\ge1+rx",
        note: "For r at least 1 and x greater than -1.",
      },
      {
        title: "Power mean order",
        formula: "M_r\\ge M_s\\text{ when }r>s",
        note: "Means increase with order.",
      },
    ],
  },
  {
    id: "olympiad-number-theory",
    title: "Olympiad Number Theory",
    description:
      "Divisibility, gcd, modular arithmetic, Diophantine equations, and classical theorems.",
    formulas: [
      {
        title: "Euclidean algorithm",
        formula: "\\gcd(a,b)=\\gcd(b,a\\bmod b)",
        note: "Repeated remainder method.",
      },
      {
        title: "Bezout identity",
        formula: "ax+by=\\gcd(a,b)",
        note: "Integer solutions exist for gcd.",
      },
      {
        title: "LCM-GCD product",
        formula: "\\operatorname{lcm}(a,b)\\gcd(a,b)=|ab|",
        note: "For non-zero integers.",
      },
      {
        title: "Euler theorem",
        formula: "a^{\\varphi(n)}\\equiv1\\pmod n",
        note: "Requires gcd(a,n)=1.",
      },
      {
        title: "Fermat little theorem",
        formula: "a^{p-1}\\equiv1\\pmod p",
        note: "p prime and p not dividing a.",
      },
      {
        title: "Wilson theorem",
        formula: "(p-1)!\\equiv-1\\pmod p",
        note: "p is prime exactly when this holds for p greater than 1.",
      },
      {
        title: "Chinese remainder",
        formula: "x\\equiv a_i\\pmod {m_i}",
        note: "Unique modulo product when moduli are pairwise coprime.",
      },
      {
        title: "Linear Diophantine condition",
        formula: "ax+by=c\\text{ solvable}\\Leftrightarrow \\gcd(a,b)\\mid c",
        note: "Integer solution criterion.",
      },
      {
        title: "Divisor count",
        formula: "n=\\prod p_i^{a_i}\\Rightarrow d(n)=\\prod(a_i+1)",
        note: "Number of positive divisors.",
      },
      {
        title: "Sum of divisors",
        formula: "\\sigma(n)=\\prod\\frac{p_i^{a_i+1}-1}{p_i-1}",
        note: "For prime factorization of n.",
      },
    ],
  },
  {
    id: "euclidean-geometry-theorems",
    title: "Euclidean Geometry Theorems",
    description:
      "Classical triangle, circle, and quadrilateral formulas used in advanced geometry.",
    formulas: [
      {
        title: "Ceva theorem",
        formula: "\\frac{BD}{DC}\\cdot\\frac{CE}{EA}\\cdot\\frac{AF}{FB}=1",
        note: "Criterion for concurrent cevians.",
      },
      {
        title: "Menelaus theorem",
        formula: "\\frac{BD}{DC}\\cdot\\frac{CE}{EA}\\cdot\\frac{AF}{FB}=-1",
        note: "Criterion for collinear points on extended sides.",
      },
      {
        title: "Stewart theorem",
        formula: "b^2m+c^2n=a(d^2+mn)",
        note: "Cevian length d splits side a into m and n.",
      },
      {
        title: "Angle bisector theorem",
        formula: "\\frac{BD}{DC}=\\frac{AB}{AC}",
        note: "Internal angle bisector in a triangle.",
      },
      {
        title: "Power of a point",
        formula: "PA\\cdot PB=PC\\cdot PD",
        note: "Secants through the same external point.",
      },
      {
        title: "Tangent-secant theorem",
        formula: "PT^2=PA\\cdot PB",
        note: "Tangent and secant from same point.",
      },
      {
        title: "Ptolemy theorem",
        formula: "AC\\cdot BD=AB\\cdot CD+BC\\cdot AD",
        note: "For cyclic quadrilaterals.",
      },
      {
        title: "Euler line relation",
        formula: "OG:GH=1:2",
        note: "Centroid G lies between circumcenter O and orthocenter H.",
      },
      {
        title: "Nine-point radius",
        formula: "R_9=\\frac{R}{2}",
        note: "Nine-point circle radius.",
      },
      {
        title: "Euler triangle formula",
        formula: "OI^2=R^2-2Rr",
        note: "Distance between circumcenter and incenter.",
      },
    ],
  },
  {
    id: "analytic-geometry-advanced",
    title: "Advanced Analytic Geometry",
    description:
      "Conic classification, pair of lines, tangents, normals, polar forms, and transformations.",
    formulas: [
      {
        title: "General second degree",
        formula: "Ax^2+Bxy+Cy^2+Dx+Ey+F=0",
        note: "General conic equation.",
      },
      {
        title: "Conic discriminant",
        formula: "\\Delta=B^2-4AC",
        note: "Classifies ellipse, parabola, hyperbola type.",
      },
      {
        title: "Pair of lines condition",
        formula: "abc+2fgh-af^2-bg^2-ch^2=0",
        note: "For ax^2+by^2+2hxy+2gx+2fy+c=0.",
      },
      {
        title: "Tangent to circle",
        formula: "xx_1+yy_1=r^2",
        note: "At point (x_1,y_1) on x^2+y^2=r^2.",
      },
      {
        title: "Tangent to parabola",
        formula: "yy_1=2a(x+x_1)",
        note: "For y^2=4ax.",
      },
      {
        title: "Tangent to ellipse",
        formula: "\\frac{xx_1}{a^2}+\\frac{yy_1}{b^2}=1",
        note: "At point on ellipse.",
      },
      {
        title: "Tangent to hyperbola",
        formula: "\\frac{xx_1}{a^2}-\\frac{yy_1}{b^2}=1",
        note: "At point on hyperbola.",
      },
      {
        title: "Chord with midpoint",
        formula: "T=S_1",
        note: "T equals S_1 form for conic chord midpoint.",
      },
      {
        title: "Polar of point",
        formula: "T=0",
        note: "Polar line of a point with respect to conic S=0.",
      },
      {
        title: "Rotation of axes",
        formula: "\\tan2\\theta=\\frac{B}{A-C}",
        note: "Removes xy term when possible.",
      },
    ],
  },
  {
    id: "precalculus",
    title: "Precalculus",
    description:
      "Functions, transformations, exponentials, logarithms, parametric equations, and polar coordinates.",
    formulas: [
      {
        title: "Vertical shift",
        formula: "y=f(x)+k",
        note: "Moves graph up or down.",
      },
      {
        title: "Horizontal shift",
        formula: "y=f(x-h)",
        note: "Moves graph right by h.",
      },
      {
        title: "Vertical scale",
        formula: "y=af(x)",
        note: "Stretches values by a.",
      },
      {
        title: "Horizontal scale",
        formula: "y=f(bx)",
        note: "Compresses horizontally by factor b.",
      },
      {
        title: "Exponential growth",
        formula: "y=ab^x",
        note: "b greater than 1 gives growth.",
      },
      {
        title: "Exponential decay",
        formula: "y=a(1-r)^t",
        note: "r is decay rate.",
      },
      {
        title: "Logistic curve",
        formula: "P(t)=\\frac{L}{1+Ae^{-kt}}",
        note: "S-shaped bounded growth.",
      },
      {
        title: "Parametric slope",
        formula: "\\frac{dy}{dx}=\\frac{dy/dt}{dx/dt}",
        note: "For parametric curves.",
      },
      {
        title: "Polar to Cartesian",
        formula: "x=r\\cos\\theta,\\quad y=r\\sin\\theta",
        note: "Convert polar coordinates.",
      },
      {
        title: "Cartesian to polar",
        formula: "r^2=x^2+y^2,\\quad \\tan\\theta=\\frac{y}{x}",
        note: "Convert Cartesian coordinates.",
      },
    ],
  },
  {
    id: "calculus-applications",
    title: "Calculus Applications",
    description:
      "Tangents, normals, optimization, related rates, curvature, arc length, surfaces, and centroids.",
    formulas: [
      {
        title: "Tangent line",
        formula: "y-f(a)=f'(a)(x-a)",
        note: "Line touching curve at x=a.",
      },
      {
        title: "Normal line",
        formula: "y-f(a)=-\\frac{1}{f'(a)}(x-a)",
        note: "Perpendicular to tangent when f'(a) non-zero.",
      },
      {
        title: "Critical point",
        formula: "f'(x)=0\\text{ or undefined}",
        note: "Candidates for extrema.",
      },
      {
        title: "Second derivative test",
        formula: "f''(c)>0\\Rightarrow min",
        note: "Concave up at critical point.",
      },
      {
        title: "Related rates chain",
        formula: "\\frac{dy}{dt}=\\frac{dy}{dx}\\frac{dx}{dt}",
        note: "Connect changing quantities.",
      },
      {
        title: "Arc length",
        formula: "L=\\int_a^b\\sqrt{1+[f'(x)]^2}\\,dx",
        note: "Length of a graph.",
      },
      {
        title: "Surface of revolution",
        formula: "S=2\\pi\\int_a^b f(x)\\sqrt{1+[f'(x)]^2}\\,dx",
        note: "Rotated around x-axis.",
      },
      {
        title: "Disk volume",
        formula: "V=\\pi\\int_a^b [R(x)]^2\\,dx",
        note: "Solid of revolution by disks.",
      },
      {
        title: "Washer volume",
        formula: "V=\\pi\\int_a^b(R^2-r^2)\\,dx",
        note: "Outer radius minus inner radius.",
      },
      {
        title: "Curvature",
        formula: "\\kappa=\\frac{|y''|}{(1+(y')^2)^{3/2}}",
        note: "Curvature of y=f(x).",
      },
    ],
  },
  {
    id: "multivariable-calculus",
    title: "Multivariable Calculus",
    description:
      "Partial derivatives, gradients, multiple integrals, Jacobians, vector calculus, and integral theorems.",
    formulas: [
      {
        title: "Partial derivative",
        formula: "f_x=\\frac{\\partial f}{\\partial x}",
        note: "Differentiate with other variables held constant.",
      },
      {
        title: "Gradient",
        formula: "\\nabla f=\\langle f_x,f_y,f_z\\rangle",
        note: "Direction of steepest increase.",
      },
      {
        title: "Directional derivative",
        formula: "D_{\\mathbf u}f=\\nabla f\\cdot\\mathbf u",
        note: "Unit direction vector u.",
      },
      {
        title: "Chain rule multivariable",
        formula: "\\frac{dz}{dt}=z_x\\frac{dx}{dt}+z_y\\frac{dy}{dt}",
        note: "For z=f(x(t),y(t)).",
      },
      {
        title: "Jacobian",
        formula:
          "J=\\det\\left(\\frac{\\partial(x_1,\\ldots,x_n)}{\\partial(u_1,\\ldots,u_n)}\\right)",
        note: "Area or volume scaling in change of variables.",
      },
      {
        title: "Double integral polar",
        formula:
          "\\iint_R f(x,y)dA=\\int\\int f(r\\cos\\theta,r\\sin\\theta)r\\,drd\\theta",
        note: "Extra factor r.",
      },
      {
        title: "Divergence",
        formula: "\\nabla\\cdot\\mathbf F=P_x+Q_y+R_z",
        note: "Flux density of vector field.",
      },
      {
        title: "Curl",
        formula:
          "\\nabla\\times\\mathbf F=\\left\\langle R_y-Q_z,P_z-R_x,Q_x-P_y\\right\\rangle",
        note: "Rotation density.",
      },
      {
        title: "Green theorem",
        formula: "\\oint_C Pdx+Qdy=\\iint_R(Q_x-P_y)dA",
        note: "Circulation to area integral.",
      },
      {
        title: "Divergence theorem",
        formula:
          "\\iint_S\\mathbf F\\cdot\\mathbf n\\,dS=\\iiint_V\\nabla\\cdot\\mathbf F\\,dV",
        note: "Flux through boundary.",
      },
    ],
  },
  {
    id: "linear-algebra-advanced",
    title: "Advanced Linear Algebra",
    description:
      "Vector spaces, eigenvalues, diagonalization, orthogonality, projections, SVD, and quadratic forms.",
    formulas: [
      {
        title: "Linear combination",
        formula: "\\mathbf v=c_1\\mathbf v_1+\\cdots+c_n\\mathbf v_n",
        note: "Build vectors from a span.",
      },
      {
        title: "Dimension theorem",
        formula: "\\dim V=\\dim\\ker T+\\dim\\operatorname{im}T",
        note: "Rank-nullity theorem.",
      },
      {
        title: "Eigen equation",
        formula: "A\\mathbf v=\\lambda\\mathbf v",
        note: "v is non-zero.",
      },
      {
        title: "Characteristic polynomial",
        formula: "p_A(\\lambda)=\\det(A-\\lambda I)",
        note: "Roots are eigenvalues.",
      },
      {
        title: "Diagonalization",
        formula: "A=PDP^{-1}",
        note: "When enough independent eigenvectors exist.",
      },
      {
        title: "Orthogonal projection",
        formula: "\\operatorname{proj}_W\\mathbf b=A(A^TA)^{-1}A^T\\mathbf b",
        note: "Projection onto column space of A.",
      },
      {
        title: "Least squares",
        formula: "A^TA\\hat x=A^T\\mathbf b",
        note: "Normal equations.",
      },
      {
        title: "Spectral theorem",
        formula: "A=Q\\Lambda Q^T",
        note: "For real symmetric A.",
      },
      {
        title: "Singular value decomposition",
        formula: "A=U\\Sigma V^T",
        note: "SVD of a matrix.",
      },
      {
        title: "Quadratic form",
        formula: "q(\\mathbf x)=\\mathbf x^TA\\mathbf x",
        note: "Classified by eigenvalues for symmetric A.",
      },
    ],
  },
  {
    id: "abstract-algebra",
    title: "Abstract Algebra",
    description:
      "Groups, rings, fields, homomorphisms, quotient structures, and finite group formulas.",
    formulas: [
      {
        title: "Group associativity",
        formula: "(ab)c=a(bc)",
        note: "One group axiom.",
      },
      { title: "Identity", formula: "ae=ea=a", note: "e is group identity." },
      {
        title: "Inverse",
        formula: "aa^{-1}=a^{-1}a=e",
        note: "Each group element has inverse.",
      },
      {
        title: "Order of subgroup",
        formula: "|H|\\mid |G|",
        note: "Lagrange theorem for finite groups.",
      },
      {
        title: "Coset count",
        formula: "[G:H]=\\frac{|G|}{|H|}",
        note: "Index of subgroup H.",
      },
      {
        title: "Homomorphism",
        formula: "\\phi(ab)=\\phi(a)\\phi(b)",
        note: "Operation-preserving map.",
      },
      {
        title: "First isomorphism theorem",
        formula: "G/\\ker\\phi\\cong\\operatorname{im}\\phi",
        note: "For group homomorphism phi.",
      },
      {
        title: "Ring distributivity",
        formula: "a(b+c)=ab+ac",
        note: "Multiplication distributes over addition.",
      },
      {
        title: "Field inverse",
        formula: "a\\ne0\\Rightarrow \\exists a^{-1}",
        note: "Every non-zero element is invertible.",
      },
      {
        title: "Euler phi for prime power",
        formula: "\\varphi(p^k)=p^k-p^{k-1}",
        note: "p prime.",
      },
    ],
  },
  {
    id: "real-analysis",
    title: "Real Analysis",
    description:
      "Sequences, limits, continuity, differentiation, integration, metric ideas, and convergence theorems.",
    formulas: [
      {
        title: "Epsilon limit",
        formula:
          "\\lim_{n\\to\\infty}a_n=L\\Leftrightarrow \\forall\\epsilon>0\\ \\exists N\\ \\forall n>N: |a_n-L|<\\epsilon",
        note: "Formal sequence limit.",
      },
      {
        title: "Cauchy sequence",
        formula:
          "\\forall\\epsilon>0\\ \\exists N\\ \\forall m,n>N: |a_m-a_n|<\\epsilon",
        note: "Converges in complete spaces.",
      },
      {
        title: "Uniform continuity",
        formula:
          "\\forall\\epsilon>0\\ \\exists\\delta>0: |x-y|<\\delta\\Rightarrow |f(x)-f(y)|<\\epsilon",
        note: "Delta independent of point.",
      },
      {
        title: "Mean value theorem",
        formula: "f'(c)=\\frac{f(b)-f(a)}{b-a}",
        note: "For continuous and differentiable functions.",
      },
      {
        title: "Taylor theorem",
        formula: "f(x)=\\sum_{k=0}^{n}\\frac{f^{(k)}(a)}{k!}(x-a)^k+R_n(x)",
        note: "Polynomial approximation plus remainder.",
      },
      {
        title: "Riemann sum",
        formula:
          "\\int_a^b f(x)dx=\\lim_{\\|P\\|\\to0}\\sum f(x_i^*)\\Delta x_i",
        note: "Integral as limit of sums.",
      },
      {
        title: "Uniform convergence test",
        formula: "\\sup_{x\\in E}|f_n(x)-f(x)|\\to0",
        note: "Definition by sup norm.",
      },
      {
        title: "Weierstrass M-test",
        formula: "|f_n(x)|\\le M_n,\\quad \\sum M_n<\\infty",
        note: "Gives uniform convergence of series.",
      },
      {
        title: "Contraction fixed point",
        formula: "d(Tx,Ty)\\le kd(x,y),\\quad 0<k<1",
        note: "Guarantees unique fixed point in complete metric space.",
      },
      {
        title: "Holder continuity",
        formula: "|f(x)-f(y)|\\le C|x-y|^\\alpha",
        note: "Alpha between 0 and 1 commonly.",
      },
    ],
  },
  {
    id: "complex-analysis",
    title: "Complex Analysis",
    description:
      "Holomorphic functions, Cauchy-Riemann equations, contour integrals, residues, and conformal maps.",
    formulas: [
      {
        title: "Cauchy-Riemann equations",
        formula: "u_x=v_y,\\quad u_y=-v_x",
        note: "For f=u+iv to be analytic under smoothness.",
      },
      {
        title: "Complex derivative",
        formula: "f'(z)=\\lim_{h\\to0}\\frac{f(z+h)-f(z)}{h}",
        note: "Limit must be path independent.",
      },
      {
        title: "Cauchy integral theorem",
        formula: "\\oint_C f(z)dz=0",
        note: "For holomorphic f on simply connected region.",
      },
      {
        title: "Cauchy integral formula",
        formula: "f(a)=\\frac{1}{2\\pi i}\\oint_C\\frac{f(z)}{z-a}dz",
        note: "a inside C.",
      },
      {
        title: "Derivative formula",
        formula:
          "f^{(n)}(a)=\\frac{n!}{2\\pi i}\\oint_C\\frac{f(z)}{(z-a)^{n+1}}dz",
        note: "Higher derivatives from contour integral.",
      },
      {
        title: "Laurent series",
        formula: "f(z)=\\sum_{n=-\\infty}^{\\infty}a_n(z-a)^n",
        note: "Around isolated singularities.",
      },
      {
        title: "Residue",
        formula: "\\operatorname{Res}(f,a)=a_{-1}",
        note: "Coefficient of (z-a)^{-1}.",
      },
      {
        title: "Residue theorem",
        formula: "\\oint_C f(z)dz=2\\pi i\\sum\\operatorname{Res}(f,a_k)",
        note: "Sum residues inside C.",
      },
      {
        title: "Mobius transform",
        formula: "w=\\frac{az+b}{cz+d}",
        note: "ad-bc non-zero.",
      },
      {
        title: "Argument principle",
        formula: "\\frac{1}{2\\pi i}\\oint_C\\frac{f'(z)}{f(z)}dz=N-P",
        note: "Zeros minus poles inside contour.",
      },
    ],
  },
  {
    id: "topology",
    title: "Topology",
    description:
      "Open sets, closure, compactness, connectedness, quotient spaces, and algebraic topology basics.",
    formulas: [
      {
        title: "Open ball",
        formula: "B(x,r)=\\{y:d(x,y)<r\\}",
        note: "Basic neighborhood in metric spaces.",
      },
      {
        title: "Closure",
        formula: "\\overline A=A\\cup A'",
        note: "Set plus its limit points.",
      },
      {
        title: "Interior",
        formula:
          "\\operatorname{int}(A)=\\bigcup\\{U:U\\subset A,\\ U\\text{ open}\\}",
        note: "Largest open subset of A.",
      },
      {
        title: "Boundary",
        formula: "\\partial A=\\overline A\\setminus\\operatorname{int}(A)",
        note: "Edge of a set.",
      },
      {
        title: "Compact metric criterion",
        formula: "compact\\Leftrightarrow sequentially\\ compact",
        note: "In metric spaces.",
      },
      {
        title: "Euler characteristic",
        formula: "\\chi=V-E+F",
        note: "For polyhedral surfaces.",
      },
      {
        title: "Euler genus formula",
        formula: "\\chi=2-2g",
        note: "Closed orientable surface of genus g.",
      },
      {
        title: "Fundamental group product",
        formula: "\\pi_1(X\\times Y)\\cong\\pi_1(X)\\times\\pi_1(Y)",
        note: "For nice path-connected spaces.",
      },
      {
        title: "Homology Euler characteristic",
        formula: "\\chi=\\sum_k(-1)^k\\operatorname{rank}H_k",
        note: "Alternating Betti number sum.",
      },
      {
        title: "Continuous preimage",
        formula:
          "f\\text{ continuous}\\Leftrightarrow f^{-1}(U)\\text{ open for every open }U",
        note: "Topological definition.",
      },
    ],
  },
  {
    id: "differential-geometry",
    title: "Differential Geometry",
    description:
      "Curves, surfaces, curvature, geodesics, metric tensors, and classical surface formulas.",
    formulas: [
      {
        title: "Arc length parameter",
        formula: "s(t)=\\int_a^t\\|\\mathbf r'(u)\\|du",
        note: "Length along a parametric curve.",
      },
      {
        title: "Unit tangent",
        formula: "\\mathbf T=\\frac{\\mathbf r'}{\\|\\mathbf r'\\|}",
        note: "Direction of motion.",
      },
      {
        title: "Curvature vector",
        formula: "\\frac{d\\mathbf T}{ds}=\\kappa\\mathbf N",
        note: "Defines curvature and normal.",
      },
      {
        title: "Curvature parametric",
        formula:
          "\\kappa=\\frac{\\|\\mathbf r'\\times\\mathbf r''\\|}{\\|\\mathbf r'\\|^3}",
        note: "For space curves.",
      },
      {
        title: "Torsion",
        formula:
          "\\tau=\\frac{(\\mathbf r'\\times\\mathbf r'')\\cdot\\mathbf r'''}{\\|\\mathbf r'\\times\\mathbf r''\\|^2}",
        note: "Twisting of a space curve.",
      },
      {
        title: "First fundamental form",
        formula: "I=Edu^2+2Fdudv+Gdv^2",
        note: "Surface metric.",
      },
      {
        title: "Surface area",
        formula: "A=\\iint\\|\\mathbf r_u\\times\\mathbf r_v\\|dudv",
        note: "Parametric surface area.",
      },
      {
        title: "Gaussian curvature",
        formula: "K=\\frac{eg-f^2}{EG-F^2}",
        note: "From first and second fundamental forms.",
      },
      {
        title: "Mean curvature",
        formula: "H=\\frac{Eg-2Ff+Ge}{2(EG-F^2)}",
        note: "Average normal curvature.",
      },
      {
        title: "Geodesic equation",
        formula:
          "\\frac{d^2x^k}{dt^2}+\\Gamma^k_{ij}\\frac{dx^i}{dt}\\frac{dx^j}{dt}=0",
        note: "Locally shortest paths.",
      },
    ],
  },
  {
    id: "discrete-math",
    title: "Discrete Math",
    description:
      "Logic, sets, graphs, recurrence relations, generating functions, and counting structures.",
    formulas: [
      {
        title: "De Morgan set law",
        formula: "(A\\cup B)^c=A^c\\cap B^c",
        note: "Complement of union.",
      },
      {
        title: "Implication equivalence",
        formula: "p\\Rightarrow q\\equiv \\neg p\\vee q",
        note: "Logical implication rewrite.",
      },
      {
        title: "Handshake lemma",
        formula: "\\sum_{v\\in V}\\deg(v)=2|E|",
        note: "Every edge contributes two degrees.",
      },
      {
        title: "Tree edges",
        formula: "|E|=|V|-1",
        note: "For a finite connected tree.",
      },
      {
        title: "Euler graph condition",
        formula:
          "\\text{Euler circuit}\\Leftrightarrow every\\ vertex\\ has\\ even\\ degree",
        note: "Connected graph assumed.",
      },
      {
        title: "Planar graph Euler",
        formula: "V-E+F=2",
        note: "Connected planar graph.",
      },
      {
        title: "Planar edge bound",
        formula: "E\\le3V-6",
        note: "Simple planar graph with V at least 3.",
      },
      {
        title: "Linear recurrence",
        formula: "a_n=c_1a_{n-1}+\\cdots+c_ka_{n-k}",
        note: "Constant-coefficient recurrence.",
      },
      {
        title: "Generating function",
        formula: "A(x)=\\sum_{n\\ge0}a_nx^n",
        note: "Encodes a sequence.",
      },
      {
        title: "Inclusion-exclusion",
        formula:
          "\\left|\\bigcup A_i\\right|=\\sum|A_i|-\\sum|A_i\\cap A_j|+\\cdots",
        note: "Counts union without overcounting.",
      },
    ],
  },
  {
    id: "optimization",
    title: "Optimization",
    description:
      "Linear, nonlinear, convex, constrained, and numerical optimization formulas.",
    formulas: [
      {
        title: "Unconstrained optimum",
        formula: "\\nabla f(x^*)=0",
        note: "First-order necessary condition.",
      },
      {
        title: "Second-order minimum",
        formula: "\\nabla^2f(x^*)\\succ0",
        note: "Positive definite Hessian.",
      },
      {
        title: "Lagrange multiplier",
        formula: "\\nabla f=\\lambda\\nabla g",
        note: "One equality constraint.",
      },
      {
        title: "KKT stationarity",
        formula:
          "\\nabla f(x)+\\sum_i\\lambda_i\\nabla g_i(x)+\\sum_j\\mu_j\\nabla h_j(x)=0",
        note: "Constrained optimization condition.",
      },
      {
        title: "Complementary slackness",
        formula: "\\lambda_i g_i(x)=0",
        note: "Active constraints carry multipliers.",
      },
      {
        title: "Gradient descent",
        formula: "x_{k+1}=x_k-\\alpha_k\\nabla f(x_k)",
        note: "Step opposite gradient.",
      },
      {
        title: "Newton method optimization",
        formula: "x_{k+1}=x_k-[\\nabla^2f(x_k)]^{-1}\\nabla f(x_k)",
        note: "Uses Hessian.",
      },
      {
        title: "Convexity first order",
        formula: "f(y)\\ge f(x)+\\nabla f(x)^T(y-x)",
        note: "For differentiable convex functions.",
      },
      {
        title: "Dual function",
        formula: "q(\\lambda)=\\inf_x L(x,\\lambda)",
        note: "Lower bound for minimization.",
      },
      {
        title: "Simplex reduced cost",
        formula: "\\bar c_j=c_j-c_B^TB^{-1}A_j",
        note: "Tests entering variables.",
      },
    ],
  },
  {
    id: "numerical-methods",
    title: "Numerical Methods",
    description:
      "Root finding, interpolation, numerical integration, ODE solvers, and error formulas.",
    formulas: [
      {
        title: "Bisection midpoint",
        formula: "m=\\frac{a+b}{2}",
        note: "Halves an interval containing a root.",
      },
      {
        title: "Newton root method",
        formula: "x_{n+1}=x_n-\\frac{f(x_n)}{f'(x_n)}",
        note: "Fast near simple roots.",
      },
      {
        title: "Secant method",
        formula: "x_{n+1}=x_n-f(x_n)\\frac{x_n-x_{n-1}}{f(x_n)-f(x_{n-1})}",
        note: "Derivative-free root method.",
      },
      {
        title: "Lagrange interpolation",
        formula: "P(x)=\\sum_{i=0}^n y_i\\prod_{j\\ne i}\\frac{x-x_j}{x_i-x_j}",
        note: "Interpolating polynomial.",
      },
      {
        title: "Trapezoidal rule",
        formula:
          "\\int_a^b f(x)dx\\approx\\frac{h}{2}[f(x_0)+2\\sum_{i=1}^{n-1}f(x_i)+f(x_n)]",
        note: "Composite trapezoid rule.",
      },
      {
        title: "Simpson rule",
        formula:
          "\\int_a^b f(x)dx\\approx\\frac{h}{3}[f_0+4f_1+2f_2+\\cdots+4f_{n-1}+f_n]",
        note: "n even.",
      },
      {
        title: "Euler method",
        formula: "y_{n+1}=y_n+hf(t_n,y_n)",
        note: "First-order ODE step.",
      },
      {
        title: "RK4 method",
        formula: "y_{n+1}=y_n+\\frac{h}{6}(k_1+2k_2+2k_3+k_4)",
        note: "Classical fourth-order Runge-Kutta.",
      },
      {
        title: "Absolute error",
        formula: "E_a=|x-\\hat x|",
        note: "True minus approximation magnitude.",
      },
      {
        title: "Relative error",
        formula: "E_r=\\frac{|x-\\hat x|}{|x|}",
        note: "Error compared with true magnitude.",
      },
    ],
  },
  {
    id: "dynamical-systems",
    title: "Dynamical Systems",
    description:
      "Fixed points, stability, maps, flows, bifurcations, and nonlinear system tools.",
    formulas: [
      {
        title: "Autonomous system",
        formula: "\\dot{\\mathbf x}=\\mathbf f(\\mathbf x)",
        note: "State evolves by current state.",
      },
      {
        title: "Equilibrium",
        formula: "\\mathbf f(\\mathbf x^*)=0",
        note: "Fixed point of continuous system.",
      },
      {
        title: "Linearization",
        formula: "\\dot{\\mathbf u}=D\\mathbf f(\\mathbf x^*)\\mathbf u",
        note: "Local behavior near equilibrium.",
      },
      {
        title: "Discrete fixed point",
        formula: "x^*=F(x^*)",
        note: "Fixed point of an iterated map.",
      },
      {
        title: "Logistic map",
        formula: "x_{n+1}=rx_n(1-x_n)",
        note: "Classic nonlinear recurrence.",
      },
      {
        title: "Stability map",
        formula: "|F'(x^*)|<1",
        note: "Attracting fixed point.",
      },
      {
        title: "Lyapunov exponent",
        formula:
          "\\lambda=\\lim_{n\\to\\infty}\\frac1n\\sum_{k=0}^{n-1}\\ln|F'(x_k)|",
        note: "Average exponential separation.",
      },
      {
        title: "Hamilton equations",
        formula:
          "\\dot q=\\frac{\\partial H}{\\partial p},\\quad \\dot p=-\\frac{\\partial H}{\\partial q}",
        note: "Canonical dynamics.",
      },
      {
        title: "Poincare map",
        formula: "P:\\Sigma\\to\\Sigma",
        note: "Return map to a section.",
      },
      {
        title: "Normal form pitchfork",
        formula: "\\dot x=rx-x^3",
        note: "Prototype bifurcation.",
      },
    ],
  },
  {
    id: "pde",
    title: "Partial Differential Equations",
    description:
      "First and second order PDEs, canonical equations, separation, transforms, and boundary formulas.",
    formulas: [
      {
        title: "Transport equation",
        formula: "u_t+cu_x=0",
        note: "Solution travels at speed c.",
      },
      {
        title: "Heat equation",
        formula: "u_t=\\alpha^2u_{xx}",
        note: "Diffusion model.",
      },
      {
        title: "Wave equation",
        formula: "u_{tt}=c^2u_{xx}",
        note: "Vibration and wave propagation.",
      },
      {
        title: "Laplace equation",
        formula: "\\nabla^2u=0",
        note: "Harmonic functions.",
      },
      {
        title: "Poisson equation",
        formula: "\\nabla^2u=f",
        note: "Forced potential equation.",
      },
      {
        title: "Separation product",
        formula: "u(x,t)=X(x)T(t)",
        note: "Turns PDE into ODEs when possible.",
      },
      {
        title: "Fourier heat solution",
        formula:
          "u(x,t)=\\sum_{n=1}^{\\infty}b_ne^{-\\alpha^2n^2\\pi^2t/L^2}\\sin\\frac{n\\pi x}{L}",
        note: "Zero boundary heat equation on interval.",
      },
      {
        title: "D'Alembert solution",
        formula: "u(x,t)=F(x-ct)+G(x+ct)",
        note: "General 1D wave solution.",
      },
      {
        title: "Green function solution",
        formula: "Lu=f\\Rightarrow u(x)=\\int G(x,\\xi)f(\\xi)d\\xi",
        note: "Integral solution operator.",
      },
      {
        title: "Characteristic equation",
        formula: "\\frac{dx}{a}=\\frac{dy}{b}=\\frac{du}{c}",
        note: "For first-order PDE au_x+bu_y=c.",
      },
    ],
  },
  {
    id: "fourier-laplace-transforms",
    title: "Fourier and Laplace Transforms",
    description:
      "Series, integral transforms, convolution, shift rules, and signal-analysis formulas.",
    formulas: [
      {
        title: "Fourier series",
        formula:
          "f(x)\\sim\\frac{a_0}{2}+\\sum_{n=1}^{\\infty}(a_n\\cos nx+b_n\\sin nx)",
        note: "Periodic expansion.",
      },
      {
        title: "Fourier coefficient a_n",
        formula: "a_n=\\frac1\\pi\\int_{-\\pi}^{\\pi}f(x)\\cos nx\\,dx",
        note: "Cosine coefficient.",
      },
      {
        title: "Fourier coefficient b_n",
        formula: "b_n=\\frac1\\pi\\int_{-\\pi}^{\\pi}f(x)\\sin nx\\,dx",
        note: "Sine coefficient.",
      },
      {
        title: "Fourier transform",
        formula:
          "\\mathcal F\\{f\\}(\\omega)=\\int_{-\\infty}^{\\infty}f(t)e^{-i\\omega t}dt",
        note: "Frequency-domain transform.",
      },
      {
        title: "Inverse Fourier transform",
        formula:
          "f(t)=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}\\hat f(\\omega)e^{i\\omega t}d\\omega",
        note: "Recover signal.",
      },
      {
        title: "Convolution",
        formula: "(f*g)(t)=\\int_{-\\infty}^{\\infty}f(\\tau)g(t-\\tau)d\\tau",
        note: "Sliding product integral.",
      },
      {
        title: "Convolution theorem",
        formula: "\\mathcal F\\{f*g\\}=\\mathcal F\\{f\\}\\mathcal F\\{g\\}",
        note: "Convolution becomes multiplication.",
      },
      {
        title: "Laplace transform",
        formula: "\\mathcal L\\{f\\}(s)=\\int_0^{\\infty}e^{-st}f(t)dt",
        note: "One-sided transform.",
      },
      {
        title: "Laplace derivative",
        formula: "\\mathcal L\\{f'\\}=sF(s)-f(0)",
        note: "Solves ODE initial value problems.",
      },
      {
        title: "Laplace convolution",
        formula: "\\mathcal L\\{f*g\\}=F(s)G(s)",
        note: "For causal convolution.",
      },
    ],
  },
  {
    id: "mathematical-physics",
    title: "Mathematical Physics",
    description:
      "Vector identities, variational calculus, tensors, operators, and equations common in physics math.",
    formulas: [
      {
        title: "Vector triple product",
        formula:
          "\\mathbf a\\times(\\mathbf b\\times\\mathbf c)=\\mathbf b(\\mathbf a\\cdot\\mathbf c)-\\mathbf c(\\mathbf a\\cdot\\mathbf b)",
        note: "BAC-CAB identity.",
      },
      {
        title: "Curl gradient",
        formula: "\\nabla\\times(\\nabla f)=0",
        note: "Gradient fields are irrotational.",
      },
      {
        title: "Divergence curl",
        formula: "\\nabla\\cdot(\\nabla\\times\\mathbf F)=0",
        note: "Curl fields are divergence-free.",
      },
      {
        title: "Laplacian",
        formula: "\\nabla^2f=f_{xx}+f_{yy}+f_{zz}",
        note: "Cartesian 3D Laplacian.",
      },
      {
        title: "Euler-Lagrange",
        formula:
          "\\frac{\\partial L}{\\partial q}-\\frac{d}{dt}\\frac{\\partial L}{\\partial \\dot q}=0",
        note: "Stationary action equation.",
      },
      {
        title: "Hamiltonian",
        formula: "H=\\sum_i p_i\\dot q_i-L",
        note: "Legendre transform of Lagrangian.",
      },
      {
        title: "Tensor transform",
        formula:
          "T'^{i}_{j}=\\frac{\\partial x'^i}{\\partial x^a}\\frac{\\partial x^b}{\\partial x'^j}T^a_b",
        note: "Mixed tensor coordinate change.",
      },
      {
        title: "Einstein summation",
        formula: "a_ib^i=\\sum_i a_ib^i",
        note: "Repeated index is summed.",
      },
      {
        title: "Schrodinger equation",
        formula: "i\\hbar\\frac{\\partial\\psi}{\\partial t}=\\hat H\\psi",
        note: "Quantum evolution equation.",
      },
      {
        title: "Maxwell divergence equations",
        formula:
          "\\nabla\\cdot\\mathbf E=\\frac{\\rho}{\\epsilon_0},\\quad \\nabla\\cdot\\mathbf B=0",
        note: "Two Maxwell equations.",
      },
    ],
  },
  {
    id: "information-theory",
    title: "Information Theory",
    description:
      "Entropy, divergence, coding, mutual information, and channel-capacity formulas.",
    formulas: [
      {
        title: "Shannon entropy",
        formula: "H(X)=-\\sum_x p(x)\\log p(x)",
        note: "Uncertainty in a distribution.",
      },
      {
        title: "Joint entropy",
        formula: "H(X,Y)=-\\sum_{x,y}p(x,y)\\log p(x,y)",
        note: "Uncertainty of pair.",
      },
      {
        title: "Conditional entropy",
        formula: "H(X|Y)=H(X,Y)-H(Y)",
        note: "Uncertainty left after Y.",
      },
      {
        title: "Mutual information",
        formula: "I(X;Y)=H(X)-H(X|Y)",
        note: "Information shared by variables.",
      },
      {
        title: "KL divergence",
        formula: "D_{KL}(P\\|Q)=\\sum_x p(x)\\log\\frac{p(x)}{q(x)}",
        note: "Relative entropy.",
      },
      {
        title: "Cross entropy",
        formula: "H(P,Q)=-\\sum_xp(x)\\log q(x)",
        note: "Expected code length under Q.",
      },
      {
        title: "Source coding bound",
        formula: "L\\ge H(X)",
        note: "Average code length lower bound.",
      },
      {
        title: "Channel capacity",
        formula: "C=\\max_{p(x)}I(X;Y)",
        note: "Maximum reliable information rate.",
      },
      {
        title: "Binary entropy",
        formula: "H_b(p)=-p\\log p-(1-p)\\log(1-p)",
        note: "Entropy of Bernoulli p.",
      },
      {
        title: "Perplexity",
        formula: "PP=2^{H}",
        note: "Effective number of choices for base-2 entropy.",
      },
    ],
  },
  {
    id: "machine-learning-math",
    title: "Machine Learning Math",
    description:
      "Losses, gradients, regression, classification, kernels, and neural-network formulas.",
    formulas: [
      {
        title: "Mean squared error",
        formula: "MSE=\\frac1n\\sum_{i=1}^n(y_i-\\hat y_i)^2",
        note: "Regression loss.",
      },
      {
        title: "Linear regression",
        formula: "\\hat y=\\mathbf x^T\\mathbf w+b",
        note: "Affine prediction model.",
      },
      {
        title: "Ridge solution",
        formula: "\\hat w=(X^TX+\\lambda I)^{-1}X^Ty",
        note: "L2-regularized least squares.",
      },
      {
        title: "Logistic sigmoid",
        formula: "\\sigma(z)=\\frac1{1+e^{-z}}",
        note: "Maps real values to probabilities.",
      },
      {
        title: "Binary cross entropy",
        formula: "L=-[y\\log\\hat y+(1-y)\\log(1-\\hat y)]",
        note: "Binary classification loss.",
      },
      {
        title: "Softmax",
        formula: "p_i=\\frac{e^{z_i}}{\\sum_j e^{z_j}}",
        note: "Multiclass probabilities.",
      },
      {
        title: "Cross entropy multiclass",
        formula: "L=-\\sum_i y_i\\log p_i",
        note: "Classification loss.",
      },
      {
        title: "Gradient update",
        formula: "\\theta_{t+1}=\\theta_t-\\eta\\nabla_\\theta L",
        note: "Basic learning step.",
      },
      {
        title: "Kernel trick",
        formula: "K(x,z)=\\phi(x)^T\\phi(z)",
        note: "Implicit feature inner product.",
      },
      {
        title: "Attention",
        formula:
          "\\operatorname{Attention}(Q,K,V)=\\operatorname{softmax}\\left(\\frac{QK^T}{\\sqrt d}\\right)V",
        note: "Scaled dot-product attention.",
      },
    ],
  },
  {
    id: "cryptography-math",
    title: "Cryptography Math",
    description:
      "Modular arithmetic, RSA, Diffie-Hellman, elliptic curves, hashes, and security math formulas.",
    formulas: [
      {
        title: "Modular inverse",
        formula: "aa^{-1}\\equiv1\\pmod n",
        note: "Exists when gcd(a,n)=1.",
      },
      { title: "RSA modulus", formula: "n=pq", note: "Product of two primes." },
      {
        title: "RSA totient",
        formula: "\\varphi(n)=(p-1)(q-1)",
        note: "For n=pq with distinct primes.",
      },
      {
        title: "RSA key relation",
        formula: "ed\\equiv1\\pmod{\\varphi(n)}",
        note: "d is inverse of e modulo phi.",
      },
      {
        title: "RSA encryption",
        formula: "c\\equiv m^e\\pmod n",
        note: "Public-key encryption step.",
      },
      {
        title: "RSA decryption",
        formula: "m\\equiv c^d\\pmod n",
        note: "Private-key recovery step.",
      },
      {
        title: "Diffie-Hellman public value",
        formula: "A\\equiv g^a\\pmod p",
        note: "a is private exponent.",
      },
      {
        title: "Diffie-Hellman shared key",
        formula: "K\\equiv B^a\\equiv A^b\\pmod p",
        note: "Both parties get same key.",
      },
      {
        title: "Elliptic curve",
        formula: "y^2=x^3+ax+b",
        note: "Short Weierstrass form.",
      },
      {
        title: "Curve nonsingularity",
        formula: "4a^3+27b^2\\ne0",
        note: "Avoids cusps and self-intersections.",
      },
    ],
  },
];

formulaCategories.push(...advancedFormulaCategories);

const probabilityStatisticsCategories: FormulaCategory[] = [
  {
    id: "probability",
    title: "Probability",
    description:
      "Events, conditional probability, Bayes theorem, random variables, expectation, variance, and common probability laws.",
    formulas: [
      {
        title: "Sample space probability",
        formula: "P(A)=\\frac{n(A)}{n(S)}",
        note: "For equally likely outcomes.",
      },
      {
        title: "Complement rule",
        formula: "P(A^c)=1-P(A)",
        note: "Probability that A does not occur.",
      },
      {
        title: "Probability bounds",
        formula: "0\\le P(A)\\le1",
        note: "Probabilities are always between 0 and 1.",
      },
      {
        title: "Addition rule two events",
        formula: "P(A\\cup B)=P(A)+P(B)-P(A\\cap B)",
        note: "Subtract the overlap once.",
      },
      {
        title: "Mutually exclusive events",
        formula: "A\\cap B=\\varnothing\\Rightarrow P(A\\cup B)=P(A)+P(B)",
        note: "Events cannot occur together.",
      },
      {
        title: "Conditional probability",
        formula: "P(A|B)=\\frac{P(A\\cap B)}{P(B)}",
        note: "Requires P(B)>0.",
      },
      {
        title: "Multiplication rule",
        formula: "P(A\\cap B)=P(A|B)P(B)",
        note: "Equivalent to conditional probability.",
      },
      {
        title: "Independent events",
        formula: "P(A\\cap B)=P(A)P(B)",
        note: "Occurrence of one does not affect the other.",
      },
      {
        title: "Bayes theorem",
        formula: "P(A|B)=\\frac{P(B|A)P(A)}{P(B)}",
        note: "Updates probability after evidence.",
      },
      {
        title: "Law of total probability",
        formula: "P(B)=\\sum_iP(B|A_i)P(A_i)",
        note: "A_i form a partition of the sample space.",
      },
      {
        title: "Odds",
        formula: "odds(A)=\\frac{P(A)}{1-P(A)}",
        note: "Probability as odds in favor.",
      },
      {
        title: "Expected value discrete",
        formula: "\\mathbb E[X]=\\sum_x xP(X=x)",
        note: "Weighted average of a discrete random variable.",
      },
      {
        title: "Expected value continuous",
        formula: "\\mathbb E[X]=\\int_{-\\infty}^{\\infty}xf(x)\\,dx",
        note: "Mean of a continuous random variable.",
      },
      {
        title: "Linearity of expectation",
        formula: "\\mathbb E[aX+bY+c]=a\\mathbb E[X]+b\\mathbb E[Y]+c",
        note: "Does not require independence.",
      },
      {
        title: "Variance definition",
        formula: "\\operatorname{Var}(X)=\\mathbb E[(X-\\mu)^2]",
        note: "Mean squared deviation from the mean.",
      },
      {
        title: "Variance shortcut",
        formula: "\\operatorname{Var}(X)=\\mathbb E[X^2]-(\\mathbb E[X])^2",
        note: "Often easier to compute.",
      },
      {
        title: "Standard deviation",
        formula: "\\sigma=\\sqrt{\\operatorname{Var}(X)}",
        note: "Spread in original units.",
      },
      {
        title: "Covariance",
        formula: "\\operatorname{Cov}(X,Y)=\\mathbb E[(X-\\mu_X)(Y-\\mu_Y)]",
        note: "Joint variation of two variables.",
      },
      {
        title: "Correlation",
        formula:
          "\\rho_{X,Y}=\\frac{\\operatorname{Cov}(X,Y)}{\\sigma_X\\sigma_Y}",
        note: "Normalized covariance.",
      },
      {
        title: "Moment generating function",
        formula: "M_X(t)=\\mathbb E[e^{tX}]",
        note: "Encodes moments where it exists.",
      },
      {
        title: "CDF",
        formula: "F_X(x)=P(X\\le x)",
        note: "Cumulative distribution function.",
      },
      {
        title: "PDF probability",
        formula: "P(a\\le X\\le b)=\\int_a^bf(x)\\,dx",
        note: "Continuous probability from density.",
      },
      {
        title: "PMF sum",
        formula: "\\sum_xp(x)=1",
        note: "Discrete probabilities sum to one.",
      },
      {
        title: "PDF integral",
        formula: "\\int_{-\\infty}^{\\infty}f(x)\\,dx=1",
        note: "Continuous density integrates to one.",
      },
      {
        title: "Chebyshev inequality",
        formula: "P(|X-\\mu|\\ge k\\sigma)\\le\\frac{1}{k^2}",
        note: "Distribution-free spread bound.",
      },
      {
        title: "Markov inequality",
        formula: "P(X\\ge a)\\le\\frac{\\mathbb E[X]}{a}",
        note: "For non-negative X and a>0.",
      },
      {
        title: "Union bound",
        formula: "P\\left(\\bigcup_iA_i\\right)\\le\\sum_iP(A_i)",
        note: "Upper bound for at least one event.",
      },
      {
        title: "Inclusion-exclusion probability",
        formula:
          "P(A\\cup B\\cup C)=P(A)+P(B)+P(C)-P(A\\cap B)-P(B\\cap C)-P(C\\cap A)+P(A\\cap B\\cap C)",
        note: "Three-event union probability.",
      },
      {
        title: "Law of total expectation",
        formula: "\\mathbb E[X]=\\mathbb E[\\mathbb E[X|Y]]",
        note: "Tower property.",
      },
      {
        title: "Law of total variance",
        formula:
          "\\operatorname{Var}(X)=\\mathbb E[\\operatorname{Var}(X|Y)]+\\operatorname{Var}(\\mathbb E[X|Y])",
        note: "Variance decomposition.",
      },
      {
        title: "Probability generating function",
        formula: "G_X(s)=\\mathbb E[s^X]",
        note: "Useful for non-negative integer-valued random variables.",
      },
    ],
  },
  {
    id: "statistics",
    title: "Statistics",
    description:
      "Descriptive statistics, sampling, estimation, confidence intervals, hypothesis tests, regression, and goodness-of-fit formulas.",
    formulas: [
      {
        title: "Population mean",
        formula: "\\mu=\\frac{1}{N}\\sum_{i=1}^Nx_i",
        note: "Average of a full population.",
      },
      {
        title: "Sample mean",
        formula: "\\bar x=\\frac{1}{n}\\sum_{i=1}^nx_i",
        note: "Average of a sample.",
      },
      {
        title: "Weighted mean",
        formula: "\\bar x_w=\\frac{\\sum w_ix_i}{\\sum w_i}",
        note: "Mean with weights.",
      },
      {
        title: "Population variance",
        formula: "\\sigma^2=\\frac{1}{N}\\sum_{i=1}^N(x_i-\\mu)^2",
        note: "Population spread.",
      },
      {
        title: "Sample variance",
        formula: "s^2=\\frac{1}{n-1}\\sum_{i=1}^n(x_i-\\bar x)^2",
        note: "Unbiased sample variance.",
      },
      {
        title: "Sample standard deviation",
        formula: "s=\\sqrt{s^2}",
        note: "Sample spread in original units.",
      },
      {
        title: "Range",
        formula: "R=x_{max}-x_{min}",
        note: "Largest minus smallest value.",
      },
      {
        title: "Interquartile range",
        formula: "IQR=Q_3-Q_1",
        note: "Middle 50 percent spread.",
      },
      {
        title: "Coefficient of variation",
        formula: "CV=\\frac{s}{\\bar x}\\times100\\%",
        note: "Relative spread.",
      },
      {
        title: "Z-score",
        formula: "z=\\frac{x-\\mu}{\\sigma}",
        note: "Standardized value.",
      },
      {
        title: "Standard error of mean",
        formula: "SE_{\\bar x}=\\frac{s}{\\sqrt n}",
        note: "Estimated spread of sample mean.",
      },
      {
        title: "Confidence interval for mean",
        formula: "\\bar x\\pm z_{\\alpha/2}\\frac{\\sigma}{\\sqrt n}",
        note: "When population sigma is known.",
      },
      {
        title: "t confidence interval for mean",
        formula: "\\bar x\\pm t_{\\alpha/2,n-1}\\frac{s}{\\sqrt n}",
        note: "When sigma is unknown.",
      },
      {
        title: "Proportion estimate",
        formula: "\\hat p=\\frac{x}{n}",
        note: "Sample proportion.",
      },
      {
        title: "Standard error of proportion",
        formula: "SE_{\\hat p}=\\sqrt{\\frac{\\hat p(1-\\hat p)}{n}}",
        note: "Estimated spread of sample proportion.",
      },
      {
        title: "Confidence interval for proportion",
        formula:
          "\\hat p\\pm z_{\\alpha/2}\\sqrt{\\frac{\\hat p(1-\\hat p)}{n}}",
        note: "Large-sample proportion interval.",
      },
      {
        title: "One-sample z statistic",
        formula: "z=\\frac{\\bar x-\\mu_0}{\\sigma/\\sqrt n}",
        note: "Test mean with known sigma.",
      },
      {
        title: "One-sample t statistic",
        formula: "t=\\frac{\\bar x-\\mu_0}{s/\\sqrt n}",
        note: "Test mean with unknown sigma.",
      },
      {
        title: "Two-sample standard error",
        formula: "SE=\\sqrt{\\frac{s_1^2}{n_1}+\\frac{s_2^2}{n_2}}",
        note: "For independent sample means.",
      },
      {
        title: "Chi-square statistic",
        formula: "\\chi^2=\\sum\\frac{(O_i-E_i)^2}{E_i}",
        note: "Goodness-of-fit or independence test.",
      },
      {
        title: "Pearson correlation",
        formula:
          "r=\\frac{\\sum(x_i-\\bar x)(y_i-\\bar y)}{\\sqrt{\\sum(x_i-\\bar x)^2\\sum(y_i-\\bar y)^2}}",
        note: "Linear association.",
      },
      {
        title: "Simple linear regression slope",
        formula:
          "b_1=\\frac{\\sum(x_i-\\bar x)(y_i-\\bar y)}{\\sum(x_i-\\bar x)^2}",
        note: "Least-squares slope.",
      },
      {
        title: "Simple linear regression intercept",
        formula: "b_0=\\bar y-b_1\\bar x",
        note: "Least-squares intercept.",
      },
      {
        title: "Regression line",
        formula: "\\hat y=b_0+b_1x",
        note: "Predicted response.",
      },
      {
        title: "Residual",
        formula: "e_i=y_i-\\hat y_i",
        note: "Observed minus predicted.",
      },
      {
        title: "Sum of squared errors",
        formula: "SSE=\\sum(y_i-\\hat y_i)^2",
        note: "Unexplained variation.",
      },
      {
        title: "Total sum of squares",
        formula: "SST=\\sum(y_i-\\bar y)^2",
        note: "Total response variation.",
      },
      {
        title: "Coefficient of determination",
        formula: "R^2=1-\\frac{SSE}{SST}",
        note: "Proportion of variation explained.",
      },
      {
        title: "Mean squared error",
        formula: "MSE=\\frac{SSE}{n-p}",
        note: "Regression error variance estimate.",
      },
      {
        title: "Root mean squared error",
        formula: "RMSE=\\sqrt{\\frac{1}{n}\\sum(y_i-\\hat y_i)^2}",
        note: "Prediction error in response units.",
      },
      {
        title: "ANOVA F statistic",
        formula: "F=\\frac{MSB}{MSW}",
        note: "Between-group over within-group mean square.",
      },
      {
        title: "Sample covariance",
        formula: "s_{xy}=\\frac{1}{n-1}\\sum(x_i-\\bar x)(y_i-\\bar y)",
        note: "Sample joint variation.",
      },
      {
        title: "Skewness",
        formula: "\\gamma_1=\\frac{\\mathbb E[(X-\\mu)^3]}{\\sigma^3}",
        note: "Asymmetry measure.",
      },
      {
        title: "Kurtosis",
        formula: "\\gamma_2=\\frac{\\mathbb E[(X-\\mu)^4]}{\\sigma^4}",
        note: "Tail and peak shape measure.",
      },
    ],
  },
  {
    id: "probability-distributions",
    title: "Probability Distributions",
    description:
      "Discrete and continuous distribution formulas: support, PMF/PDF, mean, variance, and common use cases.",
    formulas: [
      {
        title: "Bernoulli distribution",
        formula: "P(X=x)=p^x(1-p)^{1-x}",
        note: "x is 0 or 1. Mean p, variance p(1-p).",
      },
      {
        title: "Binomial distribution",
        formula: "P(X=k)=\\binom nkp^k(1-p)^{n-k}",
        note: "Mean np, variance np(1-p).",
      },
      {
        title: "Geometric distribution",
        formula: "P(X=k)=(1-p)^{k-1}p",
        note: "Trials until first success. Mean 1/p.",
      },
      {
        title: "Negative binomial distribution",
        formula: "P(X=k)=\\binom{k-1}{r-1}p^r(1-p)^{k-r}",
        note: "Trials until r successes.",
      },
      {
        title: "Hypergeometric distribution",
        formula: "P(X=k)=\\frac{\\binom Kk\\binom{N-K}{n-k}}{\\binom Nn}",
        note: "Sampling without replacement.",
      },
      {
        title: "Poisson distribution",
        formula: "P(X=k)=e^{-\\lambda}\\frac{\\lambda^k}{k!}",
        note: "Mean and variance are both lambda.",
      },
      {
        title: "Discrete uniform distribution",
        formula: "P(X=x_i)=\\frac1n",
        note: "All n outcomes are equally likely.",
      },
      {
        title: "Continuous uniform distribution",
        formula: "f(x)=\\frac1{b-a}",
        note: "a <= x <= b. Mean (a+b)/2.",
      },
      {
        title: "Normal distribution",
        formula:
          "f(x)=\\frac{1}{\\sigma\\sqrt{2\\pi}}e^{-\\frac12\\left(\\frac{x-\\mu}{\\sigma}\\right)^2}",
        note: "Mean mu, variance sigma squared.",
      },
      {
        title: "Standard normal distribution",
        formula: "Z=\\frac{X-\\mu}{\\sigma}",
        note: "Transforms normal X to standard normal Z.",
      },
      {
        title: "Exponential distribution",
        formula: "f(x)=\\lambda e^{-\\lambda x}",
        note: "x >= 0. Mean 1/lambda, variance 1/lambda squared.",
      },
      {
        title: "Gamma distribution",
        formula:
          "f(x)=\\frac{\\beta^\\alpha}{\\Gamma(\\alpha)}x^{\\alpha-1}e^{-\\beta x}",
        note: "Shape alpha, rate beta.",
      },
      {
        title: "Beta distribution",
        formula:
          "f(x)=\\frac{x^{\\alpha-1}(1-x)^{\\beta-1}}{B(\\alpha,\\beta)}",
        note: "Support is 0 to 1.",
      },
      {
        title: "Chi-square distribution",
        formula:
          "X\\sim\\chi^2_k\\Rightarrow X\\sim\\Gamma\\left(\\frac{k}{2},\\frac12\\right)",
        note: "Mean k, variance 2k.",
      },
      {
        title: "Student t distribution",
        formula: "T=\\frac{Z}{\\sqrt{V/\\nu}}",
        note: "Z standard normal, V chi-square with nu degrees of freedom.",
      },
      {
        title: "F distribution",
        formula: "F=\\frac{U/d_1}{V/d_2}",
        note: "Ratio of scaled independent chi-square variables.",
      },
      {
        title: "Lognormal distribution",
        formula: "Y=e^X",
        note: "X is normally distributed; Y is positive and skewed.",
      },
      {
        title: "Weibull distribution",
        formula:
          "f(x)=\\frac{k}{\\lambda}\\left(\\frac{x}{\\lambda}\\right)^{k-1}e^{-(x/\\lambda)^k}",
        note: "Reliability and lifetime modeling.",
      },
      {
        title: "Cauchy distribution",
        formula:
          "f(x)=\\frac{1}{\\pi\\gamma\\left[1+\\left(\\frac{x-x_0}{\\gamma}\\right)^2\\right]}",
        note: "Heavy-tailed distribution with undefined mean.",
      },
      {
        title: "Multinomial distribution",
        formula:
          "P(X_1=x_1,\\ldots,X_k=x_k)=\\frac{n!}{x_1!\\cdots x_k!}\\prod_i p_i^{x_i}",
        note: "Multiple-category generalization of binomial.",
      },
      {
        title: "Multivariate normal density",
        formula:
          "f(x)=\\frac{1}{(2\\pi)^{k/2}|\\Sigma|^{1/2}}e^{-\\frac12(x-\\mu)^T\\Sigma^{-1}(x-\\mu)}",
        note: "Vector-valued normal distribution.",
      },
      {
        title: "Normal approximation to binomial",
        formula: "X\\sim Bin(n,p)\\approx N(np,np(1-p))",
        note: "Useful for large n.",
      },
      {
        title: "Poisson approximation to binomial",
        formula: "Bin(n,p)\\approx Pois(\\lambda=np)",
        note: "Useful when n is large and p is small.",
      },
      {
        title: "Central limit theorem",
        formula: "\\frac{\\bar X-\\mu}{\\sigma/\\sqrt n}\\Rightarrow N(0,1)",
        note: "Sample means become approximately normal under broad conditions.",
      },
    ],
  },
];

formulaCategories.push(...probabilityStatisticsCategories);

const geometryShapeFormulaItems: FormulaLibraryItem[] = [
  {
    title: "Line segment length",
    formula: "L=AB",
    note: "Length of a finite straight segment.",
  },
  {
    title: "Ray notation",
    formula: "\\overrightarrow{AB}",
    note: "Ray starting at A through B.",
  },
  {
    title: "Angle around a point",
    formula: "\\theta_1+\\theta_2+\\cdots+\\theta_n=360^\\circ",
    note: "Angles around one point.",
  },
  {
    title: "Angles on a straight line",
    formula: "\\theta_1+\\theta_2=180^\\circ",
    note: "Linear pair of angles.",
  },
  {
    title: "Triangle angle sum",
    formula: "A+B+C=180^\\circ",
    note: "Interior angles of a triangle.",
  },
  {
    title: "Triangle exterior angle",
    formula: "\\angle exterior=\\angle opposite_1+\\angle opposite_2",
    note: "Exterior angle theorem.",
  },
  {
    title: "Triangle perimeter",
    formula: "P=a+b+c",
    note: "Sum of all side lengths.",
  },
  {
    title: "Scalene triangle area",
    formula: "A=\\frac{1}{2}bh",
    note: "Any triangle using base and height.",
  },
  {
    title: "Right triangle area",
    formula: "A=\\frac{1}{2}ab",
    note: "a and b are perpendicular legs.",
  },
  {
    title: "Isosceles triangle height",
    formula: "h=\\sqrt{a^2-\\frac{b^2}{4}}",
    note: "Equal side a and base b.",
  },
  {
    title: "Isosceles triangle area",
    formula: "A=\\frac{b}{4}\\sqrt{4a^2-b^2}",
    note: "Equal side a and base b.",
  },
  {
    title: "Equilateral triangle perimeter",
    formula: "P=3a",
    note: "All sides equal.",
  },
  {
    title: "Equilateral triangle height",
    formula: "h=\\frac{\\sqrt3}{2}a",
    note: "Height from side length a.",
  },
  {
    title: "Equilateral triangle inradius",
    formula: "r=\\frac{a\\sqrt3}{6}",
    note: "Radius of inscribed circle.",
  },
  {
    title: "Equilateral triangle circumradius",
    formula: "R=\\frac{a\\sqrt3}{3}",
    note: "Radius of circumscribed circle.",
  },
  {
    title: "Triangle inradius",
    formula: "r=\\frac{A}{s}",
    note: "Area A and semiperimeter s.",
  },
  {
    title: "Triangle circumradius",
    formula: "R=\\frac{abc}{4A}",
    note: "Side lengths a,b,c and area A.",
  },
  {
    title: "Median length",
    formula: "m_a=\\frac{1}{2}\\sqrt{2b^2+2c^2-a^2}",
    note: "Median to side a.",
  },
  {
    title: "Angle bisector length",
    formula: "l_a=\\sqrt{bc\\left(1-\\frac{a^2}{(b+c)^2}\\right)}",
    note: "Internal angle bisector from A.",
  },
  {
    title: "Rectangle diagonal",
    formula: "d=\\sqrt{l^2+b^2}",
    note: "Diagonal from length and breadth.",
  },
  { title: "Square perimeter", formula: "P=4a", note: "Four equal sides." },
  {
    title: "Square area by diagonal",
    formula: "A=\\frac{d^2}{2}",
    note: "Area from diagonal d.",
  },
  {
    title: "Square side from area",
    formula: "a=\\sqrt A",
    note: "Side length from square area.",
  },
  {
    title: "Square side from perimeter",
    formula: "a=\\frac{P}{4}",
    note: "Side length from square perimeter.",
  },
  {
    title: "Parallelogram perimeter",
    formula: "P=2(a+b)",
    note: "Opposite sides equal.",
  },
  {
    title: "Parallelogram area sine",
    formula: "A=ab\\sin\\theta",
    note: "Adjacent sides a,b with included angle theta.",
  },
  {
    title: "Parallelogram height from area",
    formula: "h=\\frac{A}{b}",
    note: "Height from area and base.",
  },
  {
    title: "Parallelogram base from area",
    formula: "b=\\frac{A}{h}",
    note: "Base from area and height.",
  },
  { title: "Rhombus perimeter", formula: "P=4a", note: "Four equal sides." },
  {
    title: "Rhombus area side angle",
    formula: "A=a^2\\sin\\theta",
    note: "Side a with included angle theta.",
  },
  {
    title: "Rhombus side from diagonals",
    formula: "a=\\frac{1}{2}\\sqrt{d_1^2+d_2^2}",
    note: "Diagonals bisect at right angles.",
  },
  {
    title: "Trapezium area",
    formula: "A=\\frac{1}{2}(a+b)h",
    note: "Parallel sides a,b and height h.",
  },
  {
    title: "Trapezium median",
    formula: "m=\\frac{a+b}{2}",
    note: "Midline between parallel sides.",
  },
  {
    title: "Kite area",
    formula: "A=\\frac{1}{2}d_1d_2",
    note: "Half product of diagonals.",
  },
  {
    title: "Kite perimeter",
    formula: "P=2(a+b)",
    note: "Two pairs of adjacent equal sides.",
  },
  {
    title: "Cyclic quadrilateral area",
    formula: "A=\\sqrt{(s-a)(s-b)(s-c)(s-d)}",
    note: "Brahmagupta formula.",
  },
  {
    title: "General quadrilateral area",
    formula: "A=\\frac{1}{2}d_1d_2\\sin\\theta",
    note: "Diagonals d1,d2 with included angle theta.",
  },
  {
    title: "Regular pentagon area",
    formula: "A=\\frac{1}{4}\\sqrt{5(5+2\\sqrt5)}a^2",
    note: "Regular pentagon with side a.",
  },
  {
    title: "Regular hexagon area",
    formula: "A=\\frac{3\\sqrt3}{2}a^2",
    note: "Regular hexagon with side a.",
  },
  {
    title: "Regular hexagon perimeter",
    formula: "P=6a",
    note: "Six equal sides.",
  },
  {
    title: "Regular polygon perimeter",
    formula: "P=ns",
    note: "n sides of length s.",
  },
  {
    title: "Regular polygon apothem",
    formula: "r=\\frac{s}{2\\tan(\\pi/n)}",
    note: "Inradius/apothem.",
  },
  {
    title: "Regular polygon circumradius",
    formula: "R=\\frac{s}{2\\sin(\\pi/n)}",
    note: "Radius to vertices.",
  },
  {
    title: "Regular polygon area apothem",
    formula: "A=\\frac{1}{2}Pr",
    note: "Perimeter P and apothem r.",
  },
  { title: "Circle diameter", formula: "d=2r", note: "Diameter from radius." },
  {
    title: "Circle radius from circumference",
    formula: "r=\\frac{C}{2\\pi}",
    note: "Rearranged circumference.",
  },
  {
    title: "Circle area from diameter",
    formula: "A=\\frac{\\pi d^2}{4}",
    note: "Area using diameter.",
  },
  {
    title: "Circle radius from area",
    formula: "r=\\sqrt{\\frac{A}{\\pi}}",
    note: "Radius from circle area.",
  },
  {
    title: "Circle diameter from area",
    formula: "d=2\\sqrt{\\frac{A}{\\pi}}",
    note: "Diameter from circle area.",
  },
  {
    title: "Semicircle area",
    formula: "A=\\frac{1}{2}\\pi r^2",
    note: "Half of circle area.",
  },
  {
    title: "Semicircle perimeter",
    formula: "P=\\pi r+2r",
    note: "Arc plus diameter.",
  },
  {
    title: "Quadrant area",
    formula: "A=\\frac{1}{4}\\pi r^2",
    note: "One quarter of a circle.",
  },
  {
    title: "Sector area radians",
    formula: "A=\\frac{1}{2}r^2\\theta",
    note: "Theta in radians.",
  },
  {
    title: "Sector perimeter",
    formula: "P=2r+L",
    note: "Two radii plus arc length.",
  },
  {
    title: "Segment area",
    formula: "A=\\frac{r^2}{2}(\\theta-\\sin\\theta)",
    note: "Minor segment, theta in radians.",
  },
  {
    title: "Annulus area",
    formula: "A=\\pi(R^2-r^2)",
    note: "Area between two concentric circles.",
  },
  {
    title: "Ellipse area",
    formula: "A=\\pi ab",
    note: "Semi-major axis a and semi-minor axis b.",
  },
  {
    title: "Ellipse eccentricity",
    formula: "e=\\sqrt{1-\\frac{b^2}{a^2}}",
    note: "For a greater than or equal to b.",
  },
  {
    title: "Ellipse focal distance",
    formula: "c=\\sqrt{a^2-b^2}",
    note: "Distance from center to focus.",
  },
  {
    title: "Parabola latus rectum",
    formula: "L=4a",
    note: "For y^2=4ax or x^2=4ay.",
  },
  {
    title: "Hyperbola eccentricity",
    formula: "e=\\sqrt{1+\\frac{b^2}{a^2}}",
    note: "For x^2/a^2-y^2/b^2=1.",
  },
  {
    title: "Polygon interior angle sum",
    formula: "S=(n-2)180^\\circ",
    note: "For n-sided polygon.",
  },
  {
    title: "Regular polygon interior angle",
    formula: "\\theta=\\frac{(n-2)180^\\circ}{n}",
    note: "Each angle of a regular polygon.",
  },
  {
    title: "Regular polygon exterior angle",
    formula: "\\theta=\\frac{360^\\circ}{n}",
    note: "Each exterior angle.",
  },
  {
    title: "Number of diagonals",
    formula: "D=\\frac{n(n-3)}{2}",
    note: "Diagonals in an n-gon.",
  },
];

const solidShapeFormulaItems: FormulaLibraryItem[] = [
  { title: "Cube volume", formula: "V=a^3", note: "Side length a." },
  {
    title: "Cube total surface area",
    formula: "TSA=6a^2",
    note: "Six square faces.",
  },
  {
    title: "Cube lateral surface area",
    formula: "LSA=4a^2",
    note: "Four side faces.",
  },
  {
    title: "Cube space diagonal",
    formula: "d=a\\sqrt3",
    note: "Diagonal through the cube.",
  },
  {
    title: "Cube edge from volume",
    formula: "a=\\sqrt[3]{V}",
    note: "Edge length from cube volume.",
  },
  {
    title: "Cube edge from surface area",
    formula: "a=\\sqrt{\\frac{S}{6}}",
    note: "Edge length from total surface area.",
  },
  {
    title: "Cuboid volume",
    formula: "V=lbh",
    note: "Length, breadth, height.",
  },
  {
    title: "Cuboid total surface area",
    formula: "TSA=2(lb+bh+hl)",
    note: "All six rectangular faces.",
  },
  {
    title: "Cuboid lateral surface area",
    formula: "LSA=2h(l+b)",
    note: "Four side faces.",
  },
  {
    title: "Cuboid space diagonal",
    formula: "d=\\sqrt{l^2+b^2+h^2}",
    note: "Longest diagonal.",
  },
  {
    title: "Cuboid length from volume",
    formula: "l=\\frac{V}{bh}",
    note: "Length from volume, breadth, and height.",
  },
  {
    title: "Cuboid breadth from volume",
    formula: "b=\\frac{V}{lh}",
    note: "Breadth from volume, length, and height.",
  },
  {
    title: "Cuboid height from volume",
    formula: "h=\\frac{V}{lb}",
    note: "Height from volume, length, and breadth.",
  },
  {
    title: "Right prism volume",
    formula: "V=A_bh",
    note: "Base area times height.",
  },
  {
    title: "Right prism lateral area",
    formula: "LSA=P_bh",
    note: "Base perimeter times height.",
  },
  {
    title: "Triangular prism volume",
    formula: "V=\\frac{1}{2}bhl",
    note: "Triangular base extruded by length l.",
  },
  {
    title: "Triangular prism lateral area",
    formula: "LSA=(a+b+c)l",
    note: "Base side sum times prism length.",
  },
  {
    title: "Cylinder volume",
    formula: "V=\\pi r^2h",
    note: "Circular base area times height.",
  },
  {
    title: "Cylinder base area",
    formula: "A_b=\\pi r^2",
    note: "Area of the circular base.",
  },
  {
    title: "Cylinder curved surface area",
    formula: "CSA=2\\pi rh",
    note: "Curved side only.",
  },
  {
    title: "Cylinder total surface area",
    formula: "TSA=2\\pi r(r+h)",
    note: "Curved side plus two bases.",
  },
  {
    title: "Cylinder radius from volume",
    formula: "r=\\sqrt{\\frac{V}{\\pi h}}",
    note: "Radius from volume and height.",
  },
  {
    title: "Cylinder height from volume",
    formula: "h=\\frac{V}{\\pi r^2}",
    note: "Height from volume and radius.",
  },
  {
    title: "Hollow cylinder volume",
    formula: "V=\\pi h(R^2-r^2)",
    note: "Outer radius R and inner radius r.",
  },
  {
    title: "Cone volume",
    formula: "V=\\frac{1}{3}\\pi r^2h",
    note: "One-third cylinder with same base and height.",
  },
  {
    title: "Cone base area",
    formula: "A_b=\\pi r^2",
    note: "Area of the circular base.",
  },
  {
    title: "Cone curved surface area",
    formula: "CSA=\\pi rl",
    note: "l is slant height.",
  },
  {
    title: "Cone total surface area",
    formula: "TSA=\\pi r(l+r)",
    note: "Curved area plus base.",
  },
  {
    title: "Cone slant height",
    formula: "l=\\sqrt{r^2+h^2}",
    note: "For right circular cone.",
  },
  {
    title: "Cone radius from volume",
    formula: "r=\\sqrt{\\frac{3V}{\\pi h}}",
    note: "Radius from cone volume and height.",
  },
  {
    title: "Cone height from volume",
    formula: "h=\\frac{3V}{\\pi r^2}",
    note: "Height from cone volume and radius.",
  },
  {
    title: "Frustum volume",
    formula: "V=\\frac{1}{3}\\pi h(R^2+Rr+r^2)",
    note: "Truncated cone volume.",
  },
  {
    title: "Frustum curved surface area",
    formula: "CSA=\\pi(R+r)l",
    note: "R,r are radii and l is slant height.",
  },
  {
    title: "Frustum total surface area",
    formula: "TSA=\\pi(R+r)l+\\pi R^2+\\pi r^2",
    note: "Curved area plus two circular ends.",
  },
  {
    title: "Sphere volume",
    formula: "V=\\frac{4}{3}\\pi r^3",
    note: "Volume of sphere.",
  },
  {
    title: "Sphere surface area",
    formula: "S=4\\pi r^2",
    note: "Total surface area of sphere.",
  },
  {
    title: "Sphere diameter",
    formula: "d=2r",
    note: "Diameter is twice the sphere radius.",
  },
  {
    title: "Sphere radius from surface area",
    formula: "r=\\sqrt{\\frac{S}{4\\pi}}",
    note: "Radius from sphere surface area.",
  },
  {
    title: "Sphere radius from volume",
    formula: "r=\\sqrt[3]{\\frac{3V}{4\\pi}}",
    note: "Radius from sphere volume.",
  },
  {
    title: "Hemisphere volume",
    formula: "V=\\frac{2}{3}\\pi r^3",
    note: "Half of sphere volume.",
  },
  {
    title: "Hemisphere curved surface area",
    formula: "CSA=2\\pi r^2",
    note: "Curved surface only.",
  },
  {
    title: "Hemisphere total surface area",
    formula: "TSA=3\\pi r^2",
    note: "Curved surface plus base circle.",
  },
  {
    title: "Spherical shell volume",
    formula: "V=\\frac{4}{3}\\pi(R^3-r^3)",
    note: "Outer radius R and inner radius r.",
  },
  {
    title: "Spherical cap area",
    formula: "A=2\\pi rh",
    note: "Sphere radius r and cap height h.",
  },
  {
    title: "Spherical cap volume",
    formula: "V=\\frac{\\pi h^2}{3}(3r-h)",
    note: "Sphere radius r and cap height h.",
  },
  {
    title: "Square pyramid volume",
    formula: "V=\\frac{1}{3}a^2h",
    note: "Square base side a.",
  },
  {
    title: "Square pyramid lateral area",
    formula: "LSA=2al",
    note: "l is slant height.",
  },
  {
    title: "Square pyramid total surface area",
    formula: "TSA=a^2+2al",
    note: "Base plus four triangular faces.",
  },
  {
    title: "General pyramid volume",
    formula: "V=\\frac{1}{3}A_bh",
    note: "Base area A_b and height h.",
  },
  {
    title: "Regular pyramid lateral area",
    formula: "LSA=\\frac{1}{2}P_bl",
    note: "Base perimeter P_b and slant height l.",
  },
  {
    title: "Tetrahedron volume",
    formula: "V=\\frac{a^3}{6\\sqrt2}",
    note: "Regular tetrahedron side a.",
  },
  {
    title: "Tetrahedron surface area",
    formula: "S=\\sqrt3a^2",
    note: "Regular tetrahedron side a.",
  },
  {
    title: "Octahedron volume",
    formula: "V=\\frac{\\sqrt2}{3}a^3",
    note: "Regular octahedron side a.",
  },
  {
    title: "Octahedron surface area",
    formula: "S=2\\sqrt3a^2",
    note: "Regular octahedron side a.",
  },
  {
    title: "Dodecahedron volume",
    formula: "V=\\frac{15+7\\sqrt5}{4}a^3",
    note: "Regular dodecahedron side a.",
  },
  {
    title: "Dodecahedron surface area",
    formula: "S=3\\sqrt{25+10\\sqrt5}\\,a^2",
    note: "Regular dodecahedron side a.",
  },
  {
    title: "Icosahedron volume",
    formula: "V=\\frac{5(3+\\sqrt5)}{12}a^3",
    note: "Regular icosahedron side a.",
  },
  {
    title: "Icosahedron surface area",
    formula: "S=5\\sqrt3a^2",
    note: "Regular icosahedron side a.",
  },
  {
    title: "Torus volume",
    formula: "V=2\\pi^2Rr^2",
    note: "Major radius R and minor radius r.",
  },
  {
    title: "Torus surface area",
    formula: "S=4\\pi^2Rr",
    note: "Major radius R and minor radius r.",
  },
  {
    title: "Ellipsoid volume",
    formula: "V=\\frac{4}{3}\\pi abc",
    note: "Semi-axes a,b,c.",
  },
  {
    title: "Oblique prism volume",
    formula: "V=A_bh",
    note: "Uses perpendicular height.",
  },
  {
    title: "Composite solid volume",
    formula: "V_{total}=V_1+V_2+\\cdots+V_n",
    note: "Add non-overlapping parts.",
  },
  {
    title: "Composite solid surface area",
    formula: "S_{visible}=S_1+S_2-2S_{joined}",
    note: "Subtract hidden joined faces.",
  },
  {
    title: "Scale factor area",
    formula: "A'=k^2A",
    note: "Area scales by square of length factor.",
  },
  {
    title: "Scale factor volume",
    formula: "V'=k^3V",
    note: "Volume scales by cube of length factor.",
  },
];

const unacademyCoverageItems: Record<string, FormulaLibraryItem[]> = {
  algebra: [
    {
      title: "Square sum rearrangement",
      formula: "a^2+b^2=(a+b)^2-2ab",
      note: "Useful identity from expansion.",
    },
    {
      title: "Square difference rearrangement",
      formula: "a^2+b^2=(a-b)^2+2ab",
      note: "Alternative form using difference.",
    },
    {
      title: "Three-variable square",
      formula: "(a+b+c)^2=a^2+b^2+c^2+2ab+2bc+2ca",
      note: "Expansion of three-term square.",
    },
    {
      title: "Sum of pairwise products",
      formula: "ab+bc+ca=\\frac{(a+b+c)^2-(a^2+b^2+c^2)}{2}",
      note: "Rearranged three-variable identity.",
    },
    {
      title: "Difference of fourth powers",
      formula: "a^4-b^4=(a-b)(a+b)(a^2+b^2)",
      note: "Factorization through difference of squares.",
    },
    {
      title: "Fourth power binomial",
      formula: "(a+b)^4=a^4+4a^3b+6a^2b^2+4ab^3+b^4",
      note: "Binomial expansion for n=4.",
    },
    {
      title: "Completing square equation",
      formula: "x^2+px+q=\\left(x+\\frac p2\\right)^2+q-\\frac{p^2}{4}",
      note: "Monic quadratic vertex form.",
    },
    {
      title: "Arithmetic mean of two numbers",
      formula: "AM=\\frac{a+b}{2}",
      note: "Middle value between two numbers.",
    },
    {
      title: "Geometric mean of two numbers",
      formula: "GM=\\sqrt{ab}",
      note: "For non-negative a,b.",
    },
    {
      title: "Harmonic mean of two numbers",
      formula: "HM=\\frac{2ab}{a+b}",
      note: "Reciprocal average form.",
    },
  ],
  "number-systems": [
    {
      title: "Consecutive integers",
      formula: "n,n+1,n+2,\\ldots",
      note: "Integers increasing by one.",
    },
    {
      title: "Consecutive even integers",
      formula: "2n,2n+2,2n+4,\\ldots",
      note: "Even numbers separated by two.",
    },
    {
      title: "Consecutive odd integers",
      formula: "2n+1,2n+3,2n+5,\\ldots",
      note: "Odd numbers separated by two.",
    },
    {
      title: "Sum of first n even numbers",
      formula: "2+4+\\cdots+2n=n(n+1)",
      note: "Even-number sum.",
    },
    {
      title: "Sum of first n odd numbers",
      formula: "1+3+\\cdots+(2n-1)=n^2",
      note: "Odd-number sum.",
    },
    {
      title: "Sum of first n natural numbers",
      formula: "1+2+\\cdots+n=\\frac{n(n+1)}{2}",
      note: "Triangular number.",
    },
    {
      title: "Prime test limit",
      formula:
        "n\\text{ prime}\\Rightarrow n\\text{ has no divisor }d\\le\\sqrt n",
      note: "Trial division only needs divisors up to square root.",
    },
    {
      title: "HCF and LCM relation",
      formula: "HCF(a,b)\\times LCM(a,b)=ab",
      note: "For positive integers.",
    },
    {
      title: "Decimal place shift",
      formula: "a\\times10^n\\text{ shifts decimal }n\\text{ places}",
      note: "Right for positive n, left for negative n.",
    },
    {
      title: "Recurring decimal geometric form",
      formula:
        "0.\\overline a=\\frac{a}{9},\\quad 0.\\overline{ab}=\\frac{ab}{99}",
      note: "Converts repeating decimals to fractions.",
    },
  ],
  trigonometry: [
    {
      title: "Special angles sine",
      formula:
        "\\sin0^\\circ=0,\\quad \\sin30^\\circ=\\frac12,\\quad \\sin45^\\circ=\\frac1{\\sqrt2},\\quad \\sin60^\\circ=\\frac{\\sqrt3}{2},\\quad \\sin90^\\circ=1",
      note: "Common exact sine values.",
    },
    {
      title: "Special angles cosine",
      formula:
        "\\cos0^\\circ=1,\\quad \\cos30^\\circ=\\frac{\\sqrt3}{2},\\quad \\cos45^\\circ=\\frac1{\\sqrt2},\\quad \\cos60^\\circ=\\frac12,\\quad \\cos90^\\circ=0",
      note: "Common exact cosine values.",
    },
    {
      title: "Special angles tangent",
      formula:
        "\\tan0^\\circ=0,\\quad \\tan30^\\circ=\\frac1{\\sqrt3},\\quad \\tan45^\\circ=1,\\quad \\tan60^\\circ=\\sqrt3",
      note: "Common exact tangent values.",
    },
    {
      title: "Tangent quotient",
      formula: "\\tan\\theta=\\frac{\\sin\\theta}{\\cos\\theta}",
      note: "Connects tangent with sine and cosine.",
    },
    {
      title: "Cotangent quotient",
      formula: "\\cot\\theta=\\frac{\\cos\\theta}{\\sin\\theta}",
      note: "Reciprocal quotient form.",
    },
    {
      title: "Cosine double angle variants",
      formula: "\\cos2x=2\\cos^2x-1,\\quad \\cos2x=1-2\\sin^2x",
      note: "Equivalent double-angle forms.",
    },
    {
      title: "Half angle sine",
      formula: "\\sin^2\\frac{x}{2}=\\frac{1-\\cos x}{2}",
      note: "Half-angle identity.",
    },
    {
      title: "Half angle cosine",
      formula: "\\cos^2\\frac{x}{2}=\\frac{1+\\cos x}{2}",
      note: "Half-angle identity.",
    },
    {
      title: "Product to sum sine-cosine",
      formula: "2\\sin A\\cos B=\\sin(A+B)+\\sin(A-B)",
      note: "Product-to-sum identity.",
    },
    {
      title: "Product to sum cosine-cosine",
      formula: "2\\cos A\\cos B=\\cos(A+B)+\\cos(A-B)",
      note: "Product-to-sum identity.",
    },
  ],
  geometry: [
    {
      title: "Right triangle hypotenuse",
      formula: "c=\\sqrt{a^2+b^2}",
      note: "Hypotenuse from perpendicular legs.",
    },
    {
      title: "Right triangle leg",
      formula: "a=\\sqrt{c^2-b^2}",
      note: "Unknown leg from hypotenuse and other leg.",
    },
    {
      title: "Triangle inequality",
      formula: "a+b>c,\\quad b+c>a,\\quad c+a>b",
      note: "Necessary for a triangle.",
    },
    {
      title: "Triangle altitude from area",
      formula: "h=\\frac{2A}{b}",
      note: "Height from area and chosen base.",
    },
    {
      title: "Equilateral triangle circumradius",
      formula: "R=\\frac{a}{\\sqrt3}",
      note: "Distance from center to vertex.",
    },
    {
      title: "Equilateral triangle inradius",
      formula: "r=\\frac{a}{2\\sqrt3}",
      note: "Distance from center to side.",
    },
    {
      title: "Regular octagon perimeter",
      formula: "P=8a",
      note: "Eight equal sides.",
    },
    {
      title: "Regular octagon area",
      formula: "A=2(1+\\sqrt2)a^2",
      note: "Regular octagon side a.",
    },
    {
      title: "Circle chord length",
      formula: "c=2r\\sin\\frac{\\theta}{2}",
      note: "Central angle theta.",
    },
    {
      title: "Circle segment height",
      formula: "h=r-\\sqrt{r^2-\\frac{c^2}{4}}",
      note: "Sagitta from chord length c.",
    },
    {
      title: "Arc angle from length",
      formula: "\\theta=\\frac{L}{r}",
      note: "Theta in radians.",
    },
    {
      title: "Sector angle from area",
      formula: "\\theta=\\frac{2A}{r^2}",
      note: "Theta in radians.",
    },
  ],
  "coordinate-geometry": [
    {
      title: "Internal section formula",
      formula: "P=\\left(\\frac{mx_2+nx_1}{m+n},\\frac{my_2+ny_1}{m+n}\\right)",
      note: "Point dividing segment internally in m:n.",
    },
    {
      title: "External section formula",
      formula: "P=\\left(\\frac{mx_2-nx_1}{m-n},\\frac{my_2-ny_1}{m-n}\\right)",
      note: "Point dividing segment externally in m:n.",
    },
    {
      title: "Line intercept form",
      formula: "\\frac{x}{a}+\\frac{y}{b}=1",
      note: "x-intercept a and y-intercept b.",
    },
    {
      title: "Line two-point form",
      formula: "y-y_1=\\frac{y_2-y_1}{x_2-x_1}(x-x_1)",
      note: "Line through two points.",
    },
    {
      title: "Distance from point to line",
      formula: "d=\\frac{|Ax_1+By_1+C|}{\\sqrt{A^2+B^2}}",
      note: "For line Ax+By+C=0.",
    },
    {
      title: "Area of triangle coordinates",
      formula: "A=\\frac12|x_1(y_2-y_3)+x_2(y_3-y_1)+x_3(y_1-y_2)|",
      note: "Shoelace formula for three points.",
    },
    {
      title: "Centroid coordinates",
      formula: "G=\\left(\\frac{x_1+x_2+x_3}{3},\\frac{y_1+y_2+y_3}{3}\\right)",
      note: "Triangle centroid.",
    },
    {
      title: "Reflection in x-axis",
      formula: "(x,y)\\mapsto(x,-y)",
      note: "Coordinate transformation.",
    },
    {
      title: "Reflection in y-axis",
      formula: "(x,y)\\mapsto(-x,y)",
      note: "Coordinate transformation.",
    },
    {
      title: "Reflection in origin",
      formula: "(x,y)\\mapsto(-x,-y)",
      note: "Coordinate transformation.",
    },
  ],
  "limits-continuity": [
    {
      title: "Limit of tangent over x",
      formula: "\\lim_{x\\to0}\\frac{\\tan x}{x}=1",
      note: "x in radians.",
    },
    {
      title: "Limit of sine ax over sine bx",
      formula: "\\lim_{x\\to0}\\frac{\\sin ax}{\\sin bx}=\\frac{a}{b}",
      note: "Standard trigonometric limit.",
    },
    {
      title: "Limit of one minus cos ax",
      formula: "\\lim_{x\\to0}\\frac{1-\\cos ax}{x^2}=\\frac{a^2}{2}",
      note: "Second-order cosine limit.",
    },
    {
      title: "Exponential compound limit",
      formula: "\\lim_{n\\to\\infty}\\left(1+\\frac{x}{n}\\right)^n=e^x",
      note: "Defines exponential growth limit.",
    },
  ],
  derivatives: [
    {
      title: "Derivative of tan",
      formula: "\\frac{d}{dx}\\tan x=\\sec^2x",
      note: "Trigonometric derivative.",
    },
    {
      title: "Derivative of cot",
      formula: "\\frac{d}{dx}\\cot x=-\\csc^2x",
      note: "Trigonometric derivative.",
    },
    {
      title: "Derivative of sec",
      formula: "\\frac{d}{dx}\\sec x=\\sec x\\tan x",
      note: "Trigonometric derivative.",
    },
    {
      title: "Derivative of csc",
      formula: "\\frac{d}{dx}\\csc x=-\\csc x\\cot x",
      note: "Trigonometric derivative.",
    },
    {
      title: "Derivative of inverse sine",
      formula: "\\frac{d}{dx}\\sin^{-1}x=\\frac{1}{\\sqrt{1-x^2}}",
      note: "For |x|<1.",
    },
    {
      title: "Derivative of inverse tangent",
      formula: "\\frac{d}{dx}\\tan^{-1}x=\\frac{1}{1+x^2}",
      note: "Inverse trigonometric derivative.",
    },
  ],
  integrals: [
    {
      title: "Integral of tan",
      formula: "\\int\\tan x\\,dx=\\ln|\\sec x|+C",
      note: "Standard trig integral.",
    },
    {
      title: "Integral of cot",
      formula: "\\int\\cot x\\,dx=\\ln|\\sin x|+C",
      note: "Standard trig integral.",
    },
    {
      title: "Integral of sec",
      formula: "\\int\\sec x\\,dx=\\ln|\\sec x+\\tan x|+C",
      note: "Standard trig integral.",
    },
    {
      title: "Integral of csc",
      formula: "\\int\\csc x\\,dx=\\ln|\\csc x-\\cot x|+C",
      note: "Standard trig integral.",
    },
    {
      title: "Integral inverse tangent form",
      formula: "\\int\\frac{dx}{a^2+x^2}=\\frac1a\\tan^{-1}\\frac{x}{a}+C",
      note: "For positive a.",
    },
    {
      title: "Integral inverse sine form",
      formula: "\\int\\frac{dx}{\\sqrt{a^2-x^2}}=\\sin^{-1}\\frac{x}{a}+C",
      note: "Standard radical integral.",
    },
  ],
  vectors: [
    {
      title: "Resultant of two vectors",
      formula: "|\\vec R|=\\sqrt{A^2+B^2+2AB\\cos\\theta}",
      note: "Magnitude of sum of two vectors.",
    },
    {
      title: "Direction of resultant",
      formula: "\\tan\\alpha=\\frac{B\\sin\\theta}{A+B\\cos\\theta}",
      note: "Angle alpha from vector A.",
    },
    {
      title: "Vector from two points",
      formula: "\\overrightarrow{AB}=\\langle x_2-x_1,y_2-y_1,z_2-z_1\\rangle",
      note: "Components from A to B.",
    },
    {
      title: "Direction ratios",
      formula: "a:b:c=(x_2-x_1):(y_2-y_1):(z_2-z_1)",
      note: "Ratios for a line direction.",
    },
  ],
  "set-theory-logic": [
    {
      title: "Two-set union count",
      formula: "n(A\\cup B)=n(A)+n(B)-n(A\\cap B)",
      note: "Inclusion-exclusion for two sets.",
    },
    {
      title: "Three-set union count",
      formula:
        "n(A\\cup B\\cup C)=n(A)+n(B)+n(C)-n(A\\cap B)-n(B\\cap C)-n(C\\cap A)+n(A\\cap B\\cap C)",
      note: "Inclusion-exclusion for three sets.",
    },
    {
      title: "Complement count",
      formula: "n(A')=n(U)-n(A)",
      note: "Elements outside A in universal set U.",
    },
    {
      title: "Cartesian product count",
      formula: "n(A\\times B)=n(A)n(B)",
      note: "Number of ordered pairs.",
    },
  ],
  "commercial-math": [
    {
      title: "Selling price from profit",
      formula: "SP=CP+Profit",
      note: "Add profit to cost price.",
    },
    {
      title: "Selling price from loss",
      formula: "SP=CP-Loss",
      note: "Subtract loss from cost price.",
    },
    {
      title: "Cost price from profit percent",
      formula: "CP=\\frac{100\\,SP}{100+Profit\\%}",
      note: "Recover cost when profit percent and selling price are known.",
    },
    {
      title: "Cost price from loss percent",
      formula: "CP=\\frac{100\\,SP}{100-Loss\\%}",
      note: "Recover cost when loss percent and selling price are known.",
    },
    {
      title: "Marked price after discount",
      formula: "SP=MP\\left(1-\\frac{d}{100}\\right)",
      note: "Discount d percent.",
    },
    {
      title: "Successive discount",
      formula: "d_{eq}=a+b-\\frac{ab}{100}",
      note: "Equivalent discount for a percent then b percent.",
    },
    {
      title: "Successive percentage increase",
      formula: "r_{eq}=a+b+\\frac{ab}{100}",
      note: "Equivalent increase for a percent then b percent.",
    },
    {
      title: "Percent error",
      formula: "\\%error=\\frac{|actual-approx|}{actual}\\times100\\%",
      note: "Relative error as a percent.",
    },
  ],
  "mensuration-units": [
    {
      title: "Celsius to Fahrenheit",
      formula: "F=\\frac95C+32",
      note: "Temperature conversion.",
    },
    {
      title: "Fahrenheit to Celsius",
      formula: "C=\\frac59(F-32)",
      note: "Temperature conversion.",
    },
    {
      title: "Kilometer to meter",
      formula: "1\\,km=1000\\,m",
      note: "Metric length conversion.",
    },
    {
      title: "Meter to centimeter",
      formula: "1\\,m=100\\,cm",
      note: "Metric length conversion.",
    },
    {
      title: "Kilogram to gram",
      formula: "1\\,kg=1000\\,g",
      note: "Metric mass conversion.",
    },
    {
      title: "Liter to milliliter",
      formula: "1\\,L=1000\\,mL",
      note: "Metric capacity conversion.",
    },
    {
      title: "Kilometer to mile",
      formula: "1\\,km\\approx0.621371\\,mi",
      note: "Length conversion.",
    },
    {
      title: "Mile to kilometer",
      formula: "1\\,mi\\approx1.60934\\,km",
      note: "Length conversion.",
    },
    {
      title: "Foot to meter",
      formula: "1\\,ft=0.3048\\,m",
      note: "Length conversion.",
    },
    {
      title: "Inch to centimeter",
      formula: "1\\,in=2.54\\,cm",
      note: "Length conversion.",
    },
  ],
};

formulaCategories.forEach((category) => {
  category.formulas.push(...(expandedFormulaItems[category.id] ?? []));
  category.formulas.push(...(unacademyCoverageItems[category.id] ?? []));
  if (category.id === "geometry")
    category.formulas.push(...geometryShapeFormulaItems);
  if (category.id === "mensuration-units")
    category.formulas.push(...solidShapeFormulaItems);
  const canonicalTitles = new Set<string>();
  category.formulas = category.formulas.filter((item) => {
    const canonicalTitle = item.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
    if (canonicalTitles.has(canonicalTitle)) return false;
    canonicalTitles.add(canonicalTitle);
    return true;
  });
});

export const formulaCategoryCount = formulaCategories.length;
