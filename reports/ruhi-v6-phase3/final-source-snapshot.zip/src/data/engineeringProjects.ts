import { engineeringMathDomains } from "./engineeringMathBlueprint";

export type EngineeringProjectDifficulty = "guided" | "studio" | "capstone";

export type EngineeringProject = {
  id: string;
  domainId: string;
  title: string;
  difficulty: EngineeringProjectDifficulty;
  brief: string;
  workspaceRoute: string;
  deliverables: string[];
  rubric: string[];
  evidence: string[];
  estimatedMinutes: number;
};

export const engineeringProjects: EngineeringProject[] = [
  {
    id: "calculus-surface-sensitivity-report",
    domainId: "engineering-calculus",
    title: "Surface sensitivity report",
    difficulty: "studio",
    brief:
      "Use a 3D surface to explain how scale, cross-section, and local slope change an engineering design choice.",
    workspaceRoute: "/syllabus-lab/partial-derivative-slicer",
    deliverables: [
      "Annotated surface screenshot",
      "partial derivative notes",
      "cross-section interpretation",
    ],
    rubric: [
      "Explains variables and units",
      "links slope to local sensitivity",
      "uses a clear visual checkpoint",
    ],
    evidence: [
      "3D workspace route",
      "formula family note",
      "one engineering use case",
    ],
    estimatedMinutes: 45,
  },
  {
    id: "calculus-jacobian-region-conversion",
    domainId: "engineering-calculus",
    title: "Jacobian region conversion sheet",
    difficulty: "guided",
    brief:
      "Convert a region between coordinate systems and document the determinant factor used in area or volume integration.",
    workspaceRoute: "/syllabus-lab/jacobian-area-scaling-lab",
    deliverables: [
      "before and after region sketch",
      "Jacobian determinant",
      "integral bounds checklist",
    ],
    rubric: [
      "states the transformation",
      "checks determinant sign or magnitude",
      "matches bounds to the transformed region",
    ],
    evidence: ["Formula Map route", "worked conversion", "dimension check"],
    estimatedMinutes: 35,
  },
  {
    id: "ode-rc-response-comparison",
    domainId: "engineering-differential-equations",
    title: "RC response comparison",
    difficulty: "guided",
    brief:
      "Compare a first-order circuit response against a slope-field view and identify the steady state.",
    workspaceRoute: "/syllabus-lab/slope-field-generator",
    deliverables: [
      "equation setup",
      "slope-field observation",
      "steady-state sentence",
    ],
    rubric: [
      "uses initial condition",
      "identifies time constant",
      "compares analytic and visual behavior",
    ],
    evidence: [
      "slope-field route",
      "solution curve note",
      "engineering interpretation",
    ],
    estimatedMinutes: 40,
  },
  {
    id: "ode-damped-vibration-model",
    domainId: "engineering-differential-equations",
    title: "Damped vibration model",
    difficulty: "capstone",
    brief:
      "Model a mass-spring-damper system, classify the damping case, and connect roots to physical motion.",
    workspaceRoute: "/syllabus-lab/higher-order-ode-characteristic-lab",
    deliverables: [
      "characteristic equation",
      "root classification",
      "motion sketch",
    ],
    rubric: [
      "matches roots to damping type",
      "uses correct constants",
      "explains transient response",
    ],
    evidence: ["higher-order ODE lab", "root table", "final response formula"],
    estimatedMinutes: 60,
  },
  {
    id: "linear-rank-consistency-audit",
    domainId: "engineering-linear-algebra",
    title: "Rank consistency audit",
    difficulty: "guided",
    brief:
      "Audit a system of equations using row reduction and decide whether the system has none, one, or many solutions.",
    workspaceRoute: "/syllabus-lab/rank-consistency-row-reduction",
    deliverables: ["augmented matrix", "rank comparison", "solution verdict"],
    rubric: [
      "keeps row operations traceable",
      "compares coefficient and augmented ranks",
      "states free variables if needed",
    ],
    evidence: ["row-reduction route", "rank note", "consistency statement"],
    estimatedMinutes: 35,
  },
  {
    id: "linear-eigen-transform-storyboard",
    domainId: "engineering-linear-algebra",
    title: "Eigen transform storyboard",
    difficulty: "studio",
    brief:
      "Create a visual storyboard showing how a matrix transform changes basis directions and preserves eigen directions.",
    workspaceRoute: "/syllabus-lab/eigenvector-direction-visualizer",
    deliverables: [
      "matrix transform setup",
      "eigenvalue notes",
      "before-after vector sketch",
    ],
    rubric: [
      "separates generic and eigen vectors",
      "labels scaling factors",
      "connects visual motion to algebra",
    ],
    evidence: ["linear algebra lab", "eigen check", "application caption"],
    estimatedMinutes: 50,
  },
  {
    id: "transforms-laplace-ivp-handoff",
    domainId: "transforms-signals",
    title: "Laplace IVP handoff",
    difficulty: "guided",
    brief:
      "Turn an initial-value differential equation into an algebraic Laplace-domain workflow and invert the result.",
    workspaceRoute: "/syllabus-lab/laplace-transform-workflow",
    deliverables: [
      "Laplace transform setup",
      "algebraic solve",
      "inverse transform result",
    ],
    rubric: [
      "includes initial conditions",
      "uses transform table correctly",
      "checks time-domain behavior",
    ],
    evidence: ["Laplace workflow route", "table lookup", "final response"],
    estimatedMinutes: 45,
  },
  {
    id: "transforms-fourier-harmonic-brief",
    domainId: "transforms-signals",
    title: "Fourier harmonic brief",
    difficulty: "studio",
    brief:
      "Explain how the first few harmonics approximate a periodic signal and where engineering error remains visible.",
    workspaceRoute: "/syllabus-lab/fourier-transform-spectrum-lab",
    deliverables: ["signal choice", "harmonic table", "spectrum explanation"],
    rubric: [
      "identifies symmetry",
      "connects coefficients to frequency content",
      "notes approximation limits",
    ],
    evidence: ["Fourier lab route", "coefficient list", "error observation"],
    estimatedMinutes: 50,
  },
  {
    id: "pde-heat-grid-stability-note",
    domainId: "partial-differential-equations",
    title: "Heat grid stability note",
    difficulty: "studio",
    brief:
      "Use a heat-equation grid to document how step sizes affect stable numerical diffusion.",
    workspaceRoute: "/syllabus-lab/heat-equation-color-map",
    deliverables: [
      "grid parameters",
      "stability ratio",
      "temperature-map observation",
    ],
    rubric: [
      "states boundary conditions",
      "checks stability limit",
      "connects color map to heat flow",
    ],
    evidence: ["heat map lab", "ratio calculation", "boundary note"],
    estimatedMinutes: 55,
  },
  {
    id: "pde-type-decision-tree",
    domainId: "partial-differential-equations",
    title: "PDE type decision tree",
    difficulty: "guided",
    brief:
      "Classify PDEs as elliptic, parabolic, or hyperbolic and map each class to a physical model.",
    workspaceRoute: "/syllabus-lab/pde-classification-characteristics-lab",
    deliverables: [
      "coefficient table",
      "discriminant checks",
      "physical model labels",
    ],
    rubric: [
      "uses the correct discriminant",
      "states equation type",
      "matches type to behavior",
    ],
    evidence: ["classification lab", "decision tree", "example equation"],
    estimatedMinutes: 40,
  },
  {
    id: "numerical-root-convergence-log",
    domainId: "numerical-methods",
    title: "Root-finding convergence log",
    difficulty: "guided",
    brief:
      "Compare Newton, bisection, or secant iterations and explain convergence speed using error behavior.",
    workspaceRoute: "/syllabus-lab/newton-raphson-tangent-iteration",
    deliverables: ["iteration table", "error trend", "method recommendation"],
    rubric: [
      "uses stopping criteria",
      "tracks error consistently",
      "explains failure risks",
    ],
    evidence: ["Newton lab route", "iteration rows", "residual check"],
    estimatedMinutes: 45,
  },
  {
    id: "numerical-quadrature-comparison-table",
    domainId: "numerical-methods",
    title: "Quadrature comparison table",
    difficulty: "studio",
    brief:
      "Compare numerical integration formulas on the same function and explain the accuracy tradeoff.",
    workspaceRoute: "/syllabus-lab/gaussian-quadrature-lab",
    deliverables: ["method table", "error comparison", "accuracy conclusion"],
    rubric: [
      "uses shared interval and function",
      "reports comparable estimates",
      "justifies method choice",
    ],
    evidence: ["quadrature lab", "computed values", "error statement"],
    estimatedMinutes: 50,
  },
  {
    id: "probability-queue-stability-dashboard",
    domainId: "probability-statistics-stochastic",
    title: "Queue stability dashboard",
    difficulty: "capstone",
    brief:
      "Build a compact queueing interpretation that checks utilization, waiting behavior, and reliability risk.",
    workspaceRoute: "/syllabus-lab/reliability-markov-queueing-lab",
    deliverables: [
      "arrival-service inputs",
      "utilization check",
      "waiting-time interpretation",
    ],
    rubric: [
      "states assumptions",
      "checks stability before formulas",
      "connects output to operations decision",
    ],
    evidence: ["queueing lab route", "probability model", "decision note"],
    estimatedMinutes: 65,
  },
  {
    id: "probability-distribution-selection-memo",
    domainId: "probability-statistics-stochastic",
    title: "Distribution selection memo",
    difficulty: "guided",
    brief:
      "Choose a distribution for an engineering scenario and defend it using assumptions, parameters, and outputs.",
    workspaceRoute: "/syllabus-lab/probability-distribution-expectation-lab",
    deliverables: [
      "scenario description",
      "distribution choice",
      "parameter estimate",
    ],
    rubric: [
      "matches model to data type",
      "defines parameters",
      "interprets probability result",
    ],
    evidence: ["probability lab", "assumption list", "computed probability"],
    estimatedMinutes: 35,
  },
  {
    id: "optimization-lp-resource-plan",
    domainId: "optimization-operations-research",
    title: "LP resource plan",
    difficulty: "studio",
    brief:
      "Frame a resource-allocation problem as a linear program and explain the optimal corner-point decision.",
    workspaceRoute: "/syllabus-lab/operations-research-lp",
    deliverables: [
      "decision variables",
      "objective and constraints",
      "optimal plan note",
    ],
    rubric: [
      "uses valid inequalities",
      "interprets feasible region",
      "connects optimum to resources",
    ],
    evidence: ["LP lab route", "constraint list", "corner-point check"],
    estimatedMinutes: 55,
  },
  {
    id: "optimization-pert-critical-path-pack",
    domainId: "optimization-operations-research",
    title: "PERT critical path pack",
    difficulty: "capstone",
    brief:
      "Create a network schedule, identify the critical path, and explain slack for project-control decisions.",
    workspaceRoute: "/syllabus-lab/network-pert-game-theory-lab",
    deliverables: ["activity network", "critical path", "slack table"],
    rubric: [
      "orders dependencies correctly",
      "computes earliest and latest times",
      "uses slack to justify priority",
    ],
    evidence: ["PERT lab route", "network diagram", "schedule recommendation"],
    estimatedMinutes: 70,
  },
  {
    id: "vector-flux-circulation-field-report",
    domainId: "vector-calculus-fields",
    title: "Flux circulation field report",
    difficulty: "studio",
    brief:
      "Use a field-theorem view to compare flux, circulation, divergence, and curl in one engineering field.",
    workspaceRoute: "/syllabus-lab/vector-calculus-field-theorems",
    deliverables: [
      "field definition",
      "theorem selection",
      "flux or circulation interpretation",
    ],
    rubric: [
      "chooses the correct theorem",
      "defines orientation",
      "connects local and global behavior",
    ],
    evidence: [
      "field theorem lab",
      "vector field note",
      "physical interpretation",
    ],
    estimatedMinutes: 55,
  },
  {
    id: "vector-line-integral-path-setup",
    domainId: "vector-calculus-fields",
    title: "Line integral path setup",
    difficulty: "guided",
    brief:
      "Parametrize a path and set up a line integral for work, circulation, or accumulated field effect.",
    workspaceRoute: "/syllabus-lab/vector-calculus-field-theorems",
    deliverables: [
      "path parametrization",
      "integrand setup",
      "orientation note",
    ],
    rubric: [
      "uses correct path limits",
      "substitutes the field consistently",
      "states what the integral measures",
    ],
    evidence: ["parametric route", "path sketch", "integral setup"],
    estimatedMinutes: 40,
  },
  {
    id: "complex-residue-contour-brief",
    domainId: "complex-special-control",
    title: "Residue contour brief",
    difficulty: "studio",
    brief:
      "Identify singularities inside a contour, compute residues, and interpret the contour integral result.",
    workspaceRoute: "/syllabus-lab/complex-line-integral-lab",
    deliverables: [
      "singularity list",
      "residue calculation",
      "contour-integral result",
    ],
    rubric: [
      "separates inside and outside poles",
      "computes residues cleanly",
      "uses the residue theorem correctly",
    ],
    evidence: ["complex integral lab", "pole map", "final contour value"],
    estimatedMinutes: 55,
  },
  {
    id: "complex-pole-response-card",
    domainId: "complex-special-control",
    title: "Pole response card",
    difficulty: "capstone",
    brief:
      "Use poles and zeros to explain control-system response, stability, and dominant transient behavior.",
    workspaceRoute: "/syllabus-lab/control-system-response-lab",
    deliverables: [
      "transfer function",
      "pole-zero sketch",
      "response interpretation",
    ],
    rubric: [
      "identifies stable and unstable regions",
      "connects dominant poles to transient shape",
      "explains engineering consequence",
    ],
    evidence: ["control response lab", "pole-zero card", "stability note"],
    estimatedMinutes: 65,
  },
];

export function projectsForDomain(domainId: string) {
  return engineeringProjects.filter((project) => project.domainId === domainId);
}

export function projectSummary() {
  const domainIds = new Set(engineeringMathDomains.map((domain) => domain.id));
  const coveredDomainIds = new Set(
    engineeringProjects.map((project) => project.domainId),
  );
  return {
    projectCount: engineeringProjects.length,
    domainCount: domainIds.size,
    coveredDomainCount: Array.from(domainIds).filter((domainId) =>
      coveredDomainIds.has(domainId),
    ).length,
    capstoneCount: engineeringProjects.filter(
      (project) => project.difficulty === "capstone",
    ).length,
    deliverableCount: engineeringProjects.reduce(
      (sum, project) => sum + project.deliverables.length,
      0,
    ),
    totalMinutes: engineeringProjects.reduce(
      (sum, project) => sum + project.estimatedMinutes,
      0,
    ),
  };
}
