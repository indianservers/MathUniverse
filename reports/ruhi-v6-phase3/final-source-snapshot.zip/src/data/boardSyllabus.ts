export type SyllabusBoard =
  "International Core" | "CBSE" | "Cambridge IGCSE" | "IB";

export type BoardSyllabusTopic = {
  id: string;
  board: SyllabusBoard;
  grade: string;
  phase: string;
  strand: string;
  title: string;
  topics: string[];
  visual2D: string;
  visual3D: string;
  route: string;
  sourceNote: string;
};

type TopicInput = Omit<BoardSyllabusTopic, "id" | "route">;

function slug(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function topic(input: TopicInput): BoardSyllabusTopic {
  const id = slug(`${input.board}-${input.grade}-${input.title}`);
  return { ...input, id, route: `/syllabus-visual/${id}` };
}

const cbseSource =
  "CBSE/NCERT school mathematics progression, aligned to current secondary and senior-secondary curriculum themes.";
const internationalCoreSource =
  "International middle-school and secondary mathematics progression, with Grade 6-12 foundations, algebra, geometry, statistics, calculus, vectors, and modelling packs.";
const cambridgeSource =
  "Cambridge Lower Secondary bridge, Cambridge IGCSE Mathematics 0580, and senior Cambridge mathematics extension path.";
const ibSource =
  "IB MYP mathematics strands for Grades 6-10 and DP Mathematics AA/AI strands for Grades 11-12.";

export const boardSyllabusTopics: BoardSyllabusTopic[] = [
  topic({
    board: "International Core",
    grade: "Class 6",
    phase: "Middle School Foundations",
    strand: "Numbers, Geometry, Data",
    title:
      "Whole numbers, factors, fractions, integers, basic geometry, mensuration and data",
    topics: [
      "Number system",
      "Factors and multiples",
      "Fractions and decimals",
      "Integers",
      "Basic geometrical ideas",
      "Perimeter and area",
      "Data handling",
    ],
    visual2D: "Number lines, fraction bars, angle grids and bar charts",
    visual3D: "Cuboid area-volume blocks and coordinate floor model",
    sourceNote: internationalCoreSource,
  }),
  topic({
    board: "International Core",
    grade: "Class 7",
    phase: "Middle School Number and Geometry",
    strand: "Number and Algebra Foundations",
    title:
      "Integers, rational numbers, simple equations, lines, triangles, comparing quantities and solid shapes",
    topics: [
      "Integers",
      "Rational numbers",
      "Simple equations",
      "Lines and angles",
      "Triangles",
      "Percentages",
      "Symmetry",
      "Solid shapes",
    ],
    visual2D: "Equation balance, triangle angle dragger and percent bars",
    visual3D: "Rotating nets, prisms and pyramid views",
    sourceNote: internationalCoreSource,
  }),
  topic({
    board: "International Core",
    grade: "Class 8",
    phase: "Lower Secondary Algebra and Measurement",
    strand: "Algebra, Graphs, Mensuration",
    title:
      "Linear equations, quadrilaterals, squares, cubes, exponents, factorisation, proportions and graphs",
    topics: [
      "Linear equations",
      "Quadrilaterals",
      "Squares and cubes",
      "Algebraic identities",
      "Factorisation",
      "Direct and inverse proportion",
      "Graphs",
      "Mensuration",
    ],
    visual2D: "Identity tiles, proportion graphs and coordinate plotting",
    visual3D: "Cube-root blocks and prism/cylinder measurement models",
    sourceNote: internationalCoreSource,
  }),
  topic({
    board: "International Core",
    grade: "Class 9",
    phase: "Secondary Foundation",
    strand: "Real Numbers, Proof, Geometry",
    title:
      "Number systems, polynomials, coordinate geometry, linear equations, Euclid geometry, triangles, circles and statistics",
    topics: [
      "Real numbers",
      "Polynomials",
      "Coordinate geometry",
      "Linear equations",
      "Euclid geometry",
      "Triangles",
      "Quadrilaterals",
      "Circles",
      "Statistics",
    ],
    visual2D:
      "Polynomial roots, coordinate grids, proof diagrams and statistical charts",
    visual3D: "Surface-area solids with cross-section slices",
    sourceNote: internationalCoreSource,
  }),
  topic({
    board: "International Core",
    grade: "Class 10",
    phase: "Secondary Board Readiness",
    strand: "Algebra, Trigonometry, Geometry, Probability",
    title:
      "Real numbers, polynomials, pair of equations, quadratic equations, progressions, trigonometry, circles, mensuration, statistics and probability",
    topics: [
      "Real numbers",
      "Polynomials",
      "Linear pairs",
      "Quadratics",
      "Arithmetic progressions",
      "Trigonometry",
      "Coordinate geometry",
      "Circles",
      "Surface areas and volumes",
      "Statistics",
      "Probability",
    ],
    visual2D:
      "Parabola, progression blocks, trig ratio triangle and probability tree",
    visual3D: "Heights-and-distances scene plus cylinder/cone/sphere explorer",
    sourceNote: internationalCoreSource,
  }),
  topic({
    board: "International Core",
    grade: "Class 11",
    phase: "Senior Secondary Year 1",
    strand: "Algebra, Trigonometry, Coordinate Geometry",
    title:
      "Sets, functions, trigonometry, quadratic equations, permutations, binomial theorem, straight lines and conics",
    topics: [
      "Sets",
      "Relations and functions",
      "Trigonometric functions",
      "Quadratic equations",
      "Permutations and combinations",
      "Binomial theorem",
      "Sequences and series",
      "Straight lines",
      "Conic sections",
    ],
    visual2D:
      "Function maps, unit circle, Pascal triangle and conic focus-directrix diagrams",
    visual3D: "3D conic slice and rotating trig wave surface",
    sourceNote: internationalCoreSource,
  }),
  topic({
    board: "International Core",
    grade: "Class 12",
    phase: "Senior Secondary Year 2",
    strand: "Calculus, Vectors, Probability",
    title:
      "Matrices, determinants, vectors, 3D geometry, limits, derivatives, integrals, differential equations and probability",
    topics: [
      "Matrices",
      "Determinants",
      "Vector algebra",
      "Three-dimensional geometry",
      "Limits",
      "Derivatives",
      "Integrals",
      "Differential equations",
      "Probability",
    ],
    visual2D:
      "Matrix grid, tangent line, area accumulation and probability distribution views",
    visual3D: "Vector space, planes, surfaces and slope-field ribbon",
    sourceNote: internationalCoreSource,
  }),

  topic({
    board: "CBSE",
    grade: "Class 6",
    phase: "NCERT Middle Stage",
    strand: "Number, Patterns, Geometry, Data",
    title:
      "Patterns, number play, lines and angles, data, primes, perimeter, area, fractions, constructions, symmetry and integers",
    topics: [
      "Patterns",
      "Number play",
      "Lines and angles",
      "Data handling",
      "Prime numbers",
      "Perimeter and area",
      "Fractions",
      "Constructions",
      "Symmetry",
      "Integers",
    ],
    visual2D:
      "Pattern machine, ruler-compass canvas, bar chart and number line",
    visual3D: "Area tiles lifted into volume blocks",
    sourceNote: cbseSource,
  }),
  topic({
    board: "CBSE",
    grade: "Class 7",
    phase: "NCERT Middle Stage",
    strand: "Numbers, Algebra, Geometry",
    title:
      "Integers, fractions, decimals, data, equations, lines, triangles, comparing quantities, rational numbers, area and symmetry",
    topics: [
      "Integers",
      "Fractions and decimals",
      "Data handling",
      "Simple equations",
      "Lines and angles",
      "Triangles",
      "Comparing quantities",
      "Rational numbers",
      "Perimeter and area",
      "Symmetry",
      "Solid shapes",
    ],
    visual2D:
      "Equation balance, percent bars, triangle explorer and data charts",
    visual3D: "Nets and solid-shape rotations",
    sourceNote: cbseSource,
  }),
  topic({
    board: "CBSE",
    grade: "Class 8",
    phase: "NCERT Middle Stage",
    strand: "Algebra, Geometry, Mensuration",
    title:
      "Rational numbers, linear equations, quadrilaterals, data, roots, exponents, identities, mensuration, factorisation, proportions and graphs",
    topics: [
      "Rational numbers",
      "Linear equations",
      "Quadrilaterals",
      "Data handling",
      "Squares and cubes",
      "Exponents",
      "Algebraic identities",
      "Mensuration",
      "Factorisation",
      "Proportions",
      "Graphs",
    ],
    visual2D:
      "Coordinate plots, identity tiles and direct/inverse graph comparison",
    visual3D: "Cube blocks and measurement solids",
    sourceNote: cbseSource,
  }),
  topic({
    board: "CBSE",
    grade: "Class 9",
    phase: "Secondary",
    strand: "Algebra, Geometry, Statistics",
    title:
      "Number systems, polynomials, coordinate geometry, linear equations, Euclid geometry, triangles, quadrilaterals, circles, Heron's formula, volumes and statistics",
    topics: [
      "Number systems",
      "Polynomials",
      "Coordinate geometry",
      "Linear equations",
      "Euclid geometry",
      "Triangles",
      "Quadrilaterals",
      "Circles",
      "Heron's formula",
      "Surface areas and volumes",
      "Statistics",
    ],
    visual2D:
      "Root graph, coordinate plane, proof board and statistics dashboard",
    visual3D: "Mensuration solids and triangle area mesh",
    sourceNote: cbseSource,
  }),
  topic({
    board: "CBSE",
    grade: "Class 10",
    phase: "Secondary Board",
    strand: "Algebra, Trigonometry, Geometry, Statistics",
    title:
      "Real numbers, polynomials, linear equations, quadratics, arithmetic progressions, triangles, coordinate geometry, trigonometry, circles, surface areas, statistics and probability",
    topics: [
      "Real numbers",
      "Polynomials",
      "Pair of linear equations",
      "Quadratic equations",
      "Arithmetic progressions",
      "Triangles",
      "Coordinate geometry",
      "Trigonometry",
      "Circles",
      "Surface areas and volumes",
      "Statistics",
      "Probability",
    ],
    visual2D:
      "Euclid algorithm, parabola, progression strips, unit triangle and probability tree",
    visual3D: "Heights-and-distances scene with solids",
    sourceNote: cbseSource,
  }),
  topic({
    board: "CBSE",
    grade: "Class 11",
    phase: "Senior Secondary",
    strand: "Functions, Algebra, Geometry, Calculus",
    title:
      "Sets, relations, functions, trigonometry, complex numbers, inequalities, counting, binomial theorem, sequences, lines, conics, 3D geometry, limits, statistics and probability",
    topics: [
      "Sets",
      "Relations and functions",
      "Trigonometric functions",
      "Complex numbers",
      "Linear inequalities",
      "Permutations and combinations",
      "Binomial theorem",
      "Sequences and series",
      "Straight lines",
      "Conic sections",
      "3D geometry",
      "Limits and derivatives",
      "Statistics",
      "Probability",
    ],
    visual2D:
      "Venn diagrams, Argand plane, Pascal triangle, conics and limit graph",
    visual3D: "3D coordinate space and conic section slicer",
    sourceNote: cbseSource,
  }),
  topic({
    board: "CBSE",
    grade: "Class 12",
    phase: "Senior Secondary Board",
    strand: "Calculus, Linear Algebra, Vectors, Probability",
    title:
      "Relations, functions, inverse trigonometry, matrices, determinants, continuity, derivatives, integrals, differential equations, vectors, 3D geometry, linear programming and probability",
    topics: [
      "Relations and functions",
      "Inverse trigonometry",
      "Matrices",
      "Determinants",
      "Continuity",
      "Derivatives",
      "Integrals",
      "Differential equations",
      "Vector algebra",
      "3D geometry",
      "Linear programming",
      "Probability",
    ],
    visual2D:
      "Matrix operations, tangent/area graphs, feasible region and distributions",
    visual3D: "Vector planes, surfaces and slope fields",
    sourceNote: cbseSource,
  }),

  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 6",
    phase: "Cambridge Lower Secondary Bridge",
    strand: "Number, Geometry, Statistics",
    title:
      "Integers, fractions, decimals, percentages, ratio, expressions, angles, shapes, measures and data displays",
    topics: [
      "Integers",
      "Fractions",
      "Decimals",
      "Percentages",
      "Ratio",
      "Expressions",
      "Angles",
      "2D shapes",
      "Measures",
      "Data displays",
    ],
    visual2D: "Ratio bars, angle lab and statistical charts",
    visual3D: "Measured solids and nets",
    sourceNote: cambridgeSource,
  }),
  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 7",
    phase: "Cambridge Lower Secondary Bridge",
    strand: "Algebra, Geometry, Probability",
    title:
      "Directed numbers, standard form, algebraic expressions, formulae, coordinates, transformations, area, volume and probability",
    topics: [
      "Directed numbers",
      "Standard form",
      "Expressions",
      "Formulae",
      "Coordinates",
      "Transformations",
      "Area",
      "Volume",
      "Probability",
    ],
    visual2D: "Coordinate transformation canvas and probability tree",
    visual3D: "Transformation grid lifted into 3D prism model",
    sourceNote: cambridgeSource,
  }),
  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 8",
    phase: "Cambridge Lower Secondary Bridge",
    strand: "Graphs, Equations, Geometry",
    title:
      "Linear equations, sequences, graphs, Pythagoras, similarity, circles, compound measures and data analysis",
    topics: [
      "Linear equations",
      "Sequences",
      "Graphs",
      "Pythagoras",
      "Similarity",
      "Circles",
      "Compound measures",
      "Data analysis",
    ],
    visual2D: "Line graph, sequence machine, circle sector and scatter plot",
    visual3D: "Pythagoras blocks and circle-sector extrusion",
    sourceNote: cambridgeSource,
  }),
  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 9",
    phase: "IGCSE Core/Extended",
    strand: "Number, Algebra, Geometry",
    title:
      "IGCSE number, algebra, coordinate geometry, geometry, mensuration, trigonometry, transformations, probability and statistics",
    topics: [
      "Number",
      "Algebra and graphs",
      "Coordinate geometry",
      "Geometry",
      "Mensuration",
      "Trigonometry",
      "Transformations",
      "Vectors",
      "Probability",
      "Statistics",
    ],
    visual2D: "Core/Extended graphing, transformation and statistics panels",
    visual3D: "Mensuration and vector-space scenes",
    sourceNote: cambridgeSource,
  }),
  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 10",
    phase: "IGCSE Core/Extended",
    strand: "Extended Algebra, Trig, Vectors, Statistics",
    title:
      "Advanced IGCSE equations, functions, differentiation, trigonometry, 3D mensuration, vectors and statistical interpretation",
    topics: [
      "Algebraic manipulation",
      "Equations",
      "Functions",
      "Differentiation",
      "Trigonometry",
      "3D mensuration",
      "Vectors",
      "Probability",
      "Statistics",
    ],
    visual2D:
      "Function composition, tangent gradient and cumulative frequency views",
    visual3D: "3D trigonometry and vector geometry lab",
    sourceNote: cambridgeSource,
  }),
  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 11",
    phase: "Cambridge International AS Bridge",
    strand: "Pure Mathematics and Statistics",
    title:
      "Functions, quadratics, coordinate geometry, circular measure, trigonometry, series, differentiation, integration and statistics",
    topics: [
      "Functions",
      "Quadratics",
      "Coordinate geometry",
      "Circular measure",
      "Trigonometry",
      "Series",
      "Differentiation",
      "Integration",
      "Statistics",
    ],
    visual2D: "AS graphing, circular measure and calculus panels",
    visual3D: "Surface and curve traces for rates and accumulation",
    sourceNote: cambridgeSource,
  }),
  topic({
    board: "Cambridge IGCSE",
    grade: "Grade 12",
    phase: "Cambridge International A Level Bridge",
    strand: "Advanced Pure, Mechanics, Probability",
    title:
      "Algebra, logarithms, trigonometry, numerical methods, vectors, differential equations, mechanics and probability distributions",
    topics: [
      "Algebra",
      "Logarithms",
      "Trigonometry",
      "Numerical methods",
      "Vectors",
      "Differential equations",
      "Mechanics",
      "Probability distributions",
    ],
    visual2D: "Newton iteration, distribution curves and mechanics graphs",
    visual3D: "Vector fields, trajectories and slope-field surfaces",
    sourceNote: cambridgeSource,
  }),

  topic({
    board: "IB",
    grade: "Grade 6",
    phase: "MYP Year 1",
    strand: "Number, Algebra, Geometry, Statistics",
    title:
      "Number patterns, operations, variables, geometric reasoning, measurement, data handling and inquiry modelling",
    topics: [
      "Number patterns",
      "Operations",
      "Variables",
      "Geometric reasoning",
      "Measurement",
      "Data handling",
      "Inquiry modelling",
    ],
    visual2D: "Inquiry graph, data display and pattern rule builder",
    visual3D: "Measurement solids and spatial reasoning model",
    sourceNote: ibSource,
  }),
  topic({
    board: "IB",
    grade: "Grade 7",
    phase: "MYP Year 2",
    strand: "Forms, Relationships, Logic",
    title:
      "Fractions, ratios, rates, algebraic rules, angles, transformations, surface area, probability and real-world models",
    topics: [
      "Fractions",
      "Ratios",
      "Rates",
      "Algebraic rules",
      "Angles",
      "Transformations",
      "Surface area",
      "Probability",
      "Models",
    ],
    visual2D: "Rate graphs, transformation canvas and chance simulations",
    visual3D: "Surface-area nets and transformed solids",
    sourceNote: ibSource,
  }),
  topic({
    board: "IB",
    grade: "Grade 8",
    phase: "MYP Year 3",
    strand: "Patterns, Systems, Representation",
    title:
      "Linear relationships, equations, exponents, similarity, Pythagoras, circles, volume, bivariate data and modelling",
    topics: [
      "Linear relationships",
      "Equations",
      "Exponents",
      "Similarity",
      "Pythagoras",
      "Circles",
      "Volume",
      "Bivariate data",
      "Modelling",
    ],
    visual2D: "Scatter plot, linear model and theorem explorer",
    visual3D: "Pythagorean solids and volume comparison",
    sourceNote: ibSource,
  }),
  topic({
    board: "IB",
    grade: "Grade 9",
    phase: "MYP Year 4",
    strand: "Standard and Extended Mathematics",
    title:
      "Quadratics, functions, coordinate geometry, trigonometry, sequences, networks, statistics and mathematical investigations",
    topics: [
      "Quadratics",
      "Functions",
      "Coordinate geometry",
      "Trigonometry",
      "Sequences",
      "Networks",
      "Statistics",
      "Investigations",
    ],
    visual2D: "Parabola sliders, unit circle and network graph",
    visual3D: "Trig height scene and function surface preview",
    sourceNote: ibSource,
  }),
  topic({
    board: "IB",
    grade: "Grade 10",
    phase: "MYP Year 5",
    strand: "MYP eAssessment Readiness",
    title:
      "Functions, algebraic manipulation, geometric proof, trigonometry, vectors, probability, statistics and criterion-based modelling",
    topics: [
      "Functions",
      "Algebraic manipulation",
      "Geometric proof",
      "Trigonometry",
      "Vectors",
      "Probability",
      "Statistics",
      "Modelling",
    ],
    visual2D:
      "Criterion-style investigation board with function, vector and statistics views",
    visual3D: "Vector geometry and modelling scene",
    sourceNote: ibSource,
  }),
  topic({
    board: "IB",
    grade: "Grade 11",
    phase: "DP Year 1",
    strand: "AA/AI SL-HL Core",
    title:
      "Number and algebra, functions, geometry and trigonometry, statistics, probability and introductory calculus",
    topics: [
      "Number and algebra",
      "Functions",
      "Geometry",
      "Trigonometry",
      "Statistics",
      "Probability",
      "Calculus",
      "Technology modelling",
    ],
    visual2D:
      "AA/AI toggle with functions, distributions and derivative panels",
    visual3D: "Function surface, vector and probability landscape",
    sourceNote: ibSource,
  }),
  topic({
    board: "IB",
    grade: "Grade 12",
    phase: "DP Year 2",
    strand: "AA/AI SL-HL Extension",
    title:
      "Advanced functions, calculus, differential equations, vectors, complex numbers, probability distributions, statistics and exploration modelling",
    topics: [
      "Advanced functions",
      "Calculus",
      "Differential equations",
      "Vectors",
      "Complex numbers",
      "Probability distributions",
      "Statistics",
      "Exploration modelling",
    ],
    visual2D:
      "IA-style modelling canvas, complex plane, distributions and slope fields",
    visual3D: "Vector fields, complex rotations and calculus surface scene",
    sourceNote: ibSource,
  }),
];

export const syllabusBoards = Array.from(
  new Set(boardSyllabusTopics.map((topic) => topic.board)),
);
export const syllabusGrades = [
  "Class 6",
  "Class 7",
  "Class 8",
  "Class 9",
  "Class 10",
  "Class 11",
  "Class 12",
  "Grade 6",
  "Grade 7",
  "Grade 8",
  "Grade 9",
  "Grade 10",
  "Grade 11",
  "Grade 12",
];

function normalizeLegacyTopicId(id: string) {
  return id
    .replace(/^ap-state-/, "international-core-")
    .replace("-linear-equation-euclid-", "-linear-equations-euclid-");
}

export function getBoardSyllabusTopic(id: string | undefined) {
  if (!id) return undefined;
  const normalizedId = normalizeLegacyTopicId(id);
  return boardSyllabusTopics.find(
    (topic) => topic.id === normalizedId || topic.id === id,
  );
}
