import ModelDownloadStatus from './model-loading/ModelDownloadStatus';
import './studios/studioHomeLayout.css';
import OfflineMathAssistant from './offline-intelligence/OfflineMathAssistant';
import {MODEL_TRAINING_ENABLED} from './math-robo/intelligence/buildPolicy';
import {
  Component,
  lazy,
  Suspense,
  useEffect,
  useState,
  type ComponentType,
  type ErrorInfo,
  type ReactNode,
} from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import AppLayout from "./components/layout/AppLayout";
import SeoMetadata from "./components/seo/SeoMetadata";
import { formulaVisualizerConfigs } from "./data/formulaVisualizerRoutes";
import { differentialEquationRouteAliases } from "./studios/differential-equations/routes";
import StandaloneStudioTheory from "./studios/mockup/StandaloneStudioTheory";
import { StudioModelProvider } from "./studios/phase1/StudioModelProvider";
import StudioCurriculum from "./studios/curriculum/StudioCurriculum";

const routeChunkReloadPrefix = "math-universe-route-chunk-reload:";
const routeChunkReloadWindowMs = 30_000;

function isRouteChunkLoadError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);
  return /ChunkLoadError|Loading chunk|Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module/i.test(
    message,
  );
}

function NavigatePreserve({ to }: { to: string }) {
  const location = useLocation();
  const dest = new URL(to, "https://math.local");
  const merged = new URLSearchParams(dest.search);
  const incoming = new URLSearchParams(location.search);
  incoming.forEach((value, key) => {
    if (!merged.has(key)) merged.set(key, value);
  });
  const search = merged.toString();
  return (
    <Navigate
      to={`${dest.pathname}${search ? `?${search}` : ""}${location.hash}`}
      replace
    />
  );
}

function lazyRoute<Props>(
  loader: () => Promise<{ default: ComponentType<Props> }>,
) {
  return lazy(async () => {
    try {
      const module = await loader();
      if (typeof window !== "undefined")
        sessionStorage.removeItem(
          `${routeChunkReloadPrefix}${window.location.pathname}`,
        );
      return module;
    } catch (error) {
      if (typeof window !== "undefined" && isRouteChunkLoadError(error)) {
        const reloadKey = `${routeChunkReloadPrefix}${window.location.pathname}`;
        const lastReload = Number(sessionStorage.getItem(reloadKey) ?? 0);
        if (
          !Number.isFinite(lastReload) ||
          Date.now() - lastReload > routeChunkReloadWindowMs
        ) {
          sessionStorage.setItem(reloadKey, String(Date.now()));
          await clearStaleAppCaches();
          window.location.replace(window.location.href);
        }
      }
      throw error;
    }
  });
}

async function clearStaleAppCaches() {
  if (!navigator.onLine) return;
  if ("serviceWorker" in navigator) {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(
      registrations.map((registration) => registration.unregister()),
    );
  }
  if ("caches" in window) {
    const keys = await caches.keys();
    await Promise.all(keys.map((key) => caches.delete(key)));
  }
}

const About = lazyRoute(() => import("./pages/About"));
const AccuracyCertification = lazyRoute(
  () => import("./pages/AccuracyCertification"),
);
const CoverageDashboardPage = lazyRoute(
  () => import("./pages/CoverageDashboardPage"),
);
const Phase3LearningSystemPage = lazyRoute(
  () => import("./pages/Phase3LearningSystemPage"),
);
const AdvancedSyllabusLabPage = lazyRoute(
  () => import("./pages/AdvancedSyllabusLabPage"),
);
const AdvancedConceptStudios = lazyRoute(
  () => import("./pages/AdvancedConceptStudios"),
);
const AlgebraStudio = lazyRoute(() => import("./pages/AlgebraStudio"));
const AlgebraClassic = lazyRoute(() => import("./pages/Algebra"));
const AlgebraicStructuresStudio = lazyRoute(
  () => import("./pages/AlgebraicStructuresStudio"),
);
const AIApplications = lazyRoute(() => import("./pages/AIApplications"));
const ModelTraining = MODEL_TRAINING_ENABLED ? lazyRoute(() => import("./pages/ModelTraining")) : () => null;
const ARMathLab = lazyRoute(() => import("./pages/ARMathLab"));
const BoardSyllabusVisualizer = lazyRoute(
  () => import("./pages/BoardSyllabusVisualizer"),
);
const BoardPage = lazyRoute(() => import("./modules/board/BoardPage"));
const CalculusStudio = lazyRoute(() => import("./pages/CalculusStudio"));
const CircleToTriangleVisualization = lazyRoute(
  () => import("./pages/CircleToTriangleVisualization"),
);
const ComplexNumbers = lazyRoute(() => import("./pages/ComplexNumbers"));
const ConceptDependencyGraph = lazyRoute(
  () => import("./pages/ConceptDependencyGraph"),
);
const ConceptMapPage = lazyRoute(() => import("./concept-map/ConceptMapPage"));
const DailyChallenge = lazyRoute(() => import("./pages/DailyChallenge"));
const DiscreteWorld = lazyRoute(() => import("./pages/DiscreteWorld"));
const Documentation = lazyRoute(() => import("./pages/Documentation"));
const EigenvectorsVisualizerPage = lazyRoute(
  () => import("./pages/EigenvectorsVisualizerPage"),
);
const EngineeringMath = lazyRoute(() => import("./pages/EngineeringMath"));
const Formulas = lazyRoute(() => import("./pages/Formulas"));
const FormulaVisualizerPage = lazyRoute(
  () => import("./pages/FormulaVisualizerPage"),
);
const FourierSeriesAnimator = lazyRoute(
  () => import("./pages/FourierSeriesAnimator"),
);
const FourierSeriesVisualizerPage = lazyRoute(
  () => import("./pages/FourierSeriesVisualizerPage"),
);
const Geometry = lazyRoute(() => import("./pages/Geometry"));
const GeometryConceptPage = lazyRoute(
  () => import("./pages/GeometryConceptPage"),
);
const GraphComparisonMode = lazyRoute(
  () => import("./pages/GraphComparisonMode"),
);
const GraphTheory = lazyRoute(() => import("./pages/GraphTheory"));
const Home = lazyRoute(() => import("./pages/Home"));
const LessonsHomePage = lazyRoute(
  () => import("./modules/lessons/pages/LessonsHomePage"),
);
const LearnDiscoveryPage = lazyRoute(
  () => import("./modules/lessons/pages/LearnDiscoveryPage"),
);
const LessonsCategoryPage = lazyRoute(
  () => import("./modules/lessons/pages/LessonsCategoryPage"),
);
const LessonPage = lazyRoute(
  () => import("./modules/lessons/pages/LessonPage"),
);
const AdvancedConceptLessonsPage = lazyRoute(
  () => import("./modules/lessons/pages/AdvancedConceptLessonsPage"),
);
const AdvancedConceptLessonPage = lazyRoute(
  () => import("./modules/lessons/pages/AdvancedConceptLessonPage"),
);
const SchoolLessonsPage = lazyRoute(
  () => import("./modules/lessons/pages/SchoolLessonsPage"),
);
const SchoolLessonPage = lazyRoute(
  () => import("./modules/lessons/pages/SchoolLessonPage"),
);
const Phase4ComputationalLabPage = lazyRoute(
  () => import("./pages/Phase4ComputationalLabPage"),
);
const Phase5MathEnvironmentPage = lazyRoute(
  () => import("./pages/Phase5MathEnvironmentPage"),
);
const LinearAlgebra = lazyRoute(() => import("./pages/LinearAlgebra"));
const DifferentialEquations = lazyRoute(() => import("./pages/DifferentialEquations"));
const MathLab = lazyRoute(() => import("./pages/MathLab"));
const MathLab3DGraphing = lazyRoute(() => import("./pages/MathLab3DGraphing"));
const MathLabConicSolver = lazyRoute(
  () => import("./pages/MathLabConicSolver"),
);
const MathLabFunctionExplorer = lazyRoute(
  () => import("./pages/MathLabFunctionExplorer"),
);
const MathLabGraphingCalculator = lazyRoute(
  () => import("./pages/MathLabGraphingCalculator"),
);
const MathLabLinearAlgebra = lazyRoute(
  () => import("./pages/MathLabLinearAlgebra"),
);
const MathLabProbability = lazyRoute(
  () => import("./pages/MathLabProbability"),
);
const MathLabSmartQuery = lazyRoute(() => import("./pages/MathLabSmartQuery"));
const MathLabToolPage = lazyRoute(() => import("./pages/MathLabToolPage"));
const MathematicalModellingStudio = lazyRoute(
  () => import("./pages/MathematicalModellingStudio"),
);
const ModellingEnhancementWorkbench = lazyRoute(
  () => import("./studios/modelling/ModellingEnhancementWorkbench"),
);
const StudioProjectCenter = lazyRoute(
  () => import("./studios/platform/StudioProjectCenter"),
);
const MathVisualizationPage = lazyRoute(
  () => import("./pages/MathVisualizationPage"),
);
const MathVisualDictionary = lazyRoute(
  () => import("./pages/MathVisualDictionary"),
);
const WorkspaceHome = lazyRoute(() => import("./pages/WorkspaceHome"));
const WorkspaceTeach = lazyRoute(() => import("./pages/WorkspaceTeach"));
const MagicMaths = lazyRoute(() => import("./pages/MagicMaths"));
const MatrixOperationPage = lazyRoute(
  () => import("./pages/MatrixOperationPage"),
);
const MatrixOperations = lazyRoute(() => import("./pages/MatrixOperations"));
const MatrixOperationsSandbox = lazyRoute(
  () => import("./pages/MatrixOperationsSandbox"),
);
const MatrixTransformationsVisualizerPage = lazyRoute(
  () => import("./pages/MatrixTransformationsVisualizerPage"),
);
const NCERTConceptPage = lazyRoute(() => import("./pages/NCERTConceptPage"));
const NCERTDashboardPage = lazyRoute(
  () => import("./pages/NCERTDashboardPage"),
);
const NumberSystems = lazyRoute(() => import("./pages/NumberSystems"));
const Olympyard = lazyRoute(() => import("./pages/Olympyard"));
const OlympyardMockTest = lazyRoute(() => import("./pages/OlympyardMockTest"));
const OlympyardPractice = lazyRoute(() => import("./pages/OlympyardPractice"));
const ParametricCurveExplorer = lazyRoute(
  () => import("./pages/ParametricCurveExplorer"),
);
const ProbabilityStatistics = lazyRoute(
  () => import("./pages/ProbabilityStatistics"),
);
const ProbabilityStatisticsModulePage = lazyRoute(
  () =>
    import("./modules/probability-statistics/pages/ProbabilityStatisticsModulePage"),
);
const DistributionAtlasPage = lazyRoute(
  () => import("./modules/probability-statistics/pages/DistributionAtlasPage"),
);
const DistributionDetailPage = lazyRoute(
  () => import("./modules/probability-statistics/pages/DistributionDetailPage"),
);
const ProbabilityStatisticsPhaseTwoPage = lazyRoute(
  () =>
    import("./modules/probability-statistics/pages/ProbabilityStatisticsPhaseTwoPage"),
);
const ProbabilityStatisticsPhaseThreePage = lazyRoute(
  () =>
    import("./modules/probability-statistics/pages/ProbabilityStatisticsPhaseThreePage"),
);
const StatisticsSyllabusCompletionPage = lazyRoute(
  () =>
    import("./modules/probability-statistics/pages/StatisticsSyllabusCompletionPage"),
);
const Quiz = lazyRoute(() => import("./pages/Quiz"));
const ScientificCalculator = lazyRoute(
  () => import("./pages/ScientificCalculator"),
);
const SetTheory = lazyRoute(() => import("./pages/SetTheory"));
const ShapesExplorer = lazyRoute(() => import("./pages/ShapesExplorer"));
const GeometrySolidsRedirect = lazyRoute(() => import("./studios/geometry/GeometrySolidsRedirect"));
const Sitemap = lazyRoute(() => import("./pages/Sitemap"));
const SpacedRepetitionQuiz = lazyRoute(
  () => import("./pages/SpacedRepetitionQuiz"),
);
const StepByStepProblemSolver = lazyRoute(
  () => import("./pages/StepByStepProblemSolver"),
);
const ProblemSolverDocumentation = lazyRoute(
  () => import("./pages/ProblemSolverDocumentation"),
);
const SurfacePlotter3D = lazyRoute(() => import("./pages/SurfacePlotter3D"));
const Syllabus = lazyRoute(() => import("./pages/Syllabus"));
const SyllabusVisualPage = lazyRoute(
  () => import("./pages/SyllabusVisualPage"),
);
const Theorems = lazyRoute(() => import("./pages/Theorems"));
const Trigonometry = lazyRoute(() => import("./pages/Trigonometry"));
const TrigonometryConceptPage = lazyRoute(
  () => import("./pages/TrigonometryConceptPage"),
);
const TrigFormulaVisualizerPage = lazyRoute(
  () => import("./trigonometry/pages/TrigFormulaVisualizerPage"),
);
const UnitConverter = lazyRoute(() => import("./pages/UnitConverter"));
const UniversalMathDocumentPage = lazyRoute(
  () => import("./pages/UniversalMathDocumentPage"),
);
const VisualFormulasHub = lazyRoute(() => import("./pages/VisualFormulasHub"));
const VisualShowcase = lazyRoute(() => import("./pages/VisualShowcase"));
const VisualProofsHomePage = lazyRoute(
  () => import("./visual-proofs/pages/VisualProofsHomePage"),
);
const VisualProofCategoryPage = lazyRoute(
  () => import("./visual-proofs/pages/VisualProofCategoryPage"),
);
const VisualProofPage = lazyRoute(
  () => import("./visual-proofs/pages/VisualProofPage"),
);
const WorkedExamplesLibrary = lazyRoute(
  () => import("./pages/WorkedExamplesLibrary"),
);
const Workspace3D = lazyRoute(() => import("./pages/Workspace3D"));
const WorkspaceData = lazyRoute(() => import("./pages/WorkspaceData"));
const WorkspaceGeometry = lazyRoute(() => import("./pages/WorkspaceGeometry"));
const WorkspaceGraph = lazyRoute(() => import("./pages/WorkspaceGraph"));
const EmbedDesigner = lazyRoute(() => import("./pages/EmbedDesigner"));

type AppErrorBoundaryProps = { children: ReactNode; resetKey: string };
type AppErrorBoundaryState = { hasError: boolean };

class AppErrorBoundary extends Component<
  AppErrorBoundaryProps,
  AppErrorBoundaryState
> {
  state: AppErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): AppErrorBoundaryState {
    return { hasError: true };
  }

  componentDidUpdate(previousProps: AppErrorBoundaryProps) {
    if (this.state.hasError && previousProps.resetKey !== this.props.resetKey) {
      this.setState({ hasError: false });
    }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Math Universe failed to render", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6 text-slate-950 dark:bg-slate-950 dark:text-white">
          <section className="max-w-xl rounded-lg border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <p className="text-sm font-semibold uppercase tracking-wide text-cyan-600 dark:text-cyan-300">
              Math Universe
            </p>
            <h1 className="mt-3 text-2xl font-bold">Something went wrong.</h1>
            <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">
              Reload the app to restore the latest lesson shell and cached
              visualizations.
            </p>
            <button
              className="action-primary mt-5"
              type="button"
              onClick={() => {
                void clearStaleAppCaches().finally(() =>
                  window.location.replace(window.location.href),
                );
              }}
            >
              Reload app
            </button>
          </section>
        </main>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  const location = useLocation();

  return (
    <AppErrorBoundary resetKey={location.pathname}>
      <SeoMetadata />
      <RouteProgressBar />
      <OfflineMathAssistant />
      <ModelDownloadStatus />
      <Suspense fallback={<RouteFallback />}>
        <StudioModelProvider key={location.pathname}><Routes>
          <Route element={<AppLayout />}>
            <Route index element={<Home />} />
            <Route path="studios/curriculum" element={<StudioCurriculum />} />
            <Route path="studios/:studioId/curriculum" element={<StudioCurriculum />} />
            <Route
              path="accuracy-certification"
              element={<AccuracyCertification />}
            />
            <Route
              path="coverage-dashboard"
              element={<CoverageDashboardPage />}
            />
            <Route
              path="curriculum-evidence"
              element={<Phase3LearningSystemPage />}
            />
            <Route path="learning/*" element={<Phase3LearningSystemPage />} />
            <Route path="compute/*" element={<Phase4ComputationalLabPage />} />
            <Route path="data/*" element={<Phase4ComputationalLabPage />} />
            <Route
              path="probability-lab"
              element={<Phase4ComputationalLabPage />}
            />
            <Route path="math-3d" element={<Phase5MathEnvironmentPage />} />
            <Route
              path="authoring-studio"
              element={<Phase5MathEnvironmentPage />}
            />
            <Route
              path="curriculum-operations"
              element={<Phase5MathEnvironmentPage />}
            />
            <Route
              path="release-scorecard"
              element={<Phase5MathEnvironmentPage />}
            />
            <Route path="algebra" element={<AlgebraStudio />} />
            <Route path="algebra/expressions" element={<AlgebraStudio />} />
            <Route path="algebra/equations" element={<AlgebraStudio />} />
            <Route path="algebra/functions" element={<AlgebraStudio />} />
            <Route path="algebra/polynomials" element={<AlgebraStudio />} />
            <Route path="algebra/systems" element={<AlgebraStudio />} />
            <Route path="algebra/exponents-logs" element={<AlgebraStudio />} />
            <Route path="algebra/sequences" element={<AlgebraStudio />} />
            <Route path="algebra/proof" element={<AlgebraStudio />} />
            <Route path="algebra/cas" element={<AlgebraStudio />} />
            <Route path="algebra/advanced" element={<AlgebraStudio />} />
            <Route path="algebra/classic" element={<AlgebraClassic />} />
            <Route path="algebraic-structures" element={<AlgebraicStructuresStudio page="home" />} />
            <Route path="algebraic-structures/groups-rings-fields" element={<AlgebraicStructuresStudio page="groups-rings-fields" />} />
            <Route path="algebraic-structures/structure-test" element={<AlgebraicStructuresStudio page="structure-test" />} />
            <Route path="algebraic-structures/cayley-tables" element={<AlgebraicStructuresStudio page="cayley-tables" />} />
            <Route path="algebraic-structures/semigroups-monoids" element={<AlgebraicStructuresStudio page="semigroups-monoids" />} />
            <Route path="algebraic-structures/posets-lattices" element={<AlgebraicStructuresStudio page="posets-lattices" />} />
            <Route path="algebraic-structures/boolean-algebra" element={<AlgebraicStructuresStudio page="boolean-algebra" />} />
            <Route path="algebra/algebraic-structures" element={<Navigate to="/algebraic-structures" replace />} />
            <Route path="math-lab" element={<MathLab />} />
            <Route path="engineering-math" element={<EngineeringMath />} />
            <Route
              path="math-lab/graphing-calculator"
              element={<MathLabGraphingCalculator />}
            />
            <Route
              path="math-lab/function-explorer"
              element={<MathLabFunctionExplorer />}
            />
            <Route
              path="math-lab/linear-algebra"
              element={<MathLabLinearAlgebra />}
            />
            <Route
              path="math-lab/3d-graphing"
              element={<MathLab3DGraphing />}
            />
            <Route path="math-lab/conics" element={<MathLabConicSolver />} />
            <Route
              path="math-lab/probability"
              element={<MathLabProbability />}
            />
            <Route
              path="math-lab/continued-fractions"
              element={<AdvancedConceptStudios />}
            />
            <Route
              path="math-lab/famous-problems"
              element={<AdvancedConceptStudios />}
            />
            <Route
              path="math-lab/stats-inference"
              element={<AdvancedConceptStudios />}
            />
            <Route
              path="math-lab/differential-equations"
              element={<AdvancedConceptStudios />}
            />
            <Route
              path="math-lab/special-functions"
              element={<AdvancedConceptStudios />}
            />
            <Route
              path="math-lab/cas-solver"
              element={<Navigate to="/problem-solver" replace />}
            />
            <Route path="math-lab/query" element={<MathLabSmartQuery />} />
            <Route path="math-lab/:toolId" element={<MathLabToolPage />} />
            <Route
              path="ar-math-lab"
              element={<Navigate to="/modules/ar-math-lab" replace />}
            />
            <Route path="modules/ar-math-lab" element={<ARMathLab />} />
            <Route
              path="visual-dictionary"
              element={<MathVisualDictionary />}
            />
            <Route path="magic-maths" element={<MagicMaths />} />
            <Route path="magic-maths/:conceptSlug" element={<MagicMaths />} />
            <Route path="workspace" element={<WorkspaceHome />} />
            <Route
              path="math-document"
              element={<UniversalMathDocumentPage />}
            />
            <Route path="board" element={<BoardPage />} />
            <Route path="workspace/graph" element={<WorkspaceGraph />} />
            <Route path="workspace/geometry" element={<WorkspaceGeometry />} />
            <Route path="workspace/3d" element={<Workspace3D />} />
            <Route path="design" element={<Navigate to="/design/twodgraph" replace />} />
            <Route path="design/:kind" element={<EmbedDesigner />} />
            <Route path="workspace/data" element={<WorkspaceData />} />
            <Route
              path="workspace/data/overview"
              element={<WorkspaceData page="overview" />}
            />
            <Route
              path="workspace/data/spreadsheet"
              element={<WorkspaceData page="spreadsheet" />}
            />
            <Route
              path="workspace/data/analysis"
              element={<WorkspaceData page="analysis" />}
            />
            <Route
              path="workspace/data/cas"
              element={<WorkspaceData page="cas" />}
            />
            <Route
              path="workspace/data/results"
              element={<WorkspaceData page="results" />}
            />
            <Route
              path="workspace/data/objects"
              element={<WorkspaceData page="objects" />}
            />
            <Route
              path="workspace/teach"
              element={<WorkspaceTeach />}
            />
            <Route path="math-workspaces/:group" element={<WorkspaceHome />} />
            <Route path="formulas" element={<Formulas />} />
            <Route path="formulas/:categorySlug" element={<Formulas />} />
            <Route path="visual-formulas" element={<VisualFormulasHub />} />
            <Route
              path="visual-formulas/sierpinski-carpet"
              element={<FormulaVisualizerPage conceptId="sierpinski-carpet" />}
            />
            <Route
              path="visual-formulas/proportional-reasoning-2"
              element={
                <FormulaVisualizerPage conceptId="proportional-reasoning-2" />
              }
            />
            {formulaVisualizerConfigs
              .filter(
                (config) =>
                  config.id !== "trigonometry" &&
                  config.id !== "sierpinski-carpet" &&
                  config.id !== "proportional-reasoning-2",
              )
              .map((config) => (
                <Route
                  key={config.route}
                  path={config.route.slice(1)}
                  element={config.id === "number-systems" ? <NumberSystems /> : <FormulaVisualizerPage conceptId={config.id} />}
                />
              ))}
            <Route path="theorems" element={<Theorems />} />
            <Route path="theorems/:categorySlug" element={<Theorems />} />
            <Route
              path="theorems/:categorySlug/:theoremSlug"
              element={<Theorems />}
            />
            <Route path="visual-showcase" element={<VisualShowcase />} />
            <Route
              path="circle-to-triangle"
              element={<CircleToTriangleVisualization />}
            />
            <Route path="visual-proofs" element={<VisualProofsHomePage />} />
            <Route
              path="visual-proofs/:categorySlug"
              element={<VisualProofCategoryPage />}
            />
            <Route
              path="visual-proofs/geometry/circle-to-triangle"
              element={<CircleToTriangleVisualization />}
            />
            <Route
              path="visual-proofs/:categorySlug/:proofSlug"
              element={<VisualProofPage />}
            />
            <Route path="geometry" element={<Geometry />} />
            <Route path="geometry/solids" element={<GeometrySolidsRedirect />} />
            {["construction", "triangles", "circles", "polygons", "transformations", "coordinate", "measurement", "proofs", "ar"].map((slug) => (
              <Route key={`geometry-${slug}`} path={`geometry/${slug}`} element={<Geometry />} />
            ))}
            <Route
              path="geometry/:conceptId"
              element={<GeometryConceptPage />}
            />
            <Route path="shapes" element={<ShapesExplorer />} />
            <Route path="number-systems" element={<NumberSystems />} />
            <Route path="number-systems/fundamentals" element={<NumberSystems />} />
            <Route path="number-systems/natural-whole" element={<NumberSystems />} />
            <Route path="number-systems/integers" element={<NumberSystems />} />
            <Route path="number-systems/fractions-decimals-percentages" element={<NumberSystems />} />
            <Route path="number-systems/ordering-comparing" element={<NumberSystems />} />
            <Route path="number-systems/absolute-distance-intervals" element={<NumberSystems />} />
            <Route path="number-systems/properties-operations" element={<NumberSystems />} />
            <Route path="number-systems/rational" element={<NumberSystems />} />
            <Route path="number-systems/irrational" element={<NumberSystems />} />
            <Route path="number-systems/real-line" element={<NumberSystems />} />
            <Route path="number-systems/hierarchy" element={<NumberSystems />} />
            <Route path="number-systems/concepts" element={<NumberSystems />} />
            <Route path="number-systems/practice" element={<NumberSystems />} />
            <Route path="number-systems/accuracy" element={<Navigate to="/number-systems/practice" replace />} />
            <Route path="number-systems/space" element={<Navigate to="/number-systems/hierarchy" replace />} />
            <Route path="trigonometry" element={<Trigonometry />} />
            {["sine-law", "cosine-law", "area", "ssa-ambiguous-case", "solve-triangle"].map(slug => <Route key={`oblique-${slug}`} path={`trigonometry/oblique/${slug}`} element={<Trigonometry />} />)}
            <Route path="trigonometry/oblique/*" element={<Trigonometry />} />
            <Route path="trigonometry/inverse/*" element={<Trigonometry />} />
            {["unit-circle", "right-triangle", "graphs", "identities", "inverse", "oblique", "waves", "applications", "ar"].map((slug) => (
              <Route key={`trig-${slug}`} path={`trigonometry/${slug}`} element={<Trigonometry />} />
            ))}
            <Route
              path="trigonometry/formula-visualizer"
              element={<TrigFormulaVisualizerPage />}
            />
            <Route
              path="trigonometry/:conceptId"
              element={<TrigonometryConceptPage />}
            />
            <Route path="calculus" element={<CalculusStudio page="home" />} />
            <Route
              path="calculus/limits"
              element={<CalculusStudio page="limits" />}
            />
            <Route
              path="calculus/derivatives"
              element={<CalculusStudio page="derivatives" />}
            />
            <Route
              path="calculus/derivative-applications"
              element={<CalculusStudio page="derivative-applications" />}
            />
            <Route
              path="calculus/integration"
              element={<CalculusStudio page="integration" />}
            />
            <Route
              path="calculus/integration-techniques"
              element={<CalculusStudio page="integration-techniques" />}
            />
            <Route
              path="calculus/integral-applications"
              element={<CalculusStudio page="integral-applications" />}
            />
            <Route
              path="calculus/differential-equations"
              element={<CalculusStudio page="differential-equations" />}
            />
            <Route
              path="calculus/series-parametric-polar"
              element={<CalculusStudio page="series-parametric-polar" />}
            />
            <Route
              path="calculus/multivariable-vector"
              element={<CalculusStudio page="multivariable-vector" />}
            />
            <Route
              path="calculus/jacobians-coordinate-transformations"
              element={<CalculusStudio page="jacobians" />}
            />
            <Route
              path="calculus/beta-gamma"
              element={<CalculusStudio page="beta-gamma" />}
            />
            <Route path="calculus/series-tests" element={<CalculusStudio page="series-tests" />} />
            <Route path="calculus/curve-tracing" element={<CalculusStudio page="curve-tracing" />} />
            <Route path="calculus/taylor-two-variables" element={<CalculusStudio page="taylor-two-variables" />} />
            <Route path="calculus/lagrange-multipliers" element={<CalculusStudio page="lagrange-multipliers" />} />
            <Route path="calculus/change-order-integration" element={<CalculusStudio page="change-order" />} />
            <Route path="calculus/centroid-center-of-mass" element={<CalculusStudio page="centroid" />} />
            <Route path="calculus/moments-of-inertia" element={<CalculusStudio page="moments-of-inertia" />} />
            <Route path="calculus/multiple-integral-applications" element={<CalculusStudio page="integral-engineering" />} />
            <Route
              path="calculus/advanced"
              element={<CalculusStudio page="advanced" />}
            />
            <Route
              path="calculus/integrals"
              element={<Navigate to="/calculus/integration" replace />}
            />
            <Route
              path="calculus/motion"
              element={
                <Navigate
                  to="/calculus/derivative-applications?mode=motion"
                  replace
                />
              }
            />
            <Route
              path="calculus/practice"
              element={<Navigate to="/calculus" replace />}
            />
            <Route
              path="calculus/proof-problems"
              element={<Navigate to="/calculus/integration?mode=ftc" replace />}
            />
            <Route
              path="calculus/series-blocks"
              element={
                <Navigate to="/calculus/series-parametric-polar" replace />
              }
            />
            <Route
              path="calculus/atlas"
              element={<Navigate to="/calculus" replace />}
            />
            <Route
              path="calculus/formulas"
              element={
                <Navigate to="/calculus/integration-techniques" replace />
              }
            />
            <Route
              path="calculus/applications"
              element={
                <Navigate to="/calculus/derivative-applications" replace />
              }
            />
            <Route path="combinatorics" element={<Navigate to="/discrete-world/combinatorics" replace />} />
            <Route path="complex-numbers" element={<ComplexNumbers />} />
            {["argand-plane", "arithmetic", "polar-forms", "rotation", "roots", "euler", "loci", "fractals", "waves-circuits"].map((slug) => (
              <Route key={`complex-${slug}`} path={`complex-numbers/${slug}`} element={<ComplexNumbers />} />
            ))}
            <Route path="set-theory" element={<SetTheory />} />
            <Route path="set-theory/:pageSlug" element={<SetTheory />} />
            <Route path="statistics" element={<ProbabilityStatistics />} />
            <Route path="linear-algebra" element={<LinearAlgebra />} />
            {["vectors", "matrices", "row-reduction", "linear-transforms", "determinants", "vector-spaces", "eigenvectors", "orthogonality", "least-squares", "playground", "cayley-hamilton", "diagonalization", "quadratic-forms", "principal-axes", "matrix-factorizations", "similarity", "jordan-form"].map((slug) => (
              <Route key={`la-${slug}`} path={`linear-algebra/${slug}`} element={<LinearAlgebra />} />
            ))}
            <Route path="differential-equations" element={<DifferentialEquations />} />
            {["laplace", "pde", "boundary-values"].map(slug => <Route key={slug} path={`differential-equations/${slug}`} element={<DifferentialEquations />} />)}
            {["explorer", "method-selector", "slope-fields", "initial-value", "separable", "homogeneous-first-order", "exact", "linear-first-order", "bernoulli", "growth-models", "euler", "heun", "rk4", "higher-order-linear", "undetermined-coefficients", "variation-of-parameters", "cauchy-euler", "systems", "phase-plane", "mechanical-oscillations", "lcr-circuit", "newton-cooling", ...Object.keys(differentialEquationRouteAliases)].map((slug) => (
              <Route key={`de-${slug}`} path={`differential-equations/${slug}`} element={<DifferentialEquations />} />
            ))}
            <Route path="matrices" element={<MatrixOperations />} />
            <Route
              path="matrices/:operationId"
              element={<MatrixOperationPage />}
            />
            <Route
              path="matrix-sandbox"
              element={<MatrixOperationsSandbox />}
            />
            <Route path="ai-applications" element={<AIApplications />} />
            {MODEL_TRAINING_ENABLED && <Route path="model-training" element={<ModelTraining />} />}
            {MODEL_TRAINING_ENABLED && <Route path="model-training/capabilities" element={<ModelTraining />} />}
            <Route
              path="mathematical-modelling"
              element={<MathematicalModellingStudio />}
            />
            {["motion", "population", "epidemics", "finance", "optimization", "networks", "regression", "periodic", "numerical", "comparison"].map((slug) => (
              <Route key={`model-${slug}`} path={`mathematical-modelling/${slug}`} element={<MathematicalModellingStudio />} />
            ))}
            <Route
              path="mathematical-modelling/advanced"
              element={<ModellingEnhancementWorkbench />}
            />
            <Route path="studio-projects" element={<StudioProjectCenter />} />
            <Route path="learning-paths" element={<Navigate to="/learn" replace />} />
            <Route path="learn" element={<LessonsHomePage />} />
            <Route path="learn/:topicSlug" element={<LearnDiscoveryPage />} />
            <Route
              path="learn/:topicSlug/:subtopicSlug"
              element={<LearnDiscoveryPage />}
            />
            <Route path="lessons" element={<LessonsHomePage />} />
            <Route
              path="lessons/advanced-concepts"
              element={<AdvancedConceptLessonsPage />}
            />
            <Route
              path="lessons/advanced-concepts/:lessonSlug"
              element={<AdvancedConceptLessonPage />}
            />
            <Route path="lessons/school" element={<SchoolLessonsPage />} />
            <Route
              path="lessons/school/:levelSlug"
              element={<SchoolLessonsPage />}
            />
            <Route
              path="lessons/school/:levelSlug/:lessonSlug"
              element={<SchoolLessonPage />}
            />
            <Route
              path="lessons/:categorySlug"
              element={<LessonsCategoryPage />}
            />
            <Route
              path="lessons/:categorySlug/:lessonSlug"
              element={<LessonPage />}
            />
            <Route path="olympyard" element={<Olympyard />} />
            <Route path="olympyard/mock-test" element={<OlympyardMockTest />} />
            <Route
              path="olympyard/practice/:topicId"
              element={<OlympyardPractice />}
            />
            <Route
              path="spaced-repetition"
              element={<SpacedRepetitionQuiz />}
            />
            <Route
              path="problem-solver"
              element={<StepByStepProblemSolver />}
            />
            <Route
              path="problem-solver/docs"
              element={<ProblemSolverDocumentation />}
            />
            <Route path="concept-map" element={<ConceptMapPage />} />
            <Route path="concept-graph" element={<ConceptDependencyGraph />} />
            <Route path="daily-challenge" element={<DailyChallenge />} />
            <Route path="worked-examples" element={<WorkedExamplesLibrary />} />
            <Route path="graph-comparison" element={<GraphComparisonMode />} />
            <Route path="graph-theory" element={<GraphTheory />} />
            <Route path="discrete-world" element={<DiscreteWorld />} />
            {["number-sense", "primes", "modular-arithmetic", "number-patterns", "combinatorics", "logic", "sets", "graphs", "algorithms", "cryptography"].map((slug) => (
              <Route key={`dw-${slug}`} path={`discrete-world/${slug}`} element={<DiscreteWorld />} />
            ))}
            <Route
              path="parametric-curves"
              element={<ParametricCurveExplorer />}
            />
            <Route path="surface-plotter" element={<SurfacePlotter3D />} />
            <Route
              path="fourier-animator"
              element={<FourierSeriesAnimator />}
            />
            <Route
              path="polar-visualizer"
              element={
                <NavigatePreserve to="/calculus/series-parametric-polar?mode=polar" />
              }
            />
            <Route path="unit-converter" element={<UnitConverter />} />
            <Route
              path="probability-statistics"
              element={<ProbabilityStatistics />}
            />
            {["data-explorer", "descriptive", "interactive-distributions", "experiments", "counting", "clt", "confidence-intervals", "hypothesis", "correlation", "anova"].map((slug) => (
              <Route key={`stats-${slug}`} path={`probability-statistics/${slug}`} element={<ProbabilityStatistics />} />
            ))}
            <Route
              path="probability-statistics/module"
              element={<ProbabilityStatisticsModulePage />}
            />
            <Route
              path="probability-statistics/distributions"
              element={<DistributionAtlasPage />}
            />
            <Route
              path="probability-statistics/distributions/:distributionId"
              element={<DistributionDetailPage />}
            />
            <Route
              path="probability-statistics/sampling"
              element={<ProbabilityStatisticsPhaseTwoPage page="sampling" />}
            />
            <Route
              path="probability-statistics/inference"
              element={<ProbabilityStatisticsPhaseTwoPage page="inference" />}
            />
            <Route
              path="probability-statistics/regression"
              element={<ProbabilityStatisticsPhaseTwoPage page="regression" />}
            />
            <Route
              path="probability-statistics/bayesian"
              element={<ProbabilityStatisticsPhaseThreePage page="bayesian" />}
            />
            <Route
              path="probability-statistics/stochastic"
              element={
                <ProbabilityStatisticsPhaseThreePage page="stochastic" />
              }
            />
            <Route
              path="probability-statistics/advanced-models"
              element={
                <ProbabilityStatisticsPhaseThreePage page="advanced-models" />
              }
            />
            <Route
              path="probability-statistics/survey-sampling"
              element={
                <StatisticsSyllabusCompletionPage studioId="survey-sampling" />
              }
            />
            <Route
              path="probability-statistics/design-of-experiments"
              element={
                <StatisticsSyllabusCompletionPage studioId="design-of-experiments" />
              }
            />
            <Route
              path="probability-statistics/quality-control"
              element={
                <StatisticsSyllabusCompletionPage studioId="quality-control" />
              }
            />
            <Route
              path="probability-statistics/time-series"
              element={
                <StatisticsSyllabusCompletionPage studioId="time-series" />
              }
            />
            <Route
              path="probability-statistics/nonparametric"
              element={
                <StatisticsSyllabusCompletionPage studioId="nonparametric" />
              }
            />
            <Route
              path="probability-statistics/multivariate-analysis"
              element={
                <StatisticsSyllabusCompletionPage studioId="multivariate-analysis" />
              }
            />
            <Route
              path="probability-statistics/advanced-inference"
              element={
                <StatisticsSyllabusCompletionPage studioId="advanced-inference" />
              }
            />
            <Route
              path="probability-statistics/official-statistics"
              element={
                <StatisticsSyllabusCompletionPage studioId="official-statistics" />
              }
            />
            <Route
              path="probability-statistics/survival-analysis"
              element={
                <StatisticsSyllabusCompletionPage studioId="survival-analysis" />
              }
            />
            <Route
              path="probability-statistics/actuarial-reliability"
              element={
                <StatisticsSyllabusCompletionPage studioId="actuarial-reliability" />
              }
            />
            <Route
              path="probability-statistics/statistical-computing"
              element={
                <StatisticsSyllabusCompletionPage studioId="statistical-computing" />
              }
            />
            <Route
              path="probability-statistics/applied-modelling"
              element={
                <StatisticsSyllabusCompletionPage studioId="applied-modelling" />
              }
            />
            <Route
              path="probability-statistics/school-statistics"
              element={
                <StatisticsSyllabusCompletionPage studioId="school-statistics" />
              }
            />
            <Route
              path="mathematical-logic"
              element={<Navigate to="/discrete-world/logic?mode=Truth+Table" replace />}
            />
            <Route path="truth-table" element={<Navigate to="/discrete-world/logic?mode=Truth+Table" replace />} />
            <Route
              path="math/algebra"
              element={<Navigate to="/algebra" replace />}
            />
            <Route
              path="math/geometry"
              element={<Navigate to="/geometry" replace />}
            />
            <Route
              path="math/trigonometry"
              element={<Navigate to="/trigonometry" replace />}
            />
            <Route
              path="math/functions"
              element={<Navigate to="/math-lab/function-explorer" replace />}
            />
            <Route
              path="math/functions-graphs"
              element={<Navigate to="/workspace/graph" replace />}
            />
            <Route
              path="math/limits-continuity"
              element={<NavigatePreserve to="/calculus/limits" />}
            />
            <Route
              path="math/derivatives"
              element={<NavigatePreserve to="/calculus/derivatives" />}
            />
            <Route
              path="math/integration"
              element={<NavigatePreserve to="/calculus/integration" />}
            />
            <Route
              path="math/matrix-transformations"
              element={<MatrixTransformationsVisualizerPage />}
            />
            <Route
              path="math/eigenvectors"
              element={<EigenvectorsVisualizerPage />}
            />
            <Route
              path="math/slope-fields"
              element={<NavigatePreserve to="/calculus/differential-equations?mode=slope" />}
            />
            <Route
              path="math/fourier-series"
              element={<FourierSeriesVisualizerPage />}
            />
            <Route
              path="math/permutations-combinations"
              element={<Navigate to="/discrete-world/combinatorics" replace />}
            />
            <Route
              path="math/:visualizationId"
              element={<MathVisualizationPage />}
            />
            <Route path="ncert" element={<NCERTDashboardPage />} />
            <Route path="ncert/:conceptId" element={<NCERTConceptPage />} />
            <Route
              path="syllabus-visual/:topicId"
              element={<BoardSyllabusVisualizer />}
            />
            <Route
              path="syllabus-visual-v2/:slug"
              element={<SyllabusVisualPage />}
            />
            <Route
              path="syllabus-lab/:labId"
              element={<AdvancedSyllabusLabPage />}
            />
            <Route path="syllabus" element={<Syllabus />} />
            <Route path="syllabus/:levelId" element={<Syllabus />} />
            <Route path="calculator" element={<ScientificCalculator />} />
            <Route path="quiz" element={<Quiz />} />
            <Route path="documentation" element={<Documentation />} />
            <Route path="sitemap" element={<Sitemap />} />
            <Route path="about" element={<About />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
        <StandaloneStudioTheory /></StudioModelProvider>
      </Suspense>
    </AppErrorBoundary>
  );
}

function RouteProgressBar() {
  const location = useLocation();
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    setVisible(true);
    setProgress(18);
    const timers = [
      window.setTimeout(() => setProgress(48), 80),
      window.setTimeout(() => setProgress(78), 220),
      window.setTimeout(() => setProgress(100), 420),
      window.setTimeout(() => setVisible(false), 700),
    ];

    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [location.hash, location.pathname, location.search]);

  return (
    <div
      className={`route-progress ${visible ? "route-progress-visible" : ""}`}
      role="progressbar"
      aria-label="Loading page"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(progress)}
    >
      <span style={{ transform: `scaleX(${progress / 100})` }} />
    </div>
  );
}

function RouteFallback() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center p-6">
      <div
        className="h-10 w-10 animate-spin rounded-full border-4 border-cyan-200 border-t-cyan-600"
        aria-label="Loading"
      />
    </div>
  );
}

