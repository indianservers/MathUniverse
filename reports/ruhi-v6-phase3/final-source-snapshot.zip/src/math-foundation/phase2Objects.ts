import type { MathDependencyGraph } from "./dependencyGraph";
import type { MathDiagnostic } from "./types";

export type Phase2ObjectType =
  | "SCALAR"
  | "CONSTANT"
  | "VARIABLE"
  | "FUNCTION"
  | "EQUATION"
  | "INEQUALITY"
  | "POINT"
  | "POINT_LIST"
  | "SEQUENCE"
  | "TABLE"
  | "EXPLICIT_CURVE"
  | "IMPLICIT_CURVE"
  | "PARAMETRIC_CURVE"
  | "POLAR_CURVE"
  | "PIECEWISE_FUNCTION"
  | "REGION"
  | "GEOMETRY"
  | "MEASUREMENT"
  | "TRANSFORMATION"
  | "SLIDER"
  | "ACTION"
  | "NOTE"
  | "FOLDER";
export type ObjectStyle2d = {
  color: string;
  opacity: number;
  lineWidth: number;
  lineStyle: "SOLID" | "DASHED" | "DOTTED";
  pointSize: number;
  pointShape: "CIRCLE" | "SQUARE" | "DIAMOND" | "CROSS";
  fill: string;
  label: string;
  labelPosition: "AUTO" | "ABOVE" | "BELOW" | "LEFT" | "RIGHT";
  regionPattern: "SOLID" | "DIAGONAL" | "CROSSHATCH" | "DOTS";
  layer: number;
  trace: boolean;
  auxiliary: boolean;
};
export type Phase2Object = {
  id: string;
  nodeId?: string;
  type: Phase2ObjectType;
  name: string;
  definition: string;
  visible: boolean;
  locked: boolean;
  folderId?: string;
  order: number;
  style: ObjectStyle2d;
  diagnostics: MathDiagnostic[];
  createdAt: string;
  updatedAt: string;
};
export type SliderConfig = {
  objectId: string;
  symbol: string;
  min: number;
  max: number;
  stepNumerator: number;
  stepDenominator: number;
  value: number;
  speed: number;
  duration: number;
  direction: "FORWARD" | "REVERSE";
  loop: "LOOP" | "PING_PONG" | "ONCE";
  easing: "LINEAR" | "EASE_IN_OUT";
};
export type AnimationTrack = SliderConfig & {
  playing: boolean;
  startedAt: number;
  startValue: number;
};

export class Phase2ObjectRegistry {
  private objects = new Map<string, Phase2Object>();
  private selection = new Set<string>();
  private density: "COMPACT" | "COMFORTABLE" = "COMFORTABLE";
  constructor(private readonly graph: MathDependencyGraph) {}
  add(
    input: Omit<
      Phase2Object,
      "id" | "order" | "style" | "diagnostics" | "createdAt" | "updatedAt"
    > & { id?: string; style?: Partial<ObjectStyle2d> },
  ) {
    const now = new Date().toISOString();
    const object: Phase2Object = {
      ...input,
      id: input.id ?? crypto.randomUUID(),
      order: this.objects.size,
      style: { ...defaultStyle(), ...input.style },
      diagnostics: [],
      createdAt: now,
      updatedAt: now,
    };
    if (
      input.definition &&
      !["NOTE", "FOLDER", "ACTION"].includes(input.type)
    ) {
      const record = this.graph.define(input.definition, input.nodeId);
      object.nodeId = record?.id;
      object.diagnostics = this.graph.getSnapshot().diagnostics;
    }
    this.objects.set(object.id, object);
    return structuredClone(object);
  }
  update(id: string, patch: Partial<Omit<Phase2Object, "id" | "createdAt">>) {
    const current = this.objects.get(id);
    if (!current) return;
    const next = {
      ...current,
      ...patch,
      style: { ...current.style, ...patch.style },
      updatedAt: new Date().toISOString(),
    };
    if (patch.definition && next.nodeId) {
      const record = this.graph.define(patch.definition, next.nodeId);
      next.diagnostics =
        record?.result.diagnostics ?? this.graph.getSnapshot().diagnostics;
    }
    this.objects.set(id, next);
    return structuredClone(next);
  }
  duplicate(id: string) {
    const source = this.objects.get(id);
    if (!source) return;
    return this.add({
      ...source,
      id: undefined,
      nodeId: undefined,
      name: `${source.name} copy`,
      definition: source.definition,
      style: source.style,
    });
  }
  remove(ids: string[]) {
    ids.forEach((id) => {
      const object = this.objects.get(id);
      if (object?.nodeId) this.graph.remove(object.nodeId);
      this.objects.delete(id);
      this.selection.delete(id);
    });
    this.reindex();
  }
  reorder(id: string, target: number) {
    const ordered = this.list();
    const index = ordered.findIndex((entry) => entry.id === id);
    if (index < 0) return;
    const [object] = ordered.splice(index, 1);
    ordered.splice(Math.max(0, Math.min(target, ordered.length)), 0, object);
    ordered.forEach((entry, index_) =>
      this.objects.set(entry.id, { ...entry, order: index_ }),
    );
  }
  select(ids: string[]) {
    this.selection = new Set(ids.filter((id) => this.objects.has(id)));
  }
  batch(
    patch: Pick<Partial<Phase2Object>, "visible" | "locked"> & {
      style?: Partial<ObjectStyle2d>;
    },
  ) {
    this.selection.forEach((id) =>
      this.update(id, patch as Partial<Omit<Phase2Object, "id" | "createdAt">>),
    );
  }
  list(filter?: {
    query?: string;
    errorsOnly?: boolean;
    warningsOnly?: boolean;
  }) {
    const query = filter?.query?.toLowerCase().trim();
    return [...this.objects.values()]
      .filter(
        (object) =>
          (!query ||
            `${object.name} ${object.definition} ${object.type}`
              .toLowerCase()
              .includes(query)) &&
          (!filter?.errorsOnly ||
            object.diagnostics.some((entry) => entry.severity === "ERROR")) &&
          (!filter?.warningsOnly ||
            object.diagnostics.some((entry) => entry.severity === "WARNING")),
      )
      .sort((a, b) => a.order - b.order)
      .map((entry) => structuredClone(entry));
  }
  usedBy(id: string) {
    const object = this.objects.get(id);
    if (!object?.nodeId) return [];
    const symbol = this.graph.getRecord(object.nodeId)?.symbol;
    return symbol
      ? this.graph
          .getSnapshot()
          .records.filter((record) => record.dependencies.includes(symbol))
          .map((record) => record.id)
      : [];
  }
  setDensity(value: "COMPACT" | "COMFORTABLE") {
    this.density = value;
  }
  serialize() {
    return {
      version: 1,
      density: this.density,
      objects: this.list(),
      selection: [...this.selection],
    };
  }
  private reindex() {
    this.list().forEach((entry, index) =>
      this.objects.set(entry.id, { ...entry, order: index }),
    );
  }
}

export function createSliderTrack(config: SliderConfig): AnimationTrack {
  return { ...config, playing: false, startedAt: 0, startValue: config.value };
}
export function sliderValueAt(
  track: AnimationTrack,
  timestamp: number,
  reducedMotion = false,
) {
  if (!track.playing || reducedMotion) return clampToStep(track.value, track);
  const elapsed =
    Math.max(0, (timestamp - track.startedAt) / 1000) * track.speed;
  const span = track.max - track.min;
  const rawProgress = track.duration <= 0 ? 1 : elapsed / track.duration;
  let progress =
    track.loop === "ONCE"
      ? Math.min(1, rawProgress)
      : track.loop === "LOOP"
        ? rawProgress % 1
        : rawProgress % 2 <= 1
          ? rawProgress % 1
          : 1 - (rawProgress % 1);
  if (track.direction === "REVERSE") progress = 1 - progress;
  if (track.easing === "EASE_IN_OUT")
    progress =
      progress < 0.5
        ? 2 * progress * progress
        : 1 - (-2 * progress + 2) ** 2 / 2;
  return clampToStep(track.min + span * progress, track);
}
export function applySliderValue(
  graph: MathDependencyGraph,
  track: AnimationTrack,
  value: number,
) {
  const next = clampToStep(value, track);
  const record = graph.define(`${track.symbol}=${next}`);
  return { track: { ...track, value: next }, record };
}
function clampToStep(value: number, track: SliderConfig) {
  const step = track.stepNumerator / Math.max(1, track.stepDenominator);
  const clamped = Math.max(track.min, Math.min(track.max, value));
  return Number(
    (track.min + Math.round((clamped - track.min) / step) * step).toPrecision(
      14,
    ),
  );
}
function defaultStyle(): ObjectStyle2d {
  return {
    color: "#22d3ee",
    opacity: 1,
    lineWidth: 2,
    lineStyle: "SOLID",
    pointSize: 6,
    pointShape: "CIRCLE",
    fill: "#22d3ee33",
    label: "",
    labelPosition: "AUTO",
    regionPattern: "DIAGONAL",
    layer: 0,
    trace: false,
    auxiliary: false,
  };
}
