import WorkspaceChromeThemeToggle from "../components/workspace/WorkspaceChromeThemeToggle";
import { Award, Box, Camera, Check, ChevronDown, Cuboid, Download, Eye, Filter, Grid3X3, Heart, History, Mic, PanelLeftClose, PanelLeftOpen, Palette, Pause, Play, Printer, RefreshCw, Redo2, RotateCcw, RotateCw, Ruler, Search, Settings, Shapes, SlidersHorizontal, Sparkles, Star, Undo2, Volume2, Wand2, X, ZoomIn, ZoomOut } from "lucide-react";
import { OrbitControls, Text } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { ReactNode, useEffect, useMemo, useRef, useState, type PointerEvent } from "react";
import * as THREE from "three";
import ThreeSceneWrapper from "../components/three/ThreeSceneWrapper";
import MathExpression from "../components/ui/MathExpression";
import SectionCard from "../components/ui/SectionCard";
import SliderControl, { SliderGroup } from "../components/ui/SliderControl";
import TopicHeader from "../components/ui/TopicHeader";
import { useProgress } from "../hooks/useProgress";
import { roundTo } from "../utils/math";
import { ContextualWorkspaceLink } from "../components/workspace/MathWorkspaceNavigation";
import { createMathWorkspacePayload } from "../workspace/mathWorkspaces";
import { useDialogFocus } from "../hooks/useDialogFocus";
import { useReducedMotion } from "../hooks/useReducedMotion";
import ShapeThumbnail from "../components/shapes/ShapeThumbnail";

type ShapeKind = "2d" | "3d";
type ShapeFillMode = "gradient" | "solid" | "outline";
export type ShapeCategory = "2D Basic" | "2D Curved" | "2D Polygons" | "3D Solids" | "3D Curved Solids";
export type ShapeId =
  | "circle" | "semicircle" | "sector" | "ellipse" | "triangle" | "right-triangle" | "equilateral-triangle" | "isosceles-triangle" | "scalene-triangle" | "square" | "rectangle" | "rounded-rectangle"
  | "parallelogram" | "rhombus" | "trapezium" | "kite" | "pentagon" | "hexagon" | "heptagon" | "octagon" | "nonagon" | "decagon" | "dodecagon" | "regular-polygon"
  | "annulus" | "quadrant" | "segment" | "crescent" | "star" | "cross"
  | "cube" | "cuboid" | "sphere" | "hemisphere" | "cylinder" | "hollow-cylinder" | "capsule" | "ellipsoid" | "cone" | "frustum" | "torus"
  | "tetrahedron" | "octahedron" | "dodecahedron" | "icosahedron" | "square-pyramid" | "triangular-pyramid" | "rectangular-pyramid" | "pentagonal-pyramid" | "hexagonal-pyramid"
  | "triangular-prism" | "pentagonal-prism" | "hexagonal-prism" | "octagonal-prism";

export type ShapeDefinition = {
  id: ShapeId;
  name: string;
  kind: ShapeKind;
  category: ShapeCategory;
  formula: string;
  description: string;
  dimensions: string[];
  use: string;
  thumbnail: string;
};

type Metrics = Record<string, number>;
type ShapeToolMode = "rotate" | "pan" | "measure" | "grid";
type ShapeUnit = "units" | "mm" | "cm" | "m" | "in";
type ShapesTheme = "dark" | "light" | "glow";
type ShapeSort = "name" | "dimension" | "complexity" | "vertices";
type ShapeHistorySnapshot = {
  a: number;
  b: number;
  c: number;
  sides: number;
  angle: number;
  selectedId: ShapeId;
  wireframe: boolean;
  fillMode: ShapeFillMode;
  colorA: string;
  colorB: string;
  shapeGlow: boolean;
  showGrid: boolean;
  viewZoom: number;
  viewRotation: number;
  autoRotate: boolean;
};

const SHAPES_PREFERENCES_KEY = "math-universe-shapes-preferences-v2";
const savedShapesTheme = (): ShapesTheme => {
  try { const saved=JSON.parse(localStorage.getItem(SHAPES_PREFERENCES_KEY) ?? "{}").theme; return saved === "dark" || saved === "glow" ? saved : "light"; }
  catch { return "light"; }
};
const unitScale: Record<ShapeUnit, number> = { units: 1, mm: 10, cm: 1, m: 0.01, in: 0.3937008 };

type DockPaneTab = "Live Values" | "Net & Cross-Sections" | "Formula Map";

type ShapeFormulaEntry = {
  title: string;
  formula: string;
  note: string;
  valueLabel?: string;
};

const shapeSeeds: Omit<ShapeDefinition, "thumbnail">[] = [
  { id: "circle", name: "Circle", kind: "2d", category: "2D Curved", formula: "C = 2 pi r, A = pi r^2", description: "All points at a fixed distance from the center.", dimensions: ["radius"], use: "Wheels, clocks, lenses, gears." },
  { id: "semicircle", name: "Semicircle", kind: "2d", category: "2D Curved", formula: "Arc = pi r, A = 1/2 pi r^2", description: "Half of a circle split by a diameter.", dimensions: ["radius"], use: "Arches, windows, half-pipe profiles." },
  { id: "sector", name: "Sector", kind: "2d", category: "2D Curved", formula: "A = theta/360 pi r^2, L = theta/360 2 pi r", description: "A slice of a circle controlled by central angle.", dimensions: ["radius", "angle"], use: "Pie charts, clock angles, circular tracks." },
  { id: "ellipse", name: "Ellipse", kind: "2d", category: "2D Curved", formula: "A = pi ab", description: "A stretched circle with semi-major and semi-minor axes.", dimensions: ["semi-major axis a", "semi-minor axis b"], use: "Orbits, lenses, design curves." },
  { id: "triangle", name: "General Triangle", kind: "2d", category: "2D Basic", formula: "A = 1/2 bh, P = a + b + c", description: "A three-sided polygon. No equal sides or right angle are assumed.", dimensions: ["base", "perpendicular height"], use: "Trusses, roofs, triangulation, game meshes." },
  { id: "right-triangle", name: "Right Triangle", kind: "2d", category: "2D Basic", formula: "A = 1/2 ab, c = sqrt(a^2 + b^2)", description: "A triangle with one 90 degree angle.", dimensions: ["base", "height"], use: "Slopes, ramps, navigation, trigonometry." },
  { id: "equilateral-triangle", name: "Equilateral Triangle", kind: "2d", category: "2D Basic", formula: "A = sqrt(3)/4 s^2, P = 3s", description: "A triangle with three equal sides and three 60 degree angles.", dimensions: ["side"], use: "Trusses, tessellations, warning signs." },
  { id: "isosceles-triangle", name: "Isosceles Triangle", kind: "2d", category: "2D Basic", formula: "A = 1/2 bh, P = b + 2s", description: "A triangle with two equal sides and a line of symmetry.", dimensions: ["base", "height"], use: "Roofs, bridge frames, symmetry." },
  { id: "scalene-triangle", name: "Scalene Triangle", kind: "2d", category: "2D Basic", formula: "A = 1/2 bh, P = a + b + c", description: "A triangle with three different side lengths and three different angles.", dimensions: ["base", "perpendicular height", "apex offset"], use: "Surveying, triangulation, irregular structures." },
  { id: "square", name: "Square", kind: "2d", category: "2D Basic", formula: "A = s^2, P = 4s, d = s sqrt(2)", description: "Four equal sides and four right angles.", dimensions: ["side"], use: "Tiles, grids, pixels, floor plans." },
  { id: "rectangle", name: "Rectangle", kind: "2d", category: "2D Basic", formula: "A = lw, P = 2(l+w)", description: "Opposite sides equal, all angles right angles.", dimensions: ["length", "width"], use: "Screens, rooms, pages, dashboards." },
  { id: "rounded-rectangle", name: "Rounded Rectangle", kind: "2d", category: "2D Basic", formula: "A = lw - (4-pi)r^2", description: "A rectangle whose four corners are replaced by quarter-circle arcs.", dimensions: ["length", "width", "corner radius"], use: "Screens, cards, signs, interface design." },
  { id: "parallelogram", name: "Parallelogram", kind: "2d", category: "2D Polygons", formula: "A = bh, P = 2(a+b)", description: "Opposite sides are parallel and equal.", dimensions: ["base", "height", "side"], use: "Vector addition, tiling, force diagrams." },
  { id: "rhombus", name: "Rhombus", kind: "2d", category: "2D Polygons", formula: "A = d1 d2 / 2, P = 4s", description: "A parallelogram with four equal sides.", dimensions: ["diagonal 1", "diagonal 2"], use: "Patterns, crystals, lattice geometry." },
  { id: "trapezium", name: "Trapezium", kind: "2d", category: "2D Polygons", formula: "A = 1/2 (a+b)h", description: "A quadrilateral with one pair of parallel sides.", dimensions: ["base", "top", "height"], use: "Bridges, ramps, cross-sections." },
  { id: "kite", name: "Kite", kind: "2d", category: "2D Polygons", formula: "A = d1 d2 / 2", description: "Two pairs of adjacent equal sides.", dimensions: ["diagonal 1", "diagonal 2"], use: "Kites, decorative panels, symmetry studies." },
  { id: "pentagon", name: "Pentagon", kind: "2d", category: "2D Polygons", formula: "A = 5s^2/(4 tan(pi/5)), P = 5s", description: "A five-sided polygon.", dimensions: ["side"], use: "Badges, architecture, tiling studies." },
  { id: "hexagon", name: "Hexagon", kind: "2d", category: "2D Polygons", formula: "A = 3sqrt(3)s^2/2, P = 6s", description: "A six-sided polygon common in efficient packing.", dimensions: ["side"], use: "Honeycombs, bolts, grid maps." },
  { id: "heptagon", name: "Heptagon", kind: "2d", category: "2D Polygons", formula: "A = 7s^2/(4 tan(pi/7)), P = 7s", description: "A seven-sided polygon.", dimensions: ["side"], use: "Coins, decorative geometry, polygon classification." },
  { id: "octagon", name: "Octagon", kind: "2d", category: "2D Polygons", formula: "A = 2(1+sqrt(2))s^2, P = 8s", description: "An eight-sided polygon.", dimensions: ["side"], use: "Stop signs, floor patterns, design frames." },
  { id: "nonagon", name: "Nonagon", kind: "2d", category: "2D Polygons", formula: "A = 9s^2/(4 tan(pi/9)), P = 9s", description: "A regular nine-sided polygon.", dimensions: ["side"], use: "Decorative frames, radial layouts, polygon studies." },
  { id: "decagon", name: "Decagon", kind: "2d", category: "2D Polygons", formula: "A = 10s^2/(4 tan(pi/10)), P = 10s", description: "A ten-sided polygon.", dimensions: ["side"], use: "Circular approximations, ornaments, game tokens." },
  { id: "dodecagon", name: "Dodecagon", kind: "2d", category: "2D Polygons", formula: "A = 12s^2/(4 tan(pi/12)), P = 12s", description: "A regular twelve-sided polygon.", dimensions: ["side"], use: "Clock faces, coins, architectural plans." },
  { id: "regular-polygon", name: "Regular Polygon", kind: "2d", category: "2D Polygons", formula: "A = n s^2 / (4 tan(pi/n)), P = ns", description: "All sides and angles are equal.", dimensions: ["side", "sides"], use: "Tiling, icons, nuts and bolts, meshes." },
  { id: "annulus", name: "Annulus", kind: "2d", category: "2D Curved", formula: "A = pi(R^2-r^2)", description: "A ring-shaped region between two concentric circles.", dimensions: ["outer radius", "inner radius"], use: "Washers, rings, tracks, gaskets." },
  { id: "quadrant", name: "Quadrant", kind: "2d", category: "2D Curved", formula: "A = 1/4 pi r^2, arc = 1/2 pi r", description: "One quarter of a circle.", dimensions: ["radius"], use: "Coordinate planes, rounded corners, quarter turns." },
  { id: "segment", name: "Circular Segment", kind: "2d", category: "2D Curved", formula: "A = sector area - triangle area", description: "A region cut from a circle by a chord.", dimensions: ["radius", "angle"], use: "Lenses, bridge arches, tank fill levels." },
  { id: "crescent", name: "Crescent", kind: "2d", category: "2D Curved", formula: "A = area(big circle) - overlap", description: "A moon-like shape made from two offset circular arcs.", dimensions: ["outer radius", "inner radius"], use: "Astronomy icons, logos, moon phases." },
  { id: "star", name: "Star Polygon", kind: "2d", category: "2D Polygons", formula: "A = 5Rr sin(36 deg)", description: "A five-point star polygon with alternating outer and inner radii.", dimensions: ["outer radius", "inner radius"], use: "Flags, ratings, decorative geometry." },
  { id: "cross", name: "Cross Shape", kind: "2d", category: "2D Polygons", formula: "A = 4aw-w^2, P = 8a", description: "Two centered rectangles of total arm length 2a and width w crossing at right angles.", dimensions: ["arm half-length", "arm width"], use: "Symbols, floor plans, structural layouts." },
  { id: "cube", name: "Cube", kind: "3d", category: "3D Solids", formula: "SA = 6s^2, V = s^3", description: "A solid with six equal square faces.", dimensions: ["side"], use: "Dice, voxels, packaging, 3D grids." },
  { id: "cuboid", name: "Cuboid", kind: "3d", category: "3D Solids", formula: "SA = 2(lw+lh+wh), V = lwh", description: "A rectangular box with length, width, and height.", dimensions: ["length", "width", "height"], use: "Rooms, cartons, tanks, containers." },
  { id: "sphere", name: "Sphere", kind: "3d", category: "3D Curved Solids", formula: "SA = 4 pi r^2, V = 4/3 pi r^3", description: "All surface points are the same distance from the center.", dimensions: ["radius"], use: "Planets, balls, bubbles, atoms." },
  { id: "hemisphere", name: "Hemisphere", kind: "3d", category: "3D Curved Solids", formula: "CSA = 2 pi r^2, TSA = 3 pi r^2, V = 2/3 pi r^3", description: "Half of a sphere with a circular base.", dimensions: ["radius"], use: "Domes, bowls, observatories." },
  { id: "cylinder", name: "Cylinder", kind: "3d", category: "3D Curved Solids", formula: "SA = 2 pi r(r+h), V = pi r^2 h", description: "Two circular bases connected by a curved surface.", dimensions: ["radius", "height"], use: "Cans, pipes, tanks, pistons." },
  { id: "hollow-cylinder", name: "Hollow Cylinder", kind: "3d", category: "3D Curved Solids", formula: "V = pi h(R^2-r^2)", description: "A tube with outer and inner circular radii.", dimensions: ["outer radius", "inner radius", "height"], use: "Pipes, sleeves, washers, ducts." },
  { id: "capsule", name: "Capsule", kind: "3d", category: "3D Curved Solids", formula: "V = pi r^2 h + 4/3 pi r^3", description: "A cylinder capped by two hemispheres.", dimensions: ["radius", "cylinder length"], use: "Pills, pressure vessels, game colliders." },
  { id: "ellipsoid", name: "Ellipsoid", kind: "3d", category: "3D Curved Solids", formula: "V = 4/3 pi abc", description: "A sphere stretched along three semi-axes.", dimensions: ["semi-axis a", "semi-axis b", "semi-axis c"], use: "Planets, lenses, probability clouds." },
  { id: "cone", name: "Cone", kind: "3d", category: "3D Curved Solids", formula: "SA = pi r(r+l), V = 1/3 pi r^2 h", description: "A circular base tapering to one point.", dimensions: ["radius", "height"], use: "Funnels, traffic cones, nozzles." },
  { id: "frustum", name: "Frustum", kind: "3d", category: "3D Curved Solids", formula: "V = 1/3 pi h(R^2 + Rr + r^2)", description: "A cone with its top cut off parallel to the base.", dimensions: ["radius", "top radius", "height"], use: "Buckets, lampshades, tapered columns." },
  { id: "tetrahedron", name: "Tetrahedron", kind: "3d", category: "3D Solids", formula: "V = s^3/(6sqrt(2))", description: "A polyhedron with four triangular faces.", dimensions: ["side"], use: "Molecular geometry, dice, meshes." },
  { id: "octahedron", name: "Octahedron", kind: "3d", category: "3D Solids", formula: "V = sqrt(2)s^3/3", description: "A polyhedron with eight triangular faces.", dimensions: ["side"], use: "Crystals, dice, symmetric models." },
  { id: "dodecahedron", name: "Dodecahedron", kind: "3d", category: "3D Solids", formula: "SA = 3sqrt(25+10sqrt(5))s^2, V = (15+7sqrt(5))s^3/4", description: "A Platonic solid with twelve pentagonal faces.", dimensions: ["edge length"], use: "Dice, topology, symmetry studies." },
  { id: "icosahedron", name: "Icosahedron", kind: "3d", category: "3D Solids", formula: "SA = 5sqrt(3)s^2, V = 5(3+sqrt(5))s^3/12", description: "A Platonic solid with twenty triangular faces.", dimensions: ["edge length"], use: "Geodesic models, dice, meshes." },
  { id: "square-pyramid", name: "Square Pyramid", kind: "3d", category: "3D Solids", formula: "V = 1/3 s^2 h", description: "A square base rising to one apex.", dimensions: ["side", "height"], use: "Pyramids, roofs, monuments." },
  { id: "triangular-pyramid", name: "Triangular Pyramid", kind: "3d", category: "3D Solids", formula: "V = 1/3 Bh", description: "A pyramid with a triangular base.", dimensions: ["base side", "height"], use: "Tetrahedral models, roof geometry." },
  { id: "rectangular-pyramid", name: "Rectangular Pyramid", kind: "3d", category: "3D Solids", formula: "V = 1/3 lwh", description: "A rectangular base rising to one apex.", dimensions: ["length", "width", "height"], use: "Roofs, monuments, packaging." },
  { id: "pentagonal-pyramid", name: "Pentagonal Pyramid", kind: "3d", category: "3D Solids", formula: "V = 1/3 Bh", description: "A regular pentagonal base joined to one apex.", dimensions: ["base side", "height"], use: "Architecture, crystal models, geometric sculpture." },
  { id: "hexagonal-pyramid", name: "Hexagonal Pyramid", kind: "3d", category: "3D Solids", formula: "V = 1/3 Bh", description: "A regular hexagonal base joined to one apex.", dimensions: ["base side", "height"], use: "Roofs, crystal models, geometric sculpture." },
  { id: "triangular-prism", name: "Triangular Prism", kind: "3d", category: "3D Solids", formula: "V = 1/2 bhL", description: "A triangular face extruded through a length.", dimensions: ["base", "height", "length"], use: "Roof forms, wedges, optical prisms." },
  { id: "pentagonal-prism", name: "Pentagonal Prism", kind: "3d", category: "3D Solids", formula: "V = pentagon area * length", description: "A pentagonal face extruded through a length.", dimensions: ["side", "length"], use: "Columns, packaging, architecture." },
  { id: "hexagonal-prism", name: "Hexagonal Prism", kind: "3d", category: "3D Solids", formula: "V = 3sqrt(3)/2 s^2 L", description: "A hexagonal face extruded through a length.", dimensions: ["side", "length"], use: "Pencils, honeycomb cells, bolts." },
  { id: "octagonal-prism", name: "Octagonal Prism", kind: "3d", category: "3D Solids", formula: "V = 2(1+sqrt(2))s^2 L", description: "An octagonal face extruded through a length.", dimensions: ["side", "length"], use: "Columns, packaging, architectural structures." },
  { id: "torus", name: "Torus", kind: "3d", category: "3D Curved Solids", formula: "SA = 4 pi^2 Rr, V = 2 pi^2 Rr^2", description: "A doughnut-shaped solid with major and minor radii.", dimensions: ["major radius", "minor radius"], use: "Tires, O-rings, magnetic coils." },
];

const categories = ["All", "2D Basic", "2D Curved", "2D Polygons", "3D Solids", "3D Curved Solids"] as const;
const shapeMenuCategories = categories.filter((item): item is ShapeCategory => item !== "All");

export default function ShapesExplorer() {
  const { markTopicVisited, markTopicInteracted } = useProgress();
  const [selectedId, setSelectedId] = useState<ShapeId>("circle");
  const [expandedCategories, setExpandedCategories] = useState<Set<ShapeCategory>>(() => new Set(["2D Basic", "2D Curved", "3D Solids"]));
  const [a, setA] = useState(4);
  const [b, setB] = useState(3);
  const [c, setC] = useState(5);
  const [sides, setSides] = useState(6);
  const [angle, setAngle] = useState(90);
  const [wireframe, setWireframe] = useState(false);
  const [fillMode, setFillMode] = useState<ShapeFillMode>("gradient");
  const [colorA, setColorA] = useState("#22d3ee");
  const [colorB, setColorB] = useState("#8b5cf6");
  const [shapeGlow, setShapeGlow] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [viewZoom, setViewZoom] = useState(1);
  const [viewRotation, setViewRotation] = useState(0);
  const [autoRotate, setAutoRotate] = useState(true);
  const [viewTab, setViewTab] = useState<ShapeKind>("2d");
  const [stageHeight, setStageHeight] = useState(520);
  const [viewResetNonce, setViewResetNonce] = useState(0);
  const [shapeMenuCollapsed, setShapeMenuCollapsed] = useState(() => typeof window !== "undefined" && window.innerWidth <= 900);
  const [mobileInspectorOpen, setMobileInspectorOpen] = useState(false);
  const [mobileInspectorSize, setMobileInspectorSize] = useState<"half" | "full">("half");
  const inspectorRef = useRef<HTMLElement | null>(null);
  const inspectorTriggerRef = useRef<HTMLButtonElement | null>(null);
  const inspectorDragRef = useRef<{ y: number; size: "half" | "full" } | null>(null);
  const reducedMotion = useReducedMotion();
  useDialogFocus(mobileInspectorOpen, inspectorRef, inspectorTriggerRef);
  const [studioTab, setStudioTab] = useState<"Explore" | "Properties" | "Formulas" | "Compare" | "Learn" | "In Simple words">("Explore");
  const [dockTab, setDockTab] = useState<DockPaneTab>("Live Values");
  const [inspectorTab, setInspectorTab] = useState<"Dimensions" | "Formulas" | "Properties">("Dimensions");
  const [libraryFilter, setLibraryFilter] = useState<"All" | ShapeKind>("All");
  const [shapeSearch, setShapeSearch] = useState("");
  const [showLabels, setShowLabels] = useState(true);
  const [lockProportions, setLockProportions] = useState(false);
  const [surfacePaint, setSurfacePaint] = useState(45);
  const [favoriteIds, setFavoriteIds] = useState<Set<ShapeId>>(() => new Set());
  const [recentIds, setRecentIds] = useState<ShapeId[]>([]);
  const [compareIds, setCompareIds] = useState<ShapeId[]>(["circle", "square"]);
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [advancedFilter, setAdvancedFilter] = useState<"all" | "curved" | "polygon" | "solid">("all");
  const [shapeSort, setShapeSort] = useState<ShapeSort>("name");
  const [unit, setUnit] = useState<ShapeUnit>("units");
  const [precision, setPrecision] = useState(2);
  const [toolMode, setToolMode] = useState<ShapeToolMode>("rotate");
  const [gridSpacing, setGridSpacing] = useState(1);
  const [snapToGrid, setSnapToGrid] = useState(false);
  const [showAxes, setShowAxes] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [theme, setTheme] = useState<ShapesTheme>(savedShapesTheme);
  const [exportOpen, setExportOpen] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [largeLabels, setLargeLabels] = useState(false);
  const [colorblindPalette, setColorblindPalette] = useState(false);
  const [netProgress, setNetProgress] = useState(0);
  const [sliceAxis, setSliceAxis] = useState<"x" | "y" | "z">("z");
  const [slicePosition, setSlicePosition] = useState(50);
  const [sliceAngle, setSliceAngle] = useState(0);
  const [highlightedSymbol, setHighlightedSymbol] = useState<string | null>(null);
  const [learnStep, setLearnStep] = useState(0);
  const [historyStack, setHistoryStack] = useState<ShapeHistorySnapshot[]>([]);
  const [redoStack, setRedoStack] = useState<ShapeHistorySnapshot[]>([]);
  const historyGuard = useRef(false);
  useEffect(() => markTopicVisited("shapes"), [markTopicVisited]);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(SHAPES_PREFERENCES_KEY) ?? "{}") as { favorites?: ShapeId[]; recent?: ShapeId[]; unit?: ShapeUnit; precision?: number; theme?: ShapesTheme };
      setFavoriteIds(new Set(saved.favorites ?? []));
      setRecentIds(saved.recent ?? []);
      if (saved.unit) setUnit(saved.unit);
      if (typeof saved.precision === "number") setPrecision(saved.precision);
    } catch { /* Ignore malformed local preferences. */ }
  }, []);

  useEffect(() => {
    localStorage.setItem(SHAPES_PREFERENCES_KEY, JSON.stringify({ favorites: [...favoriteIds], recent: recentIds, unit, precision, theme }));
  }, [favoriteIds, precision, recentIds, unit, theme]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shapeParam = params.get("shape");
    const initialShape = shapes.find((shape) => shape.id === shapeParam);
    if (initialShape) {
      setSelectedId(initialShape.id);
      setViewTab(initialShape.kind);
    }
    const readNumber = (...keys: string[]) => {
      const raw = keys.map((key) => params.get(key)).find((value) => value !== null);
      const value = raw === undefined || raw === null ? Number.NaN : Number(raw);
      return Number.isFinite(value) ? value : undefined;
    };
    const first = readNumber("v_base", "v_side", "v_radius", "v_length", "v_outer_radius_r");
    const second = readNumber("v_perpendicular_height", "v_height", "v_width", "v_inner_radius_r");
    const third = readNumber("v_apex_offset", "v_third_dimension");
    if (first !== undefined) setA(first);
    if (second !== undefined) setB(second);
    if (third !== undefined) setC(third);
  }, []);

  const selected = shapes.find((shape) => shape.id === selectedId) ?? shapes[0];
  const groupedShapes = useMemo(() => shapeMenuCategories.map((item) => ({ category: item, shapes: shapes.filter((shape) => shape.category === item) })), []);
  const filteredGroupedShapes = useMemo(() => {
    const query = shapeSearch.trim().toLowerCase();
    return groupedShapes
      .map(({ category, shapes: categoryShapes }) => ({
        category,
        shapes: categoryShapes.filter((shape) => {
          const matchesType = libraryFilter === "All" || shape.kind === libraryFilter;
          const matchesFavorite = !favoritesOnly || favoriteIds.has(shape.id);
          const matchesAdvanced = advancedFilter === "all" || (advancedFilter === "curved" ? /circle|ellipse|annulus|sector|segment|crescent|sphere|cylinder|cone|torus|capsule|frustum|hemisphere/.test(shape.id) : advancedFilter === "polygon" ? shape.kind === "2d" && !/circle|ellipse|annulus|sector|segment|crescent|semicircle|quadrant/.test(shape.id) : shape.kind === "3d");
          const matchesQuery = !query || [shape.name, shape.category, shape.description, shape.formula, shape.use].join(" ").toLowerCase().includes(query);
          return matchesType && matchesFavorite && matchesAdvanced && matchesQuery;
        }).sort((left, right) => shapeSort === "name" ? left.name.localeCompare(right.name) : shapeSort === "dimension" ? left.kind.localeCompare(right.kind) || left.name.localeCompare(right.name) : shapeSort === "vertices" ? shapeProperties(left).vertices - shapeProperties(right).vertices || left.name.localeCompare(right.name) : shapeComplexity(left) - shapeComplexity(right) || left.name.localeCompare(right.name)),
      }))
      .filter((group) => group.shapes.length > 0);
  }, [advancedFilter, favoriteIds, favoritesOnly, groupedShapes, libraryFilter, shapeSearch, shapeSort]);
  const metrics = getMetrics(selected.id, a, b, c, sides, angle);
  const formulaEntries = useMemo(() => getShapeFormulaEntries(selected.id), [selected.id]);
  const familyShapes = useMemo(() => shapes.filter((shape) => shape.category === selected.category && shape.id !== selected.id).slice(0, 4), [selected.category, selected.id]);
  const structure = shapeProperties(selected);
  const secondRange = secondControlRange(selected.id, a);
  const thirdRange = thirdControlRange(selected.id, a, b);

  useEffect(() => {
    if (needsSecond(selected.id) && (b < secondRange.min || b > secondRange.max)) setB(Math.min(secondRange.max, Math.max(secondRange.min, b)));
    if (needsThird(selected.id) && (c < thirdRange.min || c > thirdRange.max)) setC(Math.min(thirdRange.max, Math.max(thirdRange.min, c)));
  }, [selected.id, a, b, c, secondRange.min, secondRange.max, thirdRange.min, thirdRange.max]);

  const selectShape = (shape: ShapeDefinition) => {
    recordHistory();
    setSelectedId(shape.id);
    setRecentIds((current) => [shape.id, ...current.filter((id) => id !== shape.id)].slice(0, 8));
    setExpandedCategories((items) => new Set([...items, shape.category]));
    setViewZoom(1);
    setViewRotation(0);
    setViewTab(shape.kind);
    setViewResetNonce((value) => value + 1);
    const params = new URLSearchParams(window.location.search);
    params.set("shape", shape.id);
    window.history.replaceState(null, "", `${window.location.pathname}?${params.toString()}`);
    markTopicInteracted("shapes");
  };
  const toggleCategory = (item: ShapeCategory) => {
    setExpandedCategories((current) => {
      const next = new Set(current);
      if (next.has(item)) next.delete(item);
      else next.add(item);
      return next;
    });
  };

  const zoomIn = () => setViewZoom((value) => Math.min(2, roundTo(value + 0.1, 2)));
  const zoomOut = () => setViewZoom((value) => Math.max(0.55, roundTo(value - 0.1, 2)));
  const rotateLeft = () => setViewRotation((value) => value - 15);
  const rotateRight = () => setViewRotation((value) => value + 15);
  const resetView = () => {
    recordHistory();
    setViewZoom(1);
    setViewRotation(0);
    setAutoRotate(true);
    setViewResetNonce((value) => value + 1);
  };
  const snapshot = (): ShapeHistorySnapshot => ({ a, b, c, sides, angle, selectedId, wireframe, fillMode, colorA, colorB, shapeGlow, showGrid, viewZoom, viewRotation, autoRotate });
  const applySnapshot = (next: ShapeHistorySnapshot) => {
    historyGuard.current = true;
    setA(next.a); setB(next.b); setC(next.c); setSides(next.sides); setAngle(next.angle); setSelectedId(next.selectedId);
    setWireframe(next.wireframe); setFillMode(next.fillMode); setColorA(next.colorA); setColorB(next.colorB); setShapeGlow(next.shapeGlow);
    setShowGrid(next.showGrid); setViewZoom(next.viewZoom); setViewRotation(next.viewRotation); setAutoRotate(next.autoRotate);
  };
  const recordHistory = () => { if (historyGuard.current) { historyGuard.current = false; return; } setHistoryStack((current) => [...current.slice(-39), snapshot()]); setRedoStack([]); };
  const undoShape = () => { const previous = historyStack.at(-1); if (!previous) return; setRedoStack((current) => [...current, snapshot()]); setHistoryStack((current) => current.slice(0, -1)); applySnapshot(previous); };
  const redoShape = () => { const next = redoStack.at(-1); if (!next) return; setHistoryStack((current) => [...current, snapshot()]); setRedoStack((current) => current.slice(0, -1)); applySnapshot(next); };
  const setDimension = (key: "a" | "b" | "c" | "sides" | "angle", value: number) => { recordHistory(); if (key === "a") setA(value); else if (key === "b") setB(value); else if (key === "c") setC(value); else if (key === "sides") setSides(Math.round(value)); else setAngle(value); };
  const toggleFavorite = () => {
    setFavoriteIds((current) => {
      const next = new Set(current);
      if (next.has(selected.id)) next.delete(selected.id);
      else next.add(selected.id);
      return next;
    });
  };
  const setShapeMode = (mode: "solid" | "wireframe" | "transparent") => {
    recordHistory();
    if (mode === "wireframe") {
      setWireframe(true);
      setFillMode("outline");
      return;
    }
    setWireframe(false);
    setFillMode(mode === "transparent" ? "gradient" : "solid");
  };
  const activeShapeMode = wireframe || fillMode === "outline" ? "wireframe" : fillMode === "solid" ? "solid" : "transparent";
  const exportSummary = () => downloadTextFile(`${selected.name.toLowerCase().replace(/\s+/g, "-")}-shape-summary.txt`, `${selected.name}\n${selected.description}\nFormula: ${selected.formula}\nSymbols: ${symbolSummary(selected.id, a, b, c, sides, angle)}\nMetrics:\n${Object.entries(metrics).map(([label, value]) => `${label}: ${roundTo(value, 3)}`).join("\n")}`);
  const metricPower = (label: string) => label.toLowerCase().includes("volume") ? 3 : /area|surface/.test(label.toLowerCase()) ? 2 : 1;
  const converted = (value: number, label: string) => roundTo(value * unitScale[unit] ** metricPower(label), precision);
  const metricUnit = (label: string) => {
    const exponent = metricPower(label);
    const base = unit === "units" ? "u" : unit;
    return exponent === 3 ? `${base}³` : exponent === 2 ? `${base}²` : base;
  };
  const toggleCompare = (id: ShapeId) => setCompareIds((current) => current.includes(id) ? current.filter((item) => item !== id) : current.length < 4 ? [...current, id] : [...current.slice(1), id]);
  const shapePayload = createMathWorkspacePayload({
    sourceWorkspace: "shapes",
    objectType: "shape",
    label: selected.name,
    value: selected.formula,
    metadata: { shapeId: selected.id, dimension: selected.kind },
  });
  const openMobileInspector = () => { setMobileInspectorSize("half"); setMobileInspectorOpen(true); };
  const closeMobileInspector = () => setMobileInspectorOpen(false);
  const finishInspectorDrag = (event: PointerEvent<HTMLElement>) => {
    const drag = inspectorDragRef.current;
    if (!drag) return;
    const delta = event.clientY - drag.y;
    inspectorDragRef.current = null;
    if (delta > 90) {
      if (drag.size === "full") setMobileInspectorSize("half");
      else closeMobileInspector();
    } else if (delta < -90) setMobileInspectorSize("full");
  };

  return (
    <div data-shapes-theme={theme} className={`shapes-studio-shell ${mobileInspectorOpen ? "has-mobile-inspector" : ""} ${highContrast ? "is-high-contrast" : ""} ${largeLabels ? "has-large-labels" : ""}`} onPointerDown={() => markTopicInteracted("shapes")}>
      <header className="shapes-studio-topbar">
        <div className="shapes-title-lockup">
          <button type="button" className="shapes-icon-button" onClick={() => setShapeMenuCollapsed((value) => !value)} title="Toggle shape library">
            {shapeMenuCollapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </button>
          <h1>2D &amp; 3D Shapes Explorer</h1>
        </div>
        <nav className="shapes-mode-tabs" aria-label="Explorer modes">
          {(["Explore", "Properties", "Formulas", "Compare", "Learn", "In Simple words"] as const).map((tab) => (
            <button key={tab} type="button" className={studioTab === tab ? "is-active" : ""} onClick={() => {
              setStudioTab(tab);
              if (tab === "Properties") setDockTab("Net & Cross-Sections");
              else if (tab === "Formulas") setDockTab("Formula Map");
              else if (tab === "Explore") setDockTab("Live Values");
            }}>{tab}</button>
          ))}
        </nav>
        <div className="shapes-mobile-quick-actions"><WorkspaceChromeThemeToggle theme={theme==="dark"?"default":theme} storageKey="math-universe-shapes-theme" onChange={next=>setTheme(next==="default"?"dark":next)}/><button type="button" className="shapes-icon-button" onClick={() => setExportOpen(true)} aria-label="Export shape"><Download className="h-4 w-4" /></button><button type="button" className="shapes-icon-button" onClick={() => setSettingsOpen(true)} aria-label="Workspace settings"><Settings className="h-4 w-4" /></button><button ref={inspectorTriggerRef} type="button" className="shapes-mobile-properties shapes-icon-button" onClick={openMobileInspector} aria-haspopup="dialog" aria-expanded={mobileInspectorOpen}><SlidersHorizontal className="h-4 w-4" /><span>Properties</span></button></div>
        <div className="shapes-top-actions">
          <button type="button" className="shapes-toolbar-button" onClick={undoShape} disabled={!historyStack.length} title="Undo"><Undo2 className="h-4 w-4" /></button>
          <button type="button" className="shapes-toolbar-button" onClick={redoShape} disabled={!redoStack.length} title="Redo"><Redo2 className="h-4 w-4" /></button>
          <button type="button" className={favoriteIds.has(selected.id) ? "shapes-toolbar-button is-active" : "shapes-toolbar-button"} onClick={toggleFavorite}><Star className="h-4 w-4" />Favourite</button>
          <button type="button" className="shapes-toolbar-button" onClick={resetView}><RefreshCw className="h-4 w-4" />Reset</button>
          <button type="button" className="shapes-toolbar-button" onClick={() => setExportOpen(true)}><Download className="h-4 w-4" />Export</button>
          <WorkspaceChromeThemeToggle theme={theme==="dark"?"default":theme} storageKey="math-universe-shapes-theme" onChange={next=>setTheme(next==="default"?"dark":next)}/>
          <button type="button" className="shapes-toolbar-button" onClick={() => setSettingsOpen(true)}><Settings className="h-4 w-4" />Settings</button>
        </div>
      </header>

      <aside className={`shapes-library-panel ${shapeMenuCollapsed ? "is-collapsed" : ""}`}>
        <div className="shapes-panel-heading"><h2>Shape Library</h2><span>{shapes.length}</span></div>
        <label className="shapes-search-box"><Search className="h-4 w-4" /><input value={shapeSearch} onChange={(event) => setShapeSearch(event.target.value)} placeholder="Search 2D & 3D shapes" /></label>
        <div className="shapes-filter-row">
          {(["All", "2d", "3d"] as const).map((filter) => (
            <button key={filter} type="button" className={libraryFilter === filter ? "is-active" : ""} onClick={() => setLibraryFilter(filter)}>{filter === "All" ? "All" : filter.toUpperCase()}</button>
          ))}
        </div>
        <div className="shapes-library-advanced">
          <button type="button" className={favoritesOnly ? "is-active" : ""} onClick={() => setFavoritesOnly((value) => !value)}><Star />Favorites</button>
          <label><Filter /><select aria-label="Shape property filter" value={advancedFilter} onChange={(event) => setAdvancedFilter(event.target.value as typeof advancedFilter)}><option value="all">All properties</option><option value="curved">Curved</option><option value="polygon">Polygons</option><option value="solid">Solids</option></select></label>
          <label><SlidersHorizontal /><select aria-label="Sort shapes" value={shapeSort} onChange={(event) => setShapeSort(event.target.value as ShapeSort)}><option value="name">Name</option><option value="dimension">2D / 3D</option><option value="complexity">Complexity</option><option value="vertices">Vertices</option></select></label>
        </div>
        <div className="shapes-library-breadcrumb"><span>{selected.category}</span><ChevronDown /><strong>{selected.name}</strong></div>
        {!!recentIds.length && <div className="shapes-recent-row"><span><History />Recent</span>{recentIds.slice(0, 5).map((id) => { const shape = shapeById(shapes, id); return <button type="button" key={id} title={shape.name} onClick={() => selectShape(shape)}><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="compact" decorative /></button>; })}</div>}
        <div className="shapes-library-list">
          {filteredGroupedShapes.map(({ category, shapes: categoryShapes }) => {
            const open = expandedCategories.has(category);
            return (
              <section key={category} className="shapes-library-group">
                <button type="button" onClick={() => toggleCategory(category)} className="shapes-library-group-toggle"><span>{category}</span><span>{open ? "⌄" : "›"}</span></button>
                {open && categoryShapes.map((shape) => {
                  const active = selected.id === shape.id;
                  return (
                    <button key={shape.id} type="button" className={`shapes-library-item ${active ? "is-active" : ""}`} onClick={() => { selectShape(shape); if (window.innerWidth <= 900) setShapeMenuCollapsed(true); }}>
                      <ShapeThumbnail src={shape.thumbnail} name={shape.name} size="small" selected={active} decorative />
                      <span>{shape.name}</span>
                      <span className={compareIds.includes(shape.id) ? "shapes-compare-pin is-active" : "shapes-compare-pin"} role="button" tabIndex={0} aria-label={`${compareIds.includes(shape.id) ? "Remove" : "Add"} ${shape.name} ${compareIds.includes(shape.id) ? "from" : "to"} comparison`} onClick={(event) => { event.stopPropagation(); toggleCompare(shape.id); }} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); event.stopPropagation(); toggleCompare(shape.id); } }}><Check /></span>
                    </button>
                  );
                })}
              </section>
            );
          })}
        </div>
        {!filteredGroupedShapes.length && <div className="shapes-empty-state"><Search /><strong>No shapes found</strong><span>Clear filters or try a broader property.</span><button type="button" onClick={() => { setShapeSearch(""); setLibraryFilter("All"); setAdvancedFilter("all"); setFavoritesOnly(false); }}>Clear filters</button></div>}
      </aside>

      <main className="shapes-workbench">
        {studioTab === "Compare" ? <ShapeCompareWorkspace shapeIds={compareIds} selectedId={selected.id} onToggle={toggleCompare} onSelect={selectShape} a={a} b={b} c={c} sides={sides} angle={angle} precision={precision} unit={unit} /> : studioTab === "Learn" ? <ShapeLearnWorkspace shape={selected} metrics={metrics} step={learnStep} onStep={setLearnStep} onOpenInspector={() => { setInspectorTab("Properties"); openMobileInspector(); }} /> : studioTab === "In Simple words" ? (
          <section className="shapes-simple-words" aria-label={`${selected.name} in simple words`}>
            <span className="shapes-simple-words__eyebrow">IN SIMPLE WORDS</span>
            <h2>{selected.name}</h2>
            <p>{selected.description} You can see this shape in {selected.use.charAt(0).toLowerCase() + selected.use.slice(1)}</p>
          </section>
        ) : (
        <>
        <section className="shapes-viewport-card">
          <div className="shapes-viewport-toolbar">
            <div className="shapes-segmented-control">
              {(["2d", "3d"] as ShapeKind[]).map((tab) => <button key={tab} type="button" className={viewTab === tab ? "is-active" : ""} onClick={() => setViewTab(tab)}>{tab === "2d" ? "2D view" : "3D view"}</button>)}
            </div>
            <div className="shapes-segmented-control">
              {(["solid", "wireframe", "transparent"] as const).map((mode) => <button key={mode} type="button" className={activeShapeMode === mode ? "is-active" : ""} onClick={() => setShapeMode(mode)}>{mode}</button>)}
            </div>
            <div className="shapes-viewport-actions">
              <button type="button" className="shapes-icon-button" onClick={zoomOut} title="Zoom out"><ZoomOut className="h-4 w-4" /></button>
              <button type="button" className="shapes-icon-button" onClick={zoomIn} title="Zoom in"><ZoomIn className="h-4 w-4" /></button>
              <button type="button" className="shapes-icon-button" onClick={resetView} title="Fit view"><RefreshCw className="h-4 w-4" /></button>
            </div>
          </div>
          <div className={`shapes-stage ${snapToGrid ? "is-snapping" : ""}`} style={{ minHeight: Math.min(stageHeight, 520), backgroundSize: showGrid ? `${28 * gridSpacing}px ${28 * gridSpacing}px, ${28 * gridSpacing}px ${28 * gridSpacing}px, 100% 100%, 100% 100%` : "100% 100%, 100% 100%" }}>
            <div className="shapes-axis-cube" aria-hidden="true"><span>TOP</span><span>LEFT</span><span>FRONT</span></div>
            {showAxes && <div className="shapes-coordinate-axes" aria-hidden="true"><i /><b /><span>x</span><em>y</em></div>}
            {viewTab === "2d" ? (
              <InteractiveShape2D resetKey={`${selected.id}-${viewResetNonce}`} onZoomIn={zoomIn} onZoomOut={zoomOut}>
                <ShapeSvg shape={selected.id} a={a} b={b} c={c} sides={sides} angle={angle} zoom={viewZoom} rotation={viewRotation} fillMode={fillMode} colorA={colorA} colorB={colorB} glow={shapeGlow} />
              </InteractiveShape2D>
            ) : (
              <ThreeSceneWrapper height="100%" mobileHeight="100%" interactionLabel="Drag to rotate - wheel or pinch to zoom" sceneSummary={`${selected.name}. ${selected.description}. ${symbolSummary(selected.id, a, b, c, sides, angle)}.`}>
                <ambientLight intensity={0.9} />
                <directionalLight position={[4, 5, 4]} intensity={1.45} />
                <directionalLight position={[-3, 1, -2]} intensity={0.7} color={colorB} />
                <pointLight position={[0, -3, 3]} intensity={shapeGlow ? 1.1 : 0.35} color={colorA} />
                <RotatingSolid shape={selected.id} a={a} b={b} c={c} angle={angle} wireframe={wireframe} zoom={viewZoom} rotation={viewRotation} autoRotate={autoRotate && !reducedMotion} sides={sides} fillMode={fillMode} colorA={colorA} colorB={colorB} glow={shapeGlow} />
                <OrbitControls enablePan enableZoom enableDamping />
              </ThreeSceneWrapper>
            )}
            {showLabels && <div className="shapes-stage-labels"><span>{symbolSummary(selected.id, a, b, c, sides, angle)}</span><span>{selected.category}</span></div>}
            <div aria-label="Direct dimension handles" style={{ position: "absolute", top: 72, right: 12, zIndex: 5, display: "grid", gap: 6, padding: 10, maxWidth: 190, borderRadius: 12, background: "rgba(15,23,42,.86)", color: "white", fontSize: 12 }}>
              <label>{primaryLabel(selected)}: {a.toFixed(1)}<input aria-label={`Drag ${primaryLabel(selected)} dimension`} type="range" min="0.5" max="10" step="0.1" value={a} onChange={(event) => { const value = Number(event.target.value); setDimension("a", value); if (lockProportions && needsSecond(selected.id)) setB(value); }} /></label>
              {needsSecond(selected.id) && <label>{secondLabel(selected)}: {b.toFixed(1)}<input aria-label={`Drag ${secondLabel(selected)} dimension`} type="range" min={secondRange.min} max={secondRange.max} step="0.1" value={b} onChange={(event) => setDimension("b", Number(event.target.value))} /></label>}
              {needsThird(selected.id) && <label>{thirdLabel(selected)}: {c.toFixed(1)}<input aria-label={`Drag ${thirdLabel(selected)} dimension`} type="range" min={thirdRange.min} max={thirdRange.max} step="0.1" value={c} onChange={(event) => setDimension("c", Number(event.target.value))} /></label>}
            </div>
            <div className="shapes-floating-controls">
              <button type="button" className={toolMode === "rotate" ? "is-active" : ""} onClick={() => { setToolMode("rotate"); setAutoRotate((value) => !value); }}><RotateCw className="h-4 w-4" />Rotate</button>
              <button type="button" className={toolMode === "pan" ? "is-active" : ""} onClick={() => setToolMode("pan")}><Eye className="h-4 w-4" />Pan</button>
              <button type="button" className={toolMode === "measure" ? "is-active" : ""} onClick={() => setToolMode("measure")}><Ruler className="h-4 w-4" />Measure</button>
              <button type="button" className={toolMode === "grid" ? "is-active" : ""} onClick={() => { setToolMode("grid"); setShowGrid((value) => !value); }}><Grid3X3 className="h-4 w-4" />Grid</button>
              <button type="button" onClick={resetView}><RefreshCw className="h-4 w-4" />Reset view</button>
            </div>
            {toolMode === "measure" && <ShapeMeasurementOverlay shape={selected} metrics={metrics} unit={unit} precision={precision} />}
            {toolMode === "grid" && <div className="shapes-grid-popover"><label>Spacing<input type="number" min="0.25" max="5" step="0.25" value={gridSpacing} onChange={(event) => setGridSpacing(Number(event.target.value))} /></label><label><input type="checkbox" checked={snapToGrid} onChange={(event) => setSnapToGrid(event.target.checked)} />Snap</label><label><input type="checkbox" checked={showAxes} onChange={(event) => setShowAxes(event.target.checked)} />Axes</label></div>}
          </div>
          <div role="separator" aria-label="Resize visualization height" onPointerDown={(event) => startHeightResize(event, stageHeight, setStageHeight)} className="shapes-resize-handle"><span /></div>
        </section>
        </>
        )}
      </main>

      {mobileInspectorOpen && <button type="button" className="shapes-mobile-sheet-backdrop" onClick={closeMobileInspector} aria-label="Close shape properties" />}
      <aside ref={inspectorRef} tabIndex={mobileInspectorOpen ? -1 : undefined} role={mobileInspectorOpen ? "dialog" : undefined} aria-modal={mobileInspectorOpen ? true : undefined} aria-label={mobileInspectorOpen ? `${selected.name} properties` : undefined} className={`shapes-inspector-panel mobile-sheet-${mobileInspectorSize}`}>
        <button type="button" className="shapes-mobile-sheet-drag" aria-label={`${mobileInspectorSize === "half" ? "Expand" : "Collapse"} properties sheet`} onClick={() => setMobileInspectorSize((size) => size === "half" ? "full" : "half")} onPointerDown={(event) => { inspectorDragRef.current = { y: event.clientY, size: mobileInspectorSize }; event.currentTarget.setPointerCapture(event.pointerId); }} onPointerUp={finishInspectorDrag}><span /></button>
        <button type="button" className="shapes-mobile-sheet-close" onClick={closeMobileInspector}>Close properties</button>
        <section className="shapes-bottom-dock">
          <div className="shapes-dock-tabs">
            {(["Live Values", "Net & Cross-Sections", "Formula Map"] as const).map((tab) => (
              <button key={tab} type="button" className={dockTab === tab ? "is-active" : ""} onClick={() => setDockTab(tab)}>{tab}</button>
            ))}
            <span className="shapes-live-status">Updates live</span>
          </div>
          {dockTab === "Live Values" && <div className="shapes-dock-grid">{Object.entries(metrics).slice(0, 6).map(([label, value]) => <Metric key={label} label={label} value={converted(value, label)} suffix={metricUnit(label)} />)}</div>}
          {dockTab === "Net & Cross-Sections" && <div className="shapes-net-strip"><NetExplorer shape={selected.id} paint={surfacePaint} progress={netProgress} a={a} b={b} c={c} /><div className="shapes-net-controls"><SliderControl density="compact" label="Fold / unfold" value={netProgress} min={0} max={100} step={5} onChange={setNetProgress} unit="%" /><SliderControl density="compact" label="Surface paint" value={surfacePaint} min={0} max={100} step={5} onChange={setSurfacePaint} unit="%" /><button type="button" onClick={() => setNetProgress(0)}>Reset net</button></div><ShapeCrossSectionControls shape={selected} axis={sliceAxis} position={slicePosition} angle={sliceAngle} onAxis={setSliceAxis} onPosition={setSlicePosition} onAngle={setSliceAngle} /></div>}
          {dockTab === "Formula Map" && <FormulaDependencyPanel shape={selected} entries={formulaEntries} highlighted={highlightedSymbol} onHighlight={setHighlightedSymbol} />}
        </section>
        <section className="shapes-inspector-card is-primary">
          <div className="shapes-panel-heading"><h2>Shape Inspector</h2><span>i</span></div>
          <div className="shapes-inspector-tabs">{(["Dimensions", "Formulas", "Properties"] as const).map((tab) => <button key={tab} type="button" className={inspectorTab === tab ? "is-active" : ""} onClick={() => setInspectorTab(tab)}>{tab}</button>)}</div>
          <div className="shapes-selected-summary"><MiniShape id={selected.id} size="large" /><div><h3>{selected.name}</h3><p>{selected.description}</p></div></div>
          {inspectorTab === "Dimensions" && (
            <>
              <SliderGroup title="">
                <PreciseDimensionControl label={primaryLabel(selected)} value={a} min={0.5} max={10} step={0.1} unit={unit} highlighted={Boolean(highlightedSymbol)} onChange={(value) => { setDimension("a", value); if (lockProportions && needsSecond(selected.id)) setB(value); }} />
                {needsSecond(selected.id) && <PreciseDimensionControl label={secondLabel(selected)} value={b} min={secondRange.min} max={secondRange.max} step={0.1} unit={unit} highlighted={Boolean(highlightedSymbol)} onChange={(value) => setDimension("b", value)} />}
                {needsThird(selected.id) && <PreciseDimensionControl label={thirdLabel(selected)} value={c} min={thirdRange.min} max={thirdRange.max} step={0.1} unit={unit} highlighted={Boolean(highlightedSymbol)} onChange={(value) => setDimension("c", value)} />}
                {selected.id === "regular-polygon" && <PreciseDimensionControl label="Number of sides" value={sides} min={3} max={12} step={1} unit="units" highlighted={highlightedSymbol === "n"} onChange={(value) => setDimension("sides", value)} />}
                {(selected.id === "sector" || selected.id === "segment") && <PreciseDimensionControl label="Central angle" value={angle} min={5} max={360} step={1} unit="units" highlighted={highlightedSymbol === "theta"} onChange={(value) => setDimension("angle", value)} suffix="°" />}
              </SliderGroup>
              <div className="shapes-toggle-list">
                <label><input type="checkbox" checked={lockProportions} onChange={(event) => setLockProportions(event.target.checked)} />Lock proportions</label>
                <label><input type="checkbox" checked={showLabels} onChange={(event) => setShowLabels(event.target.checked)} />Show labels</label>
                <label><input type="checkbox" checked={shapeGlow} onChange={() => { recordHistory(); setShapeGlow((value) => !value); }} />Glow model</label>
              </div>
            </>
          )}
          {inspectorTab === "Formulas" && <div className="shapes-formula-stack">{formulaEntries.map((entry) => <FormulaMapCard key={entry.title} entry={entry} metrics={metrics} compact />)}</div>}
          {inspectorTab === "Properties" && <div className="shapes-property-stack"><InfoTile label="Dimensions" value={selected.dimensions.join(", ")} /><InfoTile label="Current symbols" value={symbolSummary(selected.id, a, b, c, sides, angle)} /><InfoTile label="Used in" value={selected.use} /><ShapeLearningGuide shape={selected} /></div>}
          <div className="shapes-structure-grid"><Metric label="Faces" value={structure.faces} /><Metric label="Edges" value={structure.edges} /><Metric label="Vertices" value={structure.vertices} /></div>
        </section>
        <section className="shapes-inspector-card shapes-formulas-card"><div className="shapes-panel-heading"><h2>{selected.name} formulas</h2><span>{formulaEntries.length}</span></div><div className="shapes-formulas-list">{formulaEntries.map((entry) => <article key={entry.title} className="shapes-formula-entry"><div><strong>{entry.title}</strong>{entry.valueLabel && Number.isFinite(metrics[entry.valueLabel]) && <span>{converted(metrics[entry.valueLabel], entry.valueLabel)} {metricUnit(entry.valueLabel)}</span>}</div><p>{readableShapeFormula(entry.formula)}</p><small>{entry.note}</small></article>)}</div><p className="shapes-explanation">{formulaExplanation(selected.id, a, b, c, sides, angle)}</p><div className="shapes-open-in-actions"><ContextualWorkspaceLink target="cas" payload={shapePayload}>Open formula in CAS</ContextualWorkspaceLink><ContextualWorkspaceLink target={selected.kind === "3d" ? "geometry-3d" : "geometry"} payload={shapePayload}>Open in {selected.kind === "3d" ? "3D Geometry" : "Geometry"}</ContextualWorkspaceLink></div></section>
        <section className="shapes-inspector-card shapes-related-card"><div className="shapes-panel-heading"><h2>Related Shapes</h2><span>{familyShapes.length}</span></div><div className="shapes-related-grid">{familyShapes.map((shape) => <button key={shape.id} type="button" onClick={() => selectShape(shape)}><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="large" decorative /><span>{shape.name}</span></button>)}</div></section>
      </aside>

      <footer className="shapes-status-bar"><span className="is-online">Offline</span><span>{viewTab === "3d" ? "Interactive model" : "Planar model"}</span><span>Exact formulas</span><span>Saved</span></footer>
      {settingsOpen && <ShapeSettingsDialog theme={theme} unit={unit} precision={precision} highContrast={highContrast} largeLabels={largeLabels} colorblind={colorblindPalette} reducedMotion={reducedMotion} onTheme={setTheme} onUnit={setUnit} onPrecision={setPrecision} onHighContrast={setHighContrast} onLargeLabels={setLargeLabels} onColorblind={(value) => { setColorblindPalette(value); if (value) { setColorA("#0072b2"); setColorB("#f0e442"); } }} onClose={() => setSettingsOpen(false)} />}
      {exportOpen && <ShapeExportDialog shape={selected} metrics={metrics} summary={exportSummary} onClose={() => setExportOpen(false)} />}
    </div>
  );

  return (
    <div className="space-y-6" onPointerDown={() => markTopicInteracted("shapes")}>
      <TopicHeader
        title="2D and 3D Shapes Explorer"
        subtitle="Explore common plane figures and solid shapes visually with formulas, dimensions, surface area, volume, perimeter, and real-world uses."
        difficulty="Foundational"
        estimatedMinutes={35}
      />
      <SectionCard title="Shapes Explorer" description="Use the left menu to choose a 2D shape or 3D object. The selected object opens on the right with live controls.">
        <div className={shapeMenuCollapsed ? "grid gap-4 xl:grid-cols-[minmax(0,1fr)_300px]" : "grid gap-4 xl:grid-cols-[300px_minmax(0,1fr)_300px]"}>
          {shapeMenuCollapsed ? (
            <button
              type="button"
              onClick={() => setShapeMenuCollapsed(false)}
              className="flex min-h-20 w-full items-center justify-between gap-4 rounded-xl border border-cyan-300 bg-cyan-50 px-5 py-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:bg-cyan-100 hover:shadow-md dark:border-cyan-300/30 dark:bg-cyan-300/10 dark:hover:bg-cyan-300/15"
            >
              <span className="flex min-w-0 items-center gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-cyan-500 text-white shadow-lg shadow-cyan-500/25">
                  <PanelLeftOpen className="h-6 w-6" />
                </span>
                <span className="min-w-0">
                  <span className="block text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">Main menu hidden</span>
                  <span className="block text-lg font-black text-slate-950 dark:text-white">Expand Main Menu</span>
                </span>
              </span>
              <span className="mini-chip">show shapes</span>
            </button>
          ) : (
            <ShapeSelectorMenu
              groupedShapes={groupedShapes}
              selectedId={selected.id}
              expandedCategories={expandedCategories}
              onToggleCategory={toggleCategory}
              onSelect={selectShape}
              onCollapse={() => setShapeMenuCollapsed(true)}
            />
          )}
          <div className="min-w-0 rounded-2xl border border-cyan-200/80 bg-gradient-to-br from-white via-cyan-50/45 to-violet-50/70 p-3 shadow-sm dark:border-cyan-300/15 dark:from-slate-950 dark:via-cyan-950/25 dark:to-violet-950/25">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">{selected.category}</p>
                <h2 className="mt-1 text-xl font-black">{selected.name}</h2>
                <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{selected.description}</p>
              </div>
              <span className="mini-chip">{selected.kind === "3d" ? "3D object" : "2D shape"}</span>
            </div>
            <div className="mt-4 flex rounded-xl bg-white/80 p-1 shadow-sm dark:bg-slate-950/60" role="tablist" aria-label="Shape view">
              {(["2d", "3d"] as ShapeKind[]).map((tab) => (
                <button key={tab} type="button" role="tab" aria-label={tab === "2d" ? "2D Pane" : "3D Pane"} aria-selected={viewTab === tab} onClick={() => setViewTab(tab)} className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-black transition ${viewTab === tab ? "bg-gradient-to-r from-cyan-500 to-violet-500 text-white shadow-md" : "text-slate-600 hover:bg-cyan-50 dark:text-slate-300 dark:hover:bg-white/10"}`}>
                  {tab === "2d" ? "2D view" : selected.kind === "2d" ? "3D extrusion" : "3D solid"}
                </button>
              ))}
            </div>
            <div className="mt-3">
              <ShapeViewControls kind={selected.kind} zoom={viewZoom} rotation={viewRotation} autoRotate={autoRotate} onZoomIn={zoomIn} onZoomOut={zoomOut} onRotateLeft={rotateLeft} onRotateRight={rotateRight} onReset={resetView} onToggleAutoRotate={() => setAutoRotate((value) => !value)} />
            </div>
            <div
              className="relative mt-3 overflow-hidden rounded-2xl border border-cyan-400/25 shadow-[inset_0_0_80px_rgba(34,211,238,0.08),0_0_35px_rgba(139,92,246,0.12)]"
              style={{
                height: stageHeight,
                backgroundColor: "#030712",
                backgroundImage: showGrid
                  ? "linear-gradient(rgba(34,211,238,.09) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,.09) 1px, transparent 1px), radial-gradient(circle at 50% 45%, rgba(124,58,237,.28), transparent 48%), radial-gradient(circle at 20% 15%, rgba(6,182,212,.18), transparent 38%)"
                  : "radial-gradient(circle at 50% 45%, rgba(124,58,237,.3), transparent 48%), radial-gradient(circle at 20% 15%, rgba(6,182,212,.2), transparent 38%)",
                backgroundSize: showGrid ? "28px 28px, 28px 28px, 100% 100%, 100% 100%" : "100% 100%, 100% 100%",
              }}
            >
              {viewTab === "2d" ? (
                <InteractiveShape2D resetKey={`${selected.id}-${viewResetNonce}`} onZoomIn={zoomIn} onZoomOut={zoomOut}>
                  <ShapeSvg shape={selected.id} a={a} b={b} c={c} sides={sides} angle={angle} zoom={viewZoom} rotation={viewRotation} fillMode={fillMode} colorA={colorA} colorB={colorB} glow={shapeGlow} />
                </InteractiveShape2D>
              ) : (
                <ThreeSceneWrapper height="100%" mobileHeight="100%" interactionLabel="Drag to rotate - wheel or pinch to zoom">
                  <ambientLight intensity={0.9} />
                  <directionalLight position={[4, 5, 4]} intensity={1.45} />
                  <directionalLight position={[-3, 1, -2]} intensity={0.7} color={colorB} />
                  <pointLight position={[0, -3, 3]} intensity={shapeGlow ? 1.1 : 0.35} color={colorA} />
                  <RotatingSolid shape={selected.id} a={a} b={b} c={c} angle={angle} wireframe={wireframe} zoom={viewZoom} rotation={viewRotation} autoRotate={autoRotate} sides={sides} fillMode={fillMode} colorA={colorA} colorB={colorB} glow={shapeGlow} />
                  <OrbitControls enablePan enableZoom enableDamping />
                </ThreeSceneWrapper>
              )}
              <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-slate-950/75 px-3 py-1.5 text-xs font-bold text-white backdrop-blur">
                {viewTab === "2d" ? "Drag to move · wheel to zoom" : "Drag to rotate · pinch to zoom"}
              </div>
            </div>
            <div role="separator" aria-label="Resize visualization height" onPointerDown={(event) => startHeightResize(event, stageHeight, setStageHeight)} className="mx-auto mt-2 flex h-5 w-32 cursor-row-resize items-center justify-center rounded-full text-slate-400 transition hover:bg-cyan-100 hover:text-cyan-600 dark:hover:bg-cyan-300/10"><span className="h-1 w-12 rounded-full bg-current" /></div>
          </div>

          <aside className="space-y-3 rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-slate-950/45">
            <div className="rounded-xl bg-gradient-to-r from-cyan-500/10 to-violet-500/10 p-3">
              <p className="text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">Formula</p>
              <p className="mt-2 overflow-x-auto text-sm font-bold"><MathExpression value={selected.formula} /></p>
            </div>
            <ShapeAppearanceControls fillMode={fillMode} onFillMode={setFillMode} colorA={colorA} colorB={colorB} onColorA={setColorA} onColorB={setColorB} glow={shapeGlow} onGlow={() => setShapeGlow((value) => !value)} grid={showGrid} onGrid={() => setShowGrid((value) => !value)} />
            <SliderGroup title="Shape controls">
              <SliderControl density="compact" label={primaryLabel(selected)} value={a} min={0.5} max={10} step={0.1} onChange={setA} />
              {needsSecond(selected.id) && <SliderControl density="compact" label={secondLabel(selected)} value={b} min={secondRange.min} max={secondRange.max} step={0.1} onChange={setB} />}
              {needsThird(selected.id) && <SliderControl density="compact" label={thirdLabel(selected)} value={c} min={thirdRange.min} max={thirdRange.max} step={0.1} onChange={setC} />}
              {selected.id === "regular-polygon" && <SliderControl density="compact" label="Number of sides" value={sides} min={3} max={12} step={1} onChange={(value) => setSides(Math.round(value))} />}
              {(selected.id === "sector" || selected.id === "segment") && <SliderControl density="compact" label="Central angle" value={angle} min={5} max={360} step={1} onChange={setAngle} unit="deg" />}
            </SliderGroup>
            {selected.kind === "3d" && (
              <label className="flex items-center gap-3 rounded-xl bg-slate-100 p-3 text-sm font-semibold dark:bg-white/10">
                <input type="checkbox" checked={wireframe} onChange={(event) => setWireframe(event.target.checked)} />
                Wireframe
              </label>
            )}
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(metrics).map(([label, value]) => <Metric key={label} label={label} value={value} />)}
            </div>
            <div className="space-y-2">
              <InfoTile label="Dimensions" value={selected.dimensions.join(", ")} />
              <InfoTile label="Current symbols" value={symbolSummary(selected.id, a, b, c, sides, angle)} />
              <InfoTile label="Used in" value={selected.use} />
            </div>
            <p className="rounded-xl bg-cyan-50 p-3 text-xs leading-5 text-slate-600 dark:bg-cyan-300/10 dark:text-slate-300">{formulaExplanation(selected.id, a, b, c, sides, angle)}</p>
            <ShapeLearningGuide shape={selected} />
          </aside>
        </div>
      </SectionCard>

      <FormulaMapSection selected={selected} metrics={metrics} shapes={shapes} onSelect={selectShape} />
    </div>
  );
}

function FormulaMapSection({ selected, metrics, shapes, onSelect }: { selected: ShapeDefinition; metrics: Metrics; shapes: ShapeDefinition[]; onSelect: (shape: ShapeDefinition) => void }) {
  const selectedFormulaEntries = useMemo(() => getShapeFormulaEntries(selected.id), [selected.id]);
  const familyShapes = useMemo(() => shapes.filter((shape) => shape.category === selected.category && shape.id !== selected.id).slice(0, 8), [selected.category, selected.id, shapes]);
  const relatedEntries = useMemo(() => getRelatedFormulaEntries(selected), [selected]);
  const formulaCount = selectedFormulaEntries.length + relatedEntries.length;

  return (
    <SectionCard
      title="Formula Map"
      description={`Showing ${formulaCount} formulas related to the selected ${selected.kind === "3d" ? "3D object" : "shape"}: ${selected.name}.`}
      headerAction={<span className="mini-chip">{selected.kind === "3d" ? "3D object" : "2D shape"}</span>}
    >
      <div className="mb-4 rounded-2xl border border-violet-200 bg-gradient-to-r from-cyan-50 via-white to-violet-50 p-4 dark:border-violet-300/15 dark:from-cyan-950/25 dark:via-slate-950/40 dark:to-violet-950/25">
        <p className="text-xs font-black uppercase tracking-wide text-violet-700 dark:text-violet-200">Common formulas · same rule, many shapes</p>
        <div className="mt-3 grid gap-3 md:grid-cols-3">
          <FormulaMapCard entry={{ title: "Any triangle", formula: "A=1/2 bh", note: "Right, acute, obtuse, equilateral, isosceles, or scalene: use a base and its perpendicular height." }} metrics={{}} compact />
          <FormulaMapCard entry={{ title: "Any prism", formula: "V=BL", note: "Multiply the area B of the end face by the prism length L." }} metrics={{}} compact />
          <FormulaMapCard entry={{ title: "Any pyramid or cone", formula: "V=1/3 Bh", note: "One third of the matching prism or cylinder with the same base and height." }} metrics={{}} compact />
        </div>
      </div>
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
        <div className="space-y-4">
          <div className="rounded-xl border border-cyan-200 bg-cyan-50/80 p-4 dark:border-cyan-400/20 dark:bg-cyan-400/10">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">Selected formula family</p>
                <h3 className="mt-1 text-lg font-black text-slate-950 dark:text-white">{selected.name}</h3>
                <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-300">{selected.description}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <span className="mini-chip">{selected.category}</span>
                <span className="mini-chip">{selected.dimensions.join(", ")}</span>
              </div>
            </div>
            <p className="mt-3 rounded-lg bg-white/80 p-3 text-sm font-bold text-slate-800 dark:bg-slate-950/50 dark:text-cyan-50"><MathExpression value={selected.formula} /></p>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            {selectedFormulaEntries.map((entry) => (
              <FormulaMapCard key={entry.title} entry={entry} metrics={metrics} />
            ))}
          </div>

          {relatedEntries.length > 0 && (
            <div className="rounded-xl border border-slate-200 bg-white/70 p-3 dark:border-white/10 dark:bg-white/5">
              <p className="text-xs font-black uppercase text-slate-500 dark:text-slate-400">Related formulas</p>
              <div className="mt-3 grid gap-3 md:grid-cols-2">
                {relatedEntries.map((entry) => <FormulaMapCard key={entry.title} entry={entry} metrics={metrics} compact />)}
              </div>
            </div>
          )}
        </div>

        <aside className="space-y-3">
          <div className="rounded-xl border border-slate-200 bg-white/75 p-3 dark:border-white/10 dark:bg-white/5">
            <p className="text-xs font-black uppercase text-slate-500 dark:text-slate-400">Live values from selected object</p>
            <div className="mt-3 grid gap-2">
              {Object.entries(metrics).map(([label, value]) => (
                <div key={label} className="flex items-center justify-between gap-3 rounded-lg bg-slate-100 px-3 py-2 text-sm dark:bg-white/10">
                  <span className="font-bold text-slate-600 dark:text-slate-300">{label}</span>
                  <span className="font-mono font-black text-slate-950 dark:text-white">{roundTo(value, 3)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white/75 p-3 dark:border-white/10 dark:bg-white/5">
            <p className="text-xs font-black uppercase text-slate-500 dark:text-slate-400">Same family</p>
            <div className="mt-3 grid gap-2">
              {familyShapes.map((shape) => (
                <button key={shape.id} type="button" onClick={() => onSelect(shape)} className="flex items-center gap-3 rounded-lg border border-transparent bg-slate-100 px-3 py-2 text-left text-sm transition hover:border-cyan-300 hover:bg-cyan-50 dark:bg-white/10 dark:hover:bg-cyan-300/10">
                  <ShapeThumbnail src={shape.thumbnail} name={shape.name} size="medium" decorative />
                  <span className="min-w-0"><span className="block font-bold">{shape.name}</span><span className="mt-1 block truncate text-xs font-semibold text-slate-500 dark:text-slate-400"><MathExpression value={shape.formula} /></span></span>
                </button>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </SectionCard>
  );
}

function FormulaMapCard({ entry, metrics, compact = false }: { entry: ShapeFormulaEntry; metrics: Metrics; compact?: boolean }) {
  const value = entry.valueLabel ? metrics[entry.valueLabel] : undefined;
  return (
    <article className="rounded-xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-slate-950/35">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h4 className="font-black text-slate-950 dark:text-white">{entry.title}</h4>
          <p className="mt-1 text-xs leading-5 text-slate-600 dark:text-slate-300">{entry.note}</p>
        </div>
        {value !== undefined && Number.isFinite(value) && <span className="rounded-lg bg-cyan-100 px-2 py-1 font-mono text-xs font-black text-cyan-900 dark:bg-cyan-300/15 dark:text-cyan-100">{roundTo(value, 3)}</span>}
      </div>
      <p className={`mt-3 rounded-lg bg-slate-100 p-3 font-bold text-slate-800 dark:bg-white/10 dark:text-slate-100 ${compact ? "text-xs leading-5" : "text-sm leading-6"}`}><MathExpression value={entry.formula} /></p>
    </article>
  );
}

function ShapeSelectorMenu({
  groupedShapes,
  selectedId,
  expandedCategories,
  onToggleCategory,
  onSelect,
  onCollapse,
}: {
  groupedShapes: { category: ShapeCategory; shapes: ShapeDefinition[] }[];
  selectedId: ShapeId;
  expandedCategories: Set<ShapeCategory>;
  onToggleCategory: (category: ShapeCategory) => void;
  onSelect: (shape: ShapeDefinition) => void;
  onCollapse: () => void;
}) {
  return (
    <aside className="max-h-[72vh] overflow-auto rounded-xl border border-slate-200 bg-white/85 p-3 dark:border-white/10 dark:bg-slate-950/35">
      <div className="mb-3 space-y-3">
        <button
          type="button"
          onClick={onCollapse}
          className="flex min-h-16 w-full items-center justify-between gap-3 rounded-xl bg-slate-950 px-4 py-3 text-left text-white shadow-lg shadow-slate-950/10 transition hover:-translate-y-0.5 hover:bg-slate-800 dark:bg-cyan-300 dark:text-slate-950 dark:hover:bg-cyan-200"
        >
          <span className="flex min-w-0 items-center gap-3">
            <PanelLeftClose className="h-6 w-6 shrink-0" />
            <span className="min-w-0">
              <span className="block text-xs font-black uppercase opacity-75">Main menu</span>
              <span className="block text-base font-black">Collapse Menu</span>
            </span>
          </span>
          <span className="rounded-full bg-white/15 px-2 py-1 text-xs font-black dark:bg-slate-950/10">hide</span>
        </button>
        <div>
          <p className="text-xs font-black uppercase text-slate-500 dark:text-slate-400">Main menu</p>
          <h3 className="mt-1 text-base font-black">Shape families</h3>
        </div>
      </div>
      <div className="space-y-2">
        {groupedShapes.map(({ category, shapes: categoryShapes }) => {
          const open = expandedCategories.has(category);
          const activeInside = categoryShapes.some((shape) => shape.id === selectedId);
          return (
            <div key={category} className="rounded-lg border border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-white/5">
              <button
                type="button"
                onClick={() => onToggleCategory(category)}
                className={`flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left text-sm font-black transition ${activeInside ? "text-cyan-700 dark:text-cyan-200" : "text-slate-700 dark:text-slate-200"}`}
              >
                <span>{category}</span>
                <span className="rounded-full bg-white px-2 py-0.5 text-xs dark:bg-slate-950">{open ? "-" : "+"}</span>
              </button>
              {open && (
                <div className="border-t border-slate-200 p-2 dark:border-white/10">
                  <p className="mb-2 px-1 text-[11px] font-black uppercase text-slate-400">Sub menu</p>
                  <div className="grid gap-1">
                    {categoryShapes.map((shape) => {
                      const active = shape.id === selectedId;
                      return (
                        <button
                          key={shape.id}
                          type="button"
                          onClick={() => onSelect(shape)}
                          className={`flex min-w-0 items-center gap-2 rounded-md px-2 py-2 text-left text-sm transition ${active ? "bg-cyan-100 text-cyan-950 ring-1 ring-cyan-300 dark:bg-cyan-300/20 dark:text-cyan-50" : "hover:bg-white dark:hover:bg-white/10"}`}
                        >
                          <ShapeThumbnail src={shape.thumbnail} name={shape.name} size="compact" selected={active} decorative />
                          <span className="min-w-0 flex-1 truncate font-bold">{shape.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </aside>
  );
}

type KidMode = "beginner" | "advanced";
type SortMode = "2D/3D" | "sides" | "corners" | "curved edges" | "symmetry" | "faces" | "vertices" | "edges";
type UnitName = "cm" | "m" | "in";
type StudioTab = "Play" | "Build" | "Formula" | "Teacher" | "3D";

const gradeLevels = ["Class 1-2", "Class 3-5", "Class 6-8", "Class 9-10"] as const;
const objectMatches = [
  { object: "Clock", shape: "circle" as ShapeId },
  { object: "Door", shape: "rectangle" as ShapeId },
  { object: "Dice", shape: "cube" as ShapeId },
  { object: "Ice-cream cone", shape: "cone" as ShapeId },
  { object: "Can", shape: "cylinder" as ShapeId },
  { object: "Roof wedge", shape: "triangular-prism" as ShapeId },
  { object: "Washer", shape: "annulus" as ShapeId },
  { object: "Pencil", shape: "hexagonal-prism" as ShapeId },
  { object: "Pill", shape: "capsule" as ShapeId },
];
const questSteps = ["Pick safe playground tiles", "Build a slide ramp", "Choose a tunnel shape", "Paint surface area", "Share the design with teacher"];
const languageLabels = {
  English: { circle: "Circle", square: "Square", triangle: "Triangle", cube: "Cube" },
  Hindi: { circle: "वृत्त", square: "वर्ग", triangle: "त्रिभुज", cube: "घन" },
  Telugu: { circle: "వృత్తం", square: "చదరం", triangle: "త్రిభుజం", cube: "ఘనం" },
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function KidsShapeStudio({ shapes, selected, onSelect }: { shapes: ShapeDefinition[]; selected: ShapeDefinition; onSelect: (shape: ShapeDefinition) => void }) {
  const [mode, setMode] = useState<KidMode>("beginner");
  const [grade, setGrade] = useState<(typeof gradeLevels)[number]>("Class 3-5");
  const [tab, setTab] = useState<StudioTab>("Play");
  const [search, setSearch] = useState("");
  const [sortMode, setSortMode] = useState<SortMode>("2D/3D");
  const [unit, setUnit] = useState<UnitName>("cm");
  const [activeFlashcard, setActiveFlashcard] = useState(0);
  const [matchObject, setMatchObject] = useState(objectMatches[0].object);
  const [matchShape, setMatchShape] = useState<ShapeId>("circle");
  const [favorites, setFavorites] = useState<ShapeId[]>([]);
  const [recent, setRecent] = useState<ShapeId[]>([selected.id]);
  const [score, setScore] = useState(0);
  const [showHints, setShowHints] = useState(true);
  const [timed, setTimed] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const [surfacePaint, setSurfacePaint] = useState(35);
  const [lightAngle, setLightAngle] = useState(35);
  const [sliceLevel, setSliceLevel] = useState(50);
  const [collage, setCollage] = useState<ShapeId[]>(["circle", "triangle", "rectangle"]);
  const [customName, setCustomName] = useState("My rocket");
  const [notes, setNotes] = useState("Ask: Which dimensions changed? Why did the formula change?");

  useEffect(() => {
    setRecent((items) => [selected.id, ...items.filter((item) => item !== selected.id)].slice(0, 6));
  }, [selected.id]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    const matches = shapes.filter((shape) => !query || [shape.name, shape.category, shape.description, shape.formula, shape.use].join(" ").toLowerCase().includes(query));
    return [...matches].sort((left, right) => sortValue(left, sortMode) - sortValue(right, sortMode) || left.name.localeCompare(right.name));
  }, [search, shapes, sortMode]);

  const flashShape = shapes[activeFlashcard % shapes.length];
  const currentMatch = objectMatches.find((item) => item.object === matchObject) ?? objectMatches[0];
  const matchCorrect = currentMatch.shape === matchShape;
  const mastery = Math.min(100, Math.round((favorites.length / Math.max(1, shapes.length)) * 45 + score * 7 + recent.length * 3));
  const metrics = getMetrics(selected.id, 4, 3, 5, 6, 90);
  const unitFactor = unit === "m" ? 0.01 : unit === "in" ? 0.3937 : 1;

  const celebrate = () => {
    setScore((value) => value + 1);
    setConfetti(true);
    playTinySound();
    window.setTimeout(() => setConfetti(false), 900);
  };

  const speak = (text: string) => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
  };

  const toggleFavorite = (shapeId: ShapeId) => setFavorites((items) => items.includes(shapeId) ? items.filter((item) => item !== shapeId) : [...items, shapeId]);
  const selectAndTrack = (shape: ShapeDefinition) => {
    onSelect(shape);
    setRecent((items) => [shape.id, ...items.filter((item) => item !== shape.id)].slice(0, 6));
  };

  const exportCard = () => downloadTextFile(`${selected.name.toLowerCase()}-formula-card.txt`, `${selected.name}\nFormula: ${selected.formula}\nSymbols: ${selected.dimensions.join(", ")}\nExample: ${selected.use}`);
  const exportShape = () => downloadTextFile(`${selected.name.toLowerCase()}-shape.svg`, simpleShapeSvg(selected));
  const exportWorksheet = () => downloadTextFile("shape-practice-worksheet.txt", worksheetText(shapes.slice(0, 10)));
  const saveCustom = () => localStorage.setItem("math-universe-custom-shape", JSON.stringify({ name: customName, shapes: collage, savedAt: new Date().toISOString() }));
  const shareActivity = () => navigator.clipboard?.writeText(`${window.location.origin}/shapes?shape=${selected.id}`);

  return (
    <SectionCard title="Kids Shape Studio" description="Story quests, games, flashcards, nets, formulas, teacher tools, and 3D explorations built around the same shape engine.">
      {confetti && <div className="pointer-events-none fixed inset-x-0 top-16 z-50 mx-auto w-fit rounded-full bg-amber-300 px-5 py-3 text-sm font-black text-slate-950 shadow-xl">Great shape thinking!</div>}
      <div className="grid gap-4 xl:grid-cols-[320px_minmax(0,1fr)]">
        <div className="space-y-4">
          <div className="rounded-2xl bg-slate-950 p-4 text-white">
            <div className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-cyan-400 to-violet-500 text-2xl font-black">S</span>
              <div>
                <p className="text-sm text-cyan-200">Shape mascot guide</p>
                <p className="font-black">Hi, I am Shape Spark</p>
              </div>
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-300">Story mode: Help build a playground using shapes. Pick tiles, ramps, tunnels, shadows, and formula cards.</p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setMode("beginner")} className={mode === "beginner" ? "action-primary" : "action-secondary"}>Kid mode</button>
            <button type="button" onClick={() => setMode("advanced")} className={mode === "advanced" ? "action-primary" : "action-secondary"}>Advanced</button>
          </div>

          <label className="block rounded-2xl bg-slate-100 p-4 text-sm font-semibold dark:bg-white/10">
            Grade-wise level
            <select value={grade} onChange={(event) => setGrade(event.target.value as (typeof gradeLevels)[number])} className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-slate-900">
              {gradeLevels.map((item) => <option key={item}>{item}</option>)}
            </select>
          </label>

          <div className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10">
            <p className="text-sm font-bold">Progress tracking</p>
            <div className="mt-3 h-3 overflow-hidden rounded-full bg-white dark:bg-slate-950"><div className="h-full bg-gradient-to-r from-cyan-400 to-violet-500" style={{ width: `${mastery}%` }} /></div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs font-bold">
              <span className="rounded-xl bg-white p-2 dark:bg-slate-950">{mastery}% mastery</span>
              <span className="rounded-xl bg-white p-2 dark:bg-slate-950">{score} badges</span>
              <span className="rounded-xl bg-white p-2 dark:bg-slate-950">{favorites.length} favs</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {(["Play", "Build", "Formula", "Teacher", "3D"] as StudioTab[]).map((item) => <button key={item} type="button" onClick={() => setTab(item)} className={`rounded-full px-4 py-2 text-sm font-bold ${tab === item ? "bg-cyan-500 text-white" : "bg-slate-100 text-slate-700 dark:bg-white/10 dark:text-slate-200"}`}>{item}</button>)}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-slate-950/60 md:flex-row md:items-center">
            <label className="relative flex-1">
              <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-400" />
              <input value={search} onChange={(event) => setSearch(event.target.value)} className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-9 pr-3 text-sm dark:border-white/10 dark:bg-slate-900" placeholder="Search shapes, formulas, real-life uses..." />
            </label>
            <select value={sortMode} onChange={(event) => setSortMode(event.target.value as SortMode)} className="rounded-xl border border-slate-200 bg-white p-3 text-sm font-semibold dark:border-white/10 dark:bg-slate-900">
              {(["2D/3D", "sides", "corners", "curved edges", "symmetry", "faces", "vertices", "edges"] as SortMode[]).map((item) => <option key={item}>{item}</option>)}
            </select>
            <button type="button" onClick={() => speak(`${selected.name}. ${selected.description}. Formula: ${selected.formula}`)} className="action-secondary"><Volume2 className="h-4 w-4" />Read aloud</button>
          </div>

          {tab === "Play" && (
            <div className="grid gap-4 xl:grid-cols-2">
              <StudioPanel title="Flashcards and pronunciation" icon={<Mic className="h-5 w-5" />}>
                <div className="rounded-2xl bg-gradient-to-br from-cyan-100 to-violet-100 p-5 text-slate-950 dark:from-cyan-400/20 dark:to-violet-500/20 dark:text-white">
                  <div className="flex items-center gap-4"><ShapeThumbnail src={flashShape.thumbnail} name={flashShape.name} size="compare" decorative /><div><p className="text-xs font-bold uppercase">Shape flashcard</p><p className="mt-1 text-3xl font-black">{flashShape.name}</p></div></div>
                  <p className="mt-2 text-sm leading-6">{flashShape.description}</p>
                  <p className="mt-3 text-sm font-semibold"><MathExpression value={flashShape.formula} /></p>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" className="action-secondary" onClick={() => setActiveFlashcard((value) => value + 1)}>Next card</button>
                  <button type="button" className="action-secondary" onClick={() => speak(flashShape.name)}>Pronounce</button>
                  <button type="button" className="action-primary" onClick={celebrate}><Award className="h-4 w-4" />I know it</button>
                </div>
              </StudioPanel>

              <StudioPanel title="Drag-and-drop style matching" icon={<Wand2 className="h-5 w-5" />}>
                <div className="grid gap-3 md:grid-cols-2">
                  <label className="text-sm font-semibold">Real-world object<select value={matchObject} onChange={(event) => setMatchObject(event.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-slate-900">{objectMatches.map((item) => <option key={item.object}>{item.object}</option>)}</select></label>
                  <label className="text-sm font-semibold">Shape match<select value={matchShape} onChange={(event) => setMatchShape(event.target.value as ShapeId)} className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-slate-900">{shapes.map((shape) => <option key={shape.id} value={shape.id}>{shape.name}</option>)}</select></label>
                </div>
                <div className={`mt-3 rounded-2xl p-4 text-sm font-bold ${matchCorrect ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-400/10 dark:text-emerald-100" : "bg-amber-50 text-amber-800 dark:bg-amber-400/10 dark:text-amber-100"}`}>
                  {matchCorrect ? "Correct! Confetti unlocked." : showHints ? `Hint: ${matchObject} looks like a ${shapeName(currentMatch.shape)}.` : "Try again."}
                </div>
                <div className="mt-3 flex gap-2">
                  <button type="button" className="action-primary" onClick={matchCorrect ? celebrate : () => setShowHints(true)}>Check</button>
                  <button type="button" className="action-secondary" onClick={() => setShowHints((value) => !value)}>Hints</button>
                </div>
              </StudioPanel>

              <StudioPanel title="Room hunt and daily challenge" icon={<Camera className="h-5 w-5" />}>
                <p className="text-sm leading-6">Find this shape in your room: <strong>{selected.name}</strong>. AR-style shape camera idea: use the checklist now; camera detection can be connected later.</p>
                <div className="mt-3 grid gap-2 md:grid-cols-2">
                  {["I found it", "I measured it", "I named dimensions", "I explained formula"].map((item) => <button key={item} type="button" onClick={celebrate} className="rounded-xl bg-slate-100 p-3 text-sm font-bold dark:bg-white/10">{item}</button>)}
                </div>
                <label className="mt-3 flex items-center gap-3 rounded-xl bg-slate-100 p-3 text-sm font-bold dark:bg-white/10"><input type="checkbox" checked={timed} onChange={(event) => setTimed(event.target.checked)} />Timed challenge mode</label>
              </StudioPanel>

              <StudioPanel title="Multilingual kid labels" icon={<Sparkles className="h-5 w-5" />}>
                <div className="grid gap-2 md:grid-cols-3">
                  {Object.entries(languageLabels).map(([language, labels]) => <div key={language} className="rounded-2xl bg-slate-100 p-3 dark:bg-white/10"><p className="font-bold">{language}</p><p className="mt-2 text-sm">{labels.circle} / {labels.square} / {labels.triangle} / {labels.cube}</p></div>)}
                </div>
                <p className="mt-3 text-sm leading-6">Voice instructions, mistake hints, step hints, worked examples, try-again scaffolding and no-timer practice mode are active in this studio.</p>
              </StudioPanel>
            </div>
          )}

          {tab === "Build" && (
            <div className="grid gap-4 xl:grid-cols-2">
              <StudioPanel title="Pattern, tessellation, tangram and collage canvas" icon={<Shapes className="h-5 w-5" />}>
                <div className="grid grid-cols-6 gap-1 rounded-2xl bg-slate-100 p-3 dark:bg-slate-950">
                  {Array.from({ length: 36 }).map((_, index) => <MiniShape key={index} id={collage[index % collage.length]} />)}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {(["triangle", "square", "circle", "rectangle", "hexagon", "star"] as ShapeId[]).map((shapeId) => <button key={shapeId} type="button" className="mini-chip" onClick={() => setCollage((items) => [...items, shapeId].slice(-6))}>Add {shapeName(shapeId)}</button>)}
                  <button type="button" className="mini-chip" onClick={() => setCollage(["triangle", "triangle", "square", "parallelogram", "rhombus"])}>Tangram</button>
                  <button type="button" className="mini-chip" onClick={() => setCollage(["triangle", "rectangle", "circle", "cone"])}>Rocket</button>
                  <button type="button" className="mini-chip" onClick={() => setCollage(["circle", "ellipse", "triangle", "rectangle"])}>Animal</button>
                  <button type="button" className="mini-chip" onClick={() => setCollage(["rectangle", "triangle", "square", "circle"])}>House</button>
                </div>
              </StudioPanel>

              <StudioPanel title="Shape collage, free draw and save custom shape" icon={<Star className="h-5 w-5" />}>
                <input value={customName} onChange={(event) => setCustomName(event.target.value)} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-white/10 dark:bg-slate-900" />
                <div className="mt-3 rounded-2xl bg-white p-3 dark:bg-slate-950">
                  <svg viewBox="0 0 360 210" className="h-52 w-full rounded-xl bg-slate-50 dark:bg-slate-900">
                    {collage.map((shapeId, index) => <MiniShapeSvg key={`${shapeId}-${index}`} id={shapeId} x={50 + (index % 3) * 105} y={55 + Math.floor(index / 3) * 82} />)}
                    <path d="M40 180 C100 120 140 210 220 150 S305 120 330 170" fill="none" stroke="#8b5cf6" strokeWidth="4" strokeDasharray="8 6" />
                  </svg>
                </div>
                <div className="mt-3 flex flex-wrap gap-2"><button type="button" onClick={saveCustom} className="action-primary">Save custom</button><button type="button" onClick={exportShape} className="action-secondary"><Download className="h-4 w-4" />Export shape</button></div>
              </StudioPanel>

              <StudioPanel title="Symmetry, mirror and rotation explorer" icon={<Eye className="h-5 w-5" />}>
                <svg viewBox="0 0 420 180" className="h-44 w-full rounded-2xl bg-slate-100 dark:bg-slate-950">
                  <line x1="210" y1="20" x2="210" y2="160" stroke="#0f172a" strokeDasharray="7 6" strokeWidth="3" />
                  <polygon points="130,130 170,50 195,130" fill="#22d3ee" opacity="0.35" stroke="#06b6d4" strokeWidth="3" />
                  <polygon points="290,130 250,50 225,130" fill="#f59e0b" opacity="0.35" stroke="#f59e0b" strokeWidth="3" />
                  <text x="218" y="38" className="text-xs font-bold">mirror line</text>
                  <g transform="translate(90 30) rotate(45 40 40)"><rect x="10" y="10" width="60" height="60" fill="#8b5cf6" opacity="0.35" stroke="#8b5cf6" strokeWidth="3" /></g>
                </svg>
                <p className="mt-3 text-sm leading-6">Interactive symmetry lines, rotational symmetry and mirror reflection are demonstrated with live mirrored shapes.</p>
              </StudioPanel>

              <StudioPanel title="Story quest: build a playground" icon={<Award className="h-5 w-5" />}>
                <ol className="space-y-2">
                  {questSteps.map((step, index) => <li key={step} className="rounded-xl bg-slate-100 p-3 text-sm font-semibold dark:bg-white/10"><span className="text-cyan-600 dark:text-cyan-300">{index + 1}.</span> {step}</li>)}
                </ol>
              </StudioPanel>
            </div>
          )}

          {tab === "Formula" && (
            <div className="grid gap-4 xl:grid-cols-2">
              <StudioPanel title="Formula builder, missing symbol and rearrangement" icon={<Sparkles className="h-5 w-5" />}>
                <div className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10">
                  <p className="text-sm font-bold">Build: {selected.formula}</p>
                  <div className="mt-3 flex flex-wrap gap-2">{formulaTokens(selected.formula).map((token) => <span key={token} className="rounded-xl bg-white px-3 py-2 font-mono text-sm font-bold dark:bg-slate-950">{token}</span>)}</div>
                  <p className="mt-3 text-sm leading-6">Missing-symbol quiz: replace the blank in {missingFormula(selected)}. Rearrangement practice: solve for one variable using the same pieces.</p>
                </div>
                <button type="button" className="mt-3 action-primary" onClick={celebrate}>Check formula puzzle</button>
              </StudioPanel>

              <StudioPanel title="Why formula works and substitution" icon={<CalculatorIcon />}>
                <p className="text-sm leading-6">{formulaExplanation(selected.id, 4, 3, 5, 6, 90)}</p>
                <div className="mt-3 grid grid-cols-2 gap-2">{Object.entries(metrics).slice(0, 4).map(([label, value]) => <Metric key={label} label={label} value={value * unitFactor} />)}</div>
                <div className="mt-3 flex gap-2">
                  {(["cm", "m", "in"] as UnitName[]).map((item) => <button key={item} type="button" onClick={() => setUnit(item)} className={`rounded-xl px-3 py-2 text-sm font-bold ${unit === item ? "bg-cyan-500 text-white" : "bg-slate-100 dark:bg-white/10"}`}>{item}</button>)}
                </div>
                <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">Unit conversion, area vs perimeter and volume vs surface-area comparisons update from the same metrics.</p>
              </StudioPanel>

              <StudioPanel title="Shape comparison and property checklist" icon={<Search className="h-5 w-5" />}>
                <div className="max-h-72 overflow-y-auto rounded-2xl border border-slate-200 dark:border-white/10">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-100 dark:bg-white/10"><tr><th className="p-2">Shape</th><th className="p-2">Type</th><th className="p-2">Sides/Faces</th><th className="p-2">Symmetry</th></tr></thead>
                    <tbody>{filtered.slice(0, 12).map((shape) => <tr key={shape.id} className="border-t border-slate-200 dark:border-white/10"><td className="p-2"><span className="flex items-center gap-2 font-bold"><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="compact" decorative />{shape.name}</span></td><td className="p-2">{shape.kind}</td><td className="p-2">{propertyOf(shape, "sides") || propertyOf(shape, "faces")}</td><td className="p-2">{propertyOf(shape, "symmetry")}</td></tr>)}</tbody>
                  </table>
                </div>
              </StudioPanel>

              <StudioPanel title="Worked examples and real-life problems" icon={<Heart className="h-5 w-5" />}>
                <p className="text-sm leading-6">Example: A classroom board is a rectangle. If length is 4 m and breadth is 3 m, area = l x b = 12 m². Try again scaffolding: first identify dimensions, then choose formula, then substitute.</p>
                <div className="mt-3 rounded-2xl bg-amber-50 p-4 text-sm text-amber-800 dark:bg-amber-400/10 dark:text-amber-100">Mistake hint: Do not add sides when the question asks for area; multiply the dimensions that cover the surface.</div>
              </StudioPanel>
            </div>
          )}

          {tab === "Teacher" && (
            <div className="grid gap-4 xl:grid-cols-2">
              <StudioPanel title="Classroom projection and teacher notes" icon={<Printer className="h-5 w-5" />}>
                <textarea value={notes} onChange={(event) => setNotes(event.target.value)} className="min-h-28 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-white/10 dark:bg-slate-900" />
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" onClick={() => window.print()} className="action-secondary"><Printer className="h-4 w-4" />Print</button>
                  <button type="button" onClick={exportWorksheet} className="action-secondary"><Download className="h-4 w-4" />Worksheet</button>
                  <button type="button" onClick={exportCard} className="action-secondary"><Download className="h-4 w-4" />Formula card</button>
                  <button type="button" onClick={shareActivity} className="action-secondary">Share link</button>
                </div>
              </StudioPanel>

              <StudioPanel title="Parent and teacher dashboard" icon={<Award className="h-5 w-5" />}>
                <div className="grid grid-cols-2 gap-2">
                  <Metric label="Mastery" value={mastery} />
                  <Metric label="Recently learned" value={recent.length} />
                  <Metric label="Favorites" value={favorites.length} />
                  <Metric label="Quiz score" value={score} />
                </div>
                <p className="mt-3 text-sm leading-6">Auto-generated practice sheets, printable worksheets, difficulty-based quizzes, timed and no-timer modes, daily challenges and badges are tracked here.</p>
              </StudioPanel>

              <StudioPanel title="Favorites and recently learned" icon={<Heart className="h-5 w-5" />}>
                <div className="flex flex-wrap gap-2">{recent.map((shapeId) => { const shape = shapeById(shapes, shapeId); return <button key={shapeId} type="button" className="mini-chip" onClick={() => selectAndTrack(shape)}><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="compact" decorative />{shape.name}</button>; })}</div>
                <button type="button" onClick={() => toggleFavorite(selected.id)} className="mt-3 action-primary"><Heart className="h-4 w-4" />{favorites.includes(selected.id) ? "Remove favorite" : "Add favorite"}</button>
              </StudioPanel>

              <StudioPanel title="Search, sorting and filters" icon={<Search className="h-5 w-5" />}>
                <div className="grid gap-2 md:grid-cols-2">{filtered.slice(0, 8).map((shape) => <button key={shape.id} type="button" onClick={() => selectAndTrack(shape)} className="flex items-center gap-3 rounded-xl bg-slate-100 p-3 text-left text-sm font-bold dark:bg-white/10"><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="medium" decorative /><span>{shape.name}<span className="block text-xs font-normal text-slate-500">{shape.category}</span></span></button>)}</div>
              </StudioPanel>
            </div>
          )}

          {tab === "3D" && (
            <div className="grid gap-4 xl:grid-cols-2">
              <StudioPanel title="Nets, folding and surface paint" icon={<Cuboid className="h-5 w-5" />}>
                <NetExplorer shape={selected.id} paint={surfacePaint} />
                <SliderControl label="Paint the surface area" value={surfacePaint} min={0} max={100} step={5} onChange={setSurfacePaint} unit="%" />
              </StudioPanel>

              <StudioPanel title="Cross-section, shadows and light source" icon={<Eye className="h-5 w-5" />}>
                <svg viewBox="0 0 420 220" className="h-56 w-full rounded-2xl bg-slate-950">
                  <circle cx="70" cy="55" r="24" fill="#facc15" />
                  <line x1="95" y1="60" x2="250" y2={70 + lightAngle} stroke="#fde68a" strokeWidth="3" opacity="0.75" />
                  <rect x="190" y="70" width="90" height="90" fill="#22d3ee" opacity="0.65" stroke="#67e8f9" />
                  <ellipse cx="305" cy="176" rx={50 + lightAngle * 0.5} ry="18" fill="#020617" stroke="#475569" />
                  <line x1="185" y1={70 + sliceLevel * 0.9} x2="285" y2={70 + sliceLevel * 0.9} stroke="#f59e0b" strokeWidth="4" strokeDasharray="7 5" />
                  <text x="185" y="205" fill="#e2e8f0" className="text-xs font-bold">2D cross-section vs 3D solid shadow</text>
                </svg>
                <SliderControl label="Light-source explorer" value={lightAngle} min={5} max={80} step={1} onChange={setLightAngle} unit="deg" />
                <SliderControl label="Cross-section slicer" value={sliceLevel} min={0} max={100} step={5} onChange={setSliceLevel} unit="%" />
                <button type="button" className="action-primary" onClick={celebrate}>Guess the 3D shape from shadow</button>
              </StudioPanel>

              <StudioPanel title="3D controls checklist" icon={<ZoomIn className="h-5 w-5" />}>
                <ul className="grid gap-2 text-sm leading-6 md:grid-cols-2">
                  {["3D rotate with touch gestures", "Zoom and pan for all shapes", "Transparent mode", "Wireframe mode", "Show shadows", "Compare 2D cross-section", "Volume filling animation", "Surface-area unfolding nets"].map((item) => <li key={item} className="rounded-xl bg-slate-100 p-3 font-semibold dark:bg-white/10">{item}</li>)}
                </ul>
              </StudioPanel>

              <StudioPanel title="Cube, cylinder, cone, pyramid and prism net explorers" icon={<Box className="h-5 w-5" />}>
                <div className="grid gap-2 md:grid-cols-5">{(["cube", "cylinder", "cone", "square-pyramid", "triangular-prism", "tetrahedron", "hexagonal-prism", "capsule", "ellipsoid", "torus"] as ShapeId[]).map((shapeId) => <button key={shapeId} type="button" onClick={() => selectAndTrack(shapeById(shapes, shapeId))} className="rounded-xl bg-slate-100 p-3 text-xs font-bold dark:bg-white/10">{shapeName(shapeId)}</button>)}</div>
              </StudioPanel>
            </div>
          )}
        </div>
      </div>
    </SectionCard>
  );
}

function StudioPanel({ title, icon, children }: { title: string; icon: ReactNode; children: ReactNode }) {
  return <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5"><div className="mb-3 flex items-center gap-2 font-bold text-slate-900 dark:text-white">{icon}{title}</div>{children}</div>;
}

function MiniShape({ id, size = "medium" }: { id: ShapeId; size?: "compact" | "small" | "medium" | "large" | "compare" }) {
  const shape = shapeById(shapes, id);
  return <ShapeThumbnail src={shape.thumbnail} name={shape.name} size={size} decorative />;
}

function ShapeCompareWorkspace({ shapeIds, selectedId, onToggle, onSelect, a, b, c, sides, angle, precision, unit }: { shapeIds: ShapeId[]; selectedId: ShapeId; onToggle: (id: ShapeId) => void; onSelect: (shape: ShapeDefinition) => void; a: number; b: number; c: number; sides: number; angle: number; precision: number; unit: ShapeUnit }) {
  const compared = shapeIds.map((id) => shapeById(shapes, id));
  return <section className="shapes-mode-workspace"><header><div><span>Compare workspace</span><h2>Shape comparison</h2><p>Pin up to four shapes from the library. Dimensions and metrics use the current controls.</p></div><span>{compared.length}/4 pinned</span></header>{compared.length ? <div className="shapes-compare-grid">{compared.map((shape) => { const metrics = getMetrics(shape.id, a, b, c, sides, angle); const structure = shapeProperties(shape); return <article key={shape.id} className={shape.id === selectedId ? "is-selected" : ""}><button type="button" className="shapes-compare-remove" onClick={() => onToggle(shape.id)} aria-label={`Remove ${shape.name} from comparison`}><X /></button><button type="button" className="shapes-compare-select" onClick={() => onSelect(shape)}><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="compare" decorative /><strong>{shape.name}</strong><span>{shape.category}</span></button><p><MathExpression value={shape.formula} /></p><dl><div><dt>Faces</dt><dd>{structure.faces}</dd></div><div><dt>Edges</dt><dd>{structure.edges}</dd></div><div><dt>Vertices</dt><dd>{structure.vertices}</dd></div>{Object.entries(metrics).slice(0, 3).map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{roundTo(value * unitScale[unit], precision)}</dd></div>)}</dl></article>; })}</div> : <div className="shapes-empty-state"><Shapes /><strong>No shapes pinned</strong><span>Use the check icon beside a library shape.</span></div>}</section>;
}

function ShapeLearnWorkspace({ shape, metrics, step, onStep, onOpenInspector }: { shape: ShapeDefinition; metrics: Metrics; step: number; onStep: (step: number) => void; onOpenInspector: () => void }) {
  const steps = ["Recognize", "Measure", "Calculate", "Apply"];
  const content = [shapeIdentityFacts(shape.id).join(" "), `Identify ${shape.dimensions.join(", ")}. Change a dimension and observe which measurements respond.`, `Use ${shape.formula}. The current values include ${Object.entries(metrics).slice(0, 2).map(([label, value]) => `${label} ${roundTo(value, 2)}`).join(" and ")}.`, `Find a real example: ${shape.use}`][step];
  return <section className="shapes-mode-workspace shapes-learn-workspace"><header><div><span>Guided lesson</span><h2>{shape.name}</h2><p>{shape.description}</p></div><Award /></header><div className="shapes-learning-path">{steps.map((label, index) => <button type="button" key={label} className={index === step ? "is-active" : index < step ? "is-complete" : ""} onClick={() => onStep(index)}><span>{index < step ? <Check /> : index + 1}</span>{label}</button>)}</div><div className="shapes-learn-card"><ShapeThumbnail src={shape.thumbnail} name={shape.name} size="compare" decorative /><div><h3>{steps[step]}</h3><p>{content}</p><div><button type="button" onClick={() => onStep(Math.max(0, step - 1))} disabled={!step}>Previous</button><button type="button" onClick={() => step < 3 ? onStep(step + 1) : onOpenInspector()}>{step < 3 ? "Continue" : "Inspect shape"}</button></div></div></div></section>;
}

function PreciseDimensionControl({ label, value, min, max, step, unit, suffix, highlighted, onChange }: { label: string; value: number; min: number; max: number; step: number; unit: ShapeUnit; suffix?: string; highlighted: boolean; onChange: (value: number) => void }) {
  return <label className={`shapes-precise-control ${highlighted ? "is-highlighted" : ""}`}><span>{label}<span>{unit === "units" ? suffix ?? "" : unit}</span></span><div><input type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} /><input aria-label={`${label} exact value`} type="number" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Math.min(max, Math.max(min, Number(event.target.value))))} /></div></label>;
}

function ShapeMeasurementOverlay({ shape, metrics, unit, precision }: { shape: ShapeDefinition; metrics: Metrics; unit: ShapeUnit; precision: number }) {
  return <div className="shapes-measure-overlay"><header><Ruler /><strong>{shape.name} measurements</strong></header>{Object.entries(metrics).slice(0, 4).map(([label, value]) => <span key={label}>{label}<b>{roundTo(value * unitScale[unit], precision)} {unit === "units" ? "u" : unit}</b></span>)}</div>;
}

function ShapeCrossSectionControls({ shape, axis, position, angle, onAxis, onPosition, onAngle }: { shape: ShapeDefinition; axis: "x" | "y" | "z"; position: number; angle: number; onAxis: (axis: "x" | "y" | "z") => void; onPosition: (value: number) => void; onAngle: (value: number) => void }) {
  const section = shape.kind === "2d" ? "Cross-sections require a 3D solid." : /sphere|ellipsoid/.test(shape.id) ? "Ellipse" : /cone|pyramid/.test(shape.id) ? "Scaled polygon" : /cylinder/.test(shape.id) ? (axis === "z" ? "Circle" : "Rectangle") : "Polygon";
  return <section className="shapes-cross-section"><header><SlidersHorizontal /><strong>Cross-section</strong><span>{section}</span></header>{shape.kind === "3d" ? <><label>Plane<select value={axis} onChange={(event) => onAxis(event.target.value as typeof axis)}><option value="x">X plane</option><option value="y">Y plane</option><option value="z">Z plane</option></select></label><SliderControl density="compact" label="Position" value={position} min={0} max={100} step={1} onChange={onPosition} unit="%" /><SliderControl density="compact" label="Angle" value={angle} min={-90} max={90} step={1} onChange={onAngle} unit="°" /></> : <p>{section}</p>}</section>;
}

function FormulaDependencyPanel({ shape, entries, highlighted, onHighlight }: { shape: ShapeDefinition; entries: ShapeFormulaEntry[]; highlighted: string | null; onHighlight: (symbol: string | null) => void }) {
  const symbols = Array.from(new Set((shape.formula.match(/[a-zA-Z]+/g) ?? []).filter((token) => !["SA", "CSA", "TSA", "A", "V", "P"].includes(token)))).slice(0, 6);
  return <div className="shapes-formula-dependencies"><div><strong>Formula dependencies</strong><span>Select a symbol to highlight its controls.</span></div><div>{symbols.map((symbol) => <button type="button" key={symbol} className={highlighted === symbol ? "is-active" : ""} onClick={() => onHighlight(highlighted === symbol ? null : symbol)}>{symbol}</button>)}</div><section>{entries.map((entry) => <div key={entry.title}><strong>{entry.title}</strong><MathExpression value={entry.formula} /><span>{entry.note}</span></div>)}</section></div>;
}

function ShapeSettingsDialog({ theme, unit, precision, highContrast, largeLabels, colorblind, reducedMotion, onTheme, onUnit, onPrecision, onHighContrast, onLargeLabels, onColorblind, onClose }: { theme: ShapesTheme; unit: ShapeUnit; precision: number; highContrast: boolean; largeLabels: boolean; colorblind: boolean; reducedMotion: boolean; onTheme: (theme: ShapesTheme) => void; onUnit: (unit: ShapeUnit) => void; onPrecision: (value: number) => void; onHighContrast: (value: boolean) => void; onLargeLabels: (value: boolean) => void; onColorblind: (value: boolean) => void; onClose: () => void }) {
  return <div className="shapes-modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}><section className="shapes-modal" role="dialog" aria-modal="true" aria-label="Shape Explorer settings"><header><h2>Workspace settings</h2><button type="button" onClick={onClose} aria-label="Close settings"><X /></button></header><label>Appearance<select value={theme} onChange={(event) => onTheme(event.target.value as ShapesTheme)}><option value="glow">Glow theme</option><option value="dark">Dark theme</option><option value="light">Light theme</option></select></label><label>Measurement unit<select value={unit} onChange={(event) => onUnit(event.target.value as ShapeUnit)}><option value="units">Abstract units</option><option value="mm">Millimetres</option><option value="cm">Centimetres</option><option value="m">Metres</option><option value="in">Inches</option></select></label><label>Decimal precision<select value={precision} onChange={(event) => onPrecision(Number(event.target.value))}>{[0, 1, 2, 3, 4].map((value) => <option key={value} value={value}>{value} places</option>)}</select></label><label className="shapes-setting-toggle"><span>High contrast</span><input type="checkbox" checked={highContrast} onChange={(event) => onHighContrast(event.target.checked)} /></label><label className="shapes-setting-toggle"><span>Larger labels</span><input type="checkbox" checked={largeLabels} onChange={(event) => onLargeLabels(event.target.checked)} /></label><label className="shapes-setting-toggle"><span>Color-blind safe palette</span><input type="checkbox" checked={colorblind} onChange={(event) => onColorblind(event.target.checked)} /></label><p>Reduced motion follows your device setting and is currently {reducedMotion ? "enabled" : "disabled"}.</p></section></div>;
}

function ShapeExportDialog({ shape, metrics, summary, onClose }: { shape: ShapeDefinition; metrics: Metrics; summary: () => void; onClose: () => void }) {
  const exportCsv = () => downloadTextFile(`${shape.id}-measurements.csv`, `metric,value\n${Object.entries(metrics).map(([label, value]) => `${label},${value}`).join("\n")}`);
  const exportSvg = () => downloadTextFile(`${shape.id}.svg`, simpleShapeSvg(shape));
  const exportPng = async () => {
    const target = document.querySelector<HTMLElement>(".shapes-stage");
    if (!target) return;
    const { default: html2canvas } = await import("html2canvas");
    const canvas = await html2canvas(target, { backgroundColor: "#06111f", scale: Math.min(window.devicePixelRatio, 2) });
    const anchor = document.createElement("a");
    anchor.download = `${shape.id}.png`;
    anchor.href = canvas.toDataURL("image/png");
    anchor.click();
  };
  return <div className="shapes-modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}><section className="shapes-modal" role="dialog" aria-modal="true" aria-label="Export shape"><header><h2>Export {shape.name}</h2><button type="button" onClick={onClose} aria-label="Close export"><X /></button></header><div className="shapes-export-grid"><button type="button" onClick={() => { void exportPng(); onClose(); }}><Download /><strong>Viewport image</strong><span>PNG</span></button><button type="button" onClick={() => { summary(); onClose(); }}><Download /><strong>Summary</strong><span>TXT</span></button><button type="button" onClick={() => { exportSvg(); onClose(); }}><Shapes /><strong>Vector</strong><span>SVG</span></button><button type="button" onClick={() => { exportCsv(); onClose(); }}><Grid3X3 /><strong>Measurements</strong><span>CSV</span></button><button type="button" onClick={() => window.print()}><Printer /><strong>Worksheet</strong><span>PDF / Print</span></button>{shape.kind === "3d" && <button type="button" onClick={() => downloadTextFile(`${shape.id}-3d-readme.txt`, `${shape.name} is available as an interactive Math Universe model. Mesh export is not available for this procedural solid.`)}><Cuboid /><strong>3D model note</strong><span>TXT</span></button>}</div></section></div>;
}

function MiniShapeSvg({ id, x, y }: { id: ShapeId; x: number; y: number }) {
  return <g transform={`translate(${x} ${y})`}><MiniShapeGlyph id={id} /></g>;
}

function MiniShapeGlyph({ id }: { id: ShapeId }) {
  if (id.includes("triangle") || id === "cone") return <polygon points="25,4 46,44 4,44" fill="#22d3ee" stroke="#06b6d4" strokeWidth="3" />;
  if (id === "circle" || id === "sphere" || id === "cylinder") return <circle cx="25" cy="25" r="20" fill="#f59e0b" opacity="0.75" stroke="#d97706" strokeWidth="3" />;
  if (id === "regular-polygon") return <polygon points="25,3 44,14 44,36 25,47 6,36 6,14" fill="#8b5cf6" opacity="0.7" stroke="#7c3aed" strokeWidth="3" />;
  return <rect x="7" y="9" width="36" height="32" rx="4" fill="#22d3ee" opacity="0.7" stroke="#06b6d4" strokeWidth="3" />;
}

function NetExplorer({ shape, paint, progress = 0, a = 4, b = 3, c = 5 }: { shape: ShapeId; paint: number; progress?: number; a?: number; b?: number; c?: number }) {
  const definition = shapes.find((item) => item.id === shape);
  const available = ["cube", "cuboid", "cylinder", "square-pyramid"];
  const unavailable = !available.includes(shape);
  if (unavailable) return <div className="shapes-net-unavailable"><Shapes /><strong>Net preview unavailable</strong><span>{definition?.kind === "2d" ? "Select a supported 3D solid to unfold its surfaces." : `${definition?.name ?? "This solid"} needs a dedicated dimension-accurate net. Try a cube, cuboid, cylinder, or square pyramid.`}</span></div>;
  const fill = `rgba(34,211,238,${0.12 + paint / 160})`;
  const scale = 60 / (shape === "cube" ? a : Math.max(a, b, c));
  const width = a * scale, height = (shape === "cube" ? a : b) * scale, depth = (shape === "cube" ? a : c) * scale;
  const x = 170, y = 82;
  const cylinderScale = Math.min(35 / a, 180 / (2 * Math.PI * a), 70 / b);
  const cylinderRadius = a * cylinderScale, cylinderWidth = 2 * Math.PI * a * cylinderScale, cylinderHeight = b * cylinderScale;
  const pyramidScale = 60 / Math.max(a, Math.hypot(a / 2, b));
  const pyramidSide = a * pyramidScale, pyramidSlant = Math.hypot(a / 2, b) * pyramidScale;
  const pyramidX = 210 - pyramidSide / 2, pyramidY = 110 - pyramidSide / 2;
  const face = (left: number, top: number, w: number, h: number, key: string) => <rect key={key} x={left} y={top} width={w} height={h} fill={fill} stroke="#06b6d4" strokeWidth="2" />;
  return (
    <svg viewBox="0 0 420 220" className="h-56 w-full rounded-2xl bg-slate-100 dark:bg-slate-950" style={{ transform: `perspective(700px) rotateX(${progress * 0.28}deg)`, transition: "transform .2s ease" }}>
      {shape === "cylinder" ? <><rect x={210 - cylinderWidth / 2} y={110 - cylinderHeight / 2} width={cylinderWidth} height={cylinderHeight} fill={fill} stroke="#06b6d4" strokeWidth="3" /><circle cx={210 - cylinderWidth / 2 - cylinderRadius} cy="110" r={cylinderRadius} fill={fill} stroke="#f59e0b" strokeWidth="3" /><circle cx={210 + cylinderWidth / 2 + cylinderRadius} cy="110" r={cylinderRadius} fill={fill} stroke="#f59e0b" strokeWidth="3" /></> :
        shape === "cone" ? <><path d="M210 30 L320 170 L100 170 Z" fill={fill} stroke="#06b6d4" strokeWidth="3" /><circle cx="210" cy="170" r="42" fill={fill} stroke="#f59e0b" strokeWidth="3" /></> :
        shape === "square-pyramid" ? <><rect x={pyramidX} y={pyramidY} width={pyramidSide} height={pyramidSide} fill={fill} stroke="#06b6d4" strokeWidth="3" /><polygon points={`${pyramidX},${pyramidY} ${210},${pyramidY - pyramidSlant} ${pyramidX + pyramidSide},${pyramidY}`} fill={fill} stroke="#f59e0b" strokeWidth="3" /><polygon points={`${pyramidX + pyramidSide},${pyramidY} ${pyramidX + pyramidSide + pyramidSlant},${110} ${pyramidX + pyramidSide},${pyramidY + pyramidSide}`} fill={fill} stroke="#f59e0b" strokeWidth="3" /><polygon points={`${pyramidX + pyramidSide},${pyramidY + pyramidSide} ${210},${pyramidY + pyramidSide + pyramidSlant} ${pyramidX},${pyramidY + pyramidSide}`} fill={fill} stroke="#f59e0b" strokeWidth="3" /><polygon points={`${pyramidX},${pyramidY + pyramidSide} ${pyramidX - pyramidSlant},${110} ${pyramidX},${pyramidY}`} fill={fill} stroke="#f59e0b" strokeWidth="3" /></> :
        shape === "triangular-prism" ? <><polygon points="70,150 125,55 180,150" fill={fill} stroke="#06b6d4" strokeWidth="3" /><rect x="180" y="55" width="90" height="95" fill={fill} stroke="#f59e0b" strokeWidth="3" /><polygon points="270,150 325,55 380,150" fill={fill} stroke="#06b6d4" strokeWidth="3" /></> :
        <>{face(x, y, width, height, "front")}{face(x - depth, y, depth, height, "left")}{face(x + width, y, depth, height, "right")}{face(x + width + depth, y, width, height, "back")}{face(x, y - depth, width, depth, "top")}{face(x, y + height, width, depth, "bottom")}</>}
      <text x="20" y="205" fill="#334155" className="text-xs font-bold">{shape === "cube" ? `side ${a.toFixed(1)}` : shape === "cuboid" ? `length ${a.toFixed(1)} · width ${b.toFixed(1)} · height ${c.toFixed(1)}` : shape === "cylinder" ? `radius ${a.toFixed(1)} · height ${b.toFixed(1)}` : `side ${a.toFixed(1)} · height ${b.toFixed(1)}`} · fold {progress}%</text>
    </svg>
  );
}

function CalculatorIcon() {
  return <Sparkles className="h-5 w-5" />;
}

function sortValue(shape: ShapeDefinition, mode: SortMode) {
  const props = shapeProperties(shape);
  if (mode === "2D/3D") return shape.kind === "2d" ? 0 : 1;
  return props[mode] ?? 0;
}

function shapeProperties(shape: ShapeDefinition): Record<SortMode, number> {
  const curved = ["circle", "semicircle", "sector", "ellipse", "sphere", "hemisphere", "cylinder", "cone", "frustum", "torus"].includes(shape.id) ? 1 : 0;
  const sides: Partial<Record<ShapeId, number>> = { triangle: 3, "right-triangle": 3, square: 4, rectangle: 4, parallelogram: 4, rhombus: 4, trapezium: 4, kite: 4, pentagon: 5, hexagon: 6, heptagon: 7, octagon: 8, decagon: 10, "regular-polygon": 6, star: 10, cross: 12 };
  const faces: Partial<Record<ShapeId, number>> = { cube: 6, cuboid: 6, cylinder: 3, "hollow-cylinder": 3, capsule: 3, cone: 2, "square-pyramid": 5, "triangular-pyramid": 4, "rectangular-pyramid": 5, "triangular-prism": 5, "pentagonal-prism": 7, "hexagonal-prism": 8, frustum: 3, sphere: 1, ellipsoid: 1, hemisphere: 2, torus: 1, tetrahedron: 4, octahedron: 8, dodecahedron: 12, icosahedron: 20 };
  const edges: Partial<Record<ShapeId, number>> = { cube: 12, cuboid: 12, cylinder: 2, "hollow-cylinder": 4, cone: 1, "square-pyramid": 8, "triangular-pyramid": 6, "rectangular-pyramid": 8, "triangular-prism": 9, "pentagonal-prism": 15, "hexagonal-prism": 18, frustum: 2, tetrahedron: 6, octahedron: 12, dodecahedron: 30, icosahedron: 30 };
  const vertices: Partial<Record<ShapeId, number>> = { cube: 8, cuboid: 8, cone: 1, "square-pyramid": 5, "triangular-pyramid": 4, "rectangular-pyramid": 5, "triangular-prism": 6, "pentagonal-prism": 10, "hexagonal-prism": 12, tetrahedron: 4, octahedron: 6, dodecahedron: 20, icosahedron: 12 };
  return { "2D/3D": shape.kind === "2d" ? 0 : 1, sides: sides[shape.id] ?? 0, corners: sides[shape.id] ?? vertices[shape.id] ?? 0, "curved edges": curved, symmetry: ["circle", "annulus", "square", "rectangle", "hexagon", "sphere", "cube", "torus"].includes(shape.id) ? 4 : 1, faces: faces[shape.id] ?? 0, vertices: vertices[shape.id] ?? 0, edges: edges[shape.id] ?? sides[shape.id] ?? 0 };
}

function propertyOf(shape: ShapeDefinition, mode: SortMode) {
  return shapeProperties(shape)[mode];
}

function shapeName(id: ShapeId) {
  return shapes.find((shape) => shape.id === id)?.name ?? id;
}

function shapeById(items: ShapeDefinition[], id: ShapeId) {
  return items.find((shape) => shape.id === id) ?? items[0];
}

function formulaTokens(formula: string) {
  return formula.split(/(\s+|=|\+|-|\*|\/|\(|\)|,)/).filter((token) => token.trim());
}

function missingFormula(shape: ShapeDefinition) {
  return shape.formula.replace(/[A-Z]/, "__");
}

function playTinySound() {
  try {
    const context = new AudioContext();
    const osc = context.createOscillator();
    const gain = context.createGain();
    osc.frequency.value = 660;
    gain.gain.value = 0.04;
    osc.connect(gain);
    gain.connect(context.destination);
    osc.start();
    osc.stop(context.currentTime + 0.12);
  } catch {
    // Audio can be blocked until user gesture; silent fallback is fine.
  }
}

function downloadTextFile(filename: string, content: string) {
  const url = URL.createObjectURL(new Blob([content], { type: "text/plain" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function simpleShapeSvg(shape: ShapeDefinition) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 180"><rect width="240" height="180" fill="#f8fafc"/><text x="20" y="30" font-size="18" font-weight="700">${shape.name}</text><text x="20" y="158" font-size="13">${shape.formula}</text><circle cx="120" cy="88" r="46" fill="#22d3ee" opacity=".35" stroke="#06b6d4" stroke-width="4"/></svg>`;
}

function worksheetText(items: ShapeDefinition[]) {
  return items.map((shape, index) => `${index + 1}. ${shape.name}\nFormula: ${shape.formula}\nTask: Find a real object shaped like this and write its dimensions.\n`).join("\n");
}

function Metric({ label, value, suffix }: { label: string; value: number; suffix?: string }) {
  return <div className="rounded-2xl bg-slate-100 p-3 dark:bg-white/10"><p className="text-xs text-slate-500 dark:text-slate-400">{label}</p><p className="font-bold">{roundTo(value, 3)}{suffix ? <small className="ml-1 text-[10px] text-slate-500">{suffix}</small> : null}</p></div>;
}

function shapeComplexity(shape: ShapeDefinition) {
  const properties = shapeProperties(shape);
  return properties.faces + properties.edges + properties.vertices + properties.sides + properties["curved edges"] * 2;
}

function InfoTile({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10"><p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{label}</p><p className="mt-2 text-sm leading-6 text-slate-700 dark:text-slate-200">{value}</p></div>;
}

function readableShapeFormula(formula: string): string {
  return formula
    .replace(/\btheta\b/g, "θ")
    .replace(/(?<![A-Za-z])pi\b/g, "π")
    .replace(/sqrt/g, "√")
    .replace(/\bapprox\b/g, "≈")
    .replace(/\bperpendicular\b/g, "⊥")
    .replace(/\b x \b/g, " × ")
    .replace(/sin36/g, "sin 36°")
    .replace(/\^2/g, "²")
    .replace(/\^3/g, "³")
    .replace(/_([0123456789])/g, (_, digit: string) => "₀₁₂₃₄₅₆₇₈₉"[Number(digit)]);
}

function getShapeFormulaEntries(id: ShapeId): ShapeFormulaEntry[] {
  const polygon = (n: number): ShapeFormulaEntry[] => [
    { title: "Perimeter", formula: `P=${n}s`, note: `Add all ${n} equal sides.`, valueLabel: "Perimeter" },
    { title: "Area", formula: `A=${n}s^2/(4 tan(pi/${n}))`, note: "Regular-polygon area from side length.", valueLabel: "Area" },
    { title: "Apothem", formula: `a_p=s/(2 tan(pi/${n}))`, note: "Distance from center to each side.", valueLabel: "Apothem" },
  ];
  const prism = (baseArea: string, perimeter = "P_b"): ShapeFormulaEntry[] => [
    { title: "Base area", formula: `B=${baseArea}`, note: "Area of one congruent base.", valueLabel: "Base area" },
    { title: "Volume", formula: "V=B L", note: "Base area times extrusion length.", valueLabel: "Volume" },
    { title: "Lateral area", formula: `LA=${perimeter}L`, note: "Wrap area from base perimeter times length." },
    { title: "Total surface area", formula: "TSA=2B+LA", note: "Both bases plus lateral surface." },
  ];

  const formulas: Partial<Record<ShapeId, ShapeFormulaEntry[]>> = {
    circle: [
      { title: "Circumference", formula: "C=2 pi r", note: "Distance around the circle.", valueLabel: "Circumference" },
      { title: "Area", formula: "A=pi r^2", note: "Region enclosed by the circle.", valueLabel: "Area" },
      { title: "Diameter", formula: "d=2r", note: "Full width through the center." },
      { title: "Arc length", formula: "s=r theta", note: "Theta in radians for any circular arc." },
    ],
    semicircle: [
      { title: "Arc length", formula: "L=pi r", note: "Half of the full circumference.", valueLabel: "Arc length" },
      { title: "Perimeter", formula: "P=pi r+2r", note: "Curved edge plus diameter.", valueLabel: "Perimeter" },
      { title: "Area", formula: "A=1/2 pi r^2", note: "Half of circle area.", valueLabel: "Area" },
    ],
    sector: [
      { title: "Arc length", formula: "L=(theta/360) 2 pi r", note: "Central angle in degrees.", valueLabel: "Arc length" },
      { title: "Area", formula: "A=(theta/360) pi r^2", note: "Fraction of circle area.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=2r+L", note: "Two radii plus arc length." },
    ],
    ellipse: [
      { title: "Area", formula: "A=pi ab", note: "Semi-major axis a and semi-minor axis b.", valueLabel: "Area" },
      { title: "Approx perimeter", formula: "P approx pi[3(a+b)-sqrt((3a+b)(a+3b))]", note: "Ramanujan-style approximation.", valueLabel: "Approx perimeter" },
      { title: "Eccentricity", formula: "e=sqrt(1-b^2/a^2)", note: "For a >= b." },
    ],
    annulus: [
      { title: "Area", formula: "A=pi(R^2-r^2)", note: "Outer circle minus inner circle.", valueLabel: "Area" },
      { title: "Outer circumference", formula: "C_o=2 pi R", note: "Outer boundary length.", valueLabel: "Outer circumference" },
      { title: "Inner circumference", formula: "C_i=2 pi r", note: "Inner boundary length.", valueLabel: "Inner circumference" },
    ],
    quadrant: [
      { title: "Arc length", formula: "L=1/2 pi r", note: "Quarter circle arc.", valueLabel: "Arc length" },
      { title: "Area", formula: "A=1/4 pi r^2", note: "Quarter of circle area.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=2r+1/2 pi r", note: "Two radii plus quarter circumference.", valueLabel: "Perimeter" },
    ],
    segment: [
      { title: "Arc length", formula: "L=(theta/360) 2 pi r", note: "Arc cut by the chord.", valueLabel: "Arc length" },
      { title: "Segment area", formula: "A=(r^2/2)(theta-sin theta)", note: "Theta in radians.", valueLabel: "Area" },
      { title: "Chord length", formula: "c=2r sin(theta/2)", note: "Straight edge of the segment." },
    ],
    crescent: [
      { title: "Approx area", formula: "A approx pi(R^2-0.72r^2)", note: "Model-specific crescent approximation.", valueLabel: "Approx area" },
      { title: "Outer arc", formula: "L_o approx pi R", note: "Shown as a major circular arc.", valueLabel: "Outer arc" },
      { title: "Inner arc", formula: "L_i approx pi r", note: "Shown as an inner circular cut.", valueLabel: "Inner arc" },
    ],
    star: [
      { title: "Area", formula: "A=5Rr sin36", note: "Ten alternating-radius edges form ten center triangles.", valueLabel: "Area" },
      { title: "Points", formula: "n=5", note: "Current star model uses five points.", valueLabel: "Points" },
    ],
    cross: [
      { title: "Area", formula: "A=4aw-w^2", note: "Two 2a by w rectangles minus their w by w overlap.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=8a", note: "The inset and end segments combine to eight half-arm lengths.", valueLabel: "Perimeter" },
    ],
    triangle: [
      { title: "Area", formula: "A=1/2 bh", note: "Base times perpendicular height.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=a+b+c", note: "Sum of all side lengths." },
      { title: "Heron's formula", formula: "A=sqrt(s(s-a)(s-b)(s-c)), s=(a+b+c)/2", note: "Area when all three side lengths are known." },
    ],
    "right-triangle": [
      { title: "Area", formula: "A=1/2 ab", note: "Product of perpendicular legs.", valueLabel: "Area" },
      { title: "Hypotenuse", formula: "c=sqrt(a^2+b^2)", note: "Pythagorean theorem.", valueLabel: "Hypotenuse" },
      { title: "Perimeter", formula: "P=a+b+c", note: "Both legs plus hypotenuse.", valueLabel: "Perimeter" },
      { title: "Trig ratios", formula: "sin theta=opposite/hypotenuse, tan theta=opposite/adjacent", note: "Connects the triangle to trigonometry." },
    ],
    "equilateral-triangle": [
      { title: "Area", formula: "A=sqrt(3)s^2/4", note: "The common triangle rule A=bh/2 with h=sqrt(3)s/2.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=3s", note: "Three equal sides.", valueLabel: "Perimeter" },
      { title: "Height", formula: "h=sqrt(3)s/2", note: "Altitude splits the shape into two 30-60-90 triangles.", valueLabel: "Height" },
    ],
    "isosceles-triangle": [
      { title: "Area", formula: "A=1/2 bh", note: "The universal triangle area rule.", valueLabel: "Area" },
      { title: "Equal side", formula: "s=sqrt(h^2+(b/2)^2)", note: "The altitude bisects the base.", valueLabel: "Equal side" },
      { title: "Perimeter", formula: "P=b+2s", note: "Base plus two equal sides.", valueLabel: "Perimeter" },
    ],
    "scalene-triangle": [
      { title: "Area", formula: "A=1/2 bh", note: "The same base-height rule used by every triangle.", valueLabel: "Area" },
      { title: "Left side", formula: "s_1=sqrt(x^2+h^2)", note: "The apex offset x and height form a right triangle.", valueLabel: "Left side" },
      { title: "Right side", formula: "s_2=sqrt((b-x)^2+h^2)", note: "The remaining base length is b-x.", valueLabel: "Right side" },
      { title: "Heron's formula", formula: "A=sqrt(p(p-a)(p-b)(p-c))", note: "Use when all three unequal sides are known." },
      { title: "Perimeter", formula: "P=b+s_1+s_2", note: "Add the three unequal sides.", valueLabel: "Perimeter" },
    ],
    square: [
      { title: "Area", formula: "A=s^2", note: "Side squared.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=4s", note: "Four equal sides.", valueLabel: "Perimeter" },
      { title: "Diagonal", formula: "d=s sqrt(2)", note: "From Pythagoras.", valueLabel: "Diagonal" },
    ],
    rectangle: [
      { title: "Area", formula: "A=lw", note: "Length times width.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=2(l+w)", note: "Two lengths and two widths.", valueLabel: "Perimeter" },
      { title: "Diagonal", formula: "d=sqrt(l^2+w^2)", note: "Pythagoras across the rectangle.", valueLabel: "Diagonal" },
    ],
    "rounded-rectangle": [
      { title: "Area", formula: "A=lw-(4-pi)r^2", note: "Rectangle area minus the four rounded corner cutouts.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=2(l+w-4r)+2 pi r", note: "Straight portions plus four quarter-circle arcs.", valueLabel: "Perimeter" },
    ],
    parallelogram: [
      { title: "Area", formula: "A=bh", note: "Base times perpendicular height.", valueLabel: "Area" },
      { title: "Perimeter", formula: "P=2(a+b)", note: "Opposite sides are equal.", valueLabel: "Perimeter" },
      { title: "Vector area", formula: "A=|u x v|", note: "Useful for vector parallelograms." },
    ],
    rhombus: [
      { title: "Area", formula: "A=d1 d2 / 2", note: "Half product of diagonals.", valueLabel: "Area" },
      { title: "Side", formula: "s=sqrt((d1/2)^2+(d2/2)^2)", note: "Right triangle from half-diagonals.", valueLabel: "Side" },
      { title: "Perimeter", formula: "P=4s", note: "Four equal sides.", valueLabel: "Perimeter" },
    ],
    trapezium: [
      { title: "Area", formula: "A=1/2(a+b)h", note: "Average of parallel sides times height.", valueLabel: "Area" },
      { title: "Midline", formula: "m=(a+b)/2", note: "Segment joining leg midpoints.", valueLabel: "Midline" },
    ],
    kite: [
      { title: "Area", formula: "A=d1 d2 / 2", note: "Half product of perpendicular diagonals.", valueLabel: "Area" },
      { title: "Symmetry diagonal", formula: "d_s perpendicular d_o", note: "One diagonal bisects the other in a classic kite." },
    ],
    "regular-polygon": [
      { title: "Perimeter", formula: "P=ns", note: "n equal sides.", valueLabel: "Perimeter" },
      { title: "Area", formula: "A=ns^2/(4 tan(pi/n))", note: "Regular polygon from side and side count.", valueLabel: "Area" },
      { title: "Apothem", formula: "a_p=s/(2 tan(pi/n))", note: "Distance from center to a side.", valueLabel: "Apothem" },
    ],
    pentagon: polygon(5),
    hexagon: polygon(6),
    heptagon: polygon(7),
    octagon: polygon(8),
    nonagon: polygon(9),
    decagon: polygon(10),
    dodecagon: polygon(12),
    cube: [
      { title: "Surface area", formula: "SA=6s^2", note: "Six congruent square faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=s^3", note: "Side cubed.", valueLabel: "Volume" },
      { title: "Space diagonal", formula: "d=s sqrt(3)", note: "Diagonal through the cube.", valueLabel: "Diagonal" },
    ],
    cuboid: [
      { title: "Surface area", formula: "SA=2(lw+lh+wh)", note: "Area of all six rectangular faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=lwh", note: "Length times width times height.", valueLabel: "Volume" },
      { title: "Space diagonal", formula: "d=sqrt(l^2+w^2+h^2)", note: "3D Pythagoras.", valueLabel: "Diagonal" },
    ],
    sphere: [
      { title: "Surface area", formula: "SA=4 pi r^2", note: "Area of the spherical surface.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=4/3 pi r^3", note: "Space enclosed by the sphere.", valueLabel: "Volume" },
      { title: "Great circle", formula: "C=2 pi r", note: "Largest circular cross-section." },
    ],
    hemisphere: [
      { title: "Curved area", formula: "CSA=2 pi r^2", note: "Half of sphere surface.", valueLabel: "Curved area" },
      { title: "Total area", formula: "TSA=3 pi r^2", note: "Curved surface plus circular base.", valueLabel: "Total area" },
      { title: "Volume", formula: "V=2/3 pi r^3", note: "Half sphere volume.", valueLabel: "Volume" },
    ],
    cylinder: [
      { title: "Curved surface area", formula: "CSA=2 pi rh", note: "Rectangle wrapped around the side." },
      { title: "Total surface area", formula: "TSA=2 pi r(r+h)", note: "Curved area plus two circular bases.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=pi r^2h", note: "Base area times height.", valueLabel: "Volume" },
    ],
    "hollow-cylinder": [
      { title: "Material volume", formula: "V=pi h(R^2-r^2)", note: "Outer cylinder minus inner void.", valueLabel: "Material volume" },
      { title: "Outer curved area", formula: "A_o=2 pi Rh", note: "Outer wall area.", valueLabel: "Outer area" },
      { title: "Inner curved area", formula: "A_i=2 pi rh", note: "Inner wall area.", valueLabel: "Inner area" },
    ],
    capsule: [
      { title: "Surface area", formula: "SA=2 pi rh+4 pi r^2", note: "Cylinder wall plus full sphere area.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=pi r^2h+4/3 pi r^3", note: "Cylinder plus two hemispheres.", valueLabel: "Volume" },
    ],
    ellipsoid: [
      { title: "Volume", formula: "V=4/3 pi abc", note: "Sphere stretched along three axes.", valueLabel: "Volume" },
      { title: "Mean radius", formula: "r_bar=(a+b+c)/3", note: "Quick size summary.", valueLabel: "Mean radius" },
    ],
    cone: [
      { title: "Slant height", formula: "l=sqrt(r^2+h^2)", note: "Right triangle from radius and height.", valueLabel: "Slant height" },
      { title: "Surface area", formula: "SA=pi r(r+l)", note: "Base plus curved surface.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=1/3 pi r^2h", note: "One third of matching cylinder.", valueLabel: "Volume" },
    ],
    frustum: [
      { title: "Slant height", formula: "l=sqrt((R-r)^2+h^2)", note: "Side length of the cut cone.", valueLabel: "Slant height" },
      { title: "Surface area", formula: "SA=pi(R+r)l+pi(R^2+r^2)", note: "Lateral area plus both circular ends.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=1/3 pi h(R^2+Rr+r^2)", note: "Conical frustum volume.", valueLabel: "Volume" },
    ],
    tetrahedron: [
      { title: "Surface area", formula: "SA=sqrt(3)s^2", note: "Four equilateral triangle faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=s^3/(6sqrt(2))", note: "Regular tetrahedron volume.", valueLabel: "Volume" },
      { title: "Faces", formula: "F=4", note: "Four triangular faces.", valueLabel: "Faces" },
    ],
    octahedron: [
      { title: "Surface area", formula: "SA=2sqrt(3)s^2", note: "Eight equilateral triangle faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=sqrt(2)s^3/3", note: "Regular octahedron volume.", valueLabel: "Volume" },
      { title: "Faces", formula: "F=8", note: "Eight triangular faces.", valueLabel: "Faces" },
    ],
    dodecahedron: [
      { title: "Surface area", formula: "SA=3sqrt(25+10sqrt(5))s^2", note: "Area of twelve regular pentagonal faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=(15+7sqrt(5))s^3/4", note: "Volume from edge length s.", valueLabel: "Volume" },
      { title: "Faces", formula: "F=12", note: "Twelve regular pentagonal faces.", valueLabel: "Faces" },
      { title: "Edges", formula: "E=30", note: "Edge count.", valueLabel: "Edges" },
      { title: "Vertices", formula: "V=20", note: "Vertex count.", valueLabel: "Vertices" },
    ],
    icosahedron: [
      { title: "Surface area", formula: "SA=5sqrt(3)s^2", note: "Area of twenty equilateral triangular faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=5(3+sqrt(5))s^3/12", note: "Volume from edge length s.", valueLabel: "Volume" },
      { title: "Faces", formula: "F=20", note: "Twenty triangular faces.", valueLabel: "Faces" },
      { title: "Edges", formula: "E=30", note: "Edge count.", valueLabel: "Edges" },
      { title: "Vertices", formula: "V=12", note: "Vertex count.", valueLabel: "Vertices" },
    ],
    "square-pyramid": [
      { title: "Slant height", formula: "l=sqrt((s/2)^2+h^2)", note: "Face height from base midpoint to apex.", valueLabel: "Slant height" },
      { title: "Surface area", formula: "SA=s^2+2sl", note: "Square base plus four triangular faces.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=1/3 s^2h", note: "One third of matching prism.", valueLabel: "Volume" },
    ],
    "triangular-pyramid": [
      { title: "Base area", formula: "B=sqrt(3)s^2/4", note: "Equilateral triangular base.", valueLabel: "Base area" },
      { title: "Volume", formula: "V=1/3 Bh", note: "Pyramid volume from base area and height.", valueLabel: "Volume" },
    ],
    "rectangular-pyramid": [
      { title: "Base area", formula: "B=lw", note: "Rectangular base area.", valueLabel: "Base area" },
      { title: "Volume", formula: "V=1/3 lwh", note: "One third of matching cuboid.", valueLabel: "Volume" },
    ],
    "pentagonal-pyramid": [
      { title: "Base area", formula: "B=5s^2/(4 tan(pi/5))", note: "Area of the regular pentagonal base.", valueLabel: "Base area" },
      { title: "Volume", formula: "V=1/3 Bh", note: "One third of a matching pentagonal prism.", valueLabel: "Volume" },
    ],
    "hexagonal-pyramid": [
      { title: "Base area", formula: "B=3sqrt(3)s^2/2", note: "Area of the regular hexagonal base.", valueLabel: "Base area" },
      { title: "Volume", formula: "V=1/3 Bh", note: "One third of a matching hexagonal prism.", valueLabel: "Volume" },
    ],
    "triangular-prism": prism("1/2 bh", "a+b+c"),
    "pentagonal-prism": prism("5s^2/(4 tan(pi/5))", "5s"),
    "hexagonal-prism": prism("3sqrt(3)s^2/2", "6s"),
    "octagonal-prism": prism("2(1+sqrt(2))s^2", "8s"),
    torus: [
      { title: "Surface area", formula: "SA=4 pi^2 Rr", note: "Area of a swept circle.", valueLabel: "Surface area" },
      { title: "Volume", formula: "V=2 pi^2 Rr^2", note: "Volume of a circle swept around an axis.", valueLabel: "Volume" },
    ],
  };

  return formulas[id] ?? [{ title: "Primary formula", formula: "See selected shape formula", note: "Formula map entry from the selected shape definition." }];
}

function getRelatedFormulaEntries(shape: ShapeDefinition): ShapeFormulaEntry[] {
  const entries: ShapeFormulaEntry[] = [];
  if (shape.kind === "2d") {
    entries.push({ title: "Scale factor for area", formula: "A'=k^2A", note: "When all lengths scale by k, area scales by k squared." });
    entries.push({ title: "Scale factor for perimeter", formula: "P'=kP", note: "Boundary length scales linearly." });
  } else {
    entries.push({ title: "Scale factor for surface area", formula: "SA'=k^2SA", note: "Surface area scales by k squared." });
    entries.push({ title: "Scale factor for volume", formula: "V'=k^3V", note: "Volume scales by k cubed." });
  }
  if (shape.category.includes("Curved")) entries.push({ title: "Circle constant", formula: "pi=C/d", note: "Curved formulas use pi because circular cross-sections are involved." });
  if (shape.id.includes("prism")) entries.push({ title: "General prism rule", formula: "V=(base area)(length)", note: "All prism volumes follow this structure." });
  if (shape.id.includes("pyramid") || shape.id === "cone" || shape.id === "frustum") entries.push({ title: "One-third rule", formula: "V_pyramid=1/3 Bh", note: "Pyramids and cones are one third of matching prisms/cylinders." });
  return entries;
}

function formulaExplanation(id: ShapeId, a: number, b: number, c: number, sides: number, angle: number) {
  if (id === "circle") return `The radius line r=${roundTo(a, 2)} runs from center to edge. Circumference wraps once around the boundary; area fills the disk as pi*r^2.`;
  if (id === "semicircle") return `The diagram shows half a disk. Radius r=${roundTo(a, 2)} controls both the curved arc pi*r and the half-area.`;
  if (id === "sector") return `The amber slice is theta=${roundTo(angle, 0)} degrees out of 360. Arc length and area use the same fraction theta/360.`;
  if (id === "ellipse") return `The horizontal semi-axis a=${roundTo(a, 2)} and vertical semi-axis b=${roundTo(b, 2)} multiply in A=pi*a*b.`;
  if (id === "scalene-triangle") {
    const offset = Math.min(Math.max(c, 0.1), Math.max(0.1, a - 0.1));
    return `The apex is ${roundTo(offset, 2)} units from the left end of the base. This makes the three sides different, while the dashed h=${roundTo(b, 2)} line stays perpendicular to base b=${roundTo(a, 2)} for A=1/2*b*h.`;
  }
  if (id === "equilateral-triangle") return `All three sides are s=${roundTo(a, 2)}. The altitude splits it into two congruent 30-60-90 triangles, so h=sqrt(3)*s/2=${roundTo(Math.sqrt(3) * a / 2, 2)}.`;
  if (id === "isosceles-triangle") return `The altitude bisects base b=${roundTo(a, 2)}, creating two matching right triangles. Each equal side is sqrt(h^2+(b/2)^2).`;
  if (id.includes("triangle")) return `The base b=${roundTo(a, 2)} and its perpendicular height h=${roundTo(b, 2)} give A=1/2*b*h. A height must meet the base at 90°.`;
  if (id === "square") return `Every side is s=${roundTo(a, 2)}. Area counts s by s square units, while perimeter walks four equal sides.`;
  if (id === "rectangle") return `Length l=${roundTo(a, 2)} and width w=${roundTo(b, 2)} define the rectangle, so A=l*w and P=2(l+w).`;
  if (id === "rounded-rectangle") return `Length l=${roundTo(a, 2)}, width w=${roundTo(b, 2)}, and corner radius r=${roundTo(Math.min(c, a / 2, b / 2), 2)} define the rounded rectangle.`;
  if (id === "parallelogram") return `Base b=${roundTo(a, 2)} times perpendicular height h=${roundTo(b, 2)} gives area; the slanted side controls perimeter.`;
  if (id === "rhombus" || id === "kite") return `The diagonals d1=${roundTo(a, 2)} and d2=${roundTo(b, 2)} cross. Their rectangle is twice the shape area, so A=d1*d2/2.`;
  if (id === "trapezium") return `Parallel sides a=${roundTo(a, 2)} and b=${roundTo(b, 2)} are averaged, then multiplied by height h=${roundTo(c, 2)}.`;
  if (isFixedRegularPolygon(id) || id === "regular-polygon") return `${polygonSideCount(id, sides)} equal sides of length s=${roundTo(a, 2)} form the perimeter. Area can be split into equal center triangles.`;
  if (id === "annulus") return `The outer radius R=${roundTo(a, 2)} and inner radius r=${roundTo(b, 2)} make a ring area by subtracting two circle areas.`;
  if (id === "quadrant") return `A quadrant is one-fourth of a full circle, so both area and arc length are one-fourth of their circle values.`;
  if (id === "segment") return `The chord cuts off a circular segment. Its area equals sector area minus the isosceles triangle area.`;
  if (id === "crescent") return `Two offset circular arcs make a crescent. Compare the larger disk with the overlapping smaller disk.`;
  if (id === "star") return `Outer radius R=${roundTo(a, 2)} and inner radius r=${roundTo(b, 2)} alternate around the center to form triangular spikes.`;
  if (id === "cross") return `A vertical rectangle and horizontal rectangle overlap at the center; subtract the overlap once to get area.`;
  if (id === "cube") return `Side s=${roundTo(a, 2)} builds 6 identical square faces and volume s*s*s.`;
  if (id === "cuboid") return `Length l=${roundTo(a, 2)}, breadth b=${roundTo(b, 2)}, and height h=${roundTo(c, 2)} multiply for volume.`;
  if (id === "sphere" || id === "hemisphere" || id === "ellipsoid") return `Radius or axes run from center to surface. Surface area and volume respond strongly to squared and cubed dimensions.`;
  if (id === "cylinder" || id === "hollow-cylinder" || id === "capsule") return `Circular radius r=${roundTo(a, 2)} builds the base area, then height or length h=${roundTo(b, 2)} extends it through space.`;
  if (id === "cone") return `Radius r=${roundTo(a, 2)}, height h=${roundTo(b, 2)}, and slant l=${roundTo(Math.hypot(a, b), 2)} define the curved surface and one-third cylinder volume.`;
  if (id === "frustum") return `Bottom radius R=${roundTo(a, 2)}, top radius r=${roundTo(b, 2)}, and height h=${roundTo(c, 2)} describe a sliced cone.`;
  if (id.includes("pyramid") || isPlatonicSolid(id)) return `The base area and height create a pyramid-style volume, while triangular faces reveal the solid's symmetry.`;
  if (id.includes("prism")) return `The base polygon area is extruded through length L=${roundTo(id === "triangular-prism" ? c : b, 2)} to create volume.`;
  return `Major radius R=${roundTo(a, 2)} goes around the ring; minor radius r=${roundTo(b, 2)} controls the tube thickness.`;
}

function symbolSummary(id: ShapeId, a: number, b: number, c: number, sides: number, angle: number) {
  if (["circle", "semicircle", "sphere", "hemisphere", "quadrant", "tetrahedron", "octahedron", "dodecahedron", "icosahedron"].includes(id)) return `r/s=${roundTo(a, 2)}`;
  if (id === "sector" || id === "segment") return `r=${roundTo(a, 2)}, theta=${roundTo(angle, 0)} deg`;
  if (id === "ellipse") return `a=${roundTo(a, 2)}, b=${roundTo(b, 2)}`;
  if (id === "annulus" || id === "crescent" || id === "star" || id === "torus" || id === "hollow-cylinder") return `R=${roundTo(a, 2)}, r=${roundTo(b, 2)}`;
  if (id === "rectangle") return `l=${roundTo(a, 2)}, w=${roundTo(b, 2)}`;
  if (id === "cross") return `a=${roundTo(a, 2)}, w=${roundTo(b, 2)}`;
  if (id === "rounded-rectangle") return `l=${roundTo(a, 2)}, w=${roundTo(b, 2)}, r=${roundTo(Math.min(c, a / 2, b / 2), 2)}`;
  if (id === "scalene-triangle") return `b=${roundTo(a, 2)}, h=${roundTo(b, 2)}, x=${roundTo(Math.min(Math.max(c, 0.1), Math.max(0.1, a - 0.1)), 2)}`;
  if (id.includes("triangle") || id === "parallelogram") return id === "equilateral-triangle" ? `s=${roundTo(a, 2)}` : `b=${roundTo(a, 2)}, h=${roundTo(b, 2)}`;
  if (id === "square" || id === "cube" || isFixedRegularPolygon(id)) return `s=${roundTo(a, 2)}`;
  if (id === "rhombus" || id === "kite") return `d1=${roundTo(a, 2)}, d2=${roundTo(b, 2)}`;
  if (id === "trapezium") return `a=${roundTo(a, 2)}, b=${roundTo(b, 2)}, h=${roundTo(c, 2)}`;
  if (id === "regular-polygon") return `n=${sides}, s=${roundTo(a, 2)}`;
  if (id === "cuboid" || id === "ellipsoid" || id === "rectangular-pyramid") return `l/a=${roundTo(a, 2)}, b=${roundTo(b, 2)}, h/c=${roundTo(c, 2)}`;
  if (id === "cylinder" || id === "capsule") return `r=${roundTo(a, 2)}, h=${roundTo(b, 2)}`;
  if (id === "cone") return `r=${roundTo(a, 2)}, h=${roundTo(b, 2)}, l=${roundTo(Math.hypot(a, b), 2)}`;
  if (id === "frustum") return `R=${roundTo(a, 2)}, r=${roundTo(b, 2)}, h=${roundTo(c, 2)}`;
  if (id.includes("pyramid")) return `s=${roundTo(a, 2)}, h=${roundTo(b, 2)}`;
  if (id === "triangular-prism") return `b=${roundTo(a, 2)}, h=${roundTo(b, 2)}, L=${roundTo(c, 2)}`;
  if (id.includes("prism")) return `s=${roundTo(a, 2)}, L=${roundTo(b, 2)}`;
  return `R=${roundTo(a, 2)}, r=${roundTo(b, 2)}`;
}

type ShapeViewControlsProps = {
  kind: ShapeKind;
  zoom: number;
  rotation: number;
  autoRotate: boolean;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onRotateLeft: () => void;
  onRotateRight: () => void;
  onReset: () => void;
  onToggleAutoRotate: () => void;
};

function ShapeViewControls({ kind, zoom, rotation, autoRotate, onZoomIn, onZoomOut, onRotateLeft, onRotateRight, onReset, onToggleAutoRotate }: ShapeViewControlsProps) {
  return (
    <div className="space-y-3 rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-slate-950/60">
      <div className="flex flex-nowrap items-center gap-2 overflow-x-auto pb-1" aria-label="View controls">
        <IconButton label="Zoom out" onClick={onZoomOut} disabled={zoom <= 0.55}>
          <ZoomOut className="h-4 w-4" />
        </IconButton>
        <IconButton label="Zoom in" onClick={onZoomIn} disabled={zoom >= 2}>
          <ZoomIn className="h-4 w-4" />
        </IconButton>
        <IconButton label="Rotate left" onClick={onRotateLeft}>
          <RotateCcw className="h-4 w-4" />
        </IconButton>
        <IconButton label="Rotate right" onClick={onRotateRight}>
          <RotateCw className="h-4 w-4" />
        </IconButton>
        <IconButton label={autoRotate ? "Pause auto-rotate" : "Play auto-rotate"} onClick={onToggleAutoRotate}>
          {autoRotate ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </IconButton>
        <IconButton label="Reset view" onClick={onReset}>
          <RefreshCw className="h-4 w-4" />
        </IconButton>
      </div>
      <div className="flex flex-wrap gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
        <span className="mini-chip">Zoom {roundTo(zoom * 100, 0)}%</span>
        <span className="mini-chip">Rotate {rotation} deg</span>
        <span className="mini-chip">{kind === "2d" ? "2D + extruded 3D" : "solid 3D"}</span>
      </div>
    </div>
  );
}

function IconButton({ label, onClick, disabled, children }: { label: string; onClick: () => void; disabled?: boolean; children: ReactNode }) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-700 transition hover:bg-cyan-100 hover:text-cyan-700 disabled:cursor-not-allowed disabled:opacity-40 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-300/15 dark:hover:text-cyan-100 sm:h-10 sm:w-10"
    >
      {children}
    </button>
  );
}

function ShapeLearningGuide({ shape }: { shape: ShapeDefinition }) {
  const facts = shapeIdentityFacts(shape.id);
  return (
    <section className="rounded-xl border border-amber-200 bg-amber-50/90 p-3 dark:border-amber-300/20 dark:bg-amber-300/10" aria-label={`How to recognize ${shape.name}`}>
      <p className="text-xs font-black uppercase tracking-wide text-amber-800 dark:text-amber-200">How to recognize it</p>
      <ul className="mt-2 space-y-1.5 text-xs leading-5 text-slate-700 dark:text-slate-200">
        {facts.map((fact) => <li key={fact} className="flex gap-2"><span aria-hidden="true" className="font-black text-amber-600">✓</span><span>{fact}</span></li>)}
      </ul>
    </section>
  );
}

function shapeIdentityFacts(id: ShapeId): string[] {
  const triangleFacts: Partial<Record<ShapeId, string[]>> = {
    triangle: ["Exactly 3 straight sides and 3 angles.", "No side equality or special angle is assumed."],
    "right-triangle": ["One angle is exactly 90° (look for the small square).", "The side opposite 90° is the hypotenuse and is longest."],
    "equilateral-triangle": ["All 3 sides are equal (matching tick marks).", "All 3 angles are 60°; it has 3 lines of symmetry."],
    "isosceles-triangle": ["Exactly 2 sides are equal (matching tick marks).", "The 2 base angles are equal; the central altitude is also a symmetry line."],
    "scalene-triangle": ["All 3 sides have different lengths.", "All 3 angles are different; there is no line of symmetry."],
  };
  if (triangleFacts[id]) return triangleFacts[id]!;
  if (["circle", "semicircle", "sector", "quadrant", "segment", "annulus", "crescent", "ellipse"].includes(id)) {
    return ["Its boundary includes a curved circular or elliptical part.", "Use radii, axes, or a central angle—not a side length—to size it."];
  }
  if (isFixedRegularPolygon(id) || id === "regular-polygon") {
    return ["It is a closed polygon made only from straight sides.", "In this regular model, every side and every interior angle is equal."];
  }
  if (["square", "rectangle", "rounded-rectangle", "parallelogram", "rhombus", "trapezium", "kite", "cross", "star"].includes(id)) {
    return [shapeDescriptionProperty(id), "Area measures the inside; perimeter measures the complete boundary."];
  }
  if (id.includes("prism")) return ["It has 2 congruent, parallel polygon bases.", "Its side faces connect matching edges; volume = base area × length."];
  if (id.includes("pyramid")) return ["It has 1 polygon base and triangular faces meeting at one apex.", "Its perpendicular height meets the base at 90°; volume = ⅓ × base area × height."];
  if (["tetrahedron", "octahedron", "dodecahedron", "icosahedron", "cube", "cuboid"].includes(id)) {
    return ["It is a 3D solid with flat faces, edges, and vertices.", "Surface area covers the outside; volume measures the space inside."];
  }
  return ["It is a 3D solid with a curved surface.", "The diagram distinguishes radius from perpendicular height or tube radius."];
}

function shapeDescriptionProperty(id: ShapeId) {
  const properties: Partial<Record<ShapeId, string>> = {
    square: "4 equal sides and 4 right angles.", rectangle: "Opposite sides are equal and all 4 angles are right angles.",
    "rounded-rectangle": "A rectangle with 4 quarter-circle corners.", parallelogram: "Both pairs of opposite sides are parallel and equal.",
    rhombus: "All 4 sides are equal; opposite angles are equal.", trapezium: "Exactly one pair of opposite sides is parallel in this model.",
    kite: "Two pairs of adjacent sides are equal.", cross: "Two equal-width rectangles cross at right angles.", star: "5 outer points alternate with 5 inner corners.",
  };
  return properties[id] ?? "Compare its sides, angles, parallel lines, and symmetry.";
}

const futuristicPalettes = [
  { name: "Cyan violet", a: "#22d3ee", b: "#8b5cf6" },
  { name: "Electric blue", a: "#38bdf8", b: "#2563eb" },
  { name: "Neon magenta", a: "#f472b6", b: "#9333ea" },
  { name: "Aurora", a: "#34d399", b: "#06b6d4" },
];

const thumbnailAliases: Partial<Record<ShapeId, string>> = {
  segment: "circular-segment",
  star: "star-polygon",
  cross: "cross-shape",
};

export const shapeThumbnailPath = (id: ShapeId) => `/assets/shapes/thumbnails/${thumbnailAliases[id] ?? id}.png`;

export const shapes: ShapeDefinition[] = shapeSeeds.map((shape) => ({
  ...shape,
  thumbnail: shapeThumbnailPath(shape.id),
}));

function ShapeAppearanceControls({ fillMode, onFillMode, colorA, colorB, onColorA, onColorB, glow, onGlow, grid, onGrid }: {
  fillMode: ShapeFillMode;
  onFillMode: (mode: ShapeFillMode) => void;
  colorA: string;
  colorB: string;
  onColorA: (color: string) => void;
  onColorB: (color: string) => void;
  glow: boolean;
  onGlow: () => void;
  grid: boolean;
  onGrid: () => void;
}) {
  return (
    <div className="rounded-xl border border-violet-200/80 bg-gradient-to-br from-slate-950 via-indigo-950 to-violet-950 p-3 text-white shadow-lg shadow-violet-500/10">
      <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wide text-cyan-200"><Palette className="h-4 w-4" /> Appearance</div>
      <div className="mt-3 grid grid-cols-3 gap-1 rounded-lg bg-black/25 p-1">
        {(["gradient", "solid", "outline"] as ShapeFillMode[]).map((mode) => (
          <button key={mode} type="button" aria-pressed={fillMode === mode} onClick={() => onFillMode(mode)} className={`rounded-md px-2 py-2 text-xs font-bold capitalize transition ${fillMode === mode ? "bg-gradient-to-r from-cyan-500 to-violet-500 text-white shadow-[0_0_16px_rgba(139,92,246,.45)]" : "text-slate-300 hover:bg-white/10"}`}>{mode === "outline" ? "No fill" : mode}</button>
        ))}
      </div>
      <div className="mt-3 flex items-center justify-between gap-3">
        <label className="flex items-center gap-2 text-xs font-semibold text-slate-300">Color 1 <input aria-label="Primary shape color" type="color" value={colorA} onChange={(event) => onColorA(event.target.value)} className="h-8 w-10 cursor-pointer rounded border-0 bg-transparent" /></label>
        <label className={`flex items-center gap-2 text-xs font-semibold text-slate-300 ${fillMode === "solid" ? "opacity-45" : ""}`}>Color 2 <input aria-label="Secondary shape color" type="color" value={colorB} onChange={(event) => onColorB(event.target.value)} disabled={fillMode === "solid"} className="h-8 w-10 cursor-pointer rounded border-0 bg-transparent disabled:cursor-not-allowed" /></label>
      </div>
      <div className="mt-2 flex gap-2" aria-label="Color presets">
        {futuristicPalettes.map((palette) => (
          <button key={palette.name} type="button" title={palette.name} aria-label={palette.name} onClick={() => { onColorA(palette.a); onColorB(palette.b); }} className="h-7 flex-1 rounded-full border border-white/20 transition hover:-translate-y-0.5 hover:border-white/60" style={{ background: `linear-gradient(135deg, ${palette.a}, ${palette.b})` }} />
        ))}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button type="button" aria-pressed={glow} onClick={onGlow} className={`flex items-center justify-center gap-2 rounded-lg px-2 py-2 text-xs font-bold ${glow ? "bg-cyan-400/20 text-cyan-100 ring-1 ring-cyan-300/50" : "bg-white/5 text-slate-400"}`}><Sparkles className="h-4 w-4" /> Glow</button>
        <button type="button" aria-pressed={grid} onClick={onGrid} className={`flex items-center justify-center gap-2 rounded-lg px-2 py-2 text-xs font-bold ${grid ? "bg-violet-400/20 text-violet-100 ring-1 ring-violet-300/50" : "bg-white/5 text-slate-400"}`}><Grid3X3 className="h-4 w-4" /> Grid</button>
      </div>
    </div>
  );
}

function InteractiveShape2D({ children, resetKey, onZoomIn, onZoomOut }: { children: ReactNode; resetKey: string; onZoomIn: () => void; onZoomOut: () => void }) {
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragStart = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null);

  useEffect(() => setPan({ x: 0, y: 0 }), [resetKey]);

  return (
    <div
      className="flex h-full w-full touch-none select-none items-center justify-center overflow-hidden active:cursor-grabbing"
      onWheel={(event) => {
        event.preventDefault();
        if (event.deltaY < 0) onZoomIn();
        else onZoomOut();
      }}
      onPointerDown={(event) => {
        event.currentTarget.setPointerCapture(event.pointerId);
        dragStart.current = { x: event.clientX, y: event.clientY, panX: pan.x, panY: pan.y };
      }}
      onPointerMove={(event) => {
        if (!dragStart.current) return;
        setPan({ x: dragStart.current.panX + event.clientX - dragStart.current.x, y: dragStart.current.panY + event.clientY - dragStart.current.y });
      }}
      onPointerUp={() => { dragStart.current = null; }}
      onPointerCancel={() => { dragStart.current = null; }}
    >
      <div className="w-full transition-transform duration-75" style={{ transform: `translate(${pan.x}px, ${pan.y}px)` }}>{children}</div>
    </div>
  );
}

function startHeightResize(event: PointerEvent<HTMLDivElement>, currentHeight: number, setHeight: (value: number) => void) {
  event.preventDefault();
  const startY = event.clientY;
  const pointerId = event.pointerId;
  event.currentTarget.setPointerCapture(pointerId);

  const handleMove = (moveEvent: globalThis.PointerEvent) => {
    setHeight(Math.min(760, Math.max(360, currentHeight + moveEvent.clientY - startY)));
  };

  const cleanup = () => {
    window.removeEventListener("pointermove", handleMove);
    window.removeEventListener("pointerup", cleanup);
    window.removeEventListener("pointercancel", cleanup);
  };

  window.addEventListener("pointermove", handleMove);
  window.addEventListener("pointerup", cleanup);
  window.addEventListener("pointercancel", cleanup);
}

const shapeControlLabels: Record<ShapeId, readonly [string, string?, string?]> = {
  circle: ["Radius"],
  semicircle: ["Radius"],
  sector: ["Radius"],
  ellipse: ["Semi-major axis a", "Semi-minor axis b"],
  triangle: ["Base", "Perpendicular height"],
  "right-triangle": ["Leg a (base)", "Leg b (height)"],
  "equilateral-triangle": ["Side"],
  "isosceles-triangle": ["Base", "Perpendicular height"],
  "scalene-triangle": ["Base", "Perpendicular height", "Apex offset from left"],
  square: ["Side"],
  rectangle: ["Length", "Width"],
  "rounded-rectangle": ["Length", "Width", "Corner radius"],
  parallelogram: ["Base", "Perpendicular height", "Slanted side"],
  rhombus: ["Diagonal d1", "Diagonal d2"],
  trapezium: ["Base a", "Top base b", "Perpendicular height"],
  kite: ["Diagonal d1", "Diagonal d2"],
  pentagon: ["Side"],
  hexagon: ["Side"],
  heptagon: ["Side"],
  octagon: ["Side"],
  nonagon: ["Side"],
  decagon: ["Side"],
  dodecagon: ["Side"],
  "regular-polygon": ["Side"],
  annulus: ["Outer radius R", "Inner radius r"],
  quadrant: ["Radius"],
  segment: ["Radius"],
  crescent: ["Outer radius R", "Inner radius r"],
  star: ["Outer radius R", "Inner radius r"],
  cross: ["Arm half-length a", "Arm width w"],
  cube: ["Side"],
  cuboid: ["Length", "Width", "Height"],
  sphere: ["Radius"],
  hemisphere: ["Radius"],
  cylinder: ["Radius", "Height"],
  "hollow-cylinder": ["Outer radius R", "Inner radius r", "Height"],
  capsule: ["Radius", "Cylinder length"],
  ellipsoid: ["Semi-axis a", "Semi-axis b", "Semi-axis c"],
  cone: ["Radius", "Perpendicular height"],
  frustum: ["Bottom radius R", "Top radius r", "Perpendicular height"],
  torus: ["Major radius R", "Minor radius r"],
  tetrahedron: ["Edge length"],
  octahedron: ["Edge length"],
  dodecahedron: ["Edge length"],
  icosahedron: ["Edge length"],
  "square-pyramid": ["Base side", "Perpendicular height"],
  "triangular-pyramid": ["Base side", "Perpendicular height"],
  "rectangular-pyramid": ["Base length", "Base width", "Perpendicular height"],
  "pentagonal-pyramid": ["Base side", "Perpendicular height"],
  "hexagonal-pyramid": ["Base side", "Perpendicular height"],
  "triangular-prism": ["Triangle base", "Triangle height", "Prism length"],
  "pentagonal-prism": ["Base side", "Prism length"],
  "hexagonal-prism": ["Base side", "Prism length"],
  "octagonal-prism": ["Base side", "Prism length"],
};

function primaryLabel(shape: ShapeDefinition) {
  return shapeControlLabels[shape.id][0];
}

function secondLabel(shape: ShapeDefinition) {
  return shapeControlLabels[shape.id][1] ?? "Second dimension";
}

function thirdLabel(shape: ShapeDefinition) {
  return shapeControlLabels[shape.id][2] ?? "Third dimension";
}

function needsSecond(id: ShapeId) {
  return Boolean(shapeControlLabels[id][1]);
}

function needsThird(id: ShapeId) {
  return Boolean(shapeControlLabels[id][2]);
}

function secondControlRange(id: ShapeId, firstValue: number) {
  const boundedInnerRadius = ["annulus", "crescent", "star", "torus", "hollow-cylinder"].includes(id);
  if (boundedInnerRadius) return { min: 0.1, max: Math.max(0.1, roundTo(firstValue - 0.1, 1)) };
  if (id === "cross") return { min: 0.1, max: Math.max(0.1, roundTo(firstValue * 2, 1)) };
  return { min: 0.5, max: 10 };
}

function thirdControlRange(id: ShapeId, firstValue: number, secondValue: number) {
  if (id === "rounded-rectangle") return { min: 0.1, max: Math.max(0.1, roundTo(Math.min(firstValue, secondValue) / 2, 1)) };
  if (id === "scalene-triangle") return { min: 0.1, max: Math.max(0.2, roundTo(firstValue - 0.1, 1)) };
  return { min: 0.5, max: 12 };
}

function getMetrics(id: ShapeId, a: number, b: number, c: number, n: number, angle: number): Metrics {
  const fixedSides = polygonSideCount(id, n);
  const innerRadius = Math.min(b, Math.max(0.1, a - 0.1));
  const armWidth = Math.min(b, 2 * a);
  switch (id) {
    case "circle": return { Circumference: 2 * Math.PI * a, Area: Math.PI * a * a };
    case "semicircle": return { "Arc length": Math.PI * a, Perimeter: Math.PI * a + 2 * a, Area: Math.PI * a * a / 2 };
    case "sector": return { "Arc length": angle / 360 * 2 * Math.PI * a, Area: angle / 360 * Math.PI * a * a };
    case "quadrant": return { "Arc length": Math.PI * a / 2, Area: Math.PI * a * a / 4, Perimeter: Math.PI * a / 2 + 2 * a };
    case "segment": return { "Arc length": angle / 360 * 2 * Math.PI * a, Area: (a * a / 2) * (((angle * Math.PI) / 180) - Math.sin((angle * Math.PI) / 180)) };
    case "ellipse": return { Area: Math.PI * a * b, "Approx perimeter": Math.PI * (3 * (a + b) - Math.sqrt((3 * a + b) * (a + 3 * b))) };
    case "annulus": return { Area: Math.PI * (a * a - innerRadius * innerRadius), "Outer circumference": 2 * Math.PI * a, "Inner circumference": 2 * Math.PI * innerRadius };
    case "crescent": return { "Approx area": Math.max(0, Math.PI * (a * a - innerRadius * innerRadius * 0.72)), "Outer arc": Math.PI * a, "Inner arc": Math.PI * innerRadius };
    case "star": return { Area: 5 * a * innerRadius * Math.sin((36 * Math.PI) / 180), Points: 5 };
    case "cross": return { Area: 4 * a * armWidth - armWidth * armWidth, Perimeter: 8 * a };
    case "triangle": return { Area: a * b / 2, "Shown base": a, "Shown height": b };
    case "right-triangle": return { Area: a * b / 2, Hypotenuse: Math.hypot(a, b), Perimeter: a + b + Math.hypot(a, b) };
    case "equilateral-triangle": return { Area: Math.sqrt(3) * a * a / 4, Perimeter: 3 * a, Height: Math.sqrt(3) * a / 2 };
    case "isosceles-triangle": { const side = Math.hypot(a / 2, b); return { Area: a * b / 2, "Equal side": side, Perimeter: a + 2 * side }; }
    case "scalene-triangle": {
      const offset = Math.min(Math.max(c, 0.1), Math.max(0.1, a - 0.1));
      const leftSide = Math.hypot(offset, b);
      const rightSide = Math.hypot(a - offset, b);
      return { Area: a * b / 2, "Left side": leftSide, "Right side": rightSide, Perimeter: a + leftSide + rightSide };
    }
    case "square": return { Area: a * a, Perimeter: 4 * a, Diagonal: a * Math.SQRT2 };
    case "rectangle": return { Area: a * b, Perimeter: 2 * (a + b), Diagonal: Math.hypot(a, b) };
    case "rounded-rectangle": { const r = Math.min(c, a / 2, b / 2); return { Area: a * b - (4 - Math.PI) * r * r, Perimeter: 2 * (a + b - 4 * r) + 2 * Math.PI * r, "Corner radius": r }; }
    case "parallelogram": return { Area: a * b, Perimeter: 2 * (a + c) };
    case "rhombus": return { Area: a * b / 2, Side: Math.hypot(a / 2, b / 2), Perimeter: 4 * Math.hypot(a / 2, b / 2) };
    case "trapezium": return { Area: (a + b) * c / 2, "Midline": (a + b) / 2 };
    case "kite": return { Area: a * b / 2 };
    case "regular-polygon":
    case "pentagon":
    case "hexagon":
    case "heptagon":
    case "octagon":
    case "nonagon":
    case "decagon": return { Perimeter: fixedSides * a, Area: fixedSides * a * a / (4 * Math.tan(Math.PI / fixedSides)), Apothem: a / (2 * Math.tan(Math.PI / fixedSides)) };
    case "dodecagon": return { Perimeter: fixedSides * a, Area: fixedSides * a * a / (4 * Math.tan(Math.PI / fixedSides)), Apothem: a / (2 * Math.tan(Math.PI / fixedSides)) };
    case "cube": return { "Surface area": 6 * a * a, Volume: a ** 3, Diagonal: a * Math.sqrt(3) };
    case "cuboid": return { "Surface area": 2 * (a * b + a * c + b * c), Volume: a * b * c, Diagonal: Math.hypot(a, b, c) };
    case "sphere": return { "Surface area": 4 * Math.PI * a * a, Volume: 4 / 3 * Math.PI * a ** 3 };
    case "hemisphere": return { "Curved area": 2 * Math.PI * a * a, "Total area": 3 * Math.PI * a * a, Volume: 2 / 3 * Math.PI * a ** 3 };
    case "cylinder": return { "Surface area": 2 * Math.PI * a * (a + b), Volume: Math.PI * a * a * b };
    case "hollow-cylinder": return { "Material volume": Math.PI * c * (a * a - innerRadius * innerRadius), "Outer area": 2 * Math.PI * a * c, "Inner area": 2 * Math.PI * innerRadius * c };
    case "capsule": return { "Surface area": 2 * Math.PI * a * b + 4 * Math.PI * a * a, Volume: Math.PI * a * a * b + 4 / 3 * Math.PI * a ** 3 };
    case "ellipsoid": return { Volume: 4 / 3 * Math.PI * a * b * c, "Mean radius": (a + b + c) / 3 };
    case "cone": return { "Slant height": Math.hypot(a, b), "Surface area": Math.PI * a * (a + Math.hypot(a, b)), Volume: Math.PI * a * a * b / 3 };
    case "frustum": return { "Slant height": Math.hypot(a - b, c), "Surface area": Math.PI * (a + b) * Math.hypot(a - b, c) + Math.PI * (a * a + b * b), Volume: Math.PI * c * (a * a + a * b + b * b) / 3 };
    case "tetrahedron": return { "Surface area": Math.sqrt(3) * a * a, Volume: a ** 3 / (6 * Math.sqrt(2)), Faces: 4 };
    case "octahedron": return { "Surface area": 2 * Math.sqrt(3) * a * a, Volume: Math.sqrt(2) * a ** 3 / 3, Faces: 8 };
    case "dodecahedron": return { "Surface area": 3 * Math.sqrt(25 + 10 * Math.sqrt(5)) * a * a, Volume: (15 + 7 * Math.sqrt(5)) * a ** 3 / 4, Faces: 12, Edges: 30, Vertices: 20 };
    case "icosahedron": return { "Surface area": 5 * Math.sqrt(3) * a * a, Volume: 5 * (3 + Math.sqrt(5)) * a ** 3 / 12, Faces: 20, Edges: 30, Vertices: 12 };
    case "square-pyramid": return { "Slant height": Math.hypot(a / 2, b), "Surface area": a * a + 2 * a * Math.hypot(a / 2, b), Volume: a * a * b / 3 };
    case "triangular-pyramid": return { "Base area": Math.sqrt(3) * a * a / 4, Volume: (Math.sqrt(3) * a * a / 4) * b / 3 };
    case "rectangular-pyramid": return { "Base area": a * b, Volume: a * b * c / 3 };
    case "pentagonal-pyramid": { const baseArea = 5 * a * a / (4 * Math.tan(Math.PI / 5)); return { "Base area": baseArea, Volume: baseArea * b / 3 }; }
    case "hexagonal-pyramid": { const baseArea = 3 * Math.sqrt(3) * a * a / 2; return { "Base area": baseArea, Volume: baseArea * b / 3 }; }
    case "triangular-prism": return { "Base area": a * b / 2, Volume: a * b * c / 2 };
    case "pentagonal-prism": return { "Base area": 5 * a * a / (4 * Math.tan(Math.PI / 5)), Volume: 5 * a * a * b / (4 * Math.tan(Math.PI / 5)) };
    case "hexagonal-prism": return { "Base area": 3 * Math.sqrt(3) * a * a / 2, Volume: 3 * Math.sqrt(3) * a * a * b / 2 };
    case "octagonal-prism": { const baseArea = 2 * (1 + Math.SQRT2) * a * a; return { "Base area": baseArea, Volume: baseArea * b }; }
    case "torus": return { "Surface area": 4 * Math.PI * Math.PI * a * innerRadius, Volume: 2 * Math.PI * Math.PI * a * innerRadius * innerRadius };
    default: return {};
  }
}

function isFixedRegularPolygon(id: ShapeId) {
  return ["pentagon", "hexagon", "heptagon", "octagon", "nonagon", "decagon", "dodecagon"].includes(id);
}

function polygonSideCount(id: ShapeId, fallback: number) {
  const counts: Partial<Record<ShapeId, number>> = { pentagon: 5, hexagon: 6, heptagon: 7, octagon: 8, nonagon: 9, decagon: 10, dodecagon: 12, "triangular-prism": 3, "pentagonal-prism": 5, "hexagonal-prism": 6, "octagonal-prism": 8 };
  return counts[id] ?? fallback;
}

function isPlatonicSolid(id: ShapeId) {
  return ["tetrahedron", "octahedron", "dodecahedron", "icosahedron"].includes(id);
}

function ShapeSvg({ shape, a, b, c, sides, angle, zoom, rotation, fillMode, colorA, colorB, glow }: { shape: ShapeId; a: number; b: number; c: number; sides: number; angle: number; zoom: number; rotation: number; fillMode: ShapeFillMode; colorA: string; colorB: string; glow: boolean }) {
  const scale = 18;
  const cx = 240;
  const cy = 180;
  const radius = Math.min(a * scale, 140);
  const w = Math.min(a * scale * 2, 300);
  const h = Math.min(b * scale * 2, 230);
  const top = Math.min(b * scale * 2, 230);
  const height = Math.min((c || b) * scale * 2, 230);
  const sectorTheta = (angle * Math.PI) / 180;
  const sectorX = cx + radius * Math.cos(sectorTheta);
  const sectorY = cy - radius * Math.sin(sectorTheta);
  const displaySides = polygonSideCount(shape, sides);
  const polygonPoints = Array.from({ length: displaySides }, (_, index) => {
    const theta = -Math.PI / 2 + (index * 2 * Math.PI) / displaySides;
    return `${cx + radius * Math.cos(theta)},${cy + radius * Math.sin(theta)}`;
  }).join(" ");
  const starPoints = Array.from({ length: 10 }, (_, index) => {
    const theta = -Math.PI / 2 + (index * Math.PI) / 5;
    const r = index % 2 === 0 ? radius : Math.max(24, Math.min(b * scale, radius * 0.62));
    return `${cx + r * Math.cos(theta)},${cy + r * Math.sin(theta)}`;
  }).join(" ");
  const scaleneOffset = Math.min(Math.max(c, 0.1), Math.max(0.1, a - 0.1));
  const triangleApexX = shape === "scalene-triangle" ? cx - w / 2 + (scaleneOffset / a) * w : shape === "triangle" ? cx + w * 0.18 : cx;
  const equilateralRise = Math.min(w * Math.sqrt(3) / 6, 75);
  const triangleBaseY = shape === "equilateral-triangle" ? cy + equilateralRise : cy + h / 2;
  const triangleTopY = shape === "equilateral-triangle" ? cy - 2 * equilateralRise : cy - h / 2;

  return (
    <svg viewBox="0 0 480 360" className="h-[300px] w-full sm:h-[360px]">
      <defs>
        <linearGradient id="shapeFill" x1="0" x2="1">
          <stop offset="0%" stopColor={colorA} stopOpacity="0.72" />
          <stop offset="100%" stopColor={colorB} stopOpacity="0.58" />
        </linearGradient>
      </defs>
      <style>{`[data-shape-art] > :not(line):not(text) { fill: ${fillMode === "outline" ? "none" : fillMode === "solid" ? colorA : "url(#shapeFill)"} !important; stroke: ${fillMode === "solid" ? colorB : colorA} !important; stroke-width: 4px; filter: ${glow ? `drop-shadow(0 0 5px ${colorA}) drop-shadow(0 0 12px ${colorB})` : "none"}; }`}</style>
      <g data-shape-art transform={`translate(${cx} ${cy}) rotate(${rotation}) scale(${zoom}) translate(${-cx} ${-cy})`}>
        {shape === "circle" && <circle cx={cx} cy={cy} r={radius} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "semicircle" && <path d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy} L ${cx - radius} ${cy}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "sector" && <path d={`M ${cx} ${cy} L ${cx + radius} ${cy} A ${radius} ${radius} 0 ${angle > 180 ? 1 : 0} 0 ${sectorX} ${sectorY} Z`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "quadrant" && <path d={`M ${cx} ${cy} L ${cx + radius} ${cy} A ${radius} ${radius} 0 0 0 ${cx} ${cy - radius} Z`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "segment" && <path d={`M ${cx + radius} ${cy} A ${radius} ${radius} 0 ${angle > 180 ? 1 : 0} 0 ${sectorX} ${sectorY} L ${cx + radius} ${cy}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "ellipse" && <ellipse cx={cx} cy={cy} rx={Math.min(a * scale, 170)} ry={Math.min(b * scale, 120)} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "annulus" && <path d={`${ringPath(cx, cy, radius, Math.max(18, Math.min(b * scale, radius - 12)))}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" fillRule="evenodd" />}
        {shape === "crescent" && <path d={`M ${cx - radius * 0.35} ${cy - radius} A ${radius} ${radius} 0 1 0 ${cx - radius * 0.35} ${cy + radius} A ${Math.max(20, b * scale)} ${Math.max(20, b * scale)} 0 1 1 ${cx - radius * 0.35} ${cy - radius} Z`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "triangle" && <polygon points={`${cx - w / 2},${cy + h / 2} ${cx + w / 2},${cy + h / 2} ${triangleApexX},${cy - h / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "right-triangle" && <polygon points={`${cx - w / 2},${cy + h / 2} ${cx + w / 2},${cy + h / 2} ${cx - w / 2},${cy - h / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "equilateral-triangle" && <polygon points={`${cx - w / 2},${triangleBaseY} ${cx + w / 2},${triangleBaseY} ${cx},${triangleTopY}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "isosceles-triangle" && <polygon points={`${cx - w / 2},${cy + h / 2} ${cx + w / 2},${cy + h / 2} ${cx},${cy - h / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "scalene-triangle" && <polygon points={`${cx - w / 2},${cy + h / 2} ${cx + w / 2},${cy + h / 2} ${triangleApexX},${cy - h / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "square" && <rect x={cx - radius} y={cy - radius} width={radius * 2} height={radius * 2} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "rectangle" && <rect x={cx - w / 2} y={cy - h / 2} width={w} height={h} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "rounded-rectangle" && <rect x={cx - w / 2} y={cy - h / 2} width={w} height={h} rx={Math.min(c * scale, w / 2, h / 2)} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "parallelogram" && <polygon points={`${cx - w / 2 + 45},${cy - h / 2} ${cx + w / 2},${cy - h / 2} ${cx + w / 2 - 45},${cy + h / 2} ${cx - w / 2},${cy + h / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "rhombus" && <polygon points={`${cx},${cy - h / 2} ${cx + w / 2},${cy} ${cx},${cy + h / 2} ${cx - w / 2},${cy}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "trapezium" && <polygon points={`${cx - top / 2},${cy - height / 2} ${cx + top / 2},${cy - height / 2} ${cx + w / 2},${cy + height / 2} ${cx - w / 2},${cy + height / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "kite" && <polygon points={`${cx},${cy - h / 2} ${cx + w / 2},${cy - 10} ${cx},${cy + h / 2} ${cx - w / 2},${cy - 10}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {(shape === "regular-polygon" || isFixedRegularPolygon(shape)) && <polygon points={polygonPoints} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "star" && <polygon points={starPoints} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "cross" && <path d={`M ${cx - b * scale / 2} ${cy - radius} H ${cx + b * scale / 2} V ${cy - b * scale / 2} H ${cx + radius} V ${cy + b * scale / 2} H ${cx + b * scale / 2} V ${cy + radius} H ${cx - b * scale / 2} V ${cy + b * scale / 2} H ${cx - radius} V ${cy - b * scale / 2} H ${cx - b * scale / 2} Z`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {(["cube", "cuboid"] as ShapeId[]).includes(shape) && <rect x={cx - w / 2} y={cy - h / 2} width={w} height={h} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {(["sphere", "hemisphere"] as ShapeId[]).includes(shape) && <circle cx={cx} cy={cy} r={radius} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {(["cylinder", "hollow-cylinder", "capsule", "ellipsoid"] as ShapeId[]).includes(shape) && <rect x={cx - w / 2} y={cy - h / 2} width={w} height={h} rx={shape === "capsule" ? h / 2 : 12} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {(["cone", "frustum", "square-pyramid", "triangular-pyramid", "rectangular-pyramid", "pentagonal-pyramid", "hexagonal-pyramid"] as ShapeId[]).includes(shape) && <polygon points={shape === "frustum" ? `${cx - w / 4},${cy - h / 2} ${cx + w / 4},${cy - h / 2} ${cx + w / 2},${cy + h / 2} ${cx - w / 2},${cy + h / 2}` : `${cx},${cy - h / 2} ${cx + w / 2},${cy + h / 2} ${cx - w / 2},${cy + h / 2}`} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {(["tetrahedron", "octahedron", "dodecahedron", "icosahedron", "triangular-prism", "pentagonal-prism", "hexagonal-prism", "octagonal-prism"] as ShapeId[]).includes(shape) && <polygon points={polygonPoints} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" />}
        {shape === "torus" && <path d={ringPath(cx, cy, radius, Math.max(18, Math.min(b * scale, radius - 12)))} fill="url(#shapeFill)" stroke="#06b6d4" strokeWidth="4" fillRule="evenodd" />}
        <TriangleIdentityMarks shape={shape} cx={cx} w={w} baseY={triangleBaseY} topY={triangleTopY} />
        <line x1="80" y1="310" x2="400" y2="310" stroke="#94a3b8" strokeDasharray="6 6" />
        <DimensionGuides2D shape={shape} cx={cx} cy={cy} radius={radius} w={w} h={h} top={top} height={height} sectorX={sectorX} sectorY={sectorY} triangleApexX={triangleApexX} triangleBaseY={triangleBaseY} triangleTopY={triangleTopY} />
      </g>
    </svg>
  );
}

function ringPath(cx: number, cy: number, outer: number, inner: number) {
  return `M ${cx - outer} ${cy} A ${outer} ${outer} 0 1 0 ${cx + outer} ${cy} A ${outer} ${outer} 0 1 0 ${cx - outer} ${cy} M ${cx - inner} ${cy} A ${inner} ${inner} 0 1 1 ${cx + inner} ${cy} A ${inner} ${inner} 0 1 1 ${cx - inner} ${cy}`;
}

function TriangleIdentityMarks({ shape, cx, w, baseY, topY }: { shape: ShapeId; cx: number; w: number; baseY: number; topY: number }) {
  if (shape === "equilateral-triangle") return <g aria-label="Three matching side marks show all sides are equal">
    <line x1={cx - w * 0.27} y1={(baseY + topY) / 2 - 5} x2={cx - w * 0.22} y2={(baseY + topY) / 2 + 5} stroke="#f8fafc" strokeWidth="4" />
    <line x1={cx + w * 0.22} y1={(baseY + topY) / 2 + 5} x2={cx + w * 0.27} y2={(baseY + topY) / 2 - 5} stroke="#f8fafc" strokeWidth="4" />
    <line x1={cx} y1={baseY - 7} x2={cx} y2={baseY + 7} stroke="#f8fafc" strokeWidth="4" />
    <text x={cx - 12} y={topY + 28} fill="#fef3c7" fontSize="13" fontWeight="800">60°</text>
  </g>;
  if (shape === "isosceles-triangle") return <g aria-label="Two matching side marks show the sloping sides are equal">
    <line x1={cx - w * 0.27} y1={(baseY + topY) / 2 - 5} x2={cx - w * 0.22} y2={(baseY + topY) / 2 + 5} stroke="#f8fafc" strokeWidth="4" />
    <line x1={cx + w * 0.22} y1={(baseY + topY) / 2 + 5} x2={cx + w * 0.27} y2={(baseY + topY) / 2 - 5} stroke="#f8fafc" strokeWidth="4" />
  </g>;
  if (shape === "scalene-triangle") return <g aria-label="Different labels show that all three side lengths differ">
    <text x={cx - w / 2 + 16} y={(baseY + topY) / 2} fill="#fef3c7" fontSize="14" fontWeight="800">s₁</text>
    <text x={cx + w / 2 - 28} y={(baseY + topY) / 2} fill="#fef3c7" fontSize="14" fontWeight="800">s₂</text>
  </g>;
  return null;
}

function DimensionGuides2D({ shape, cx, cy, radius, w, h, top, height, sectorX, sectorY, triangleApexX, triangleBaseY, triangleTopY }: { shape: ShapeId; cx: number; cy: number; radius: number; w: number; h: number; top: number; height: number; sectorX: number; sectorY: number; triangleApexX: number; triangleBaseY: number; triangleTopY: number }) {
  const label = (x: number, y: number, text: string, color = "#0f172a") => <text x={x} y={y} fill={color} fontSize="15" fontWeight="700">{text}</text>;
  const guide = (x1: number, y1: number, x2: number, y2: number, color = "#f59e0b") => <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth="3" strokeDasharray="7 5" />;
  if (["circle", "semicircle"].includes(shape)) return <>{guide(cx, cy, cx + radius, cy)}{label(cx + radius / 2 - 5, cy - 10, "r", "#f59e0b")}{guide(cx - radius, cy + 26, cx + radius, cy + 26, "#8b5cf6")}{label(cx - 8, cy + 48, "d=2r", "#8b5cf6")}</>;
  if (shape === "sector") return <>{guide(cx, cy, cx + radius, cy)}{guide(cx, cy, sectorX, sectorY)}{label(cx + radius / 2, cy - 10, "r", "#f59e0b")}{label(cx + 18, cy - 22, "theta", "#8b5cf6")}</>;
  if (shape === "ellipse") return <>{guide(cx, cy, cx + Math.min(w / 2, 170), cy)}{guide(cx, cy, cx, cy - Math.min(h / 2, 120))}{label(cx + 55, cy - 10, "a", "#f59e0b")}{label(cx + 10, cy - 55, "b", "#8b5cf6")}</>;
  if (["triangle", "isosceles-triangle", "scalene-triangle", "equilateral-triangle"].includes(shape)) return <>
    {guide(cx - w / 2, triangleBaseY + 20, cx + w / 2, triangleBaseY + 20)}
    {guide(triangleApexX, triangleBaseY, triangleApexX, triangleTopY)}
    <line x1={triangleApexX} y1={triangleBaseY - 12} x2={triangleApexX + 12} y2={triangleBaseY - 12} stroke="#f8fafc" strokeWidth="2" />
    <line x1={triangleApexX + 12} y1={triangleBaseY - 12} x2={triangleApexX + 12} y2={triangleBaseY} stroke="#f8fafc" strokeWidth="2" />
    {label(cx - 10, triangleBaseY + 42, shape === "equilateral-triangle" ? "s" : "b", "#f59e0b")}
    {label(triangleApexX + 10, (triangleBaseY + triangleTopY) / 2, "h ⟂ b", "#8b5cf6")}
  </>;
  if (shape === "right-triangle") return <>{guide(cx - w / 2, cy + h / 2 + 20, cx + w / 2, cy + h / 2 + 20)}{guide(cx - w / 2 - 20, cy + h / 2, cx - w / 2 - 20, cy - h / 2)}{guide(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, "#ef4444")}{label(cx - 5, cy + h / 2 + 42, "b", "#f59e0b")}{label(cx - w / 2 - 45, cy, "h", "#8b5cf6")}{label(cx, cy, "c", "#ef4444")}</>;
  if (shape === "square") return <>{guide(cx - radius, cy + radius + 18, cx + radius, cy + radius + 18)}{label(cx - 5, cy + radius + 40, "s", "#f59e0b")}</>;
  if (shape === "rectangle" || shape === "rounded-rectangle") return <>{guide(cx - w / 2, cy + h / 2 + 18, cx + w / 2, cy + h / 2 + 18)}{guide(cx - w / 2 - 18, cy - h / 2, cx - w / 2 - 18, cy + h / 2)}{label(cx - 5, cy + h / 2 + 40, "l", "#f59e0b")}{label(cx - w / 2 - 42, cy, "w", "#8b5cf6")}</>;
  if (shape === "parallelogram") return <>{guide(cx - w / 2, cy + h / 2 + 18, cx + w / 2 - 45, cy + h / 2 + 18)}{guide(cx, cy + h / 2, cx, cy - h / 2)}{label(cx - 5, cy + h / 2 + 40, "b", "#f59e0b")}{label(cx + 10, cy, "h", "#8b5cf6")}</>;
  if (shape === "rhombus" || shape === "kite") return <>{guide(cx - w / 2, cy, cx + w / 2, cy)}{guide(cx, cy - h / 2, cx, cy + h / 2)}{label(cx - 8, cy - 10, "d1", "#f59e0b")}{label(cx + 10, cy, "d2", "#8b5cf6")}</>;
  if (shape === "trapezium") return <>{guide(cx - w / 2, cy + height / 2 + 18, cx + w / 2, cy + height / 2 + 18)}{guide(cx - top / 2, cy - height / 2 - 18, cx + top / 2, cy - height / 2 - 18)}{guide(cx, cy - height / 2, cx, cy + height / 2)}{label(cx - 8, cy + height / 2 + 40, "a", "#f59e0b")}{label(cx - 8, cy - height / 2 - 28, "b", "#8b5cf6")}{label(cx + 10, cy, "h", "#ef4444")}</>;
  if (shape === "regular-polygon") return <>{guide(cx, cy, cx + radius, cy)}{label(cx + radius / 2, cy - 8, "r", "#f59e0b")}{label(cx - 25, cy + radius + 30, "n sides", "#8b5cf6")}</>;
  return null;
}

function RotatingSolid({ shape, a, b, c, angle, wireframe, zoom, rotation, autoRotate, sides, fillMode, colorA, colorB, glow }: { shape: ShapeId; a: number; b: number; c: number; angle: number; wireframe: boolean; zoom: number; rotation: number; autoRotate: boolean; sides?: number; fillMode: ShapeFillMode; colorA: string; colorB: string; glow: boolean }) {
  const ref = useRef<THREE.Mesh>(null);
  const guideRef = useRef<THREE.Group>(null);
  useEffect(() => {
    if (ref.current) ref.current.rotation.y = (rotation * Math.PI) / 180;
    if (guideRef.current) guideRef.current.rotation.y = (rotation * Math.PI) / 180;
  }, [rotation]);

  useFrame((_, delta) => {
    if (ref.current && autoRotate) {
      ref.current.rotation.y += delta * 0.45;
      ref.current.rotation.x += delta * 0.12;
    }
    if (guideRef.current && autoRotate) guideRef.current.rotation.y += delta * 0.45;
  });

  // Keep real dimensions in the calculators while normalizing the rendered model to the camera.
  const size = Math.min(a, 5) * 0.52;
  const second = Math.min(b, 5) * 0.52;
  const third = Math.min(c, 6) * 0.46;
  const meshScale: [number, number, number] = shape === "ellipsoid" ? [size, second, third] : shape === "ellipse" ? [size, 1, second] : [1, 1, 1];
  const extrudeDepth = 0.55;
  const polygonSides = polygonSideCount(shape, sides ?? 6);
  const is2DPolygon = shape === "regular-polygon" || isFixedRegularPolygon(shape);

  return (
    <group scale={zoom}>
      <mesh ref={ref} scale={meshScale}>
        {shape === "circle" && <cylinderGeometry args={[size, size, extrudeDepth, 72]} />}
        {shape === "semicircle" && <cylinderGeometry args={[size, size, extrudeDepth, 36, 1, false, 0, Math.PI]} />}
        {shape === "sector" && <cylinderGeometry args={[size, size, extrudeDepth, 48, 1, false, 0, Math.max(0.2, Math.min(Math.PI * 2, (Math.PI * 2 * angle) / 360))]} />}
        {shape === "ellipse" && <cylinderGeometry args={[1, 1, extrudeDepth, 72]} />}
        {shape === "annulus" && <torusGeometry args={[Math.max(0.2, size * 0.7), Math.max(0.08, Math.min(second, size) * 0.18), 18, 72]} />}
        {shape === "quadrant" && <cylinderGeometry args={[size, size, extrudeDepth, 24, 1, false, 0, Math.PI / 2]} />}
        {shape === "segment" && <cylinderGeometry args={[size, size, extrudeDepth, 32, 1, false, 0, Math.PI * 0.75]} />}
        {shape === "crescent" && <torusGeometry args={[Math.max(0.2, size * 0.72), Math.max(0.08, Math.min(second, size) * 0.14), 16, 72, Math.PI * 1.35]} />}
        {shape === "triangle" && <cylinderGeometry args={[size, size, extrudeDepth, 3]} />}
        {shape === "right-triangle" && <cylinderGeometry args={[size, size, extrudeDepth, 3]} />}
        {(shape === "equilateral-triangle" || shape === "isosceles-triangle" || shape === "scalene-triangle") && <cylinderGeometry args={[size, size, extrudeDepth, 3]} />}
        {shape === "square" && <boxGeometry args={[size, size, extrudeDepth]} />}
        {shape === "rectangle" && <boxGeometry args={[size, second, extrudeDepth]} />}
        {shape === "rounded-rectangle" && <boxGeometry args={[size, second, extrudeDepth]} />}
        {shape === "parallelogram" && <boxGeometry args={[size, second, extrudeDepth]} />}
        {shape === "rhombus" && <octahedronGeometry args={[size, 0]} />}
        {shape === "trapezium" && <cylinderGeometry args={[Math.max(second, 0.2), size, extrudeDepth, 4]} />}
        {shape === "kite" && <octahedronGeometry args={[size, 0]} />}
        {is2DPolygon && <cylinderGeometry args={[size, size, extrudeDepth, polygonSides]} />}
        {shape === "star" && <torusKnotGeometry args={[Math.max(0.6, size * 0.5), Math.max(0.05, second * 0.08), 80, 8, 5, 2]} />}
        {shape === "cross" && <boxGeometry args={[size, Math.max(0.4, second * 0.45), extrudeDepth]} />}
        {shape === "cube" && <boxGeometry args={[size, size, size]} />}
        {shape === "cuboid" && <boxGeometry args={[size, second, third]} />}
        {shape === "sphere" && <sphereGeometry args={[size, 64, 36]} />}
        {shape === "hemisphere" && <sphereGeometry args={[size, 64, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />}
        {shape === "cylinder" && <cylinderGeometry args={[size, size, second, 64]} />}
        {shape === "hollow-cylinder" && <cylinderGeometry args={[size, size, third, 64, 1, true]} />}
        {shape === "capsule" && <capsuleGeometry args={[size, second, 16, 32]} />}
        {shape === "ellipsoid" && <sphereGeometry args={[1, 64, 36]} />}
        {shape === "cone" && <coneGeometry args={[size, second, 64]} />}
        {shape === "frustum" && <cylinderGeometry args={[second, size, third, 64]} />}
        {shape === "tetrahedron" && <tetrahedronGeometry args={[size, 0]} />}
        {shape === "octahedron" && <octahedronGeometry args={[size, 0]} />}
        {shape === "dodecahedron" && <dodecahedronGeometry args={[size, 0]} />}
        {shape === "icosahedron" && <icosahedronGeometry args={[size, 0]} />}
        {shape === "square-pyramid" && <coneGeometry args={[size, second, 4]} />}
        {shape === "triangular-pyramid" && <coneGeometry args={[size, second, 3]} />}
        {shape === "rectangular-pyramid" && <coneGeometry args={[size, third, 4]} />}
        {shape === "pentagonal-pyramid" && <coneGeometry args={[size, second, 5]} />}
        {shape === "hexagonal-pyramid" && <coneGeometry args={[size, second, 6]} />}
        {shape === "triangular-prism" && <cylinderGeometry args={[size, size, third, 3]} />}
        {shape === "pentagonal-prism" && <cylinderGeometry args={[size, size, second, 5]} />}
        {shape === "hexagonal-prism" && <cylinderGeometry args={[size, size, second, 6]} />}
        {shape === "octagonal-prism" && <cylinderGeometry args={[size, size, second, 8]} />}
        {shape === "torus" && <torusGeometry args={[size, second, 24, 96]} />}
        <meshStandardMaterial
          color={colorA}
          emissive={colorB}
          emissiveIntensity={glow ? (fillMode === "outline" ? 0.8 : 0.3) : 0.05}
          roughness={fillMode === "gradient" ? 0.22 : 0.36}
          metalness={fillMode === "gradient" ? 0.38 : 0.16}
          wireframe={wireframe || fillMode === "outline"}
          transparent
          opacity={wireframe || fillMode === "outline" ? 0.95 : 0.84}
        />
      </mesh>
      <group ref={guideRef}>
        <DimensionGuides3D shape={shape} size={size} second={second} third={third} />
      </group>
    </group>
  );
}

function DimensionGuides3D({ shape, size, second, third }: { shape: ShapeId; size: number; second: number; third: number }) {
  const half = size / 2;
  if (shape === "cube") return <><GuideLine start={[-half, -half - 0.25, half]} end={[half, -half - 0.25, half]} color="#f59e0b" /><GuideLabel position={[0, -half - 0.45, half]} text="s" /></>;
  if (shape === "cuboid") return <><GuideLine start={[-size / 2, -second / 2 - 0.3, third / 2]} end={[size / 2, -second / 2 - 0.3, third / 2]} color="#f59e0b" /><GuideLine start={[-size / 2 - 0.3, -second / 2, -third / 2]} end={[-size / 2 - 0.3, second / 2, -third / 2]} color="#8b5cf6" /><GuideLine start={[size / 2 + 0.3, -second / 2, -third / 2]} end={[size / 2 + 0.3, -second / 2, third / 2]} color="#ef4444" /><GuideLabel position={[0, -second / 2 - 0.5, third / 2]} text="l" /><GuideLabel position={[-size / 2 - 0.55, 0, -third / 2]} text="b" /><GuideLabel position={[size / 2 + 0.45, -second / 2, 0]} text="h" /></>;
  if (shape === "sphere" || shape === "hemisphere") return <><GuideLine start={[0, 0, 0]} end={[size, 0, 0]} color="#f59e0b" /><GuideLabel position={[size / 2, 0.18, 0]} text="r" /></>;
  if (shape === "cylinder") return <><GuideLine start={[0, -second / 2, 0]} end={[size, -second / 2, 0]} color="#f59e0b" /><GuideLine start={[-size - 0.3, -second / 2, 0]} end={[-size - 0.3, second / 2, 0]} color="#8b5cf6" /><GuideLabel position={[size / 2, -second / 2 - 0.18, 0]} text="r" /><GuideLabel position={[-size - 0.55, 0, 0]} text="h" /></>;
  if (shape === "cone") return <><GuideLine start={[0, -second / 2, 0]} end={[size, -second / 2, 0]} color="#f59e0b" /><GuideLine start={[-size - 0.25, -second / 2, 0]} end={[-size - 0.25, second / 2, 0]} color="#8b5cf6" /><GuideLine start={[size, -second / 2, 0]} end={[0, second / 2, 0]} color="#ef4444" /><GuideLabel position={[size / 2, -second / 2 - 0.18, 0]} text="r" /><GuideLabel position={[-size - 0.5, 0, 0]} text="h" /><GuideLabel position={[size / 2, 0.05, 0]} text="l" /></>;
  if (shape === "frustum") return <><GuideLine start={[0, -third / 2, 0]} end={[size, -third / 2, 0]} color="#f59e0b" /><GuideLine start={[0, third / 2, 0]} end={[second, third / 2, 0]} color="#8b5cf6" /><GuideLine start={[-size - 0.35, -third / 2, 0]} end={[-size - 0.35, third / 2, 0]} color="#ef4444" /><GuideLabel position={[size / 2, -third / 2 - 0.2, 0]} text="R" /><GuideLabel position={[second / 2, third / 2 + 0.25, 0]} text="r" /><GuideLabel position={[-size - 0.6, 0, 0]} text="h" /></>;
  if (shape === "square-pyramid") return <><GuideLine start={[-size / 2, -second / 2 - 0.2, size / 2]} end={[size / 2, -second / 2 - 0.2, size / 2]} color="#f59e0b" /><GuideLine start={[0, -second / 2, 0]} end={[0, second / 2, 0]} color="#8b5cf6" /><GuideLabel position={[0, -second / 2 - 0.42, size / 2]} text="s" /><GuideLabel position={[0.15, 0, 0]} text="h" /></>;
  if (shape === "triangular-prism") return <><GuideLine start={[-size, -0.25, third / 2]} end={[size, -0.25, third / 2]} color="#f59e0b" /><GuideLine start={[-size - 0.3, -0.25, -third / 2]} end={[-size - 0.3, second, -third / 2]} color="#8b5cf6" /><GuideLine start={[size + 0.25, -0.25, -third / 2]} end={[size + 0.25, -0.25, third / 2]} color="#ef4444" /><GuideLabel position={[0, -0.45, third / 2]} text="b" /><GuideLabel position={[-size - 0.55, second / 2, -third / 2]} text="h" /><GuideLabel position={[size + 0.45, -0.25, 0]} text="L" /></>;
  const [firstSymbol, secondSymbol] = dimensionGuideSymbols(shape);
  return <><GuideLine start={[0, 0, 0]} end={[size, 0, 0]} color="#f59e0b" />{secondSymbol && <GuideLine start={[0, 0, 0]} end={[0, second, 0]} color="#8b5cf6" />}<GuideLabel position={[size / 2, 0.2, 0]} text={firstSymbol} />{secondSymbol && <GuideLabel position={[0.2, second / 2, 0]} text={secondSymbol} />}</>;
}

function dimensionGuideSymbols(id: ShapeId): [string, string?] {
  if (["annulus", "crescent", "star", "torus", "hollow-cylinder"].includes(id)) return ["R", "r"];
  if (["circle", "semicircle", "sector", "quadrant", "segment", "sphere", "hemisphere", "cylinder", "capsule", "cone"].includes(id)) return ["r", shapeControlLabels[id][1] ? "h" : undefined];
  if (id === "ellipse" || id === "ellipsoid") return ["a", "b"];
  if (id === "rhombus" || id === "kite") return ["d1", "d2"];
  if (id === "rectangle" || id === "rounded-rectangle") return ["l", "w"];
  if (id === "cross") return ["a", "w"];
  if (id === "trapezium") return ["a", "b"];
  if (id.includes("triangle") || id === "parallelogram") return [id === "equilateral-triangle" ? "s" : "b", id === "equilateral-triangle" ? undefined : "h"];
  if (id.includes("prism")) return [id === "triangular-prism" ? "b" : "s", "L"];
  if (id.includes("pyramid")) return [id === "rectangular-pyramid" ? "l" : "s", "h"];
  return ["s"];
}

function GuideLine({ start, end, color }: { start: [number, number, number]; end: [number, number, number]; color: string }) {
  const startVector = new THREE.Vector3(...start);
  const endVector = new THREE.Vector3(...end);
  const direction = endVector.clone().sub(startVector);
  const length = direction.length();
  const midpoint = startVector.clone().add(direction.clone().multiplyScalar(0.5));
  const quaternion = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());
  return <mesh position={midpoint} quaternion={quaternion}><cylinderGeometry args={[0.018, 0.018, length, 10]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.15} /></mesh>;
}

function GuideLabel({ position, text }: { position: [number, number, number]; text: string }) {
  return (
    <group position={position}>
      <mesh>
        <sphereGeometry args={[0.075, 16, 10]} />
        <meshStandardMaterial color="#f8fafc" emissive="#22d3ee" emissiveIntensity={0.25} />
      </mesh>
      <Text
        position={[0.18, 0.16, 0]}
        fontSize={0.28}
        color="#f8fafc"
        anchorX="left"
        anchorY="middle"
        outlineWidth={0.018}
        outlineColor="#0f172a"
      >
        {text}
      </Text>
    </group>
  );
}
