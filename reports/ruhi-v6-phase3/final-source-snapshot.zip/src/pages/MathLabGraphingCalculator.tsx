import { ImmersiveBoundary } from "../workspace/immersive/ImmersiveInteractionManager";
import { useIntelligenceWorkspace,isKnownRoboObject } from '../offline-intelligence/workspaceBridge';
import {restoredGraphInventory} from '../math-robo/intelligence/graphInventory';
import {clipRay,clipInfiniteLine,directedData} from '../offline-intelligence/directedGeometry';
import type {VisualCommand} from '../offline-intelligence/commands';
import { graphExpressions,outlineVertices } from '../offline-intelligence/commands';
import { Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import { readEmbeddedGraphState, saveEmbeddedGraphState, type EmbeddedGraphOptions } from "../workspace/embeddedWorkspace";
import FunctionGraphCanvas, { FunctionGraphView } from "../components/math-lab/FunctionGraphCanvas";
import { buildGraphingCalculatorWorkspaceObjects } from "../workspace/universalObjectGraph";
import { useUniversalObjectGraphPublisher } from "../workspace/useUniversalObjectGraphPublisher";
import { deleteGraphWorkspace, readSavedGraphWorkspaces, saveGraphWorkspace, type SavedGraphWorkspace } from "../utils/graphWorkspaceStorage";
import type { GraphSample } from "../utils/mathEngine/graphSampler";
import { compileFunctionExpression, compileTwoVariableExpression } from "../utils/functionParser";
import GraphStudio2DWorkspace, { type GraphTransform, type PiecewiseSegment } from "../graph-studio/GraphStudio2DWorkspace";
import EmbedCodePanel from "../embed/EmbedCodePanel";
import { iframeSnippet } from "../embed/engine";
import { embedSceneFromGraphFunctions } from "../embed/fromWorkspace";
import { sampleAdvancedGraphExpression } from "../graph-studio/advancedGraphLayers";
import { createBlankGraphDataRows, numericGraphData, parseGraphData, regressionModel, type GraphDataRow, type RegressionKind } from "../graph-studio/dataAnalysis";
import { buildTransformationExpression, detectGraphAsymptotes, precisionSnapX, sampleTaylorPolynomial } from "../graph-studio/graph2dAdvanced";
import { buildExactGraphAnalysis, buildExactIntersections } from "../graph-studio/exactGraphAnalysis";
import { reconcileGraphVariables, substituteGraphVariables, advanceGraphVariable } from "../graph-studio/expressionEngine";
import { fitGraphView } from "../graph-studio/graphViewUtils";
import { sampledGraphIntersections } from "../graph-studio/sampleIntersections";
import { downloadGraphStudioFile, exportGraphStudioProject } from "../graph-studio/projectStorage";
import { useGraphStudioProject } from "../graph-studio/useGraphStudioProject";
import type { GraphStudioVariable } from "../graph-studio/types";
import {
  approximateRoots,
  approximateVisibleRange,
  approximateYIntercept,
  detectDiscontinuities,
  generateTableValues,
  sampleFunction,
} from "../utils/mathEngine/graphSampler";

type FunctionRow = {
  roboCommand?:VisualCommand;
  id: string;
  input: string;
  color: string;
  visible: boolean;
  name?: string;
  label?: string;
  note?: string;
  group?: string;
  locked?: boolean;
  opacity?: number;
  imageUrl?: string;
  imageX?: number;
  imageY?: number;
  imageWidth?: number;
  imageHeight?: number;
  piecewise?: PiecewiseSegment[];
  transform?: GraphTransform;
};

type Graph2DWorkspaceState = {
  functions: FunctionRow[];
  view: FunctionGraphView;
  showGrid: boolean;
  showAxes: boolean;
  traceMode: boolean;
  integralStart: number;
  integralEnd: number;
  variables?: GraphStudioVariable[];
  dataRows?: GraphDataRow[];
  showData?: boolean;
  showRegression?: boolean;
  showResiduals?: boolean;
  logX?: boolean;
  logY?: boolean;
  regressionKind?: RegressionKind;
  showTaylor?: boolean;
  taylorCenter?: number;
  taylorDegree?: number;
};

type GraphExpressionSample = {
  points: GraphSample[];
  boundaryPoints?: GraphSample[];
  boundaryStyle?: "line" | "dashed";
  normalized: string;
  style: "line" | "points" | "region" | "vectors" | "directed";
  family?: string;
  error?: string;
};

const COLORS = ["#06b6d4", "#f97316", "#8b5cf6", "#10b981", "#ef4444", "#eab308", "#ec4899"];
const EXAMPLES = ["2x + 1", "x^2", "sin(x)", "x^2 + y^2 = 25", "(2, 3)", "seq(n^2,0,12)", "recur(1,1.25*prev,18)", "contour(x^2+y^2,1;4;9)", "r=2*sin(3*theta),theta=0..pi", "vector(-y,x)", "slope(x-y)", "{x < 0: -x, x >= 0: x}", "sin(x) {-pi <= x <= pi}", "y >= x^2 - 4"];
const GRAPH_2D_STORAGE_KEY = "math-universe-saved-2d-graphs";
const DEFAULT_GRAPH_VIEW: FunctionGraphView = { xMin: -10, xMax: 10, yMin: -10, yMax: 10 };

function MathLabGraphingCalculatorContent({ embedded }: { embedded?: EmbeddedGraphOptions } = {}) {
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const prefilledFunction = embedded ? undefined : searchParams.get("q")?.trim();
  const sharedProject = useMemo<Partial<Graph2DWorkspaceState> | null | undefined>(() => readEmbeddedGraphState<Graph2DWorkspaceState>(embedded, "2d") ?? (embedded ? { functions: embedded.expressions.map((input, i) => ({ id: `f${i + 1}`, input, color: COLORS[i % COLORS.length], visible: true })), view: DEFAULT_GRAPH_VIEW } : (location.state as { embeddedGraphScene?: Graph2DWorkspaceState } | null)?.embeddedGraphScene ?? readSharedGraph(searchParams.get("project"))), [embedded?.activityId, location.state, searchParams]);
  const [functions, setFunctions] = useState<FunctionRow[]>(() => sharedProject?.functions?.length ? sharedProject.functions : prefilledFunction ? [
    { id: "f1", input: prefilledFunction, color: COLORS[0], visible: true },
  ] : [
    { id: "f1", input: "x^2 - 4", color: COLORS[0], visible: true },
    { id: "f2", input: "sin(x)", color: COLORS[1], visible: true },
  ]);
  useEffect(() => {
    if (!embedded?.expressionRevision) return;
    setFunctions(previous => embedded.expressions.map((input, index) => ({ ...(previous[index] ?? { id: `f${index+1}`, color: COLORS[index % COLORS.length], visible: true }), input })));
  }, [embedded?.expressionRevision]);
  const [selectedId, setSelectedId] = useState("f1");
  useIntelligenceWorkspace('graph2d', command => {
    if(command.roboClearAll){setFunctions([]);setSelectedId('');return;}
    const base=command.objectId??crypto.randomUUID();
    const matches=(row:{id:string})=>command.roboNativeRow?row.id===base:row.id.startsWith(`${base}-`);
    if(command.roboControl==='deselect'){setSelectedId('');return;}
    if(command.roboControl==='delete'){setFunctions(current=>current.filter(row=>!matches(row)));return;}
    if(command.roboControl==='visibility'){setFunctions(current=>current.map(row=>matches(row)?{...row,visible:command.roboVisible??true}:row));return;}
    if(command.roboControl==='select'){setSelectedId(command.roboNativeRow?base:`${base}-0`);return;}
    if(command.action==='update'&&!functions.some(matches))return 'The last Ruhi graph was removed. Create an object again before editing it.';
    const rows = graphExpressions(command).map((input,i) => ({id:command.roboNativeRow&&i===0?base:`${base}-${i}`,input,color:command.color,visible:command.roboVisible??true,name:command.roboLabel??command.kind,roboCommand:structuredClone(command)}));
    setFunctions(current => [...current.filter(row=>!matches(row)),...rows]);
    setSelectedId(rows[0].id);
  }, !embedded, command=>{const row=functions.find(row=>command.roboNativeRow?row.id===command.objectId:row.id.startsWith(`${command.objectId}-`));return row?.roboCommand?{command:{...row.roboCommand,color:row.color,roboVisible:row.visible}}:row?{command:{...command,color:row.color,roboVisible:row.visible,...(command.kind==='plot'?{expression:row.input.replace(/^y\s*=\s*/, '')}:{})}}:undefined;},()=>({commands:restoredGraphInventory(functions,id=>isKnownRoboObject('graph2d',id)),selectedIds:selectedId?[selectedId.replace(/-0$/,'')]:[]}));
  const [view, setView] = useState<FunctionGraphView>(() => sharedProject?.view ?? DEFAULT_GRAPH_VIEW);
  const [showGrid, setShowGrid] = useState(() => sharedProject?.showGrid ?? true);
  const [showAxes, setShowAxes] = useState(() => sharedProject?.showAxes ?? true);
  const [traceMode, setTraceMode] = useState(() => sharedProject?.traceMode ?? true);
  const [traceX, setTraceX] = useState(0);
  const [tableStart, setTableStart] = useState(-5);
  const [tableEnd, setTableEnd] = useState(5);
  const [tableStep, setTableStep] = useState(1);
  const [showDerivative, setShowDerivative] = useState(false);
  const [showIntegral, setShowIntegral] = useState(false);
  const [integralStart, setIntegralStart] = useState(() => sharedProject?.integralStart ?? -2);
  const [integralEnd, setIntegralEnd] = useState(() => sharedProject?.integralEnd ?? 2);
  const [saveName, setSaveName] = useState("My 2D graph");
  const [savedGraphs, setSavedGraphs] = useState<SavedGraphWorkspace<Graph2DWorkspaceState>[]>(() => readSavedGraphWorkspaces(GRAPH_2D_STORAGE_KEY));
  const [graphVariables, setGraphVariables] = useState<GraphStudioVariable[]>(() => sharedProject?.variables ?? []);
  const [dataRows, setDataRows] = useState<GraphDataRow[]>(() => sharedProject?.dataRows ?? createBlankGraphDataRows());
  const [showData, setShowData] = useState(() => sharedProject?.showData ?? true);
  const [showRegression, setShowRegression] = useState(() => sharedProject?.showRegression ?? false);
  const [showResiduals, setShowResiduals] = useState(() => sharedProject?.showResiduals ?? false);
  const [logX, setLogX] = useState(() => sharedProject?.logX ?? false);
  const [logY, setLogY] = useState(() => sharedProject?.logY ?? false);
  const [regressionKind, setRegressionKind] = useState<RegressionKind>(() => sharedProject?.regressionKind ?? "linear");
  const [showTaylor, setShowTaylor] = useState(() => sharedProject?.showTaylor ?? false);
  const [taylorCenter, setTaylorCenter] = useState(() => sharedProject?.taylorCenter ?? 0);
  const [taylorDegree, setTaylorDegree] = useState(() => sharedProject?.taylorDegree ?? 4);
  const [embedOpen, setEmbedOpen] = useState(false);

  const graphStudioState = useMemo<Graph2DWorkspaceState>(() => ({ functions, view, showGrid, showAxes, traceMode, integralStart, integralEnd, variables: graphVariables, dataRows, showData, showRegression, showResiduals, logX, logY, regressionKind, showTaylor, taylorCenter, taylorDegree }), [dataRows, functions, graphVariables, integralEnd, integralStart, logX, logY, regressionKind, showAxes, showData, showGrid, showRegression, showResiduals, showTaylor, taylorCenter, taylorDegree, traceMode, view]);
  useEffect(() => {
    if (!embedded) return;
    const timeout = window.setTimeout(() => saveEmbeddedGraphState(embedded, "2d", graphStudioState), 120);
    return () => window.clearTimeout(timeout);
  }, [embedded?.activityId, graphStudioState]);
  const graphStudio = useGraphStudioProject({
    persist: !embedded,
    dimension: "2d",
    initialName: "My Function Study",
    state: graphStudioState,
    applyState: (state, variables) => {
      setFunctions(state.functions);
      setSelectedId(state.functions[0]?.id ?? "");
      setView(state.view);
      setShowGrid(state.showGrid);
      setShowAxes(state.showAxes);
      setTraceMode(state.traceMode);
      setIntegralStart(state.integralStart);
      setIntegralEnd(state.integralEnd);
      setGraphVariables(state.variables ?? variables);
      setDataRows(state.dataRows?.length ? state.dataRows : createBlankGraphDataRows());
      setShowData(state.showData ?? true);
      setShowRegression(state.showRegression ?? false);
      setShowResiduals(state.showResiduals ?? false);
      setLogX(state.logX ?? false);
      setLogY(state.logY ?? false);
      setRegressionKind(state.regressionKind ?? "linear");
      setShowTaylor(state.showTaylor ?? false);
      setTaylorCenter(state.taylorCenter ?? 0);
      setTaylorDegree(state.taylorDegree ?? 4);
    },
  });

  const variablesPlaying = graphVariables.some((variable) => variable.playing);
  useEffect(() => {
    setGraphVariables((current) => {
      const next = reconcileGraphVariables(functions.filter((item) => item.visible).map((item) => item.input), current);
      return sameVariables(current, next) ? current : next;
    });
  }, [functions]);
  useEffect(() => {
    if (!variablesPlaying || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = now - last;
      last = now;
      setGraphVariables((current) => current.map((variable) => advanceGraphVariable(variable, dt)));
      frame = window.requestAnimationFrame(tick);
    };
    frame = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(frame);
  }, [variablesPlaying]);

  const plotted = useMemo<(FunctionRow&GraphExpressionSample)[]>(() => functions.map((item) => {
    if(item.roboCommand&&['line','ray','vector'].includes(item.roboCommand.kind)){const data=directedData(item.roboCommand),ends=item.roboCommand.kind==='ray'?clipRay(data.origin,data.direction,[view.xMin,view.yMin],[view.xMax,view.yMax]):item.roboCommand.kind==='line'&&item.roboCommand.linearExtent!=='segment'?clipInfiniteLine(data.origin,data.direction,[view.xMin,view.yMin],[view.xMax,view.yMax]):[data.origin,data.through];return {...item,points:(ends??[]).map(p=>({x:p[0],y:p[1],valid:true})),style:(item.roboCommand.kind==='line'?'line':'directed') as 'line'|'directed',normalized:item.input,error:undefined};}
    const source = item.transform?.enabled ? buildTransformationExpression(item.transform.parent, item.transform.a, item.transform.b, item.transform.h, item.transform.k) : item.input;
    const sampled = sampleGraphExpression(substituteGraphVariables(source, graphVariables), view.xMin, view.xMax, 900, view.yMin, view.yMax);
    return { ...item, ...sampled };
  }), [functions, graphVariables, view]);

  const selected = plotted.find((item) => item.id === selectedId) ?? plotted[0];
  const selectedFunction = functions.find((item) => item.id === selected?.id) ?? functions[0];
  const selectedSourceInput = selectedFunction?.transform?.enabled ? buildTransformationExpression(selectedFunction.transform.parent, selectedFunction.transform.a, selectedFunction.transform.b, selectedFunction.transform.h, selectedFunction.transform.k) : selectedFunction?.input ?? "";
  const selectedResolvedInput = substituteGraphVariables(selectedSourceInput, graphVariables);
  const interactivePoint = useMemo(() => buildInteractivePoint(selectedFunction, selected, traceX), [selected, selectedFunction, traceX]);
  const parameterPoint = useMemo(() => buildParameterInteractivePoint(selectedFunction, selectedResolvedInput, graphVariables, traceX), [graphVariables, selectedFunction, selectedResolvedInput, traceX]);
  const table = useMemo(() => selectedFunction ? generateTableValues(selectedResolvedInput, tableStart, tableEnd, tableStep) : { rows: [] }, [selectedFunction, selectedResolvedInput, tableEnd, tableStart, tableStep]);
  const roots = useMemo(() => selectedFunction ? approximateRoots(selectedResolvedInput, view.xMin, view.xMax) : { roots: [] }, [selectedFunction, selectedResolvedInput, view.xMax, view.xMin]);
  const yIntercept = useMemo(() => selectedFunction ? approximateYIntercept(selectedResolvedInput) : { y: null }, [selectedFunction, selectedResolvedInput]);
  const visibleRange = useMemo(() => selectedFunction ? approximateVisibleRange(selectedResolvedInput, view.xMin, view.xMax) : { min: null, max: null }, [selectedFunction, selectedResolvedInput, view.xMax, view.xMin]);
  const discontinuities = useMemo(() => selected ? detectDiscontinuities(selected.points) : [], [selected]);
  const derivativePoints = useMemo(() => selected ? approximateDerivativePoints(selected.points) : [], [selected]);
  const taylor = useMemo(() => selectedFunction ? sampleTaylorPolynomial(selectedResolvedInput, taylorCenter, taylorDegree, view.xMin, view.xMax) : { points: [], coefficients: [] }, [selectedFunction, selectedResolvedInput, taylorCenter, taylorDegree, view.xMax, view.xMin]);
  const extrema = useMemo(() => selected ? approximateExtrema(selected.points) : { minima: [], maxima: [] }, [selected]);
  const intersections = useMemo(() => sampledGraphIntersections(plotted.filter((item) => item.visible && !item.error)), [plotted]);
  const snapCandidates = useMemo(() => [...roots.roots.map((x) => ({ x, y: 0 })), ...intersections, ...extrema.minima, ...extrema.maxima], [extrema.maxima, extrema.minima, intersections, roots.roots]);
  const integralValue = useMemo(() => selected ? approximateIntegral(selected.points, Math.min(integralStart, integralEnd), Math.max(integralStart, integralEnd)) : null, [integralEnd, integralStart, selected]);
  const exactAnalysis = useMemo(() => buildExactGraphAnalysis(selectedResolvedInput, Math.min(integralStart, integralEnd), Math.max(integralStart, integralEnd)), [integralEnd, integralStart, selectedResolvedInput]);
  const exactIntersections = useMemo(() => { const visible = functions.filter((item) => item.visible); return visible.length >= 2 ? buildExactIntersections(visible[0].input, visible[1].input) : undefined; }, [functions]);
  const numericData = useMemo(() => numericGraphData(dataRows), [dataRows]);
  const regression = useMemo(() => regressionModel(numericData, regressionKind), [numericData, regressionKind]);
  const asymptotes = useMemo(() => selected ? detectGraphAsymptotes(selected.points, view.xMin, view.xMax, selectedResolvedInput) : { vertical: [], horizontal: [] }, [selected, selectedResolvedInput, view.xMax, view.xMin]);
  const dataPoints = useMemo<GraphSample[]>(() => numericData.map((point) => ({ ...point, valid: true })), [numericData]);
  const regressionPoints = useMemo<GraphSample[]>(() => regression?.line.map((point) => ({ ...point, valid: true })) ?? [], [regression]);
  const graphSeries = useMemo(() => [
    ...asymptotes.vertical.map((x, index) => ({ id: `vertical-asymptote-${index}`, label: `x = ${formatGraphNumber(x)}`, color: "#fb7185", points: [{ x, y: view.yMin, valid: true }, { x, y: view.yMax, valid: true }], visible: true, style: "dashed" as const, opacity: 0.65 })),
    ...asymptotes.horizontal.map((y, index) => ({ id: `horizontal-asymptote-${index}`, label: `y = ${formatGraphNumber(y)}`, color: "#fb7185", points: [{ x: view.xMin, y, valid: true }, { x: view.xMax, y, valid: true }], visible: true, style: "dashed" as const, opacity: 0.65 })),
    ...functions.filter((item) => item.visible && item.transform?.enabled).map((item) => ({ id: `${item.id}-parent`, label: `${item.name || "f"} parent`, color: item.color, points: sampleGraphExpression(substituteGraphVariables(item.transform!.parent, graphVariables), view.xMin, view.xMax, 700).points, visible: true, style: "dashed" as const, opacity: 0.34 })),
    ...plotted.flatMap((item) => [
      { id: item.id, label: item.label || item.name || item.input || "function", color: item.color, points: item.points, visible: item.visible && !item.error, style: item.style, strokeWidth:item.roboCommand?.roboStrokeEdges&&!item.roboCommand.roboStrokeEdges.includes(Number(item.id.split('-').at(-1)))?3:item.roboCommand?.roboLineWidth, opacity: item.opacity ?? 1 },
      ...(item.boundaryPoints?.length ? [{ id: `${item.id}-boundary`, label: `${item.input} boundary`, color: item.color, points: item.boundaryPoints, visible: item.visible && !item.error, style: item.boundaryStyle ?? "line" as const }] : []),
    ]),
    ...(showDerivative && selected ? [{ id: `${selected.id}-derivative`, label: `d/dx ${selected.input}`, color: "#ec4899", points: derivativePoints, visible: true, style: "derivative" as const }] : []),
    ...(showTaylor && selected && taylor.points.length ? [{ id: `${selected.id}-taylor`, label: `Taylor degree ${taylorDegree}`, color: "#facc15", points: taylor.points, visible: true, style: "dashed" as const }] : []),
    ...(showData && dataPoints.length ? [{ id: "data-series", label: "Data points", color: "#fbbf24", points: dataPoints, visible: true, style: "points" as const }] : []),
    ...(showRegression && regressionPoints.length ? [{ id: "linear-regression", label: "Linear regression", color: "#a7f3d0", points: regressionPoints, visible: true, style: "line" as const }] : []),
  ], [asymptotes.horizontal, asymptotes.vertical, dataPoints, derivativePoints, functions, graphVariables, plotted, regressionPoints, selected, showData, showDerivative, showRegression, showTaylor, taylor.points, taylorDegree, view.xMax, view.xMin, view.yMax, view.yMin]);
  const workspaceObjects = useMemo(() => buildGraphingCalculatorWorkspaceObjects({
    functions: plotted.map((item) => ({
      id: item.id,
      input: item.input,
      color: item.color,
      visible: item.visible,
      normalized: item.normalized,
      error: item.error,
    })),
    selectedId,
    tableRows: table.rows,
    view,
    analysis: {
      roots: roots.roots,
      yIntercept: yIntercept.y,
      visibleRange,
      discontinuities,
    },
  }), [discontinuities, plotted, roots.roots, selectedId, table.rows, view, visibleRange, yIntercept.y]);
  useUniversalObjectGraphPublisher("graphing-calculator", workspaceObjects, undefined, !embedded);

  return (
    <>
    <GraphStudio2DWorkspace
      projectName={graphStudio.project.name}
      onProjectNameChange={(name) => graphStudio.updateProject({ name })}
      canUndo={graphStudio.canUndo}
      canRedo={graphStudio.canRedo}
      onUndo={graphStudio.undo}
      onRedo={graphStudio.redo}
      onSave={() => { graphStudio.save(); saveCurrentGraph(); }}
      onExportProject={() => downloadGraphStudioFile(`${fileSlug(graphStudio.project.name)}.json`, exportGraphStudioProject({ ...graphStudio.project, state: graphStudioState }))}
      onExportCsv={exportSelectedCsv}
      onExportSvg={exportSelectedSvg}
      onExportPdf={exportGraphPdf}
      onCopyShareLink={() => void navigator.clipboard?.writeText(buildShareUrl(functions, view))}
      onCopyEmbed={() => {
        const scene = embedSceneFromGraphFunctions(functions, view, graphStudio.project.name);
        void navigator.clipboard?.writeText(iframeSnippet(window.location.origin, scene));
        setEmbedOpen(true);
      }}
      onCopyEquation={() => void navigator.clipboard?.writeText(selectedFunction?.input ?? "")}
      functions={functions}
      plotted={plotted}
      selectedId={selectedId}
      onSelect={setSelectedId}
      onUpdate={updateFunction}
      onAdd={addFunction}
      onDuplicate={duplicateFunction}
      onRemove={removeFunction}
      onClear={() => { setFunctions([]); setSelectedId(""); }}
      onMove={moveFunction}
      onRandom={tryRandom}
      onReset={resetExample}
      examples={EXAMPLES}
      onExample={setSelectedExample}
      variables={graphVariables}
      onVariablesChange={updateStudioVariables}
      dataRows={dataRows}
      onDataRowsChange={setDataRows}
      onPasteData={(text) => { const rows = parseGraphData(text); if (rows.length) setDataRows(rows); }}
      showData={showData}
      showRegression={showRegression}
      showResiduals={showResiduals}
      onShowDataChange={setShowData}
      onShowRegressionChange={setShowRegression}
      onShowResidualsChange={setShowResiduals}
      regression={regression}
      view={view}
      onViewChange={setView}
      onFitView={() => setView(fitGraphView([...plotted, ...(showData && dataPoints.length ? [{ visible: true, points: dataPoints }] : [])], view))}
      onResetView={() => setView(DEFAULT_GRAPH_VIEW)}
      showGrid={showGrid}
      showAxes={showAxes}
      traceMode={traceMode}
      traceX={traceX}
      onShowGridChange={setShowGrid}
      onShowAxesChange={setShowAxes}
      onTraceModeChange={setTraceMode}
      onTraceXChange={setTraceX}
      logX={logX}
      logY={logY}
      onLogXChange={(value) => { setLogX(value); if (value) setView((current) => ({ ...current, xMin: Math.max(0.01, current.xMin), xMax: Math.max(10, current.xMax) })); }}
      onLogYChange={(value) => { setLogY(value); if (value) setView((current) => ({ ...current, yMin: Math.max(0.01, current.yMin), yMax: Math.max(10, current.yMax) })); }}
      onAddConstruction={addConstruction}
      interactivePoints={[...(interactivePoint ? [interactivePoint] : []), ...(parameterPoint ? [parameterPoint] : [])]}
      onInteractivePointChange={moveInteractivePoint}
      linkedPoint={interactivePoint ? { x: interactivePoint.x, y: interactivePoint.y } : parameterPoint ? { x: parameterPoint.x, y: parameterPoint.y } : null}
      canvas={<FunctionGraphCanvas series={graphSeries} angleShapes={functions.filter(row=>row.visible&&row.id.endsWith('-0')&&row.roboCommand?.roboAngle).map(row=>({id:row.id,vertices:outlineVertices(row.roboCommand!),vertex:row.roboCommand!.roboAngle!.vertex,color:row.roboCommand!.roboAngle!.arcColor??row.color,strokeWidth:row.roboCommand!.roboAngle!.lineWidth??3}))} filledShapes={functions.filter(row=>row.visible&&row.id.endsWith('-0')&&row.roboCommand?.roboFillColor).map(row=>({id:row.id,vertices:outlineVertices(row.roboCommand!),color:row.roboCommand!.roboFillColor!}))} onSeriesSelect={setSelectedId} view={view} onViewChange={setView} onResetView={() => setView(DEFAULT_GRAPH_VIEW)} showGrid={showGrid} showAxes={showAxes} logX={logX} logY={logY} selectedSeriesId={selectedId} traceX={traceMode ? traceX : undefined} onTraceChange={traceMode ? setPrecisionTraceX : undefined} interactivePoints={[...(interactivePoint ? [interactivePoint] : []), ...(parameterPoint ? [parameterPoint] : [])]} onInteractivePointChange={moveInteractivePoint} precisionCrosshair imageLayers={functions.filter((item) => item.visible && isSafeImageUrl(item.imageUrl)).map((item) => ({ id: item.id, href: item.imageUrl!, x: item.imageX ?? -2, y: item.imageY ?? 2, width: item.imageWidth ?? 4, height: item.imageHeight ?? 4, opacity: item.opacity ?? 0.7, label: item.label || item.name || "Graph image" }))} residualSegments={showResiduals && regression ? regression.residuals : []} integralArea={showIntegral && selected ? { points: selected.points, color: selected.color, start: Math.min(integralStart, integralEnd), end: Math.max(integralStart, integralEnd) } : undefined} featurePoints={[...roots.roots.map((x) => ({ x, y: 0, type: "root" as const })), ...(typeof yIntercept.y === "number" ? [{ x: 0, y: yIntercept.y, type: "intercept" as const }] : []), ...extrema.minima.map((point) => ({ ...point, type: "minimum" as const })), ...extrema.maxima.map((point) => ({ ...point, type: "maximum" as const })), ...intersections.map((point) => ({ ...point, type: "intersection" as const }))]} />}
      roots={roots.roots}
      yIntercept={yIntercept.y}
      visibleRange={visibleRange}
      discontinuities={discontinuities}
      minima={extrema.minima}
      maxima={extrema.maxima}
      intersections={intersections}
      derivativePoints={derivativePoints}
      showDerivative={showDerivative}
      onShowDerivativeChange={setShowDerivative}
      showTaylor={showTaylor}
      onShowTaylorChange={setShowTaylor}
      taylorCenter={taylorCenter}
      taylorDegree={taylorDegree}
      onTaylorCenterChange={setTaylorCenter}
      onTaylorDegreeChange={setTaylorDegree}
      showIntegral={showIntegral}
      onShowIntegralChange={setShowIntegral}
      integralStart={integralStart}
      integralEnd={integralEnd}
      integralValue={integralValue}
      onIntegralStartChange={setIntegralStart}
      onIntegralEndChange={setIntegralEnd}
      tableStart={tableStart}
      tableEnd={tableEnd}
      tableStep={tableStep}
      tableRows={table.rows}
      onTableStartChange={setTableStart}
      onTableEndChange={setTableEnd}
      onTableStepChange={setTableStep}
      stylePreset={graphStudio.project.stylePreset}
      onStylePresetChange={(stylePreset) => graphStudio.updateProject({ stylePreset })}
      exactAnalysis={exactAnalysis}
      exactIntersections={exactIntersections}
      asymptotes={asymptotes}
      regressionKind={regressionKind}
      onRegressionKindChange={setRegressionKind}
      savedLibrary={<SavedGraphList saved={savedGraphs} onLoad={loadSavedGraph} onDelete={removeSavedGraph} />}
    />
    {embedOpen && (
      <EmbedCodePanel
        scene={embedSceneFromGraphFunctions(functions, view, graphStudio.project.name)}
        onClose={() => setEmbedOpen(false)}
      />
    )}
    </>
  );


  function updateStudioVariables(variables: GraphStudioVariable[]) {
    setGraphVariables(variables);
    graphStudio.updateProject({ variables });
  }

  function exportSelectedCsv() {
    if (!selected) return;
    const csv = ["x,y,valid", ...selected.points.map((point) => `${point.x},${point.y ?? ""},${point.valid}`)].join("\n");
    downloadGraphStudioFile(`${fileSlug(selected.input)}.csv`, csv, "text/csv");
  }

  function exportSelectedSvg() {
    if (!selected) return;
    const width = 1200;
    const height = 800;
    const path = selected.points.map((point) => {
      if (!point.valid || point.y === null) return "";
      const x = ((point.x - view.xMin) / (view.xMax - view.xMin)) * width;
      const y = height - ((point.y - view.yMin) / (view.yMax - view.yMin)) * height;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    }).filter(Boolean).join(" ");
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="white"/><polyline points="${path}" fill="none" stroke="${selected.color}" stroke-width="3"/><text x="24" y="38" font-family="monospace" font-size="24" fill="#0f172a">${escapeSvg(selected.input)}</text></svg>`;
    downloadGraphStudioFile(`${fileSlug(selected.input)}.svg`, svg, "image/svg+xml");
  }

  async function exportGraphPdf() {
    const svg = document.querySelector<SVGSVGElement>("#graphing-canvas-panel svg");
    if (!svg) return;
    const markup = new XMLSerializer().serializeToString(svg);
    const image = new Image();
    const url = URL.createObjectURL(new Blob([markup], { type: "image/svg+xml" }));
    await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("Graph image could not be prepared.")); image.src = url; });
    const canvas = document.createElement("canvas"); canvas.width = 1440; canvas.height = 880;
    const context = canvas.getContext("2d"); if (!context) { URL.revokeObjectURL(url); return; }
    context.fillStyle = "#ffffff"; context.fillRect(0, 0, canvas.width, canvas.height); context.drawImage(image, 0, 0, canvas.width, canvas.height); URL.revokeObjectURL(url);
    const { jsPDF } = await import("jspdf");
    const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
    pdf.setFontSize(18); pdf.text(graphStudio.project.name || "Graph Studio 2D", 32, 30);
    pdf.addImage(canvas.toDataURL("image/png"), "PNG", 32, 44, 778, 475);
    pdf.setFontSize(10); pdf.text(`Expressions: ${functions.map((item) => item.input).join(" | ").slice(0, 180)}`, 32, 540);
    pdf.save(`${fileSlug(graphStudio.project.name)}.pdf`);
  }

  function setPrecisionTraceX(value: number) {
    setTraceX(precisionSnapX(value, snapCandidates, view.xMax - view.xMin));
  }

  function updateFunction(id: string, patch: Partial<FunctionRow>) {
    setFunctions((items) => items.map((item) => item.id === id && (!item.locked || patch.locked === false || patch.visible !== undefined) ? { ...item, ...patch } : item));
  }

  function addConstruction(kind: "point" | "line" | "tangent" | "normal" | "conic") {
    const x = Number(traceX.toFixed(4));
    const fn = (() => { try { return compileFunctionExpression(selectedResolvedInput); } catch { return null; } })();
    const y = fn ? fn(x) : 0;
    const h = Math.max(1e-4, (view.xMax - view.xMin) / 10000);
    const slope = fn ? (fn(x + h) - fn(x - h)) / (2 * h) : 1;
    const expression = kind === "point" ? `(${formatGraphNumber(x)},${formatGraphNumber(y)})`
      : kind === "conic" ? `(x-(${formatGraphNumber(x)}))^2+(y-(${formatGraphNumber(y)}))^2=4`
      : kind === "normal" ? `y=${formatGraphNumber(-1 / (Math.abs(slope) < 1e-9 ? 1e-9 : slope))}*(x-(${formatGraphNumber(x)}))+(${formatGraphNumber(y)})`
      : kind === "line" ? `y=x-(${formatGraphNumber(x)})+(${formatGraphNumber(y)})`
      : `y=${formatGraphNumber(slope)}*(x-(${formatGraphNumber(x)}))+(${formatGraphNumber(y)})`;
    const id = `f${crypto.randomUUID()}`;
    setFunctions((items) => [...items, { id, input: expression, color: COLORS[items.length % COLORS.length], visible: true, name: `${kind[0].toUpperCase()}${kind.slice(1)} construction`, group: "Constructions", label: kind }]);
    setSelectedId(id);
  }

  function moveInteractivePoint(id: string, x: number, y: number) {
    if (id.startsWith("parameter:")) {
      const name = id.slice("parameter:".length);
      const variable = graphVariables.find((item) => item.name === name);
      if (!variable || !selectedFunction) return;
      const delta = Math.max(0.0001, variable.step);
      const shifted = graphVariables.map((item) => item.id === variable.id ? { ...item, value: item.value + delta } : item);
      try {
        const base = compileFunctionExpression(selectedResolvedInput)(x);
        const changedExpression = substituteGraphVariables(selectedSourceInput, shifted);
        const sensitivity = (compileFunctionExpression(changedExpression)(x) - base) / delta;
        if (Number.isFinite(sensitivity) && Math.abs(sensitivity) > 1e-8) updateStudioVariables(graphVariables.map((item) => item.id === variable.id ? { ...item, value: Math.max(item.min, Math.min(item.max, item.value + (y - base) / sensitivity)) } : item));
      } catch { /* Keep the parameter unchanged when the dragged location is outside its domain. */ }
      return;
    }
    const row = functions.find((item) => item.id === id);
    if (!row || row.locked) return;
    const descriptor = describeInteractiveExpression(row.input);
    if (!descriptor) return;
    if (descriptor.kind === "point") updateFunction(id, { input: `(${formatGraphNumber(x)},${formatGraphNumber(y)})` });
    if (descriptor.kind === "circle") updateFunction(id, { input: `(x-(${formatGraphNumber(x)}))^2+(y-(${formatGraphNumber(y)}))^2=${formatGraphNumber(descriptor.radiusSquared)}` });
    if (descriptor.kind === "line") updateFunction(id, { input: `y=${formatGraphNumber(descriptor.slope)}*x+(${formatGraphNumber(y - descriptor.slope * x)})` });
  }

  function moveFunction(id: string, direction: -1 | 1) {
    setFunctions((items) => {
      const index = items.findIndex((item) => item.id === id);
      const target = index + direction;
      if (index < 0 || target < 0 || target >= items.length) return items;
      const next = [...items];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function addFunction() {
    const id = `f${crypto.randomUUID()}`;
    setFunctions((items) => [...items, { id, input: "cos(x)", color: COLORS[items.length % COLORS.length], visible: true }]);
    setSelectedId(id);
  }

  function tryRandom() {
    const example = EXAMPLES[Math.floor(Math.random() * EXAMPLES.length)];
    const id = `f${crypto.randomUUID()}`;
    setFunctions((items) => [...items, { id, input: example, color: COLORS[items.length % COLORS.length], visible: true }]);
    setSelectedId(id);
  }

  function removeFunction(id: string) {
    setFunctions((items) => {
      const next = items.filter((item) => item.id !== id);
      if (selectedId === id && next[0]) setSelectedId(next[0].id);
      if (!next.length) setSelectedId("");
      return next;
    });
  }

  function setSelectedExample(example: string) {
    if (!selectedFunction) return;
    updateFunction(selectedFunction.id, { input: example });
  }

  function resetExample() {
    setFunctions([
      { id: "f1", input: "x^2 - 4", color: COLORS[0], visible: true },
      { id: "f2", input: "sin(x)", color: COLORS[1], visible: true },
    ]);
    setSelectedId("f1");
    setView({ xMin: -10, xMax: 10, yMin: -10, yMax: 10 });
    setTraceX(0);
  }

  function duplicateFunction(id: string) {
    const source = functions.find((item) => item.id === id);
    if (!source) return;
    const nextId = `f${crypto.randomUUID()}`;
    setFunctions((items) => [...items, { ...source, id: nextId, color: COLORS[items.length % COLORS.length] }]);
    setSelectedId(nextId);
  }

  function saveCurrentGraph() {
    const now = new Date().toISOString();
    const workspace: SavedGraphWorkspace<Graph2DWorkspaceState> = {
      id: `graph-2d-${Date.now()}`,
      name: saveName.trim() || "Untitled 2D graph",
      savedAt: now,
      state: graphStudioState,
    };
    setSavedGraphs(saveGraphWorkspace(GRAPH_2D_STORAGE_KEY, workspace));
  }

  function loadSavedGraph(workspace: SavedGraphWorkspace<Graph2DWorkspaceState>) {
    setFunctions(workspace.state.functions);
    setSelectedId(workspace.state.functions[0]?.id ?? "");
    setView(workspace.state.view);
    setShowGrid(workspace.state.showGrid);
    setShowAxes(workspace.state.showAxes);
    setTraceMode(workspace.state.traceMode);
    setIntegralStart(workspace.state.integralStart);
    setIntegralEnd(workspace.state.integralEnd);
    setGraphVariables(workspace.state.variables ?? []);
    setDataRows(workspace.state.dataRows?.length ? workspace.state.dataRows : createBlankGraphDataRows());
    setShowData(workspace.state.showData ?? true);
    setShowRegression(workspace.state.showRegression ?? false);
    setShowResiduals(workspace.state.showResiduals ?? false);
    setLogX(workspace.state.logX ?? false);
    setLogY(workspace.state.logY ?? false);
    setRegressionKind(workspace.state.regressionKind ?? "linear");
    setShowTaylor(workspace.state.showTaylor ?? false);
    setTaylorCenter(workspace.state.taylorCenter ?? 0);
    setTaylorDegree(workspace.state.taylorDegree ?? 4);
    setSaveName(workspace.name);
  }

  function removeSavedGraph(id: string) {
    setSavedGraphs(deleteGraphWorkspace<Graph2DWorkspaceState>(GRAPH_2D_STORAGE_KEY, id));
  }

}

function SavedGraphList({ saved, onLoad, onDelete }: { saved: SavedGraphWorkspace<Graph2DWorkspaceState>[]; onLoad: (workspace: SavedGraphWorkspace<Graph2DWorkspaceState>) => void; onDelete: (id: string) => void }) {
  if (!saved.length) return <p className="mt-3 text-sm font-semibold text-slate-500">No saved graphs yet.</p>;
  return (
    <div className="mt-3 max-h-56 space-y-2 overflow-auto" aria-label="Saved 2D graphs">
      {saved.map((workspace) => (
        <div key={workspace.id} className="flex items-center gap-2 rounded-xl border border-slate-200 p-2 dark:border-white/10">
          <button type="button" className="min-w-0 flex-1 text-left" onClick={() => onLoad(workspace)}>
            <span className="block truncate text-sm font-black">{workspace.name}</span>
            <span className="block text-xs text-slate-500">{workspace.state.functions.length} equation{workspace.state.functions.length === 1 ? "" : "s"}</span>
          </button>
          <button type="button" className="tooltip-icon rounded-lg p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-400/10" aria-label={`Delete ${workspace.name}`} data-tooltip="Delete saved graph" onClick={() => onDelete(workspace.id)}><Trash2 className="h-4 w-4" /></button>
        </div>
      ))}
    </div>
  );
}

export function sampleGraphExpression(input: string, xMin: number, xMax: number, samples: number, yMin = xMin, yMax = xMax): GraphExpressionSample {
  const normalized = input.trim().toLowerCase().replace(/\u00b2/g, "^2").replace(/\u00b3/g, "^3").replace(/\u03b8/g, "theta").replace(/\s+/g, "");
  const listMatch = normalized.match(/^\[(.+)\]$/);
  if (listMatch && listMatch[1].split(",").every((item) => /^-?\d+(?:\.\d+)?$/.test(item.trim()))) {
    const values = listMatch[1].split(",").map(Number);
    return {
      points: values.map((value, index) => ({ x: index + 1, y: value, valid: true })),
      normalized,
      style: "points",
    };
  }
  const advanced = sampleAdvancedGraphExpression(input, xMin, xMax);
  if (advanced) return advanced;
  if (normalized.includes(";") && normalized.split(";").every((item) => /^\(-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?\)$/.test(item))) {
    const points = normalized.split(";").map((item) => {
      const [x, y] = item.slice(1, -1).split(",").map(Number);
      return { x, y, valid: true };
    });
    return { points, normalized, style: "line" };
  }
  const pointMatch = normalized.match(/^\((-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)\)$/);
  if (pointMatch) {
    return { points: [{ x: Number(pointMatch[1]), y: Number(pointMatch[2]), valid: true }] as GraphSample[], normalized, style: "points" as const };
  }
  const circleMatch = normalized.match(/^x\^2\+y\^2=(-?\d+(?:\.\d+)?)$/i);
  if (circleMatch) {
    const radiusSquared = Number(circleMatch[1]);
    if (radiusSquared < 0) return { points: [] as GraphSample[], normalized, error: "A real circle needs a non-negative squared radius.", style: "line" as const };
    const radius = Math.sqrt(radiusSquared);
    const points = Array.from({ length: 361 }, (_, index) => {
      const angle = index / 360 * Math.PI * 2;
      return { x: radius * Math.cos(angle), y: radius * Math.sin(angle), valid: true };
    });
    return { points, normalized, style: "line" as const };
  }
  const parametric = normalized.match(/^x=(.+),y=(.+)$/i);
  if (parametric) {
    try {
      const xFn = compileFunctionExpression(parametric[1].replace(/(?<![a-z])t\b/g, "x"));
      const yFn = compileFunctionExpression(parametric[2].replace(/(?<![a-z])t\b/g, "x"));
      const count = Math.max(240, Math.floor(samples / 2));
      const points = Array.from({ length: count }, (_, index) => {
        const t = -Math.PI * 2 + index / Math.max(1, count - 1) * Math.PI * 4;
        const x = xFn(t);
        const y = yFn(t);
        return Number.isFinite(x) && Number.isFinite(y) ? { x, y, valid: true } : { x: t, y: null, valid: false };
      });
      return { points, normalized, style: "line" };
    } catch (error) {
      return { points: [], normalized, style: "line", error: error instanceof Error ? error.message : "Invalid parametric curve." };
    }
  }
  const polar = normalized.match(/^r=(.+)$/i);
  if (polar) {
    try {
      const radiusFn = compileFunctionExpression(polar[1].replace(/theta/gi, "x"));
      const count = Math.max(360, Math.floor(samples / 2));
      const points = Array.from({ length: count }, (_, index) => {
        const theta = index / Math.max(1, count - 1) * Math.PI * 2;
        const radius = radiusFn(theta);
        return Number.isFinite(radius) ? { x: radius * Math.cos(theta), y: radius * Math.sin(theta), valid: true } : { x: theta, y: null, valid: false };
      });
      return { points, normalized, style: "line" };
    } catch (error) {
      return { points: [], normalized, style: "line", error: error instanceof Error ? error.message : "Invalid polar graph." };
    }
  }
  // A bare expression in y is a sideways function, x = f(y).
  const sideways = normalized.match(/^x=(.+)$/i) ?? (/\by\b/.test(normalized) && !/[=<>]/.test(normalized) && !/\bx\b/.test(normalized) ? [normalized, normalized] : null);
  if (sideways) {
    try {
      const fn = compileFunctionExpression(sideways[1].replace(/(?<![a-z])y\b/g, "x"));
      const points = Array.from({ length: samples }, (_, index) => {
        const y = yMin + index / Math.max(1, samples - 1) * (yMax - yMin);
        const x = fn(y);
        return Number.isFinite(x) ? { x, y, valid: true } : { x: y, y: null, valid: false };
      });
      return { points, normalized, style: "line" };
    } catch (error) {
      return { points: [], normalized, style: "line", error: error instanceof Error ? error.message : "Invalid x = f(y) graph." };
    }
  }
  const relation = normalized.match(/^(.+?)(<=|>=|<|>|=)(.+)$/);
  if (relation && !normalized.includes("{") && /[xy]/i.test(normalized)) {
    const [, left, operator, right] = relation;
    try {
      const fn = compileTwoVariableExpression(`(${left})-(${right})`);
      if (operator !== "=") return { points: sampleInequalityRegion(fn, operator, xMin, xMax, yMin, yMax, 88), boundaryPoints: sampleImplicitRelation(fn, xMin, xMax, yMin, yMax, 110), boundaryStyle: operator.length === 1 ? "dashed" : "line", normalized, style: "region" };
      return { points: sampleImplicitRelation(fn, xMin, xMax, yMin, yMax, 140), normalized, style: "line" };
    } catch (error) {
      return { points: [], normalized, style: "points", error: error instanceof Error ? error.message : "Invalid implicit relation." };
    }
  }
  return { ...sampleFunction(input, xMin, xMax, samples), style: "line" as const };
}

function sampleImplicitRelation(fn: (x: number, y: number) => number, xMin: number, xMax: number, yMin: number, yMax: number, resolution: number) {
  const points: GraphSample[] = [];
  const dx = (xMax - xMin) / resolution;
  const dy = (yMax - yMin) / resolution;
  for (let row = 0; row < resolution; row += 1) {
    const y = yMin + row * dy;
    for (let column = 0; column < resolution; column += 1) {
      const x = xMin + column * dx;
      const corners = [
        { x, y, value: fn(x, y) },
        { x: x + dx, y, value: fn(x + dx, y) },
        { x: x + dx, y: y + dy, value: fn(x + dx, y + dy) },
        { x, y: y + dy, value: fn(x, y + dy) },
      ];
      if (!corners.every((corner) => Number.isFinite(corner.value))) continue;
      const intersections = [[0, 1], [1, 2], [2, 3], [3, 0]].flatMap(([from, to]) => {
        const a = corners[from];
        const b = corners[to];
        if (a.value !== 0 && b.value !== 0 && Math.sign(a.value) === Math.sign(b.value)) return [];
        const ratio = Math.abs(a.value - b.value) < 1e-12 ? 0.5 : a.value / (a.value - b.value);
        return [{ x: a.x + (b.x - a.x) * ratio, y: a.y + (b.y - a.y) * ratio, valid: true } as GraphSample];
      });
      for (let index = 0; index + 1 < intersections.length; index += 2) {
        points.push(intersections[index], intersections[index + 1], { x, y: null, valid: false });
      }
    }
  }
  return points;
}

function sampleInequalityRegion(fn: (x: number, y: number) => number, operator: string, xMin: number, xMax: number, yMin: number, yMax: number, resolution: number) {
  const points: GraphSample[] = [];
  for (let row = 0; row < resolution; row += 1) {
    const y = yMin + row / Math.max(1, resolution - 1) * (yMax - yMin);
    for (let column = 0; column < resolution; column += 1) {
      const x = xMin + column / Math.max(1, resolution - 1) * (xMax - xMin);
      const value = fn(x, y);
      const inside = operator.includes("<") ? value <= 0 : value >= 0;
      if (inside && Number.isFinite(value)) points.push({ x, y, valid: true });
    }
  }
  return points;
}

function approximateDerivativePoints(points: GraphSample[]) {
  const derivative: GraphSample[] = [];
  for (let index = 1; index < points.length - 1; index += 1) {
    const previous = points[index - 1];
    const next = points[index + 1];
    if (!previous.valid || !next.valid || previous.y === null || next.y === null || next.x === previous.x) continue;
    derivative.push({ x: points[index].x, y: (next.y - previous.y) / (next.x - previous.x), valid: true });
  }
  return derivative;
}

function approximateExtrema(points: GraphSample[]) {
  const valid = points.filter((point): point is GraphSample & { y: number } => point.valid && point.y !== null);
  const minima: Array<{ x: number; y: number }> = [];
  const maxima: Array<{ x: number; y: number }> = [];
  for (let index = 1; index < valid.length - 1; index += 1) {
    const previous = valid[index - 1];
    const current = valid[index];
    const next = valid[index + 1];
    if (current.y < previous.y && current.y <= next.y) minima.push({ x: current.x, y: current.y });
    if (current.y > previous.y && current.y >= next.y) maxima.push({ x: current.x, y: current.y });
  }
  return { minima: minima.slice(0, 6), maxima: maxima.slice(0, 6) };
}

function approximateIntegral(points: GraphSample[], start: number, end: number) {
  const valid = points.filter((point): point is GraphSample & { y: number } => point.valid && point.y !== null && point.x >= start && point.x <= end);
  if (valid.length < 2) return null;
  let area = 0;
  for (let index = 1; index < valid.length; index += 1) area += (valid[index].x - valid[index - 1].x) * (valid[index].y + valid[index - 1].y) / 2;
  return area;
}

function fileSlug(value: string) {
  return value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48) || "graph";
}

function escapeSvg(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

type InteractiveExpression =
  | { kind: "point"; x: number; y: number }
  | { kind: "circle"; x: number; y: number; radiusSquared: number }
  | { kind: "line"; slope: number; intercept: number };

function describeInteractiveExpression(input: string): InteractiveExpression | null {
  const normalized = input.replace(/\s+/g, "");
  const point = normalized.match(/^\((-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)\)$/);
  if (point) return { kind: "point", x: Number(point[1]), y: Number(point[2]) };
  const circle = normalized.match(/^\(x-\((-?\d+(?:\.\d+)?)\)\)\^2\+\(y-\((-?\d+(?:\.\d+)?)\)\)\^2=(-?\d+(?:\.\d+)?)$/i);
  if (circle) return { kind: "circle", x: Number(circle[1]), y: Number(circle[2]), radiusSquared: Number(circle[3]) };
  const line = normalized.match(/^y=(-?\d+(?:\.\d+)?)\*x\+\((-?\d+(?:\.\d+)?)\)$/i);
  if (line) return { kind: "line", slope: Number(line[1]), intercept: Number(line[2]) };
  const pointSlope = normalized.match(/^y=(-?\d+(?:\.\d+)?)\*\(x-\((-?\d+(?:\.\d+)?)\)\)\+\((-?\d+(?:\.\d+)?)\)$/i);
  if (pointSlope) {
    const slope = Number(pointSlope[1]); const anchorX = Number(pointSlope[2]); const anchorY = Number(pointSlope[3]);
    return { kind: "line", slope, intercept: anchorY - slope * anchorX };
  }
  const unitLine = normalized.match(/^y=x-\((-?\d+(?:\.\d+)?)\)\+\((-?\d+(?:\.\d+)?)\)$/i);
  if (unitLine) return { kind: "line", slope: 1, intercept: Number(unitLine[2]) - Number(unitLine[1]) };
  return null;
}

function buildInteractivePoint(row: FunctionRow | undefined, sampled: (FunctionRow & GraphExpressionSample) | undefined, traceX: number) {
  if (!row || row.locked) return null;
  const descriptor = describeInteractiveExpression(row.input);
  if (!descriptor) return null;
  const point = descriptor.kind === "line"
    ? { x: traceX, y: descriptor.slope * traceX + descriptor.intercept }
    : { x: descriptor.x, y: descriptor.y };
  if (!Number.isFinite(point.x) || !Number.isFinite(point.y) || !sampled) return null;
  return { id: row.id, ...point, label: row.name || "Drag to manipulate", color: row.color };
}

function buildParameterInteractivePoint(row: FunctionRow | undefined, resolvedExpression: string, variables: GraphStudioVariable[], traceX: number) {
  if (!row || row.locked) return null;
  const variable = variables.find((item) => new RegExp(`\\b${item.name}\\b`, "i").test(row.input));
  if (!variable) return null;
  try {
    const y = compileFunctionExpression(resolvedExpression)(traceX);
    if (!Number.isFinite(y)) return null;
    return { id: `parameter:${variable.name}`, x: traceX, y, label: `Drag to change ${variable.name}`, color: "#facc15" };
  } catch { return null; }
}

function buildShareUrl(functions: FunctionRow[], view: FunctionGraphView) {
  const payload = btoa(unescape(encodeURIComponent(JSON.stringify({ functions, view }))));
  const url = new URL(window.location.href); url.search = ""; url.searchParams.set("project", payload);
  return url.toString();
}

function readSharedGraph(value: string | null): { functions: FunctionRow[]; view: FunctionGraphView } | null {
  if (!value) return null;
  try {
    const parsed = JSON.parse(decodeURIComponent(escape(atob(value)))) as { functions?: FunctionRow[]; view?: FunctionGraphView };
    if (!Array.isArray(parsed.functions) || !parsed.view || ![parsed.view.xMin, parsed.view.xMax, parsed.view.yMin, parsed.view.yMax].every(Number.isFinite)) return null;
    return { functions: parsed.functions.filter((item) => item && typeof item.input === "string").slice(0, 40), view: parsed.view };
  } catch { return null; }
}

function formatGraphNumber(value: number) {
  if (!Number.isFinite(value)) return "0";
  return Number(value.toFixed(6)).toString();
}

function isSafeImageUrl(value?: string) {
  return Boolean(value && (/^https:\/\//i.test(value) || /^data:image\/(?:png|jpeg|gif|webp|svg\+xml)(?:;[^,]*)?,/i.test(value)));
}

function sameVariables(current: GraphStudioVariable[], next: GraphStudioVariable[]) {
  return current.length === next.length && current.every((variable, index) => variable.id === next[index]?.id);
}

export default function MathLabGraphingCalculator(props: {embedded?: EmbeddedGraphOptions} = {}) { return <ImmersiveBoundary><MathLabGraphingCalculatorContent {...props} /></ImmersiveBoundary>; }
