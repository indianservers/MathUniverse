import { BookOpen, CheckCircle2, Download, Expand, FileText, Grid3X3, List, RotateCcw, Search, Share2, Sparkles, Tags, Workflow } from "lucide-react";
import { forwardRef, useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { formulaVisualizerConfigs, getFormulaVisualizerConfig, type FormulaVisualizerEntry, type FormulaVisualizerRouteConfig } from "../data/formulaVisualizerRoutes";
import { buildFormulaVisualizationExplanation, type FormulaVisualizationExplanation } from "../data/formulaVisualizationExplanations";
import { getSetLogicVisualMode, type SetLogicVisualMode } from "../utils/setLogicVisualModel";
import { getProportionalVisualMode, PROPORTIONAL_FORMULA_IDS } from "../utils/proportionalVisualModel";
import MathExpression from "../components/ui/MathExpression";
import SectionCard from "../components/ui/SectionCard";
import SliderControl, { SliderGroup } from "../components/ui/SliderControl";
import DerivativesFormulaStudio from "./DerivativesFormulaStudio";
import IntegrationFormulaStudio from "./IntegrationFormulaStudio";

type FormulaVisualizerPageProps = {
  conceptId: string;
};

type FormulaParameters = {
  a: number;
  b: number;
  c: number;
  n: number;
  p: number;
};

export type FormulaControlSpec = {
  key: keyof FormulaParameters;
  label: string;
  min: number;
  max: number;
  step: number;
  unit?: string;
};

const defaultParams: FormulaParameters = { a: 3, b: 2, c: 1, n: 8, p: 45 };
const baseTabs = ["Explore", "Formula Bank", "Examples", "Why it Works", "Practice"] as const;
type Tab = (typeof baseTabs)[number] | "Teacher Notes";

export const realFormulaVisualizerModelTypes = [
  "graph",
  "area",
  "geometry",
  "coordinate",
  "calculus",
  "matrix",
  "vector",
  "probability",
  "statistics",
  "mensuration",
  "number-system",
  "complex",
  "sequence",
  "combinatorics",
  "set-logic",
  "function",
  "linear-programming",
  "polynomial",
  "inequality",
  "distribution",
  "limits-continuity",
  "differential-equations",
  "determinant",
  "three-d-geometry",
  "early-number-sense",
  "fraction-percent",
  "commercial-math",
  "speed-work",
  "mental-math",
  "pre-algebra",
  "number-theory",
  "euclidean-geometry",
  "analytic-geometry",
  "precalculus",
  "calculus-applications",
  "multivariable-calculus",
  "advanced-linear-algebra",
  "abstract-algebra",
  "real-analysis",
  "complex-analysis",
  "topology",
  "differential-geometry",
  "discrete-math",
  "optimization",
  "numerical-methods",
  "dynamical-systems",
  "pde",
  "transforms",
  "mathematical-physics",
  "information-theory",
  "machine-learning",
  "cryptography",
] as const satisfies readonly FormulaVisualizerEntry["visualizerType"][];

export default function FormulaVisualizerPage({ conceptId }: FormulaVisualizerPageProps) {
  const config = getFormulaVisualizerConfig(conceptId);

  if (!config) {
    return (
      <main className="desktop-page-shell">
        <section className="desktop-card p-5">
          <h1 className="text-2xl font-black">Formula visualizer not found</h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">This concept does not have a configured visualizer route.</p>
          <Link to="/formulas" className="action-primary mt-4 w-fit">
            Open Formula Library
          </Link>
        </section>
      </main>
    );
  }

  if (conceptId === "derivatives") return <DerivativesFormulaStudio config={config} />;
  if (conceptId === "integration") return <IntegrationFormulaStudio _config={config} />;
  if (conceptId === "vectors") return <VectorsFormulaStudio config={config} />;

  return <FormulaVisualizerShell config={config} />;
}

type VectorParameters = {
  ax: number;
  ay: number;
  bx: number;
  by: number;
  k: number;
};

type VectorToolState = {
  grid: boolean;
  components: boolean;
  labels: boolean;
  trace: boolean;
};

const defaultVectorParams: VectorParameters = { ax: 3, ay: 2, bx: 1, by: 8, k: 2 };

function VectorsFormulaStudio({ config }: { config: FormulaVisualizerRouteConfig }) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<Tab>("Explore");
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState("All");
  const [selectedId, setSelectedId] = useState(() => searchParams.get("v_formula") ?? config.defaultFormulaId);
  const [params, setParams] = useState<VectorParameters>(() => ({
    ax: readVectorParam(searchParams, "v_ax", defaultVectorParams.ax),
    ay: readVectorParam(searchParams, "v_ay", defaultVectorParams.ay),
    bx: readVectorParam(searchParams, "v_bx", defaultVectorParams.bx),
    by: readVectorParam(searchParams, "v_by", defaultVectorParams.by),
    k: readVectorParam(searchParams, "v_k", defaultVectorParams.k),
  }));
  const [tools, setTools] = useState<VectorToolState>({ grid: true, components: true, labels: true, trace: false });
  const [practiceAnswer, setPracticeAnswer] = useState("");

  const groups = useMemo(() => ["All", ...Array.from(new Set(config.formulas.map((formula) => formula.group)))], [config.formulas]);
  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return config.formulas.filter((formula) => {
      const matchesGroup = group === "All" || formula.group === group;
      const matchesText =
        !normalized ||
        [formula.title, formula.plainText, formula.description, formula.group, formula.difficulty, ...formula.tags]
          .join(" ")
          .toLowerCase()
          .includes(normalized);
      return matchesGroup && matchesText;
    });
  }, [config.formulas, group, query]);
  const selected = config.formulas.find((formula) => formula.id === selectedId) ?? filtered[0] ?? config.formulas[0];
  const metrics = computeVectorMetrics(params);
  const genericParams = vectorToFormulaParams(params);
  const practiceExpected = Math.round(vectorPracticeValue(selected, metrics) * 100) / 100;
  const practiceNumeric = Number(practiceAnswer);
  const practiceCorrect = practiceAnswer.trim() !== "" && Number.isFinite(practiceNumeric) && Math.abs(practiceNumeric - practiceExpected) <= 0.05;

  useEffect(() => {
    const next = new URLSearchParams(searchParams);
    next.set("v_formula", selected.id);
    next.set("v_ax", compactNumber(params.ax));
    next.set("v_ay", compactNumber(params.ay));
    next.set("v_bx", compactNumber(params.bx));
    next.set("v_by", compactNumber(params.by));
    next.set("v_k", compactNumber(params.k));
    if (next.toString() !== searchParams.toString()) setSearchParams(next, { replace: true });
  }, [params, searchParams, selected.id, setSearchParams]);

  const setVectorParam = (key: keyof VectorParameters, value: number) => {
    setParams((current) => ({ ...current, [key]: clampVectorValue(value, key === "k" ? -5 : -10, key === "k" ? 5 : 10) }));
  };
  const reset = () => {
    setParams(defaultVectorParams);
    setSelectedId(config.defaultFormulaId);
  };
  const selectFormula = (id: string) => {
    setSelectedId(id);
    setActiveTab("Explore");
  };

  return (
    <main className="desktop-page-shell bg-[radial-gradient(circle_at_20%_8%,rgba(34,211,238,0.16),transparent_28%),radial-gradient(circle_at_84%_6%,rgba(167,139,250,0.16),transparent_30%),#f8fbff]" data-testid="vectors-formula-visualizer-page">
      <section className="mx-auto flex w-full max-w-[1580px] flex-col gap-3">
        <header className="rounded-2xl border border-slate-200/90 bg-white/86 p-4 shadow-sm dark:border-white/10 dark:bg-slate-950/80">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
            <div className="min-w-0">
              <p className="flex items-center gap-2 text-xs font-black uppercase tracking-wide text-cyan-700 dark:text-cyan-300">
                <Sparkles className="h-4 w-4" />
                Visual Formula Lab
              </p>
              <h1 className="mt-1 text-3xl font-black tracking-tight text-slate-950 dark:text-white">Vectors</h1>
              <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-300">Explore vector operations through live geometry.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="action-secondary" onClick={() => setActiveTab("Formula Bank")}>
                <BookOpen className="h-4 w-4" /> Formula Library
              </button>
              <Link to={config.formulaLibraryRoute} className="action-secondary">
                <FileText className="h-4 w-4" /> Reference
              </Link>
              <button type="button" className="action-primary" onClick={reset}>
                <RotateCcw className="h-4 w-4" /> Reset
              </button>
            </div>
          </div>
          <FormulaTabs tabs={baseTabs} activeTab={activeTab} onChange={setActiveTab} />
        </header>

        {activeTab === "Explore" ? (
          <>
            <section className="grid min-h-0 min-w-0 items-start gap-3 lg:grid-cols-[minmax(0,1fr)_320px] xl:grid-cols-[270px_minmax(0,1fr)_330px]" data-testid="vectors-studio-explore-layout">
              <VectorFormulaLibrary
                filtered={filtered}
                group={group}
                groups={groups}
                query={query}
                selected={selected}
                onGroup={setGroup}
                onQuery={setQuery}
                onSelect={setSelectedId}
              />
              <VectorVisualizationStage formula={selected} params={params} metrics={metrics} tools={tools} onTools={setTools} />
              <VectorControlsPanel formula={selected} params={params} metrics={metrics} onChange={setVectorParam} onReset={reset} onStep={() => setActiveTab("Why it Works")} />
            </section>
            <LearnTheIdea formula={selected} metrics={metrics} />
          </>
        ) : null}

        {activeTab === "Formula Bank" ? <VectorFormulaBank config={config} formulas={filtered} query={query} setQuery={setQuery} onSelect={selectFormula} /> : null}
        {activeTab === "Examples" ? <VectorExamples config={config} onLoad={(next) => { setParams(next); setActiveTab("Explore"); }} /> : null}
        {activeTab === "Why it Works" ? <ExplanationPanel config={config} formula={selected} /> : null}
        {activeTab === "Practice" ? (
          <PracticePanel
            formula={selected}
            params={genericParams}
            answer={practiceAnswer}
            expected={practiceExpected}
            correct={practiceCorrect}
            setAnswer={setPracticeAnswer}
          />
        ) : null}
      </section>
    </main>
  );
}

function VectorFormulaBank({ config, formulas, query, setQuery, onSelect }: { config: FormulaVisualizerRouteConfig; formulas: FormulaVisualizerEntry[]; query: string; setQuery: (value: string) => void; onSelect: (id: string) => void }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-sm dark:border-white/10 dark:bg-slate-950/88">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-2xl font-black text-slate-950 dark:text-white">Formula Bank</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{config.formulas.length} vector formulas with compact references and live entry points.</p>
        </div>
        <label className="flex min-h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold dark:border-white/10 dark:bg-slate-900 lg:w-[360px]">
          <Search className="h-4 w-4 text-slate-400" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search bank..." className="min-w-0 flex-1 bg-transparent outline-none" />
        </label>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {formulas.map((formula) => (
          <article key={formula.id} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm dark:border-white/10 dark:bg-white/5">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-black text-slate-950 dark:text-white">{formula.title}</h3>
              <span className="mini-chip">{formula.difficulty}</span>
            </div>
            <MathExpression value={formula.latex} className="mt-2 text-cyan-700 dark:text-cyan-200" />
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{formula.description}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="mini-chip">{formula.group}</span>
              {formula.tags.slice(0, 3).map((tag) => <span key={tag} className="mini-chip">{tag}</span>)}
            </div>
            <button type="button" className="action-secondary mt-3" onClick={() => onSelect(formula.id)}>
              Open in Explore
            </button>
          </article>
        ))}
      </div>
    </section>
  );
}

function VectorExamples({ config, onLoad }: { config: FormulaVisualizerRouteConfig; onLoad: (params: VectorParameters) => void }) {
  const examples = config.examples.map((example, index) => {
    const base = [
      { ax: 3, ay: 2, bx: 1, by: 8, k: 2 },
      { ax: -2, ay: 4, bx: 5, by: -1, k: -1.5 },
      { ax: 6, ay: -3, bx: -4, by: 5, k: 3 },
    ][index % 3];
    return { ...example, vectorValues: base };
  });
  return (
    <section className="grid gap-3 lg:grid-cols-3">
      {examples.map((example) => (
        <article key={example.title} className="rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-sm dark:border-white/10 dark:bg-slate-950/88">
          <h2 className="text-xl font-black text-slate-950 dark:text-white">{example.title}</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{example.description}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <span className="mini-chip">a=({example.vectorValues.ax}, {example.vectorValues.ay})</span>
            <span className="mini-chip">b=({example.vectorValues.bx}, {example.vectorValues.by})</span>
            <span className="mini-chip">k={example.vectorValues.k}</span>
          </div>
          <button type="button" className="action-primary mt-4" onClick={() => onLoad(example.vectorValues)}>
            Load example
          </button>
        </article>
      ))}
    </section>
  );
}

function computeVectorMetrics(params: VectorParameters) {
  const dot = params.ax * params.bx + params.ay * params.by;
  const cross = params.ax * params.by - params.ay * params.bx;
  const magA = Math.hypot(params.ax, params.ay);
  const magB = Math.hypot(params.bx, params.by);
  const sum = { x: params.ax + params.bx, y: params.ay + params.by };
  const sumMagnitude = Math.hypot(sum.x, sum.y);
  const sumAngle = angleDegrees(sum.x, sum.y);
  const angle = magA > 0 && magB > 0 ? Math.acos(Math.max(-1, Math.min(1, dot / (magA * magB)))) * 180 / Math.PI : 0;
  const projectionScale = magB > 0 ? dot / (magB * magB) : 0;
  const projection = { x: projectionScale * params.bx, y: projectionScale * params.by };
  const unitA = magA > 0 ? { x: params.ax / magA, y: params.ay / magA } : { x: 0, y: 0 };
  return { dot, cross, magA, magB, sum, sumMagnitude, sumAngle, angle, projection, projectionScale, unitA };
}

function vectorResultCards(formula: FormulaVisualizerEntry, metrics: ReturnType<typeof computeVectorMetrics>, params: VectorParameters) {
  if (formula.id === "dot-product") return [
    { label: "Dot product", value: compactNumber(metrics.dot), color: "text-cyan-600 dark:text-cyan-200" },
    { label: "Angle", value: `${compactNumber(metrics.angle)} deg`, color: "text-violet-600 dark:text-violet-200" },
    { label: "Alignment", value: metrics.dot >= 0 ? "same direction" : "opposite pull", color: "text-emerald-600 dark:text-emerald-200" },
  ];
  if (formula.id === "cross-product") return [
    { label: "Cross product", value: compactNumber(metrics.cross), color: "text-amber-600 dark:text-amber-200" },
    { label: "Area", value: compactNumber(Math.abs(metrics.cross)), color: "text-cyan-600 dark:text-cyan-200" },
    { label: "Orientation", value: metrics.cross >= 0 ? "counterclockwise" : "clockwise", color: "text-violet-600 dark:text-violet-200" },
  ];
  if (formula.id === "projection") return [
    { label: "Projection", value: `(${compactNumber(metrics.projection.x)}, ${compactNumber(metrics.projection.y)})`, color: "text-amber-600 dark:text-amber-200" },
    { label: "Scale on b", value: compactNumber(metrics.projectionScale), color: "text-cyan-600 dark:text-cyan-200" },
    { label: "|b|", value: compactNumber(metrics.magB), color: "text-violet-600 dark:text-violet-200" },
  ];
  if (formula.id === "scalar-vector") return [
    { label: "Scaled vector", value: `(${compactNumber(params.k * params.ax)}, ${compactNumber(params.k * params.ay)})`, color: "text-amber-600 dark:text-amber-200" },
    { label: "Magnitude", value: compactNumber(Math.abs(params.k) * metrics.magA), color: "text-cyan-600 dark:text-cyan-200" },
    { label: "Scalar k", value: compactNumber(params.k), color: "text-violet-600 dark:text-violet-200" },
  ];
  if (formula.id === "magnitude") return [
    { label: "Magnitude |a|", value: compactNumber(metrics.magA), color: "text-cyan-600 dark:text-cyan-200" },
    { label: "Direction a", value: `${compactNumber(angleDegrees(params.ax, params.ay))} deg`, color: "text-violet-600 dark:text-violet-200" },
    { label: "Components", value: `(${compactNumber(params.ax)}, ${compactNumber(params.ay)})`, color: "text-amber-600 dark:text-amber-200" },
  ];
  if (formula.id === "unit-vector") return [
    { label: "Unit vector", value: `(${compactNumber(metrics.unitA.x)}, ${compactNumber(metrics.unitA.y)})`, color: "text-cyan-600 dark:text-cyan-200" },
    { label: "|a|", value: compactNumber(metrics.magA), color: "text-violet-600 dark:text-violet-200" },
    { label: "Unit length", value: metrics.magA > 0 ? "1" : "undefined", color: "text-amber-600 dark:text-amber-200" },
  ];
  if (formula.id === "angle-between") return [
    { label: "Angle theta", value: `${compactNumber(metrics.angle)} deg`, color: "text-violet-600 dark:text-violet-200" },
    { label: "Dot product", value: compactNumber(metrics.dot), color: "text-cyan-600 dark:text-cyan-200" },
    { label: "|a||b|", value: compactNumber(metrics.magA * metrics.magB), color: "text-amber-600 dark:text-amber-200" },
  ];
  return [
    { label: "Resultant", value: `(${compactNumber(metrics.sum.x)}, ${compactNumber(metrics.sum.y)})`, color: "text-cyan-600 dark:text-cyan-200" },
    { label: "Magnitude", value: compactNumber(metrics.sumMagnitude), color: "text-emerald-600 dark:text-emerald-200" },
    { label: "Direction", value: `${compactNumber(metrics.sumAngle)} deg`, color: "text-violet-600 dark:text-violet-200" },
  ];
}

function vectorCalculationLines(formula: FormulaVisualizerEntry, params: VectorParameters, metrics: ReturnType<typeof computeVectorMetrics>) {
  if (formula.id === "dot-product") return ["\\vec a\\cdot\\vec b=a_xb_x+a_yb_y", `=${compactNumber(params.ax)}(${compactNumber(params.bx)})+${compactNumber(params.ay)}(${compactNumber(params.by)})`, `=${compactNumber(metrics.dot)}`];
  if (formula.id === "cross-product") return ["|\\vec a\\times\\vec b|=|a_xb_y-a_yb_x|", `=|${compactNumber(params.ax)}(${compactNumber(params.by)})-${compactNumber(params.ay)}(${compactNumber(params.bx)})|`, `=${compactNumber(Math.abs(metrics.cross))}`];
  if (formula.id === "projection") return ["\\mathrm{proj}_b a=\\frac{a\\cdot b}{|b|^2}b", `=\\frac{${compactNumber(metrics.dot)}}{${compactNumber(metrics.magB ** 2)}}(${compactNumber(params.bx)},${compactNumber(params.by)})`, `=(${compactNumber(metrics.projection.x)},${compactNumber(metrics.projection.y)})`];
  if (formula.id === "scalar-vector") return ["k\\vec a=\\langle ka_x,ka_y\\rangle", `=${compactNumber(params.k)}(${compactNumber(params.ax)},${compactNumber(params.ay)})`, `=(${compactNumber(params.k * params.ax)},${compactNumber(params.k * params.ay)})`];
  if (formula.id === "magnitude") return ["|\\vec a|=\\sqrt{a_x^2+a_y^2}", `=\\sqrt{${compactNumber(params.ax)}^2+${compactNumber(params.ay)}^2}`, `=${compactNumber(metrics.magA)}`];
  if (formula.id === "unit-vector") return ["\\hat a=\\frac{\\vec a}{|\\vec a|}", `=\\frac{(${compactNumber(params.ax)},${compactNumber(params.ay)})}{${compactNumber(metrics.magA)}}`, `=(${compactNumber(metrics.unitA.x)},${compactNumber(metrics.unitA.y)})`];
  if (formula.id === "angle-between") return ["\\cos\\theta=\\frac{a\\cdot b}{|a||b|}", `=\\frac{${compactNumber(metrics.dot)}}{${compactNumber(metrics.magA)}\\cdot${compactNumber(metrics.magB)}}`, `\\theta=${compactNumber(metrics.angle)}^\\circ`];
  return ["\\vec a+\\vec b=(a_x+b_x,a_y+b_y)", `=(${compactNumber(params.ax)}+${compactNumber(params.bx)},${compactNumber(params.ay)}+${compactNumber(params.by)})`, `=(${compactNumber(metrics.sum.x)},${compactNumber(metrics.sum.y)})`];
}

function vectorBadge(formula: FormulaVisualizerEntry, metrics: ReturnType<typeof computeVectorMetrics>, params: VectorParameters) {
  if (formula.id === "dot-product") return `a dot b = ${compactNumber(metrics.dot)}`;
  if (formula.id === "cross-product") return `area = ${compactNumber(Math.abs(metrics.cross))}`;
  if (formula.id === "projection") return `proj = (${compactNumber(metrics.projection.x)}, ${compactNumber(metrics.projection.y)})`;
  if (formula.id === "scalar-vector") return `k a = (${compactNumber(params.k * params.ax)}, ${compactNumber(params.k * params.ay)})`;
  if (formula.id === "magnitude") return `|a| = ${compactNumber(metrics.magA)}`;
  if (formula.id === "unit-vector") return `unit = (${compactNumber(metrics.unitA.x)}, ${compactNumber(metrics.unitA.y)})`;
  if (formula.id === "angle-between") return `theta = ${compactNumber(metrics.angle)} deg`;
  return `|a + b| = ${compactNumber(metrics.sumMagnitude)}`;
}

function vectorPracticeValue(formula: FormulaVisualizerEntry, metrics: ReturnType<typeof computeVectorMetrics>) {
  if (formula.id === "dot-product") return metrics.dot;
  if (formula.id === "cross-product") return Math.abs(metrics.cross);
  if (formula.id === "projection") return metrics.projectionScale;
  if (formula.id === "magnitude" || formula.id === "unit-vector") return metrics.magA;
  if (formula.id === "angle-between") return metrics.angle;
  return metrics.sumMagnitude;
}

function vectorToFormulaParams(params: VectorParameters): FormulaParameters {
  return { a: params.ax, b: params.ay, c: params.bx, n: params.by, p: params.k };
}

function readVectorParam(searchParams: URLSearchParams, key: string, fallback: number) {
  const raw = searchParams.get(key);
  if (raw === null) return fallback;
  const value = Number(raw);
  return Number.isFinite(value) ? value : fallback;
}

function clampVectorValue(value: number, min: number, max: number) {
  if (!Number.isFinite(value)) return 0;
  return Number(Math.min(max, Math.max(min, value)).toFixed(4));
}

function compactNumber(value: number) {
  if (!Number.isFinite(value)) return "undefined";
  return Number(value.toFixed(2)).toString();
}

function angleDegrees(x: number, y: number) {
  if (x === 0 && y === 0) return 0;
  const angle = Math.atan2(y, x) * 180 / Math.PI;
  return angle < 0 ? angle + 360 : angle;
}

function downloadVectorPng(svg: SVGSVGElement | null) {
  if (!svg || typeof document === "undefined") return;
  const xml = new XMLSerializer().serializeToString(svg);
  const svgBlob = new Blob([xml], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svgBlob);
  const image = new Image();
  image.onload = () => {
    const canvas = document.createElement("canvas");
    canvas.width = 1520;
    canvas.height = 860;
    const context = canvas.getContext("2d");
    if (!context) return;
    context.fillStyle = "#07152d";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    URL.revokeObjectURL(url);
    const anchor = document.createElement("a");
    anchor.download = "vectors-formula-visualizer.png";
    anchor.href = canvas.toDataURL("image/png");
    anchor.click();
  };
  image.src = url;
}

function printVectorPdf(target: HTMLElement | null) {
  if (!target || typeof window === "undefined") return;
  window.print();
}

async function shareCurrentVectorUrl() {
  if (typeof window === "undefined") return;
  const url = window.location.href;
  if (navigator.share) {
    await navigator.share({ title: "Vectors Formula Visualizer", url });
    return;
  }
  await navigator.clipboard?.writeText(url);
}

function FormulaTabs({ tabs, activeTab, onChange }: { tabs: readonly Tab[]; activeTab: Tab; onChange: (tab: Tab) => void }) {
  return (
    <nav className="mt-4 flex gap-2 overflow-x-auto" aria-label="Vectors formula visualizer tabs">
      {tabs.map((tab) => (
        <button key={tab} type="button" className={activeTab === tab ? "action-primary shrink-0 px-4 py-2 text-sm" : "tool-button shrink-0 px-4 py-2 text-sm"} onClick={() => onChange(tab)}>
          {tab}
        </button>
      ))}
    </nav>
  );
}

function VectorFormulaLibrary({
  filtered,
  group,
  groups,
  query,
  selected,
  onGroup,
  onQuery,
  onSelect,
}: {
  filtered: FormulaVisualizerEntry[];
  group: string;
  groups: string[];
  query: string;
  selected: FormulaVisualizerEntry;
  onGroup: (value: string) => void;
  onQuery: (value: string) => void;
  onSelect: (value: string) => void;
}) {
  return (
    <aside className="rounded-2xl border border-slate-200 bg-white/92 p-3 shadow-sm dark:border-white/10 dark:bg-slate-950/82 lg:col-span-2 xl:col-span-1">
      <h2 className="text-sm font-black uppercase tracking-wide text-slate-950 dark:text-white">Formulas</h2>
      <label className="mt-3 flex min-h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold dark:border-white/10 dark:bg-slate-900">
        <Search className="h-4 w-4 text-slate-400" />
        <span className="sr-only">Search vector formulas</span>
        <input value={query} onChange={(event) => onQuery(event.target.value)} placeholder="Search formulas..." className="min-w-0 flex-1 bg-transparent outline-none" />
      </label>
      <div className="mt-2 flex gap-1 overflow-x-auto pb-1">
        {groups.map((item) => (
          <button key={item} type="button" className={group === item ? "mini-chip bg-cyan-500 text-white" : "mini-chip"} onClick={() => onGroup(item)}>
            {item}
          </button>
        ))}
      </div>
      <div className="mt-2 max-h-[56vh] space-y-2 overflow-y-auto pr-1 thin-scrollbar">
        {filtered.map((formula) => (
          <FormulaListItem key={formula.id} formula={formula} selected={formula.id === selected.id} onSelect={() => onSelect(formula.id)} />
        ))}
      </div>
    </aside>
  );
}

function FormulaListItem({ formula, selected, onSelect }: { formula: FormulaVisualizerEntry; selected: boolean; onSelect: () => void }) {
  return (
    <button
      type="button"
      className={`w-full rounded-xl border p-3 text-left transition ${selected ? "border-cyan-300 bg-cyan-50 shadow-sm dark:border-cyan-300/50 dark:bg-cyan-400/10" : "border-slate-200 bg-white hover:border-cyan-200 dark:border-white/10 dark:bg-white/5"}`}
      onClick={onSelect}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="flex min-w-0 items-start gap-2">
          <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${selected ? "bg-cyan-500" : "bg-slate-300"}`} />
          <span className="min-w-0">
            <span className="block text-sm font-black text-slate-950 dark:text-white">{formula.title}</span>
            <MathExpression value={formula.latex} className="mt-1 block text-sm text-slate-700 dark:text-cyan-100" />
          </span>
        </span>
        <span className="mini-chip shrink-0">{formula.group}</span>
      </div>
    </button>
  );
}

function VectorVisualizationStage({ formula, params, metrics, tools, onTools }: { formula: FormulaVisualizerEntry; params: VectorParameters; metrics: ReturnType<typeof computeVectorMetrics>; tools: VectorToolState; onTools: (tools: VectorToolState) => void }) {
  const stageRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const resultCards = vectorResultCards(formula, metrics, params);

  const toggle = (key: keyof VectorToolState) => onTools({ ...tools, [key]: !tools[key] });

  return (
    <section className="min-w-0 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-sm dark:border-white/10 dark:bg-slate-950/88">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-black text-slate-950 dark:text-white">{formula.title}</h2>
            <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-sm font-black text-emerald-700 dark:border-emerald-300/30 dark:bg-emerald-300/10 dark:text-emerald-100">{vectorBadge(formula, metrics, params)}</span>
          </div>
          <p className="mt-1 text-sm leading-5 text-slate-600 dark:text-slate-300">{formula.description}</p>
          <MathExpression value={formula.latex} display className="mt-2 text-lg font-black text-slate-900 dark:text-white" />
        </div>
        <VectorLegend params={params} metrics={metrics} />
      </header>

      <div ref={stageRef} className="mt-3 overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 shadow-inner shadow-cyan-950/40">
        <VectorGraph ref={svgRef} formula={formula} params={params} metrics={metrics} tools={tools} />
      </div>

      <div className="mt-3 grid gap-2 md:grid-cols-3">
        {resultCards.map((card) => (
          <article key={card.label} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm dark:border-white/10 dark:bg-white/5">
            <p className="text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">{card.label}</p>
            <p className={`mt-1 text-2xl font-black ${card.color}`}>{card.value}</p>
          </article>
        ))}
      </div>
      <VisualizationToolbar
        tools={tools}
        onToggle={toggle}
        onResetView={() => onTools({ grid: true, components: true, labels: true, trace: false })}
        onFullscreen={() => stageRef.current?.requestFullscreen?.()}
        onPng={() => downloadVectorPng(svgRef.current)}
        onPdf={() => printVectorPdf(stageRef.current)}
        onShare={() => shareCurrentVectorUrl()}
      />
    </section>
  );
}

function VectorLegend({ params, metrics }: { params: VectorParameters; metrics: ReturnType<typeof computeVectorMetrics> }) {
  const rows = [
    ["bg-cyan-400", `Vector a (${compactNumber(params.ax)}, ${compactNumber(params.ay)})`],
    ["bg-violet-500", `Vector b (${compactNumber(params.bx)}, ${compactNumber(params.by)})`],
    ["bg-amber-400", `Resultant a + b (${compactNumber(metrics.sum.x)}, ${compactNumber(metrics.sum.y)})`],
  ];
  return (
    <div className="grid gap-1 text-xs font-bold text-slate-700 dark:text-slate-200">
      {rows.map(([dot, label]) => (
        <span key={label} className="flex items-center gap-2">
          <i className={`h-1.5 w-5 rounded-full ${dot}`} />
          {label}
        </span>
      ))}
    </div>
  );
}

const VectorGraph = forwardRef<SVGSVGElement, { formula: FormulaVisualizerEntry; params: VectorParameters; metrics: ReturnType<typeof computeVectorMetrics>; tools: VectorToolState }>(function VectorGraph({ formula, params, metrics, tools }, ref) {
  const scale = 28;
  const origin = { x: 340, y: 300 };
  const point = (x: number, y: number) => ({ x: origin.x + x * scale, y: origin.y - y * scale });
  const a = point(params.ax, params.ay);
  const b = point(params.bx, params.by);
  const sum = point(metrics.sum.x, metrics.sum.y);
  const tipBFromA = { x: a.x + params.bx * scale, y: a.y - params.by * scale };
  const projection = point(metrics.projection.x, metrics.projection.y);
  const scalar = point(params.ax * params.k, params.ay * params.k);
  const showResultant = ["vector-addition", "magnitude", "unit-vector", "direction-cosines"].includes(formula.id);
  const showDotProjection = ["dot-product", "projection", "angle-between"].includes(formula.id);
  const showCross = formula.id === "cross-product";

  return (
    <svg ref={ref} viewBox="0 0 760 430" role="img" aria-label={`${formula.title} vector graph`} className="block aspect-[76/43] min-h-[360px] w-full">
      <defs>
        <marker id="vfs-cyan-arrow" markerWidth="13" markerHeight="13" refX="11" refY="6.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L13,6.5 L0,13 z" fill="#22d3ee" /></marker>
        <marker id="vfs-violet-arrow" markerWidth="13" markerHeight="13" refX="11" refY="6.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L13,6.5 L0,13 z" fill="#8b5cf6" /></marker>
        <marker id="vfs-amber-arrow" markerWidth="13" markerHeight="13" refX="11" refY="6.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L13,6.5 L0,13 z" fill="#f59e0b" /></marker>
      </defs>
      <rect width="760" height="430" rx="22" fill="#07152d" />
      {tools.grid ? <GraphGrid origin={origin} scale={scale} /> : null}
      <line x1="36" y1={origin.y} x2="724" y2={origin.y} stroke="#cbd5e1" strokeWidth="1.6" />
      <line x1={origin.x} y1="28" x2={origin.x} y2="398" stroke="#cbd5e1" strokeWidth="1.6" />
      <text x="728" y={origin.y - 12} fill="#e0f2fe" fontSize="15" fontWeight="900">x</text>
      <text x={origin.x + 12} y="36" fill="#e0f2fe" fontSize="15" fontWeight="900">y</text>
      {tools.components ? (
        <g strokeDasharray="7 7">
          <line x1={a.x} y1={a.y} x2={a.x} y2={origin.y} stroke="#22d3ee" strokeWidth="1.5" opacity="0.72" />
          <line x1={a.x} y1={a.y} x2={origin.x} y2={a.y} stroke="#22d3ee" strokeWidth="1.5" opacity="0.72" />
          <line x1={sum.x} y1={sum.y} x2={sum.x} y2={origin.y} stroke="#f59e0b" strokeWidth="1.5" opacity="0.72" />
          <line x1={sum.x} y1={sum.y} x2={origin.x} y2={sum.y} stroke="#f59e0b" strokeWidth="1.5" opacity="0.72" />
        </g>
      ) : null}
      {tools.trace ? <polyline points={`${origin.x},${origin.y} ${a.x},${a.y} ${tipBFromA.x},${tipBFromA.y}`} fill="none" stroke="#e0f2fe" strokeWidth="2" strokeDasharray="8 8" opacity="0.58" /> : null}
      {showCross ? <polygon points={`${origin.x},${origin.y} ${a.x},${a.y} ${sum.x},${sum.y} ${b.x},${b.y}`} fill="#f59e0b" opacity="0.16" stroke="#f59e0b" strokeWidth="2" /> : null}
      {showDotProjection ? (
        <g>
          <line x1={a.x} y1={a.y} x2={projection.x} y2={projection.y} stroke="#f8fafc" strokeWidth="1.8" strokeDasharray="7 7" opacity="0.75" />
          <line x1={origin.x} y1={origin.y} x2={projection.x} y2={projection.y} stroke="#f59e0b" strokeWidth="5" markerEnd="url(#vfs-amber-arrow)" />
          <circle cx={projection.x} cy={projection.y} r="5" fill="#f59e0b" />
        </g>
      ) : null}
      <line x1={origin.x} y1={origin.y} x2={a.x} y2={a.y} stroke="#22d3ee" strokeWidth="5" strokeLinecap="round" markerEnd="url(#vfs-cyan-arrow)" />
      <line x1={origin.x} y1={origin.y} x2={b.x} y2={b.y} stroke="#8b5cf6" strokeWidth="5" strokeLinecap="round" markerEnd="url(#vfs-violet-arrow)" />
      {formula.id === "scalar-vector" ? <line x1={origin.x} y1={origin.y} x2={scalar.x} y2={scalar.y} stroke="#f59e0b" strokeWidth="5" strokeLinecap="round" markerEnd="url(#vfs-amber-arrow)" /> : null}
      {showResultant || formula.id === "vector-addition" ? <line x1={origin.x} y1={origin.y} x2={sum.x} y2={sum.y} stroke="#f59e0b" strokeWidth="5" strokeLinecap="round" markerEnd="url(#vfs-amber-arrow)" /> : null}
      {formula.id === "vector-addition" ? <line x1={a.x} y1={a.y} x2={tipBFromA.x} y2={tipBFromA.y} stroke="#8b5cf6" strokeWidth="4" strokeLinecap="round" markerEnd="url(#vfs-violet-arrow)" opacity="0.9" /> : null}
      <circle cx={a.x} cy={a.y} r="5.5" fill="#a5f3fc" />
      <circle cx={b.x} cy={b.y} r="5.5" fill="#ddd6fe" />
      <circle cx={sum.x} cy={sum.y} r="6" fill="#fcd34d" />
      {tools.labels ? (
        <g fontSize="18" fontWeight="900">
          <text x={(origin.x + a.x) / 2 + 14} y={(origin.y + a.y) / 2 - 10} fill="#67e8f9">a</text>
          <text x={(origin.x + b.x) / 2 + 14} y={(origin.y + b.y) / 2 - 10} fill="#c4b5fd">b</text>
          <text x={(origin.x + sum.x) / 2 + 16} y={(origin.y + sum.y) / 2 - 12} fill="#fbbf24">a + b</text>
          {showDotProjection ? <text x={projection.x + 12} y={projection.y + 20} fill="#fbbf24">projection</text> : null}
        </g>
      ) : null}
    </svg>
  );
});

function GraphGrid({ origin, scale }: { origin: { x: number; y: number }; scale: number }) {
  const verticals = Array.from({ length: 25 }, (_, index) => index - 12);
  const horizontals = Array.from({ length: 15 }, (_, index) => index - 7);
  return (
    <g>
      {verticals.map((value) => (
        <line key={`v-${value}`} x1={origin.x + value * scale} y1="28" x2={origin.x + value * scale} y2="398" stroke={value === 0 ? "#cbd5e1" : "#1e3a5f"} strokeWidth={value === 0 ? 1.5 : 1} />
      ))}
      {horizontals.map((value) => (
        <line key={`h-${value}`} x1="36" y1={origin.y - value * scale} x2="724" y2={origin.y - value * scale} stroke={value === 0 ? "#cbd5e1" : "#1e3a5f"} strokeWidth={value === 0 ? 1.5 : 1} />
      ))}
      {verticals.filter((value) => value % 2 === 0 && value !== 0).map((value) => (
        <text key={`vx-${value}`} x={origin.x + value * scale} y={origin.y + 22} fill="#94a3b8" fontSize="12" fontWeight="800" textAnchor="middle">{value}</text>
      ))}
      {horizontals.filter((value) => value % 2 === 0 && value !== 0).map((value) => (
        <text key={`hy-${value}`} x={origin.x - 14} y={origin.y - value * scale + 4} fill="#94a3b8" fontSize="12" fontWeight="800" textAnchor="end">{value}</text>
      ))}
    </g>
  );
}

function VisualizationToolbar({
  tools,
  onToggle,
  onResetView,
  onFullscreen,
  onPng,
  onPdf,
  onShare,
}: {
  tools: VectorToolState;
  onToggle: (key: keyof VectorToolState) => void;
  onResetView: () => void;
  onFullscreen: () => void;
  onPng: () => void;
  onPdf: () => void;
  onShare: () => void;
}) {
  const buttons: Array<{ key: keyof VectorToolState; label: string; icon: JSX.Element }> = [
    { key: "grid", label: "Grid", icon: <Grid3X3 className="h-4 w-4" /> },
    { key: "components", label: "Components", icon: <Workflow className="h-4 w-4" /> },
    { key: "labels", label: "Labels", icon: <Tags className="h-4 w-4" /> },
    { key: "trace", label: "Trace", icon: <List className="h-4 w-4" /> },
  ];
  return (
    <div className="mt-3 flex flex-wrap gap-2 rounded-xl border border-slate-200 bg-slate-50 p-2 dark:border-white/10 dark:bg-white/5">
      {buttons.map((button) => (
        <button key={button.key} type="button" className={tools[button.key] ? "action-primary px-3 py-2 text-sm" : "tool-button px-3 py-2 text-sm"} onClick={() => onToggle(button.key)}>
          {button.icon} {button.label}
        </button>
      ))}
      <button type="button" className="tool-button px-3 py-2 text-sm" onClick={onResetView}><RotateCcw className="h-4 w-4" /> Reset view</button>
      <button type="button" className="tool-button px-3 py-2 text-sm" onClick={onFullscreen}><Expand className="h-4 w-4" /> Fullscreen</button>
      <button type="button" className="tool-button px-3 py-2 text-sm" onClick={onPng}><Download className="h-4 w-4" /> PNG</button>
      <button type="button" className="tool-button px-3 py-2 text-sm" onClick={onPdf}><FileText className="h-4 w-4" /> PDF</button>
      <button type="button" className="tool-button px-3 py-2 text-sm" onClick={onShare}><Share2 className="h-4 w-4" /> Share</button>
    </div>
  );
}

function VectorControlsPanel({ formula, params, metrics, onChange, onReset, onStep }: { formula: FormulaVisualizerEntry; params: VectorParameters; metrics: ReturnType<typeof computeVectorMetrics>; onChange: (key: keyof VectorParameters, value: number) => void; onReset: () => void; onStep: () => void }) {
  return (
    <aside className="rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-sm dark:border-white/10 dark:bg-slate-950/88 lg:sticky lg:top-24">
      <h2 className="text-sm font-black uppercase tracking-wide text-slate-950 dark:text-white">Vector Controls</h2>
      <VectorInputGroup title="Vector a" color="cyan" pair={`(${compactNumber(params.ax)}, ${compactNumber(params.ay)})`} controls={[["ax", "a_x"], ["ay", "a_y"]]} params={params} onChange={onChange} />
      {formula.id !== "magnitude" && formula.id !== "unit-vector" && formula.id !== "scalar-vector" ? (
        <VectorInputGroup title="Vector b" color="violet" pair={`(${compactNumber(params.bx)}, ${compactNumber(params.by)})`} controls={[["bx", "b_x"], ["by", "b_y"]]} params={params} onChange={onChange} />
      ) : null}
      {formula.id === "scalar-vector" ? (
        <VectorInputGroup title="Scalar" color="amber" pair={`k = ${compactNumber(params.k)}`} controls={[["k", "k"]]} params={params} onChange={onChange} min={-5} max={5} />
      ) : null}
      <LiveCalculation formula={formula} params={params} metrics={metrics} onStep={onStep} />
      <button type="button" className="action-secondary mt-3 w-full" onClick={onReset}>
        <RotateCcw className="h-4 w-4" /> Reset
      </button>
    </aside>
  );
}

function VectorInputGroup({ title, color, pair, controls, params, onChange, min = -10, max = 10 }: { title: string; color: "cyan" | "violet" | "amber"; pair: string; controls: Array<[keyof VectorParameters, string]>; params: VectorParameters; onChange: (key: keyof VectorParameters, value: number) => void; min?: number; max?: number }) {
  const colorClasses = color === "cyan" ? "border-cyan-300 bg-cyan-50/70 text-cyan-700 dark:border-cyan-300/40 dark:bg-cyan-400/10 dark:text-cyan-100" : color === "violet" ? "border-violet-300 bg-violet-50/70 text-violet-700 dark:border-violet-300/40 dark:bg-violet-400/10 dark:text-violet-100" : "border-amber-300 bg-amber-50/70 text-amber-700 dark:border-amber-300/40 dark:bg-amber-400/10 dark:text-amber-100";
  const accent = color === "cyan" ? "accent-cyan-500" : color === "violet" ? "accent-violet-500" : "accent-amber-500";
  return (
    <section className={`mt-3 rounded-xl border p-3 ${colorClasses}`}>
      <div className="mb-2 flex items-center justify-between gap-2">
        <h3 className="text-sm font-black">{title}</h3>
        <span className="text-sm font-black">{pair}</span>
      </div>
      <div className="grid gap-2">
        {controls.map(([key, label]) => (
          <label key={key} className="grid grid-cols-[42px_minmax(0,1fr)_68px] items-center gap-2">
            <span className="font-serif text-sm font-black">{label}</span>
            <input aria-label={`${label} slider`} type="range" min={min} max={max} step="0.25" value={params[key]} onChange={(event) => onChange(key, Number(event.target.value))} className={`min-w-0 ${accent}`} />
            <input aria-label={`${label} value`} type="number" min={min} max={max} step="0.25" value={Number(params[key].toFixed(4))} onChange={(event) => onChange(key, Number(event.target.value))} className="min-w-0 rounded-lg border border-white/80 bg-white px-2 py-1 text-right text-sm font-black text-slate-900 outline-none focus:border-cyan-400 dark:border-white/10 dark:bg-slate-950 dark:text-white" />
          </label>
        ))}
      </div>
      <div className="mt-1 flex justify-between px-[42px] text-[10px] font-black opacity-70"><span>{min}</span><span>{max}</span></div>
    </section>
  );
}

function LiveCalculation({ formula, params, metrics, onStep }: { formula: FormulaVisualizerEntry; params: VectorParameters; metrics: ReturnType<typeof computeVectorMetrics>; onStep: () => void }) {
  const lines = vectorCalculationLines(formula, params, metrics);
  return (
    <section className="mt-3 rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-white/5">
      <h3 className="text-sm font-black uppercase tracking-wide text-slate-950 dark:text-white">Live Calculation</h3>
      <div className="mt-2 grid gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
        {lines.map((line) => <MathExpression key={line} value={line} display />)}
      </div>
      <button type="button" className="action-primary mt-3 w-full" onClick={onStep}>
        <List className="h-4 w-4" /> Step-by-step
      </button>
    </section>
  );
}

function LearnTheIdea({ formula, metrics }: { formula: FormulaVisualizerEntry; metrics: ReturnType<typeof computeVectorMetrics> }) {
  const isAddition = formula.id === "vector-addition";
  const cards = isAddition
    ? [
        ["1", "Add components", `Add x-components and y-components separately. Result: (${compactNumber(metrics.sum.x)}, ${compactNumber(metrics.sum.y)}).`],
        ["2", "Draw tip-to-tail", "Place b at the head of a. The same arrow from start to final tip is a + b."],
        ["3", "Read the resultant", `Length is ${compactNumber(metrics.sumMagnitude)} and direction is ${compactNumber(metrics.sumAngle)} degrees.`],
      ]
    : [
        ["1", "Read the vectors", "Start with components, because every vector formula is built from them."],
        ["2", "Apply the formula", formula.description],
        ["3", "Check the geometry", "Compare the number with the graph: length, angle, area, or projection should match the visual."],
      ];
  return (
    <details className="rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-sm dark:border-white/10 dark:bg-slate-950/88" open>
      <summary className="cursor-pointer text-sm font-black uppercase tracking-wide text-cyan-700 dark:text-cyan-300">Learn the Idea</summary>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        {cards.map(([number, title, text]) => (
          <article key={title} className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/5">
            <div className="flex items-start gap-3">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-blue-600 text-sm font-black text-white">{number}</span>
              <div>
                <h3 className="font-black text-slate-950 dark:text-white">{title}</h3>
                <p className="mt-1 text-sm leading-5 text-slate-600 dark:text-slate-300">{text}</p>
              </div>
            </div>
          </article>
        ))}
      </div>
      <details className="mt-3 rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-white/10 dark:bg-white/5">
        <summary className="cursor-pointer font-black">More explanation</summary>
        <FormulaExplanationContent explanation={buildFormulaVisualizationExplanation(formula)} formula={formula} compact />
      </details>
    </details>
  );
}



function FormulaVisualizerShell({ config }: { config: FormulaVisualizerRouteConfig }) {
  const [activeTab, setActiveTab] = useState<Tab>("Explore");
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState("All");
  const [difficulty, setDifficulty] = useState("All");
  const [selectedId, setSelectedId] = useState(config.defaultFormulaId);
  const [params, setParams] = useState<FormulaParameters>(defaultParams);
  const [practiceAnswer, setPracticeAnswer] = useState("");
  const tabs = useMemo<Tab[]>(() => (config.teacherNotes ? [...baseTabs, "Teacher Notes"] : [...baseTabs]), [config.teacherNotes]);

  const groups = useMemo(() => ["All", ...Array.from(new Set(config.formulas.map((formula) => formula.group)))], [config.formulas]);
  const difficulties = useMemo(() => ["All", ...Array.from(new Set(config.formulas.map((formula) => formula.difficulty)))], [config.formulas]);
  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return config.formulas.filter((formula) => {
      const matchesGroup = group === "All" || formula.group === group;
      const matchesDifficulty = difficulty === "All" || formula.difficulty === difficulty;
      const matchesText =
        !normalized ||
        [formula.title, formula.plainText, formula.description, formula.group, formula.difficulty, ...formula.tags]
          .join(" ")
          .toLowerCase()
          .includes(normalized);
      return matchesGroup && matchesDifficulty && matchesText;
    });
  }, [config.formulas, difficulty, group, query]);

  const selected = config.formulas.find((formula) => formula.id === selectedId) ?? filtered[0] ?? config.formulas[0];
  const practiceExpected = Math.round(computeResult(selected, params) * 100) / 100;
  const practiceNumeric = Number(practiceAnswer);
  const practiceCorrect = practiceAnswer.trim() !== "" && Number.isFinite(practiceNumeric) && Math.abs(practiceNumeric - practiceExpected) <= 0.05;

  const updateParam = (key: keyof FormulaParameters, value: number) => setParams((current) => ({ ...current, [key]: value }));
  const reset = () => setParams(defaultParams);

  return (
    <main className="desktop-page-shell" data-testid={`${config.id}-formula-visualizer-page`}>
      <section className="mx-auto flex w-full max-w-[1580px] flex-col gap-3">
        <header className="desktop-card overflow-hidden p-0">
          <div className="border-b border-slate-200 bg-gradient-to-r from-cyan-50 via-white to-violet-50 p-4 dark:border-white/10 dark:from-cyan-950/30 dark:via-slate-950 dark:to-violet-950/30">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
              <div className="min-w-0">
                <p className="flex items-center gap-2 text-xs font-black uppercase tracking-wide text-cyan-700 dark:text-cyan-300">
                  <Sparkles className="h-4 w-4" />
                  Visual Formula Visualizer
                </p>
                <h1 className="mt-1 text-3xl font-black tracking-tight text-slate-950 dark:text-white">{config.title}</h1>
                <p className="mt-2 max-w-4xl text-sm leading-6 text-slate-600 dark:text-slate-300">{config.subtitle}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link to="/formulas" className="action-secondary">
                  All formulas
                </Link>
                {config.id === "number-systems" ? (
                  <Link to="/number-systems" className="action-secondary">
                    Number Systems Studio
                  </Link>
                ) : null}
                <Link to={config.formulaLibraryRoute} className="action-secondary">
                  Reference sheet
                </Link>
                <button type="button" className="action-primary" onClick={reset}>
                  <RotateCcw className="h-4 w-4" /> Reset controls
                </button>
              </div>
            </div>
          </div>
          <nav className="flex gap-1 overflow-x-auto p-2" aria-label={`${config.shortTitle} formula visualizer tabs`}>
            {tabs.map((tab) => (
              <button key={tab} type="button" className={activeTab === tab ? "action-primary shrink-0 px-3 py-2 text-sm" : "tool-button shrink-0 px-3 py-2 text-sm"} onClick={() => setActiveTab(tab)}>
                {tab}
              </button>
            ))}
          </nav>
        </header>

        {activeTab === "Explore" ? (
          <section
            className="grid min-h-0 min-w-0 items-start gap-3 xl:grid-cols-[minmax(260px,300px)_minmax(0,1fr)] 2xl:grid-cols-[minmax(260px,320px)_minmax(0,1fr)_minmax(300px,340px)]"
            data-testid="formula-visualizer-explore-layout"
          >
            <FormulaSelector
              config={config}
              difficulty={difficulty}
              difficulties={difficulties}
              filtered={filtered}
              group={group}
              groups={groups}
              query={query}
              selected={selected}
              setDifficulty={setDifficulty}
              setGroup={setGroup}
              setQuery={setQuery}
              setSelectedId={setSelectedId}
            />
            <InteractiveFormulaPanel config={config} formula={selected} params={params} />
            <FormulaParameterControls formula={selected} params={params} reset={reset} updateParam={updateParam} />
          </section>
        ) : null}

        {activeTab === "Formula Bank" ? <FormulaBank config={config} formulas={filtered} query={query} setQuery={setQuery} setSelectedId={setSelectedId} setActiveTab={setActiveTab} /> : null}
        {activeTab === "Examples" ? <ExamplePanel config={config} setParams={setParams} setActiveTab={setActiveTab} /> : null}
        {activeTab === "Why it Works" ? <ExplanationPanel config={config} formula={selected} /> : null}
        {activeTab === "Practice" ? (
          <PracticePanel
            formula={selected}
            params={params}
            answer={practiceAnswer}
            expected={practiceExpected}
            correct={practiceCorrect}
            setAnswer={setPracticeAnswer}
          />
        ) : null}
        {activeTab === "Teacher Notes" && config.teacherNotes ? <TeacherNotesPanel config={config} /> : null}
      </section>
    </main>
  );
}

function FormulaSelector({
  config,
  difficulty,
  difficulties,
  filtered,
  group,
  groups,
  query,
  selected,
  setDifficulty,
  setGroup,
  setQuery,
  setSelectedId,
}: {
  config: FormulaVisualizerRouteConfig;
  difficulty: string;
  difficulties: string[];
  filtered: FormulaVisualizerEntry[];
  group: string;
  groups: string[];
  query: string;
  selected: FormulaVisualizerEntry;
  setDifficulty: (value: string) => void;
  setGroup: (value: string) => void;
  setQuery: (value: string) => void;
  setSelectedId: (value: string) => void;
}) {
  return (
    <aside className="desktop-sidebar-panel min-h-0 min-w-0 space-y-3 xl:sticky xl:top-24">
      <label className="flex min-h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold dark:border-white/10 dark:bg-slate-950/70">
        <Search className="h-4 w-4 text-slate-400" />
        <span className="sr-only">Search {config.shortTitle} formulas</span>
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search formula..." className="min-w-0 flex-1 bg-transparent outline-none" />
      </label>
      <div className="grid grid-cols-2 gap-2">
        <select className="min-w-0 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold dark:border-white/10 dark:bg-slate-950" value={group} onChange={(event) => setGroup(event.target.value)} aria-label="Formula group filter">
          {groups.map((item) => <option key={item}>{item}</option>)}
        </select>
        <select className="min-w-0 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold dark:border-white/10 dark:bg-slate-950" value={difficulty} onChange={(event) => setDifficulty(event.target.value)} aria-label="Formula difficulty filter">
          {difficulties.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
      <div className="max-h-[58vh] space-y-2 overflow-y-auto pr-1 thin-scrollbar">
        {filtered.map((formula) => (
          <button
            key={formula.id}
            type="button"
            className={`w-full rounded-xl border p-3 text-left transition ${formula.id === selected.id ? "border-cyan-300 bg-cyan-50 shadow-sm dark:border-cyan-300/50 dark:bg-cyan-400/10" : "border-slate-200 bg-white/80 hover:border-cyan-200 dark:border-white/10 dark:bg-white/5"}`}
            onClick={() => setSelectedId(formula.id)}
          >
            <div className="flex items-start justify-between gap-2">
              <p className="text-sm font-black text-slate-950 dark:text-white">{formula.title}</p>
              <span className="mini-chip">{formula.difficulty}</span>
            </div>
            <MathExpression value={formula.latex} className="mt-2 text-sm text-cyan-700 dark:text-cyan-200" />
            <p className="mt-2 line-clamp-2 text-xs leading-5 text-slate-600 dark:text-slate-300">{formula.description}</p>
          </button>
        ))}
      </div>
    </aside>
  );
}

function InteractiveFormulaPanel({ config, formula, params }: { config: FormulaVisualizerRouteConfig; formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const result = computeResult(formula, params);
  const explanation = buildFormulaVisualizationExplanation(formula);
  return (
    <SectionCard
      title={formula.title}
      description={`${formula.group} visual model with live formula, diagram, and value updates.`}
      className="min-w-0"
      allowFullscreen
      headerAction={
        <div className="rounded-xl border border-cyan-200 bg-cyan-50 px-3 py-2 text-sm font-black text-cyan-900 dark:border-cyan-300/30 dark:bg-cyan-400/10 dark:text-cyan-100">
          Live value: {formatNumber(result)}
        </div>
      }
    >
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-wide text-cyan-700 dark:text-cyan-300">{formula.group}</p>
          <MathExpression value={formula.latex} display className="mt-2 text-lg text-slate-950 dark:text-white" />
        </div>
      </div>
      <FormulaCanvas formula={formula} params={params} />
      <div className="mt-3 grid gap-2 md:grid-cols-3">
        <InfoTile label="Formula type" value={formula.visualizerType} />
        <InfoTile label="Variables" value={formula.variables.join(", ")} />
        <InfoTile label="Reference" value={config.category} />
      </div>
      <details className="mt-4 rounded-2xl border border-cyan-200 bg-cyan-50/70 p-4 dark:border-cyan-300/20 dark:bg-cyan-300/10" open>
        <summary className="cursor-pointer text-lg font-black text-slate-950 dark:text-white">How to understand this visualization</summary>
        <FormulaExplanationContent explanation={explanation} formula={formula} compact />
      </details>
    </SectionCard>
  );
}

function FormulaParameterControls({ formula, params, reset, updateParam }: { formula: FormulaVisualizerEntry; params: FormulaParameters; reset: () => void; updateParam: (key: keyof FormulaParameters, value: number) => void }) {
  const warning = getWarning(formula, params);
  const controls = getFormulaControlSpecs(formula);
  return (
    <aside className="desktop-sidebar-panel min-w-0 space-y-3 xl:col-span-2 2xl:col-span-1 2xl:sticky 2xl:top-24">
      <SliderGroup title="Controls" description="Move values and watch the visual, result, and substitution update together.">
        {controls.map((control) => (
          <SliderControl
            key={`${control.key}-${control.label}`}
            density="compact"
            label={control.label}
            value={params[control.key]}
            min={control.min}
            max={control.max}
            step={control.step}
            unit={control.unit}
            onChange={(value) => updateParam(control.key, value)}
          />
        ))}
      </SliderGroup>
      {warning ? <div className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm font-bold text-amber-900 dark:border-amber-300/40 dark:bg-amber-300/10 dark:text-amber-100">{warning}</div> : null}
      <div className="rounded-xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-white/5">
        <p className="text-sm font-black text-slate-950 dark:text-white">Substitution</p>
        <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{buildSubstitution(formula, params)}</p>
        <button type="button" className="action-secondary mt-3 w-full" onClick={reset}>
          <RotateCcw className="h-4 w-4" /> Reset
        </button>
      </div>
    </aside>
  );
}

const controlKeyOrder: (keyof FormulaParameters)[] = ["a", "b", "c", "n", "p"];

const variableControlAliases: Record<string, keyof FormulaParameters> = {
  r: "a",
  x: "a",
  y: "b",
  h: "b",
  theta: "p",
  "θ": "p",
  d: "n",
  x1: "a",
  y1: "b",
  x2: "c",
  y2: "n",
  ax: "a",
  ay: "b",
  bx: "c",
  by: "n",
  mu: "a",
  sigma: "b",
  "p(e)": "p",
};

export function getFormulaControlSpecs(formula: FormulaVisualizerEntry): FormulaControlSpec[] {
  if (formula.visualizerType === "number-system") {
    return formula.variables.map((variable) => {
      const lower = variable.trim().toLowerCase();
      if (formula.id === "irrational-root" && lower === "p") return { key: "n" as const, label: "p", min: 2, max: 50, step: 1 };
      if (lower === "n") return { key: "n" as const, label: variable, min: 2, max: 120, step: 1 };
      if (lower === "q" && formula.id === "decimal-terminating") return { key: "n" as const, label: "q", min: 2, max: 120, step: 1 };
      if (lower === "a") return { key: "a" as const, label: "a", min: 2, max: 96, step: 1 };
      if (lower === "b") return { key: "b" as const, label: "b", min: 2, max: 96, step: 1 };
      if (lower === "p") return { key: "a" as const, label: "p", min: -24, max: 24, step: 1 };
      if (lower === "q") return { key: "b" as const, label: "q", min: 1, max: 24, step: 1 };
      return { key: "n" as const, label: variable, min: 2, max: 48, step: 1 };
    });
  }
  const used = new Set<keyof FormulaParameters>();

  return formula.variables.slice(0, controlKeyOrder.length).map((variable) => {
    const normalized = variable.trim();
    const lower = normalized.toLowerCase();
    const directKey = controlKeyOrder.includes(normalized as keyof FormulaParameters) ? normalized as keyof FormulaParameters : undefined;
    const preferredKey = directKey ?? variableControlAliases[lower];
    const key = preferredKey && !used.has(preferredKey)
      ? preferredKey
      : controlKeyOrder.find((candidate) => !used.has(candidate)) ?? "a";
    used.add(key);

    if (lower === "theta" || normalized === "θ") {
      return { key, label: "θ", min: 5, max: 85, step: 1, unit: "°" };
    }
    if (key === "n") return { key, label: normalized, min: 1, max: 24, step: 1 };
    if (key === "p") return { key, label: normalized, min: 0, max: 100, step: 1, unit: "%" };
    return { key, label: normalized, min: -6, max: 8, step: 0.25 };
  });
}

function FormulaCanvas({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const result = computeResult(formula, params);
  const points = useMemo(() => makeCurvePoints(formula, params), [formula, params]);
  const bars = makeBars(params);
  const areaSize = Math.max(44, Math.min(128, Math.abs(params.a) * 18 + 40));
  const bSize = Math.max(34, Math.min(100, Math.abs(params.b) * 16 + 28));
  const vectorA = { x: 230 + params.a * 18, y: 190 - params.b * 18 };
  const vectorB = { x: 230 + params.c * 24, y: 190 - (params.n - 8) * 9 };
  const radius = Math.max(36, Math.min(112, Math.abs(params.a) * 12 + 44));
  const sectorAngle = (params.p / 100) * Math.PI * 2;
  const sectorEnd = { x: 230 + radius * Math.cos(-sectorAngle), y: 190 + radius * Math.sin(-sectorAngle) };

  return (
    <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200 bg-slate-950 shadow-inner shadow-cyan-950/30 group-data-[fullscreen=true]/section:h-[calc(100vh-250px)] dark:border-white/10">
      <svg viewBox="0 0 760 500" role="img" aria-label={`${formula.title} interactive visual output`} className="aspect-[38/25] h-auto w-full max-w-full group-data-[fullscreen=true]/section:h-full">
        <defs>
          <linearGradient id="formulaPane" x1="0" x2="1">
            <stop stopColor="#08111f" />
            <stop offset="1" stopColor="#10243c" />
          </linearGradient>
          <filter id="softGlow" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="5" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        <rect width="760" height="500" rx="22" fill="url(#formulaPane)" />
        <g transform="translate(0 100)">
          <Grid />
          {isProportionalReasoningFormula(formula.id) ? (
          <ProportionalReasoningVisual formula={formula} params={params} />
        ) : isTrigonometryFormula(formula.id) ? (
          <TrigonometryFormulaVisual formula={formula} params={params} />
        ) : isDeepenedPhaseOneFormula(formula.id) ? (
          <DeepenedPhaseOneVisual formula={formula} params={params} />
        ) : formula.visualizerType === "area" ? (
          <g transform="translate(240 78)">
            <rect x="0" y="0" width={areaSize} height={areaSize} fill="#22d3ee" opacity="0.78" />
            <rect x={areaSize} y="0" width={bSize} height={areaSize} fill="#f59e0b" opacity="0.78" />
            <rect x="0" y={areaSize} width={areaSize} height={bSize} fill="#f59e0b" opacity="0.72" />
            <rect x={areaSize} y={areaSize} width={bSize} height={bSize} fill="#a78bfa" opacity="0.82" />
            <path d={`M0 0 H${areaSize + bSize} V${areaSize + bSize} H0 Z`} fill="none" stroke="#e0f2fe" strokeWidth="4" />
            <Text x={areaSize / 2} y={areaSize / 2} value="a^2" />
            <Text x={areaSize + bSize / 2} y={areaSize / 2} value="ab" />
            <Text x={areaSize / 2} y={areaSize + bSize / 2} value="ab" />
            <Text x={areaSize + bSize / 2} y={areaSize + bSize / 2} value="b^2" />
          </g>
        ) : formula.visualizerType === "geometry" || formula.visualizerType === "mensuration" ? (
          <g>
            <circle cx="230" cy="190" r={radius} fill="#22d3ee" opacity="0.16" stroke="#67e8f9" strokeWidth="4" />
            <path d={`M230 190 L${230 + radius} 190 A${radius} ${radius} 0 ${params.p > 50 ? 1 : 0} 0 ${sectorEnd.x} ${sectorEnd.y} Z`} fill="#f59e0b" opacity="0.45" stroke="#fde68a" strokeWidth="3" />
            <polygon points={`430,280 ${430 + areaSize},280 ${430 + areaSize * 0.74},${280 - bSize}`} fill="#a78bfa" opacity="0.5" stroke="#ddd6fe" strokeWidth="4" />
            <line x1="230" y1="190" x2={230 + radius} y2="190" stroke="#e0f2fe" strokeWidth="3" />
            <Text x="230" y="185" value="r" />
            <Text x="508" y="304" value="base" />
            <Text x="610" y="218" value="height" />
          </g>
        ) : formula.visualizerType === "coordinate" || formula.visualizerType === "graph" || formula.visualizerType === "calculus" ? (
          <g>
            <polyline points={points} fill="none" stroke="#22d3ee" strokeWidth="5" strokeLinecap="round" filter="url(#softGlow)" />
            {formula.visualizerType === "calculus" ? bars.map((bar) => <rect key={bar.x} x={bar.x} y={bar.y} width={bar.w} height={bar.h} fill="#f59e0b" opacity="0.45" stroke="#fde68a" />) : null}
            <circle cx="380" cy={190 - result * 9} r="8" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
            <line x1="80" y1="190" x2="680" y2="190" stroke="#94a3b8" strokeWidth="2" />
            <line x1="380" y1="50" x2="380" y2="330" stroke="#94a3b8" strokeWidth="2" />
          </g>
        ) : formula.visualizerType === "matrix" ? (
          <MatrixVisual params={params} />
        ) : formula.visualizerType === "vector" ? (
          <g>
            <line x1="80" y1="190" x2="680" y2="190" stroke="#94a3b8" strokeWidth="2" />
            <line x1="230" y1="330" x2="230" y2="50" stroke="#94a3b8" strokeWidth="2" />
            <Arrow x1={230} y1={190} x2={vectorA.x} y2={vectorA.y} color="#22d3ee" label="a" />
            <Arrow x1={230} y1={190} x2={vectorB.x} y2={vectorB.y} color="#f59e0b" label="b" />
            <Arrow x1={230} y1={190} x2={vectorA.x + vectorB.x - 230} y2={vectorA.y + vectorB.y - 190} color="#a78bfa" label="a+b" />
          </g>
        ) : formula.visualizerType === "probability" ? (
          <g>
            <circle cx="330" cy="190" r={95 + params.a * 3} fill="#22d3ee" opacity="0.42" stroke="#67e8f9" strokeWidth="4" />
            <circle cx="430" cy="190" r={85 + params.b * 3} fill="#a78bfa" opacity="0.42" stroke="#ddd6fe" strokeWidth="4" />
            <Text x="285" y="190" value="A" />
            <Text x="475" y="190" value="B" />
            <Text x="380" y="190" value="A∩B" />
            <rect x="120" y="312" width={Math.max(20, params.p * 5)} height="18" rx="9" fill="#f59e0b" />
          </g>
        ) : isPhase2Visual(formula.visualizerType) ? (
          <Phase2Visual formula={formula} params={params} />
        ) : isPhase3Visual(formula.visualizerType) ? (
          <Phase3Visual formula={formula} params={params} />
        ) : (
          <StatisticsVisual params={params} />
          )}
        </g>
        <foreignObject x="34" y="24" width="300" height="88">
          <div className="rounded-xl border border-cyan-300/40 bg-slate-950/75 p-3 text-white">
            <p className="text-xs font-black uppercase text-cyan-200">Selected model</p>
            <p className="mt-1 text-sm font-black">{formula.title}</p>
            <p className="mt-1 text-xs text-slate-300">Live value {formatNumber(result)}</p>
          </div>
        </foreignObject>
      </svg>
    </div>
  );
}

function FormulaBank({ config, formulas, query, setQuery, setSelectedId, setActiveTab }: { config: FormulaVisualizerRouteConfig; formulas: FormulaVisualizerEntry[]; query: string; setQuery: (value: string) => void; setSelectedId: (value: string) => void; setActiveTab: (tab: Tab) => void }) {
  return (
    <section className="desktop-card p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-2xl font-black">Formula Bank</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{config.formulas.length} formulas grouped for fast visual practice.</p>
        </div>
        <label className="flex min-h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold dark:border-white/10 dark:bg-slate-950/70 lg:w-[360px]">
          <Search className="h-4 w-4 text-slate-400" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search bank..." className="min-w-0 flex-1 bg-transparent outline-none" />
        </label>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {formulas.map((formula) => (
          <article key={formula.id} className="rounded-xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-white/5">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-black">{formula.title}</h3>
              <span className="mini-chip">{formula.group}</span>
            </div>
            <MathExpression value={formula.latex} className="mt-2 text-cyan-700 dark:text-cyan-200" />
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{formula.description}</p>
            <button type="button" className="action-secondary mt-3" onClick={() => { setSelectedId(formula.id); setActiveTab("Explore"); }}>
              Open visual
            </button>
          </article>
        ))}
      </div>
    </section>
  );
}

function ExamplePanel({ config, setParams, setActiveTab }: { config: FormulaVisualizerRouteConfig; setParams: (params: FormulaParameters) => void; setActiveTab: (tab: Tab) => void }) {
  return (
    <section className="grid gap-3 lg:grid-cols-3">
      {config.examples.map((example) => (
        <article key={example.title} className="desktop-card p-4">
          <h2 className="text-xl font-black">{example.title}</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{example.description}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {Object.entries(example.values).map(([key, value]) => <span key={key} className="mini-chip">{key}={value}</span>)}
          </div>
          <button type="button" className="action-primary mt-4" onClick={() => { setParams({ ...defaultParams, ...example.values }); setActiveTab("Explore"); }}>
            Load example
          </button>
        </article>
      ))}
    </section>
  );
}

function ExplanationPanel({ config, formula }: { config: FormulaVisualizerRouteConfig; formula: FormulaVisualizerEntry }) {
  const explanation = buildFormulaVisualizationExplanation(formula);
  return (
    <section className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_340px]">
      <article className="desktop-card p-4">
        <h2 className="text-2xl font-black">Why it works</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{explanation.conceptSummary}</p>
        <div className="mt-4 rounded-xl border border-cyan-200 bg-cyan-50 p-4 dark:border-cyan-300/30 dark:bg-cyan-400/10">
          <MathExpression value={formula.latex} display className="text-lg" />
        </div>
        <FormulaExplanationContent explanation={explanation} formula={formula} />
      </article>
      <aside className="desktop-sidebar-panel space-y-3">
        <h3 className="text-lg font-black">Related learning</h3>
        <Link to={config.formulaLibraryRoute} className="action-secondary w-full">
          <BookOpen className="h-4 w-4" /> Formula reference
        </Link>
        {config.relatedRoutes.map((route) => (
          <Link key={route.href} to={route.href} className="action-secondary w-full">
            {route.label}
          </Link>
        ))}
      </aside>
    </section>
  );
}

function FormulaExplanationContent({ explanation, formula, compact = false }: { explanation: FormulaVisualizationExplanation; formula: FormulaVisualizerEntry; compact?: boolean }) {
  return (
    <div className={`mt-4 grid gap-3 ${compact ? "xl:grid-cols-2" : ""}`}>
      <ExplanationBlock title="1. What you are looking at" items={explanation.diagramReading} />
      <ExplanationBlock title="2. What each control changes" items={explanation.controlEffects} />
      <ExplanationBlock title="3. Step-by-step reasoning" items={explanation.reasoningSteps.map((step, index) => `${index + 1}. ${step}`)} />
      <ExplanationBlock title="4. What must remain true" text={explanation.invariant} />
      <section className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950 dark:border-amber-300/30 dark:bg-amber-300/10 dark:text-amber-50">
        <h3 className="font-black">5. Common mistake to avoid</h3>
        <p className="mt-2 font-semibold leading-6">{explanation.commonMistake}</p>
      </section>
      <section className="rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-950 dark:border-emerald-300/30 dark:bg-emerald-300/10 dark:text-emerald-50">
        <h3 className="font-black">6. Try this</h3>
        <p className="mt-2 font-semibold leading-6">{explanation.tryThis}</p>
        <p className="mt-2 rounded-lg bg-white/70 p-2 font-bold dark:bg-slate-950/30"><span className="font-black">Success condition:</span> {explanation.successCondition}</p>
      </section>
      {formula.notes ? <ExplanationBlock title="Formula note" text={formula.notes} /> : null}
      <details className="rounded-xl border border-slate-200 bg-white/80 p-3 text-sm dark:border-white/10 dark:bg-white/5">
        <summary className="cursor-pointer font-black">Text-only diagram description</summary>
        <p className="mt-2 leading-6 text-slate-600 dark:text-slate-300">{explanation.textAlternative}</p>
      </details>
    </div>
  );
}

function ExplanationBlock({ title, text, items }: { title: string; text?: string; items?: string[] }) {
  return (
    <section className="rounded-xl border border-slate-200 bg-white/80 p-3 text-sm dark:border-white/10 dark:bg-white/5">
      <h3 className="font-black text-slate-950 dark:text-white">{title}</h3>
      {text ? <p className="mt-2 leading-6 text-slate-600 dark:text-slate-300">{text}</p> : null}
      {items ? <ul className="mt-2 grid gap-2 leading-6 text-slate-600 dark:text-slate-300">{items.map((item) => <li key={item} className="flex gap-2"><span aria-hidden="true" className="font-black text-cyan-600">•</span><span>{item}</span></li>)}</ul> : null}
    </section>
  );
}

function PracticePanel({ formula, params, answer, expected, correct, setAnswer }: { formula: FormulaVisualizerEntry; params: FormulaParameters; answer: string; expected: number; correct: boolean; setAnswer: (value: string) => void }) {
  return (
    <section className="desktop-card p-4">
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div>
          <h2 className="text-2xl font-black">Quick Practice</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
            Estimate the live value for <strong>{formula.title}</strong> using the current controls: {buildSubstitution(formula, params)}
          </p>
          <label className="mt-4 block">
            <span className="text-sm font-black">Your answer</span>
            <input className="mt-2 h-12 w-full rounded-xl border border-slate-200 bg-white px-3 text-lg font-black outline-none focus:border-cyan-400 dark:border-white/10 dark:bg-slate-950" value={answer} onChange={(event) => setAnswer(event.target.value)} inputMode="decimal" />
          </label>
          {answer.trim() ? (
            <p className={`mt-3 rounded-xl p-3 text-sm font-black ${correct ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-300/10 dark:text-emerald-100" : "bg-amber-50 text-amber-800 dark:bg-amber-300/10 dark:text-amber-100"}`}>
              {correct ? "Correct. Nice substitution." : `Close check: expected about ${expected}.`}
            </p>
          ) : null}
        </div>
        <div className="rounded-xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
          <CheckCircle2 className="h-7 w-7 text-cyan-500" />
          <h3 className="mt-2 text-lg font-black">Student prompt</h3>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
            Change one slider only. Say what changed in the visual, what stayed the same, and which part of the formula explains it.
          </p>
        </div>
      </div>
    </section>
  );
}

function MatrixVisual({ params }: { params: FormulaParameters }) {
  const cells = [params.a, params.b, params.c, params.n / 2];
  const det = cells[0] * cells[3] - cells[1] * cells[2];
  return (
    <g transform="translate(250 74)">
      {cells.map((cell, index) => {
        const x = (index % 2) * 100;
        const y = Math.floor(index / 2) * 78;
        return (
          <g key={index}>
            <rect x={x} y={y} width="82" height="60" rx="12" fill="#22d3ee" opacity="0.25" stroke="#67e8f9" strokeWidth="3" />
            <Text x={x + 41} y={y + 36} value={formatNumber(cell)} />
          </g>
        );
      })}
      <Text x="300" y="32" value={`det=${formatNumber(det)}`} />
      <rect x="280" y="66" width={Math.abs(det) * 4 + 28} height="120" rx="12" fill="#f59e0b" opacity="0.44" />
    </g>
  );
}

function StatisticsVisual({ params }: { params: FormulaParameters }) {
  const values = [params.a, params.b, params.c, params.n / 2, params.p / 10].map((value) => Math.max(0.5, value + 4));
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return (
    <g transform="translate(160 86)">
      {values.map((value, index) => (
        <rect key={index} x={index * 82} y={220 - value * 18} width="46" height={value * 18} rx="10" fill={index % 2 ? "#a78bfa" : "#22d3ee"} opacity="0.75" />
      ))}
      <line x1="0" y1={220 - mean * 18} x2="430" y2={220 - mean * 18} stroke="#facc15" strokeWidth="4" strokeDasharray="10 8" />
      <Text x="500" y={224 - mean * 18} value="mean" />
    </g>
  );
}

function isProportionalReasoningFormula(id: string) {
  return PROPORTIONAL_FORMULA_IDS.includes(id as (typeof PROPORTIONAL_FORMULA_IDS)[number]);
}

function ProportionalReasoningVisual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const mode = getProportionalVisualMode(formula.id);
  if (!mode) return null;
  if (mode === "equivalent-ratios") return <EquivalentRatiosVisual params={params} />;
  if (mode === "cross-multiplication") return <CrossMultiplicationVisual params={params} />;
  if (mode === "missing-fourth-term") return <MissingFourthTermVisual params={params} />;
  if (mode === "representative-fraction") return <RepresentativeFractionVisual params={params} />;
  if (mode === "actual-distance-map-scale") return <ActualDistanceVisual params={params} />;
  if (mode === "map-distance-actual-scale") return <MapDistanceVisual params={params} />;
  if (mode === "multi-term-ratio-share") return <RatioShareVisual params={params} />;
  if (mode === "ratio-to-percentage") return <RatioPercentageVisual params={params} />;
  if (mode === "ratio-to-pie-angle") return <RatioPieAngleVisual params={params} />;
  if (mode === "direct-proportion") return <DirectProportionVisual params={params} />;
  if (mode === "inverse-proportion") return <InverseProportionVisual params={params} />;
  return <ProportionConstantCheckVisual params={params} />;
}

function ratioValues(params: FormulaParameters) {
  return {
    a: Math.max(0.25, Math.abs(params.a)), b: Math.max(0.25, Math.abs(params.b)),
    c: Math.max(0.25, Math.abs(params.c)), d: Math.max(1, Math.abs(params.n)),
  };
}

function FractionStack({ x, y, numerator, denominator, color }: { x: number; y: number; numerator: string; denominator: string; color: string }) {
  return <g><text x={x} y={y - 18} fill={color} fontSize="28" fontWeight="900" textAnchor="middle">{numerator}</text><line x1={x - 42} y1={y} x2={x + 42} y2={y} stroke="#e0f2fe" strokeWidth="4" /><text x={x} y={y + 40} fill={color} fontSize="28" fontWeight="900" textAnchor="middle">{denominator}</text></g>;
}

function EquivalentRatiosVisual({ params }: { params: FormulaParameters }) {
  const { a, b, c, d } = ratioValues(params);
  const equivalent = Math.abs(a / b - c / d) < 0.001;
  return <g><FractionStack x={250} y={185} numerator={formatNumber(a)} denominator={formatNumber(b)} color="#67e8f9" /><Text x="380" y="190" value={equivalent ? "=" : "≠"} /><FractionStack x={510} y={185} numerator={formatNumber(c)} denominator={formatNumber(d)} color="#c4b5fd" /><Text x="380" y="88" value="compare simplified ratios" /><Text x="380" y="300" value={`${formatNumber(a / b)} ${equivalent ? "=" : "≠"} ${formatNumber(c / d)}`} /></g>;
}

function CrossMultiplicationVisual({ params }: { params: FormulaParameters }) {
  const { a, b, c, d } = ratioValues(params);
  const ad = a * d; const bc = b * c; const equal = Math.abs(ad - bc) < 0.001;
  return <g><FractionStack x={250} y={174} numerator={formatNumber(a)} denominator={formatNumber(b)} color="#67e8f9" /><FractionStack x={510} y={174} numerator={formatNumber(c)} denominator={formatNumber(d)} color="#c4b5fd" /><path d="M250 130 L510 220" stroke="#facc15" strokeWidth="7" strokeLinecap="round" /><path d="M250 220 L510 130" stroke="#f59e0b" strokeWidth="7" strokeLinecap="round" /><Text x="380" y="80" value="multiply diagonally" /><Text x="270" y="292" value={`a·d = ${formatNumber(ad)}`} /><Text x="500" y="292" value={`b·c = ${formatNumber(bc)}`} /><Text x="380" y="338" value={equal ? "cross-products are equal" : `not equal: Δ=${formatNumber(ad - bc)}`} /></g>;
}

function MissingFourthTermVisual({ params }: { params: FormulaParameters }) {
  const { a, b, c } = ratioValues(params); const missing = (b * c) / a;
  return <g><FractionStack x={250} y={184} numerator={formatNumber(a)} denominator={formatNumber(b)} color="#67e8f9" /><Text x="380" y="188" value="=" /><FractionStack x={510} y={184} numerator={formatNumber(c)} denominator="?" color="#facc15" /><path d="M250 142 L510 226" stroke="#f59e0b" strokeWidth="6" strokeDasharray="10 8" /><Text x="380" y="82" value="solve the missing denominator" /><Text x="380" y="304" value={`d = b·c/a = ${formatNumber(b)}·${formatNumber(c)}/${formatNumber(a)}`} /><Text x="380" y="346" value={`d = ${formatNumber(missing)}`} /></g>;
}

function ScaleRuler({ y, length, color, label }: { y: number; length: number; color: string; label: string }) {
  return <g><line x1="150" y1={y} x2={150 + length} y2={y} stroke={color} strokeWidth="14" strokeLinecap="round" /><line x1="150" y1={y - 18} x2="150" y2={y + 18} stroke="#e0f2fe" strokeWidth="3" /><line x1={150 + length} y1={y - 18} x2={150 + length} y2={y + 18} stroke="#e0f2fe" strokeWidth="3" /><Text x={150 + length / 2} y={y - 30} value={label} /></g>;
}

function RepresentativeFractionVisual({ params }: { params: FormulaParameters }) {
  const { a, b } = ratioValues(params); const actualCm = b * 100000; const denominator = actualCm / a;
  return <g><ScaleRuler y={130} length={130} color="#22d3ee" label={`${formatNumber(a)} cm on map`} /><ScaleRuler y={242} length={430} color="#f59e0b" label={`${formatNumber(b)} km = ${formatNumber(actualCm)} cm`} /><Text x="530" y="104" value="convert to same unit" /><Text x="380" y="312" value={`RF = ${formatNumber(a)}:${formatNumber(actualCm)} = 1:${formatNumber(denominator)}`} /></g>;
}

function ActualDistanceVisual({ params }: { params: FormulaParameters }) {
  const { a, b } = ratioValues(params); const actualCm = a * b; const actualKm = actualCm / 100000;
  return <g><ScaleRuler y={126} length={150} color="#22d3ee" label={`map = ${formatNumber(a)} cm`} /><path d="M310 126 H520" stroke="#facc15" strokeWidth="5" /><Text x="414" y="98" value={`× scale ${formatNumber(b)}`} /><ScaleRuler y={242} length={420} color="#f59e0b" label={`actual = ${formatNumber(actualCm)} cm`} /><Text x="380" y="315" value={`= ${formatNumber(actualKm)} km`} /></g>;
}

function MapDistanceVisual({ params }: { params: FormulaParameters }) {
  const { a, b } = ratioValues(params); const actualCm = a * 100000; const mapCm = actualCm / b;
  return <g><ScaleRuler y={126} length={420} color="#f59e0b" label={`actual = ${formatNumber(a)} km = ${formatNumber(actualCm)} cm`} /><path d="M520 164 H310" stroke="#facc15" strokeWidth="5" /><Text x="414" y="192" value={`÷ scale ${formatNumber(b)}`} /><ScaleRuler y={256} length={150} color="#22d3ee" label={`map = ${formatNumber(mapCm)} cm`} /><Text x="500" y="300" value="real world → map" /></g>;
}

function RatioBar({ params, showValues = true }: { params: FormulaParameters; showValues?: boolean }) {
  const { a, b, c } = ratioValues(params); const parts = [a, b, c]; const total = a + b + c; let cursor = 145; const colors = ["#22d3ee", "#f59e0b", "#a78bfa"];
  return <g>{parts.map((part, index) => { const width = part / total * 470; const x = cursor; cursor += width; return <g key={index}><rect x={x} y="132" width={width} height="92" rx="12" fill={colors[index]} opacity="0.76" stroke="#e0f2fe" /><Text x={x + width / 2} y="180" value={showValues ? formatNumber(part) : `${formatNumber(part / total * 100)}%`} /></g>; })}</g>;
}

function RatioShareVisual({ params }: { params: FormulaParameters }) { const { a, b, c } = ratioValues(params); const sum = a + b + c; const share = a / sum * Math.abs(params.n); return <g><RatioBar params={params} /><Text x="380" y="86" value={`split total ${formatNumber(Math.abs(params.n))} in ratio ${formatNumber(a)}:${formatNumber(b)}:${formatNumber(c)}`} /><Text x="380" y="282" value={`first share = ${formatNumber(a)}/${formatNumber(sum)} × ${formatNumber(Math.abs(params.n))}`} /><Text x="380" y="330" value={`= ${formatNumber(share)}`} /></g>; }

function RatioPercentageVisual({ params }: { params: FormulaParameters }) { const { a, b, c } = ratioValues(params); const percent = a / (a + b + c) * 100; return <g><RatioBar params={params} showValues={false} /><rect x="145" y="254" width="470" height="28" rx="14" fill="#172554" stroke="#cbd5e1" /><rect x="145" y="254" width={470 * percent / 100} height="28" rx="14" fill="#22d3ee" /><Text x="380" y="88" value="ratio parts become percentages of 100" /><Text x="380" y="330" value={`first part = ${formatNumber(percent)}%`} /></g>; }

function RatioPieAngleVisual({ params }: { params: FormulaParameters }) { const { a, b, c } = ratioValues(params); const angle = a / (a + b + c) * 360; const radians = angle * Math.PI / 180; const endX = 380 + 112 * Math.sin(radians); const endY = 190 - 112 * Math.cos(radians); return <g><circle cx="380" cy="190" r="112" fill="#172554" stroke="#ddd6fe" strokeWidth="5" /><path d={`M380 190 L380 78 A112 112 0 ${angle > 180 ? 1 : 0} 1 ${endX} ${endY} Z`} fill="#facc15" opacity="0.78" stroke="#fef08a" strokeWidth="4" /><Text x="380" y="190" value={`${formatNumber(angle)}°`} /><Text x="380" y="340" value={`${formatNumber(a)}/${formatNumber(a + b + c)} × 360°`} /></g>; }

function ProportionAxes() { return <g><line x1="120" y1="310" x2="650" y2="310" stroke="#94a3b8" strokeWidth="3" /><line x1="120" y1="310" x2="120" y2="60" stroke="#94a3b8" strokeWidth="3" /><Text x="650" y="340" value="x" /><Text x="92" y="70" value="y" /></g>; }

function DirectProportionVisual({ params }: { params: FormulaParameters }) { const x = Math.max(.25, Math.abs(params.a)); const k = Math.max(.25, Math.abs(params.b)); const y = k * x; const points = Array.from({length:9},(_,i)=>`${120+i*58},${310-Math.min(230,k*i*7)}`).join(" "); return <g><ProportionAxes /><polyline points={points} fill="none" stroke="#22d3ee" strokeWidth="6" /><circle cx={120+x*45} cy={310-Math.min(230,y*9)} r="11" fill="#facc15" /><Text x="500" y="92" value={`y = ${formatNumber(k)}x`} /><Text x="500" y="136" value={`y/x = ${formatNumber(k)}`} /><Text x="500" y="180" value={`(${formatNumber(x)}, ${formatNumber(y)})`} /></g>; }

function InverseProportionVisual({ params }: { params: FormulaParameters }) { const { a, b, c } = ratioValues(params); const k = a * b; const x = c; const y = k/x; const points = Array.from({length:48},(_,i)=>{const xv=.5+i*.16; return `${120+xv*55},${310-Math.min(235,(k/xv)*8)}`;}).join(" "); return <g><ProportionAxes /><polyline points={points} fill="none" stroke="#f59e0b" strokeWidth="6" /><circle cx={120+x*55} cy={310-Math.min(235,y*8)} r="11" fill="#facc15" /><Text x="510" y="92" value={`xy = k = ${formatNumber(k)}`} /><Text x="510" y="136" value={`y = ${formatNumber(k)}/x`} /><Text x="510" y="180" value={`(${formatNumber(x)}, ${formatNumber(y)})`} /></g>; }

function ProportionConstantCheckVisual({ params }: { params: FormulaParameters }) { const { a, b, c, d } = ratioValues(params); const r1=b/a,r2=d/c,p1=a*b,p2=c*d; const direct=Math.abs(r1-r2)<.001; const inverse=Math.abs(p1-p2)<.001; const result=direct?"DIRECT: equal y/x":inverse?"INVERSE: equal xy":"NEITHER constant matches"; return <g><rect x="130" y="92" width="220" height="172" rx="18" fill="#22d3ee" opacity=".22" stroke="#67e8f9" strokeWidth="4" /><rect x="410" y="92" width="220" height="172" rx="18" fill="#a78bfa" opacity=".22" stroke="#ddd6fe" strokeWidth="4" /><Text x="240" y="132" value={`Pair 1: (${formatNumber(a)},${formatNumber(b)})`} /><Text x="240" y="178" value={`y/x=${formatNumber(r1)}`} /><Text x="240" y="222" value={`xy=${formatNumber(p1)}`} /><Text x="520" y="132" value={`Pair 2: (${formatNumber(c)},${formatNumber(d)})`} /><Text x="520" y="178" value={`y/x=${formatNumber(r2)}`} /><Text x="520" y="222" value={`xy=${formatNumber(p2)}`} /><Text x="380" y="322" value={result} /></g>; }

/** @deprecated Kept only as a reference for older snapshots; the live page uses formula-specific models above. */
export function LegacyProportionalReasoningVisual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const a = Math.max(0.25, Math.abs(params.a));
  const b = Math.max(0.25, Math.abs(params.b));
  const c = Math.max(0.25, Math.abs(params.c));
  const d = Math.max(1, Math.abs(params.n));
  const parts = [a, b, c].map((value) => Math.max(0.1, value));
  const partSum = parts.reduce((sum, value) => sum + value, 0);
  const widths = parts.map((part) => (part / partSum) * 430);
  const firstPercent = (a / partSum) * 100;
  const firstAngle = (a / partSum) * 360;
  const ratioDiff = a * d - b * c;
  const mapActualKm = (a * b) / 100000;
  const directK = b || 1;
  const inverseK = Math.max(0.1, a * b);
  const pieAngle = (firstAngle / 180) * Math.PI;
  const pieEnd = { x: 560 + 82 * Math.cos(pieAngle - Math.PI / 2), y: 190 + 82 * Math.sin(pieAngle - Math.PI / 2) };

  if (["equivalent-ratios", "cross-multiplication", "missing-fourth-term"].includes(formula.id)) {
    const leftHeight = 46 + a * 12;
    const leftWidth = 52 + d * 5;
    const rightHeight = 46 + b * 12;
    const rightWidth = 52 + c * 9;
    return (
      <g>
        <rect x="118" y={245 - leftHeight} width={leftWidth} height={leftHeight} rx="10" fill="#22d3ee" opacity="0.45" stroke="#67e8f9" strokeWidth="4" />
        <rect x="398" y={245 - rightHeight} width={rightWidth} height={rightHeight} rx="10" fill="#f59e0b" opacity="0.45" stroke="#fde68a" strokeWidth="4" />
        <Text x={118 + leftWidth / 2} y={222 - leftHeight} value={`a x d = ${formatNumber(a * d)}`} />
        <Text x={398 + rightWidth / 2} y={222 - rightHeight} value={`b x c = ${formatNumber(b * c)}`} />
        <line x1="110" y1="278" x2="650" y2="278" stroke="#94a3b8" strokeWidth="3" />
        <Text x="380" y="86" value={Math.abs(ratioDiff) < 0.01 ? "equivalent ratios" : `difference ${formatNumber(ratioDiff)}`} />
        <Text x="380" y="128" value={formula.id === "missing-fourth-term" ? `missing d = ${formatNumber((b * c) / a)}` : "compare cross-products"} />
      </g>
    );
  }

  if (["representative-fraction", "actual-distance-map-scale", "map-distance-actual-scale"].includes(formula.id)) {
    const mapWidth = Math.max(50, Math.min(240, a * 42));
    const actualWidth = Math.max(160, Math.min(520, mapWidth + Math.log10(Math.max(10, b)) * 84));
    return (
      <g>
        <line x1="120" y1="145" x2={120 + mapWidth} y2="145" stroke="#22d3ee" strokeWidth="12" strokeLinecap="round" />
        <line x1="120" y1="245" x2={120 + actualWidth} y2="245" stroke="#f59e0b" strokeWidth="12" strokeLinecap="round" />
        <line x1="120" y1="122" x2="120" y2="270" stroke="#e0f2fe" strokeWidth="3" strokeDasharray="8 8" />
        <line x1={120 + mapWidth} y1="122" x2={120 + actualWidth} y2="270" stroke="#e0f2fe" strokeWidth="3" strokeDasharray="8 8" />
        <Text x={120 + mapWidth / 2} y="112" value={`${formatNumber(a)} map units`} />
        <Text x={120 + actualWidth / 2} y="296" value={`${formatNumber(mapActualKm)} km actual`} />
        <Text x="560" y="118" value={`scale 1:${formatNumber(b)}`} />
        <Text x="560" y="164" value="same units first" />
      </g>
    );
  }

  if (["multi-term-ratio-share", "ratio-to-percentage", "ratio-to-pie-angle"].includes(formula.id)) {
    let x = 140;
    const colors = ["#22d3ee", "#f59e0b", "#a78bfa"];
    return (
      <g>
        {widths.map((width, index) => {
          const currentX = x;
          x += width;
          return (
            <g key={index}>
              <rect x={currentX} y="115" width={width} height="76" rx="14" fill={colors[index]} opacity="0.7" />
              <Text x={currentX + width / 2} y="154" value={`${formatNumber(parts[index])}`} />
            </g>
          );
        })}
        <circle cx="560" cy="190" r="82" fill="#172554" stroke="#67e8f9" strokeWidth="4" />
        <path d={`M560 190 L560 108 A82 82 0 ${firstAngle > 180 ? 1 : 0} 1 ${pieEnd.x} ${pieEnd.y} Z`} fill="#facc15" opacity="0.65" stroke="#fef08a" strokeWidth="3" />
        <Text x="350" y="250" value={`share=${formatNumber((a / partSum) * Math.abs(params.n))}`} />
        <Text x="560" y="302" value={`${formatNumber(firstPercent)}% / ${formatNumber(firstAngle)} deg`} />
      </g>
    );
  }

  return (
    <g>
      <line x1="100" y1="300" x2="670" y2="300" stroke="#94a3b8" strokeWidth="3" />
      <line x1="120" y1="62" x2="120" y2="320" stroke="#94a3b8" strokeWidth="3" />
      <polyline
        points={Array.from({ length: 9 }, (_, index) => {
          const x = 1 + index;
          const y = formula.id === "inverse-proportion" ? inverseK / x : directK * x;
          return `${120 + index * 58},${Math.max(70, Math.min(300, 300 - y * 9))}`;
        }).join(" ")}
        fill="none"
        stroke={formula.id === "inverse-proportion" ? "#f59e0b" : "#22d3ee"}
        strokeWidth="5"
        strokeLinecap="round"
      />
      <Text x="520" y="96" value={formula.id === "inverse-proportion" ? `xy=${formatNumber(inverseK)}` : `y/x=${formatNumber(directK)}`} />
      <Text x="520" y="142" value={formula.id === "constant-check" ? "ratio or product?" : formula.id === "inverse-proportion" ? "hyperbola model" : "line model"} />
    </g>
  );
}

function isTrigonometryFormula(id: string) {
  return [
    "sin-ratio",
    "cos-ratio",
    "tan-ratio",
    "pythagorean-identity",
    "tan-identity",
    "sine-rule",
    "cosine-rule",
    "angle-sum-sine",
  ].includes(id);
}

function TrigonometryFormulaVisual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const angle = (Math.max(5, Math.min(85, params.p)) / 180) * Math.PI;
  const r = 104;
  const cx = 220;
  const cy = 190;
  const px = cx + r * Math.cos(angle);
  const py = cy - r * Math.sin(angle);
  const tri = { ax: 420, ay: 284, bx: 660, by: 284, cx: 420 + Math.max(70, Math.abs(params.a) * 34), cy: 284 - Math.max(86, Math.abs(params.b) * 30) };
  const showTriangleRule = ["sine-rule", "cosine-rule"].includes(formula.id);

  if (showTriangleRule) {
    return (
      <g>
        <polygon points={`${tri.ax},${tri.ay} ${tri.bx},${tri.by} ${tri.cx},${tri.cy}`} fill="#22d3ee" opacity="0.28" stroke="#e0f2fe" strokeWidth="5" />
        <path d={`M${tri.bx - 46} ${tri.by} A46 46 0 0 0 ${tri.bx - 34} ${tri.by - 34}`} fill="none" stroke="#facc15" strokeWidth="5" />
        <Text x={(tri.ax + tri.bx) / 2} y={tri.ay + 28} value="a" />
        <Text x={(tri.bx + tri.cx) / 2 + 24} y={(tri.by + tri.cy) / 2} value="b" />
        <Text x={(tri.ax + tri.cx) / 2 - 28} y={(tri.ay + tri.cy) / 2} value="c" />
        <Text x={tri.bx - 34} y={tri.by - 26} value="C" />
        <Text x="240" y="116" value={formula.id === "cosine-rule" ? "c^2 = a^2+b^2-2ab cos C" : "a/sin A = b/sin B = c/sin C"} />
        <Text x="240" y="166" value={formula.id === "cosine-rule" ? "Pythagoras plus angle correction" : "same circumcircle ratio"} />
      </g>
    );
  }

  return (
    <g>
      <circle cx={cx} cy={cy} r={r} fill="#22d3ee" opacity="0.12" stroke="#67e8f9" strokeWidth="4" />
      <line x1={cx - 135} y1={cy} x2={cx + 145} y2={cy} stroke="#94a3b8" strokeWidth="3" />
      <line x1={cx} y1={cy + 135} x2={cx} y2={cy - 145} stroke="#94a3b8" strokeWidth="3" />
      <Arrow x1={cx} y1={cy} x2={px} y2={py} color="#facc15" label="r=1" />
      <line x1={px} y1={py} x2={px} y2={cy} stroke="#f59e0b" strokeWidth="5" />
      <line x1={cx} y1={cy} x2={px} y2={cy} stroke="#22d3ee" strokeWidth="5" />
      <polygon points={`${420},${284} ${650},${284} ${650},${py}`} fill="#a78bfa" opacity="0.24" stroke="#ddd6fe" strokeWidth="4" />
      <Text x={px + 38} y={(py + cy) / 2} value="sin" />
      <Text x={(cx + px) / 2} y={cy + 28} value="cos" />
      <Text x="535" y="118" value={formula.id === "pythagorean-identity" ? "sin^2 + cos^2 = 1" : formula.id === "tan-identity" ? "tan = sin / cos" : "triangle ratio"} />
      <Text x="535" y="164" value={`${formula.title}: ${formatNumber(computeResult(formula, params))}`} />
    </g>
  );
}

function TeacherNotesPanel({ config }: { config: FormulaVisualizerRouteConfig }) {
  const notes = config.teacherNotes;
  if (!notes) return null;
  return (
    <section className="desktop-card p-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-wide text-cyan-700 dark:text-cyan-300">Teacher Notes</p>
          <h2 className="text-2xl font-black text-slate-950 dark:text-white">{config.shortTitle} classroom support</h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">{notes.quickBoardExplanation}</p>
        </div>
        <Link to={config.formulaLibraryRoute} className="action-secondary shrink-0">
          <BookOpen className="h-4 w-4" /> Formula reference
        </Link>
      </div>
      <div className="mt-4 grid gap-3 lg:grid-cols-3">
        <InfoBlock title="Discussion prompt" text={notes.discussionPrompt} />
        <InfoBlock title="Misconception check" text={notes.misconceptionPrompt} />
        <InfoBlock title="5-minute activity" text={notes.fiveMinuteActivity} />
        <InfoBlock title="Practice challenge" text={notes.practiceChallenge} />
        <InfoBlock title="Prerequisites" text={notes.prerequisites.join(", ")} />
        <InfoBlock title="Next concepts" text={notes.nextConcepts.join(", ")} />
      </div>
    </section>
  );
}

function InfoBlock({ title, text }: { title: string; text: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <p className="text-sm font-black text-slate-950 dark:text-white">{title}</p>
      <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{text}</p>
    </div>
  );
}

function DeepenedPhaseOneVisual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  if (["completing-square", "quadratic-standard"].includes(formula.id)) return <QuadraticDepthVisual params={params} formula={formula} />;
  if (["pythagoras", "circle-area", "sector-area"].includes(formula.id)) return <GeometryDepthVisual params={params} formula={formula} />;
  if (["section", "triangle-area-coordinates"].includes(formula.id)) return <CoordinateDepthVisual params={params} formula={formula} />;
  if (["chain-rule", "product-rule"].includes(formula.id)) return <DerivativeDepthVisual params={params} formula={formula} />;
  if (["area-under-curve", "area-between-curves"].includes(formula.id)) return <IntegrationDepthVisual params={params} formula={formula} />;
  if (["determinant-2x2", "linear-transform"].includes(formula.id)) return <MatrixDepthVisual params={params} formula={formula} />;
  if (["projection", "dot-product"].includes(formula.id)) return <VectorDepthVisual params={params} formula={formula} />;
  if (formula.id === "bayes") return <BayesDepthVisual params={params} />;
  if (["standard-deviation", "regression"].includes(formula.id)) return <StatisticsDepthVisual params={params} formula={formula} />;
  if (["cylinder-volume", "cone-volume", "sphere-volume"].includes(formula.id)) return <MensurationDepthVisual params={params} formula={formula} />;
  return <StatisticsVisual params={params} />;
}

function QuadraticDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const discriminant = params.b ** 2 - 4 * params.a * params.c;
  const vertexX = params.a === 0 ? 0 : -params.b / (2 * params.a);
  const curve = makeCurvePoints({ ...formula, visualizerType: "graph" }, params);
  return (
    <g>
      <polyline points={curve} fill="none" stroke="#22d3ee" strokeWidth="5" strokeLinecap="round" filter="url(#softGlow)" />
      <line x1="80" y1="190" x2="680" y2="190" stroke="#94a3b8" strokeWidth="2" />
      <line x1="380" y1="50" x2="380" y2="330" stroke="#94a3b8" strokeWidth="2" />
      <line x1={380 + vertexX * 48} y1="70" x2={380 + vertexX * 48} y2="324" stroke="#facc15" strokeWidth="3" strokeDasharray="8 8" />
      <rect x="118" y="76" width="86" height="86" fill="#22d3ee" opacity="0.35" stroke="#67e8f9" strokeWidth="3" />
      <rect x="204" y="76" width="54" height="86" fill="#f59e0b" opacity="0.42" />
      <rect x="118" y="162" width="86" height="54" fill="#f59e0b" opacity="0.42" />
      <Text x="560" y="88" value={`D=${formatNumber(discriminant)}`} />
      <Text x="560" y="130" value={discriminant > 0 ? "2 real roots" : discriminant === 0 ? "1 repeated root" : "no real roots"} />
    </g>
  );
}

function GeometryDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const r = Math.max(44, Math.min(110, Math.abs(params.a) * 14 + 44));
  if (formula.id === "pythagoras") {
    const a = Math.max(70, Math.abs(params.a) * 22 + 70);
    const b = Math.max(60, Math.abs(params.b) * 22 + 60);
    return (
      <g transform="translate(175 82)">
        <polygon points={`0,210 ${a},210 ${a},${210 - b}`} fill="#22d3ee" opacity="0.36" stroke="#e0f2fe" strokeWidth="4" />
        <rect x="0" y={210 - a} width={a} height={a} fill="#22d3ee" opacity="0.2" stroke="#67e8f9" />
        <rect x={a} y={210 - b} width={b} height={b} fill="#f59e0b" opacity="0.22" stroke="#fde68a" />
        <rect x={a + 100} y={210 - Math.sqrt(a * a + b * b) * 0.56} width={Math.sqrt(a * a + b * b) * 0.56} height={Math.sqrt(a * a + b * b) * 0.56} fill="#a78bfa" opacity="0.24" stroke="#ddd6fe" />
        <Text x="74" y="230" value="a^2" />
        <Text x={a + 36} y={210 - b - 18} value="b^2" />
        <Text x={a + 205} y="112" value="c^2" />
      </g>
    );
  }
  const sectors = Array.from({ length: 16 }, (_, index) => {
    const angle = (index / 16) * Math.PI * 2;
    const next = ((index + 1) / 16) * Math.PI * 2;
    return `M230 190 L${230 + r * Math.cos(angle)} ${190 + r * Math.sin(angle)} A${r} ${r} 0 0 1 ${230 + r * Math.cos(next)} ${190 + r * Math.sin(next)} Z`;
  });
  return (
    <g>
      <circle cx="230" cy="190" r={r} fill="#22d3ee" opacity="0.14" stroke="#67e8f9" strokeWidth="4" />
      {sectors.map((path, index) => <path key={path} d={path} fill={index % 2 ? "#f59e0b" : "#22d3ee"} opacity="0.4" stroke="#e0f2fe" strokeWidth="1" />)}
      <path d={`M430 286 L560 286 L495 ${286 - r} Z`} fill="#f59e0b" opacity="0.42" stroke="#fde68a" strokeWidth="4" />
      <Text x="230" y="332" value="sector slices" />
      <Text x="504" y="308" value="near triangle" />
    </g>
  );
}

function CoordinateDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const p1 = { x: 180, y: 280 };
  const p2 = { x: 560, y: 110 };
  const t = Math.max(0.15, Math.min(0.85, Math.abs(params.a) / 8));
  const px = p1.x + (p2.x - p1.x) * t;
  const py = p1.y + (p2.y - p1.y) * t;
  return (
    <g>
      <line x1="80" y1="300" x2="680" y2="300" stroke="#94a3b8" />
      <line x1="120" y1="50" x2="120" y2="330" stroke="#94a3b8" />
      <polygon points="180,280 560,110 500,296" fill="#22d3ee" opacity="0.28" stroke="#67e8f9" strokeWidth="4" />
      <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#facc15" strokeWidth="5" />
      <circle cx={px} cy={py} r="11" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      <Text x={px + 58} y={py - 16} value={formula.id === "section" ? "ratio point" : "det area"} />
      <Text x="530" y="330" value={formula.id === "section" ? "weighted average" : "shoelace sum"} />
    </g>
  );
}

function DerivativeDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const outer = makeCurvePoints({ ...formula, id: "quadratic-standard", visualizerType: "graph" }, params);
  return (
    <g>
      <polyline points={outer} fill="none" stroke="#22d3ee" strokeWidth="5" strokeLinecap="round" />
      <rect x="168" y="116" width={Math.abs(params.a) * 28 + 82} height={Math.abs(params.b) * 20 + 82} fill="#f59e0b" opacity="0.28" stroke="#fde68a" strokeWidth="4" />
      <rect x="168" y="116" width={Math.abs(params.a) * 28 + 82} height="24" fill="#a78bfa" opacity="0.55" />
      <rect x="168" y="116" width="24" height={Math.abs(params.b) * 20 + 82} fill="#22d3ee" opacity="0.55" />
      <Text x="540" y="96" value={formula.id === "chain-rule" ? "outer rate x inner rate" : "two changing sides"} />
      <Text x="540" y="138" value={formula.id === "chain-rule" ? "f'(g(x))g'(x)" : "u'v + uv'"} />
    </g>
  );
}

function IntegrationDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const top = makeCurvePoints({ ...formula, id: "quadratic-standard", visualizerType: "graph" }, params);
  const bottom = makeCurvePoints({ ...formula, id: "sin-derivative", visualizerType: "graph" }, { ...params, a: params.a + 1 });
  const bars = makeBars(params);
  return (
    <g>
      <polyline points={top} fill="none" stroke="#22d3ee" strokeWidth="5" />
      {formula.id === "area-between-curves" ? <polyline points={bottom} fill="none" stroke="#f59e0b" strokeWidth="4" /> : null}
      {bars.slice(0, 12).map((bar) => <rect key={bar.x} x={bar.x} y={bar.y} width={bar.w} height={bar.h} fill="#a78bfa" opacity="0.34" stroke="#ddd6fe" />)}
      <Text x="540" y="88" value={formula.id === "area-between-curves" ? "top - bottom" : "accumulated area"} />
      <Text x="540" y="128" value="rectangles -> integral" />
    </g>
  );
}

function MatrixDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const det = params.a * (params.n / 2) - params.b * params.c;
  const skew = Math.max(-60, Math.min(60, params.b * 10));
  return (
    <g transform="translate(150 70)">
      {Array.from({ length: 5 }, (_, index) => <line key={`x-${index}`} x1={index * 58} y1="0" x2={index * 58 + skew} y2="230" stroke="#67e8f9" opacity="0.35" />)}
      {Array.from({ length: 5 }, (_, index) => <line key={`y-${index}`} x1="0" y1={index * 58} x2="250" y2={index * 58 + params.c * 7} stroke="#67e8f9" opacity="0.35" />)}
      <polygon points={`0,0 116,${params.c * 8} ${116 + skew},${116 + params.c * 8} ${skew},116`} fill="#f59e0b" opacity="0.36" stroke="#fde68a" strokeWidth="4" />
      <Text x="460" y="70" value={formula.id === "determinant-2x2" ? `area scale=${formatNumber(det)}` : "grid transform"} />
      <Text x="460" y="118" value="unit square moves" />
    </g>
  );
}

function VectorDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const origin = { x: 220, y: 220 };
  const a = { x: origin.x + params.a * 26 + 110, y: origin.y - params.b * 24 };
  const b = { x: origin.x + 230, y: origin.y - params.c * 28 - 30 };
  return (
    <g>
      <line x1="90" y1="220" x2="675" y2="220" stroke="#94a3b8" />
      <Arrow x1={origin.x} y1={origin.y} x2={a.x} y2={a.y} color="#22d3ee" label="a" />
      <Arrow x1={origin.x} y1={origin.y} x2={b.x} y2={b.y} color="#f59e0b" label="b" />
      <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#facc15" strokeWidth="3" strokeDasharray="8 8" />
      <circle cx={(a.x + b.x) / 2} cy={(a.y + b.y) / 2} r="8" fill="#facc15" />
      <Text x="560" y="86" value={formula.id === "projection" ? "shadow on b" : "acute + / obtuse -"} />
      <Text x="560" y="128" value={`dot=${formatNumber(computeResult(formula, params))}`} />
    </g>
  );
}

function BayesDepthVisual({ params }: { params: FormulaParameters }) {
  const prior = Math.max(0.05, Math.min(0.95, params.p / 100));
  const likelihood = Math.max(0.05, Math.min(0.95, Math.abs(params.a) / 8));
  const posterior = (likelihood * prior) / (likelihood * prior + (1 - likelihood) * (1 - prior));
  return (
    <g>
      <line x1="150" y1="190" x2="330" y2="120" stroke="#22d3ee" strokeWidth="5" />
      <line x1="150" y1="190" x2="330" y2="260" stroke="#a78bfa" strokeWidth="5" />
      <line x1="330" y1="120" x2="560" y2="100" stroke="#f59e0b" strokeWidth="5" />
      <line x1="330" y1="260" x2="560" y2="286" stroke="#f59e0b" strokeWidth="5" opacity="0.45" />
      <Text x="138" y="190" value="start" />
      <Text x="330" y="92" value={`prior=${formatNumber(prior)}`} />
      <Text x="565" y="78" value={`posterior=${formatNumber(posterior)}`} />
    </g>
  );
}

function StatisticsDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const values = [params.a, params.b, params.c, params.n / 2, params.p / 10].map((value) => value + 5);
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  return (
    <g transform="translate(150 80)">
      {values.map((value, index) => {
        const x = index * 78;
        const y = 230 - value * 16;
        return (
          <g key={index}>
            <circle cx={x} cy={y} r="10" fill="#22d3ee" />
            <line x1={x} y1={y} x2={x} y2={230 - mean * 16} stroke="#facc15" strokeWidth="3" strokeDasharray="5 5" />
            {formula.id === "regression" ? <line x1={x} y1={y} x2={x} y2={250 - (index * 14 + mean * 12)} stroke="#f59e0b" strokeWidth="3" /> : null}
          </g>
        );
      })}
      <line x1="-20" y1={230 - mean * 16} x2="390" y2={230 - mean * 16} stroke="#facc15" strokeWidth="4" />
      <line x1="-10" y1="250" x2="390" y2="194" stroke="#a78bfa" strokeWidth="4" opacity={formula.id === "regression" ? 1 : 0.25} />
      <Text x="520" y="78" value={formula.id === "regression" ? "residuals" : "spread from mean"} />
    </g>
  );
}

function MensurationDepthVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const r = Math.max(28, Math.abs(params.a) * 7 + 34);
  const h = Math.max(80, Math.abs(params.b) * 18 + 100);
  return (
    <g>
      <ellipse cx="190" cy={250 - h} rx={r} ry="18" fill="#22d3ee" opacity="0.42" stroke="#67e8f9" strokeWidth="3" />
      <rect x={190 - r} y={250 - h} width={r * 2} height={h} fill="#22d3ee" opacity="0.18" stroke="#67e8f9" strokeWidth="3" />
      <ellipse cx="190" cy="250" rx={r} ry="18" fill="#22d3ee" opacity="0.42" stroke="#67e8f9" strokeWidth="3" />
      <path d={`M390 ${250 - h} L${390 - r} 250 Q390 ${268} ${390 + r} 250 Z`} fill="#f59e0b" opacity="0.34" stroke="#fde68a" strokeWidth="4" />
      <circle cx="590" cy="190" r={r} fill="#a78bfa" opacity="0.26" stroke="#ddd6fe" strokeWidth="4" />
      <Text x="190" y="300" value="cylinder" />
      <Text x="390" y="300" value="cone = 1/3" />
      <Text x="590" y="300" value={formula.id === "sphere-volume" ? "sphere" : "compare volumes"} />
    </g>
  );
}

function isDeepenedPhaseOneFormula(id: string) {
  return [
    "completing-square",
    "quadratic-standard",
    "pythagoras",
    "circle-area",
    "sector-area",
    "section",
    "triangle-area-coordinates",
    "chain-rule",
    "product-rule",
    "area-under-curve",
    "area-between-curves",
    "determinant-2x2",
    "linear-transform",
    "projection",
    "dot-product",
    "bayes",
    "standard-deviation",
    "regression",
    "cylinder-volume",
    "cone-volume",
    "sphere-volume",
  ].includes(id);
}

function Phase2Visual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  switch (formula.visualizerType) {
    case "number-system":
      return <NumberSystemVisual formula={formula} params={params} />;
    case "complex":
      return <ComplexVisual params={params} />;
    case "sequence":
      return <SequenceVisual params={params} />;
    case "combinatorics":
      return <CombinatoricsVisual params={params} />;
    case "set-logic":
      return <SetLogicVisual formula={formula} params={params} />;
    case "function":
    case "polynomial":
      return <FunctionFamilyVisual params={params} formula={formula} />;
    case "linear-programming":
      return <LinearProgrammingVisual params={params} />;
    case "inequality":
      return <InequalityVisual params={params} />;
    case "distribution":
      return <DistributionVisual params={params} />;
    default:
      return <StatisticsVisual params={params} />;
  }
}

function NumberSystemVisual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const n = Math.max(2, Math.round(Math.abs(params.n)));
  const a = Math.max(2, Math.round(Math.abs(params.a)));
  const b = Math.max(1, Math.round(Math.abs(params.b)));
  const gcd = gcdInt(a, b);
  if (formula.id === "prime-factorization") {
    const factors = primeFactorList(n);
    return (
      <g>
        <Text x="380" y="70" value={`${n} = ${factorLabel(n)}`} />
        {factors.map((prime, index) => (
          <g key={`${prime}-${index}`} transform={`translate(${160 + index * 70} 170)`}>
            <circle cx="0" cy="0" r="26" fill="#22d3ee" opacity="0.4" stroke="#67e8f9" strokeWidth="3" />
            <Text x="0" y="0" value={String(prime)} />
            {index < factors.length - 1 ? <line x1="28" y1="0" x2="42" y2="0" stroke="#67e8f9" /> : null}
          </g>
        ))}
        <Text x="380" y="280" value="Factor tree stops only at primes" />
      </g>
    );
  }
  if (formula.id === "hcf-gcd" || formula.id === "lcm") {
    return (
      <g>
        <Text x="380" y="80" value={formula.id === "lcm" ? `lcm(${a},${b})=${(a * b) / gcd}` : `gcd(${a},${b})=${gcd}`} />
        <rect x="140" y="130" width={Math.min(420, a * 4)} height="36" rx="10" fill="#22d3ee" opacity="0.35" />
        <rect x="140" y="190" width={Math.min(420, b * 4)} height="36" rx="10" fill="#f59e0b" opacity="0.35" />
        <Text x="150" y="154" value={`a=${a}`} />
        <Text x="150" y="214" value={`b=${b}`} />
        <Text x="380" y="280" value={`overlap gcd=${gcd}`} />
      </g>
    );
  }
  if (formula.id === "euclid-division") {
    const q = Math.floor(a / b);
    const r = a % b;
    return (
      <g>
        <Text x="380" y="80" value={`${a} = ${b}·${q} + ${r}`} />
        <rect x="140" y="150" width={Math.min(480, a * 3)} height="40" rx="10" fill="#22d3ee" opacity="0.3" />
        <rect x="140" y="150" width={Math.min(480, q * b * 3)} height="40" rx="10" fill="#8b5cf6" opacity="0.45" />
        <Text x="380" y="260" value={`0 ≤ r=${r} < ${b}`} />
      </g>
    );
  }
  if (formula.id === "decimal-terminating") {
    let remaining = n;
    while (remaining % 2 === 0) remaining /= 2;
    while (remaining % 5 === 0) remaining /= 5;
    const ok = remaining === 1;
    return (
      <g>
        <Text x="380" y="90" value={`q=${n}`} />
        <Text x="380" y="140" value={ok ? "Only 2s and 5s → terminating" : "Other prime factors → repeating"} />
        <Text x="380" y="200" value={factorLabel(n)} />
      </g>
    );
  }
  if (formula.id === "rational-form") {
    const x = a / Math.max(1, b);
    const map = 110 + ((Math.max(-6, Math.min(6, x)) + 6) / 12) * 540;
    return (
      <g>
        <line x1="110" y1="240" x2="650" y2="240" stroke="#e0f2fe" strokeWidth="4" />
        <circle cx={map} cy="240" r="13" fill="#22d3ee" />
        <Text x="380" y="80" value={`${a}/${b} = ${x.toFixed(4)}`} />
      </g>
    );
  }
  if (formula.id === "irrational-root") {
    const value = Math.sqrt(n);
    const square = Number.isInteger(value);
    return (
      <g>
        <Text x="380" y="90" value={`√${n} ≈ ${value.toFixed(5)}`} />
        <Text x="380" y="150" value={square ? "Perfect square → rational" : "Not a square → irrational"} />
        <line x1="110" y1="240" x2="650" y2="240" stroke="#e0f2fe" strokeWidth="4" />
        <circle cx={110 + Math.min(12, value) * 40} cy="240" r="12" fill={square ? "#10b981" : "#f59e0b"} />
      </g>
    );
  }
  const sum = String(n).split("").reduce((total, digit) => total + Number(digit), 0);
  return (
    <g>
      <Text x="380" y="90" value={`n=${n}, digit sum=${sum}`} />
      <Text x="380" y="150" value={sum % 9 === 0 && n % 9 === 0 ? "9 divides n" : "9 does not divide n"} />
      <Text x="380" y="220" value={`${n} ≡ ${n % 9} (mod 9)`} />
    </g>
  );
}

function primeFactorList(n: number) {
  const factors: number[] = [];
  let remaining = Math.max(1, Math.round(Math.abs(n)));
  for (let prime = 2; prime * prime <= remaining; prime += 1) {
    while (remaining % prime === 0) {
      factors.push(prime);
      remaining /= prime;
    }
  }
  if (remaining > 1) factors.push(remaining);
  return factors;
}

function factorLabel(n: number) {
  const factors = primeFactorList(n);
  if (!factors.length) return "1";
  const counts = new Map<number, number>();
  for (const factor of factors) counts.set(factor, (counts.get(factor) ?? 0) + 1);
  return [...counts.entries()].map(([prime, power]) => (power === 1 ? `${prime}` : `${prime}^${power}`)).join(" × ");
}

function ComplexVisual({ params }: { params: FormulaParameters }) {
  const zx = 380 + params.a * 35;
  const zy = 190 - params.b * 35;
  const conjugateY = 190 + params.b * 35;
  const r = Math.sqrt(params.a ** 2 + params.b ** 2);
  return (
    <g>
      <line x1="100" y1="190" x2="660" y2="190" stroke="#94a3b8" strokeWidth="3" />
      <line x1="380" y1="50" x2="380" y2="330" stroke="#94a3b8" strokeWidth="3" />
      <Arrow x1={380} y1={190} x2={zx} y2={zy} color="#22d3ee" label="z" />
      <Arrow x1={380} y1={190} x2={zx} y2={conjugateY} color="#f59e0b" label="conj" />
      <circle cx="380" cy="190" r={Math.max(24, r * 35)} fill="none" stroke="#a78bfa" strokeWidth="3" strokeDasharray="8 8" />
      <Text x="590" y="86" value={`|z|=${formatNumber(r)}`} />
      <Text x="590" y="126" value={`arg=${formatNumber((Math.atan2(params.b, params.a) * 180) / Math.PI)} deg`} />
    </g>
  );
}

function SequenceVisual({ params }: { params: FormulaParameters }) {
  const count = Math.max(4, Math.min(12, Math.round(params.n)));
  return (
    <g transform="translate(100 80)">
      {Array.from({ length: count }, (_, index) => {
        const value = params.a + index * params.b;
        const h = Math.max(18, Math.min(210, 80 + value * 10));
        return (
          <g key={index}>
            <rect x={index * 52} y={240 - h} width="34" height={h} rx="8" fill={index % 2 ? "#a78bfa" : "#22d3ee"} opacity="0.78" />
            <text x={index * 52 + 17} y="262" fill="#cbd5e1" fontSize="12" textAnchor="middle">{index + 1}</text>
          </g>
        );
      })}
      <Text x="560" y="70" value={`a_n=${formatNumber(params.a + (count - 1) * params.b)}`} />
      <Text x="560" y="112" value={`S_n=${formatNumber((count / 2) * (2 * params.a + (count - 1) * params.b))}`} />
    </g>
  );
}

function CombinatoricsVisual({ params }: { params: FormulaParameters }) {
  const n = Math.max(3, Math.min(10, Math.round(params.n)));
  const r = Math.max(1, Math.min(n, Math.round(Math.abs(params.b))));
  return (
    <g transform="translate(124 76)">
      {Array.from({ length: n }, (_, index) => (
        <circle key={index} cx={index * 48} cy="60" r="18" fill={index < r ? "#facc15" : "#22d3ee"} opacity="0.86" stroke="#e0f2fe" strokeWidth="3" />
      ))}
      {Array.from({ length: r }, (_, index) => (
        <rect key={index} x={120 + index * 76} y="166" width="54" height="54" rx="12" fill="#a78bfa" opacity="0.74" stroke="#ddd6fe" strokeWidth="3" />
      ))}
      <Text x="500" y="58" value={`n=${n}`} />
      <Text x="500" y="102" value={`r=${r}`} />
      <Text x="500" y="178" value={`nCr=${comb(n, r)}`} />
    </g>
  );
}

function SetLogicVisual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  const mode = getSetLogicVisualMode(formula.id);
  if (mode === "cartesian") return <CartesianProductVisual params={params} />;
  if (mode === "implication" || mode === "biconditional" || mode === "contrapositive") {
    return <LogicTruthTableVisual mode={mode} params={params} />;
  }
  return <SetRegionVisual mode={mode} params={params} />;
}

function SetRegionVisual({ mode, params }: { mode: Exclude<SetLogicVisualMode, "cartesian" | "implication" | "biconditional" | "contrapositive">; params: FormulaParameters }) {
  const sizeA = Math.max(0, Math.round(Math.abs(params.a)));
  const sizeB = Math.max(0, Math.round(Math.abs(params.b)));
  const overlap = Math.min(sizeA, sizeB, Math.max(0, Math.round(Math.abs(params.c))));
  const unionCount = sizeA + sizeB - overlap;
  const activeLabel = mode === "union" ? "A ∪ B" : mode === "intersection" ? "A ∩ B" : mode === "difference" ? "A − B" : mode === "complement" ? "(A ∪ B)′" : `n(A ∪ B) = ${unionCount}`;
  const showUnion = mode === "union" || mode === "cardinality";
  return (
    <g>
      <defs>
        <clipPath id="set-clip-a"><circle cx="330" cy="188" r="104" /></clipPath>
        <mask id="set-a-minus-b"><rect width="760" height="390" fill="black" /><circle cx="330" cy="188" r="104" fill="white" /><circle cx="430" cy="188" r="104" fill="black" /></mask>
        <mask id="set-outside-union"><rect width="760" height="390" fill="white" /><circle cx="330" cy="188" r="104" fill="black" /><circle cx="430" cy="188" r="104" fill="black" /></mask>
      </defs>
      <rect x="142" y="54" width="476" height="270" rx="18" fill="#0f2740" stroke="#64748b" strokeWidth="3" />
      {mode === "complement" ? <rect x="142" y="54" width="476" height="270" rx="18" fill="#f59e0b" opacity="0.55" mask="url(#set-outside-union)" /> : null}
      {showUnion ? <><circle cx="330" cy="188" r="104" fill="#22d3ee" opacity="0.64" /><circle cx="430" cy="188" r="104" fill="#a78bfa" opacity="0.64" /></> : null}
      {mode === "intersection" ? <circle cx="430" cy="188" r="104" fill="#facc15" opacity="0.78" clipPath="url(#set-clip-a)" /> : null}
      {mode === "difference" ? <rect width="760" height="390" fill="#22d3ee" opacity="0.8" mask="url(#set-a-minus-b)" /> : null}
      <circle cx="330" cy="188" r="104" fill={showUnion ? "transparent" : "#22d3ee"} fillOpacity="0.13" stroke="#67e8f9" strokeWidth="4" />
      <circle cx="430" cy="188" r="104" fill={showUnion ? "transparent" : "#a78bfa"} fillOpacity="0.13" stroke="#ddd6fe" strokeWidth="4" />
      <Text x="278" y="188" value={mode === "cardinality" ? String(sizeA - overlap) : "A"} />
      <Text x="482" y="188" value={mode === "cardinality" ? String(sizeB - overlap) : "B"} />
      <Text x="380" y="188" value={mode === "cardinality" ? String(overlap) : "A∩B"} />
      <Text x="380" y="304" value={activeLabel} />
      {mode === "cardinality" ? <Text x="380" y="92" value={`${sizeA} + ${sizeB} − ${overlap} = ${unionCount}`} /> : null}
    </g>
  );
}

function CartesianProductVisual({ params }: { params: FormulaParameters }) {
  const aCount = Math.max(1, Math.min(5, Math.round(Math.abs(params.a))));
  const bCount = Math.max(1, Math.min(5, Math.round(Math.abs(params.b))));
  return (
    <g transform="translate(170 70)">
      <Text x="210" y="0" value={`A × B has ${aCount * bCount} ordered pairs`} />
      {Array.from({ length: aCount }, (_, row) => (
        <g key={`a-${row}`}>
          <Text x="0" y={66 + row * 48} value={`a${row + 1}`} />
          {Array.from({ length: bCount }, (_, column) => (
            <g key={`${row}-${column}`}>
              {row === 0 ? <Text x={100 + column * 78} y="34" value={`b${column + 1}`} /> : null}
              <rect x={67 + column * 78} y={43 + row * 48} width="66" height="38" rx="9" fill={(row + column) % 2 ? "#a78bfa" : "#22d3ee"} opacity="0.62" stroke="#e0f2fe" />
              <text x={100 + column * 78} y={67 + row * 48} fill="white" fontSize="12" fontWeight="700" textAnchor="middle">({row + 1},{column + 1})</text>
            </g>
          ))}
        </g>
      ))}
      <Text x="210" y="310" value={`|A|·|B| = ${aCount}·${bCount} = ${aCount * bCount}`} />
    </g>
  );
}

function LogicTruthTableVisual({ mode, params }: { mode: "implication" | "biconditional" | "contrapositive"; params: FormulaParameters }) {
  const selectedP = params.p >= 50;
  const selectedQ = params.b >= 0;
  const rows = [[true, true], [true, false], [false, true], [false, false]] as const;
  const title = mode === "implication" ? "p ⇒ q ≡ ¬p ∨ q" : mode === "biconditional" ? "p ⇔ q" : "p ⇒ q ≡ ¬q ⇒ ¬p";
  const value = (p: boolean, q: boolean) => mode === "biconditional" ? p === q : !p || q;
  return (
    <g transform="translate(152 62)">
      <Text x="228" y="0" value={title} />
      {["p", "q", mode === "biconditional" ? "p⇔q" : mode === "contrapositive" ? "¬q⇒¬p" : "p⇒q"].map((label, index) => <Text key={label} x={80 + index * 150} y="52" value={label} />)}
      {rows.map(([p, q], row) => {
        const selected = p === selectedP && q === selectedQ;
        return <g key={`${p}-${q}`}>
          <rect x="18" y={72 + row * 52} width="420" height="42" rx="10" fill={selected ? "#f59e0b" : row % 2 ? "#172b45" : "#10243c"} opacity={selected ? 0.68 : 0.9} stroke={selected ? "#fde68a" : "#334155"} />
          <Text x="80" y={94 + row * 52} value={p ? "T" : "F"} />
          <Text x="230" y={94 + row * 52} value={q ? "T" : "F"} />
          <Text x="380" y={94 + row * 52} value={value(p, q) ? "T" : "F"} />
        </g>;
      })}
      <Text x="228" y="306" value="Highlighted row follows the live p and q controls" />
    </g>
  );
}

function FunctionFamilyVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const curve = makeCurvePoints({ ...formula, visualizerType: "graph" }, params);
  return (
    <g>
      <line x1="80" y1="190" x2="680" y2="190" stroke="#94a3b8" strokeWidth="2" />
      <line x1="380" y1="50" x2="380" y2="330" stroke="#94a3b8" strokeWidth="2" />
      <polyline points={curve} fill="none" stroke="#22d3ee" strokeWidth="5" strokeLinecap="round" />
      <line x1={380 + params.a * 34} y1="56" x2={380 + params.a * 34} y2="330" stroke="#facc15" strokeWidth="3" strokeDasharray="8 8" />
      <Text x="560" y="88" value={formula.visualizerType === "polynomial" ? "roots / degree" : "input to output"} />
    </g>
  );
}

function LinearProgrammingVisual({ params }: { params: FormulaParameters }) {
  const x1 = 160 + Math.abs(params.a) * 24;
  const y1 = 300 - Math.abs(params.b) * 24;
  return (
    <g>
      <line x1="120" y1="310" x2="650" y2="310" stroke="#94a3b8" strokeWidth="3" />
      <line x1="120" y1="310" x2="120" y2="66" stroke="#94a3b8" strokeWidth="3" />
      <polygon points={`120,310 120,130 ${x1 + 230},${y1} 610,310`} fill="#22d3ee" opacity="0.28" stroke="#67e8f9" strokeWidth="4" />
      <line x1="120" y1="130" x2={x1 + 230} y2={y1} stroke="#facc15" strokeWidth="4" />
      <line x1={x1 + 230} y1={y1} x2="610" y2="310" stroke="#a78bfa" strokeWidth="4" />
      <circle cx={x1 + 230} cy={y1} r="10" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      <Text x="500" y="96" value="best corner" />
      <Text x="510" y="138" value={`Z=${formatNumber(params.a * 2 + params.b * 3)}`} />
    </g>
  );
}

function InequalityVisual({ params }: { params: FormulaParameters }) {
  const boundary = 380 + params.a * 36;
  return (
    <g>
      <line x1="120" y1="210" x2="640" y2="210" stroke="#e0f2fe" strokeWidth="5" />
      <rect x="120" y="180" width={Math.max(0, boundary - 120)} height="60" rx="18" fill="#22d3ee" opacity="0.35" />
      <circle cx={boundary} cy="210" r="15" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      <Text x="380" y="112" value="shade solution interval" />
      <path d={`M180 310 C300 ${260 - params.b * 10}, 460 ${260 + params.c * 12}, 600 310`} fill="none" stroke="#a78bfa" strokeWidth="5" />
    </g>
  );
}

function DistributionVisual({ params }: { params: FormulaParameters }) {
  const meanX = 380 + params.a * 18;
  const spread = Math.max(34, 84 + Math.abs(params.b) * 10);
  const normal = Array.from({ length: 100 }, (_, index) => {
    const x = 100 + index * 5.6;
    const z = (x - meanX) / spread;
    const y = 292 - Math.exp(-0.5 * z * z) * 170;
    return `${x},${y}`;
  }).join(" ");
  return (
    <g>
      <line x1="100" y1="292" x2="660" y2="292" stroke="#94a3b8" strokeWidth="3" />
      <polyline points={normal} fill="none" stroke="#22d3ee" strokeWidth="5" strokeLinecap="round" />
      <line x1={meanX} y1="106" x2={meanX} y2="292" stroke="#facc15" strokeWidth="4" strokeDasharray="8 8" />
      {Array.from({ length: 9 }, (_, index) => (
        <rect key={index} x={130 + index * 42} y={292 - (index + 2) * 12} width="28" height={(index + 2) * 12} rx="7" fill="#a78bfa" opacity="0.62" />
      ))}
      <Text x="548" y="102" value={`p=${formatNumber(params.p / 100)}`} />
      <Text x="548" y="142" value={`mean=${formatNumber(params.a)}`} />
    </g>
  );
}

function Phase3Visual({ formula, params }: { formula: FormulaVisualizerEntry; params: FormulaParameters }) {
  switch (formula.visualizerType) {
    case "limits-continuity":
    case "real-analysis":
      return <LimitContinuityVisual params={params} formula={formula} />;
    case "differential-equations":
      return <DifferentialEquationVisual params={params} />;
    case "determinant":
      return <DeterminantVisual params={params} />;
    case "three-d-geometry":
    case "differential-geometry":
      return <IsometricGeometryVisual params={params} formula={formula} />;
    case "early-number-sense":
      return <NumberSenseVisual params={params} />;
    case "fraction-percent":
      return <FractionPercentVisual params={params} />;
    case "commercial-math":
      return <CommercialMathVisual params={params} />;
    case "speed-work":
      return <SpeedWorkVisual params={params} />;
    case "mental-math":
      return <MentalMathVisual params={params} formula={formula} />;
    case "pre-algebra":
      return <PreAlgebraVisual params={params} />;
    case "number-theory":
    case "cryptography":
      return <ModularClockVisual params={params} formula={formula} />;
    case "euclidean-geometry":
      return <EuclideanTheoremVisual params={params} />;
    case "analytic-geometry":
    case "precalculus":
      return <ConicFunctionVisual params={params} formula={formula} />;
    case "calculus-applications":
    case "optimization":
    case "numerical-methods":
      return <OptimizationNumericalVisual params={params} formula={formula} />;
    case "multivariable-calculus":
      return <VectorFieldVisual params={params} />;
    case "advanced-linear-algebra":
      return <LinearAlgebraAdvancedVisual params={params} />;
    case "abstract-algebra":
      return <CayleyTableVisual params={params} />;
    case "complex-analysis":
      return <ComplexMappingVisual params={params} />;
    case "topology":
      return <TopologyVisual params={params} />;
    case "discrete-math":
      return <DiscreteMathVisual params={params} />;
    case "dynamical-systems":
      return <DynamicalSystemsVisual params={params} />;
    case "pde":
      return <PdeVisual params={params} />;
    case "transforms":
      return <TransformVisual params={params} />;
    case "mathematical-physics":
      return <MathematicalPhysicsVisual params={params} />;
    case "information-theory":
      return <InformationTheoryVisual params={params} />;
    case "machine-learning":
      return <MachineLearningVisual params={params} />;
    default:
      return <FunctionFamilyVisual params={params} formula={{ ...formula, visualizerType: "graph" }} />;
  }
}

function LimitContinuityVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const a = 380 + params.a * 26;
  const eps = Math.max(18, params.p * 0.9);
  const curve = makeCurvePoints({ ...formula, visualizerType: "graph" }, params);
  return (
    <g>
      <rect x="80" y={190 - eps / 2} width="600" height={eps} rx="16" fill="#22d3ee" opacity="0.16" />
      <polyline points={curve} fill="none" stroke="#67e8f9" strokeWidth="5" />
      <line x1={a} y1="58" x2={a} y2="330" stroke="#facc15" strokeWidth="4" strokeDasharray="8 8" />
      <circle cx={a - 42} cy={190 + params.b * 10} r="10" fill="#f59e0b" stroke="#fff7ed" strokeWidth="4" />
      <circle cx={a + 42} cy={190 + params.c * 10} r="10" fill="#a78bfa" stroke="#fff7ed" strokeWidth="4" />
      <Text x="170" y="86" value="left / right approach" />
      <Text x="610" y="300" value="epsilon band" />
    </g>
  );
}

function DifferentialEquationVisual({ params }: { params: FormulaParameters }) {
  const k = params.a / 6;
  return (
    <g>
      {Array.from({ length: 9 }, (_, row) =>
        Array.from({ length: 13 }, (_, col) => {
          const x = 95 + col * 48;
          const y = 68 + row * 30;
          const slope = Math.tanh(k + (row - 4) * 0.16);
          return <line key={`${row}-${col}`} x1={x - 12} y1={y - slope * 12} x2={x + 12} y2={y + slope * 12} stroke="#67e8f9" strokeWidth="3" opacity="0.75" />;
        }),
      )}
      <path d={`M120 300 C250 ${250 - params.a * 18}, 420 ${190 - params.b * 20}, 640 ${100 + params.c * 14}`} fill="none" stroke="#facc15" strokeWidth="5" />
      <circle cx={260 + params.b * 16} cy={220 - params.c * 12} r="12" fill="#f59e0b" stroke="#fff7ed" strokeWidth="4" />
      <Text x="580" y="78" value="solution curve" />
      <Text x="190" y="330" value="initial value" />
    </g>
  );
}

function DeterminantVisual({ params }: { params: FormulaParameters }) {
  const det = params.a * params.n - params.b * params.c;
  const scale = Math.max(0.25, Math.min(1.8, Math.abs(det) / 12));
  const parallelogram = `360,230 ${360 + params.a * 24},${230 - params.b * 18} ${360 + params.a * 24 + params.c * 24},${230 - params.b * 18 - params.n * 8} ${360 + params.c * 24},${230 - params.n * 8}`;
  return (
    <g>
      <g transform="translate(110 92)">
        {[["a", params.a], ["b", params.b], ["c", params.c], ["d", params.n]].map(([label, value], index) => (
          <g key={String(label)} transform={`translate(${(index % 2) * 74} ${Math.floor(index / 2) * 64})`}>
            <rect width="58" height="48" rx="10" fill="#0f172a" stroke="#67e8f9" strokeWidth="3" />
            <Text x="29" y="24" value={`${label}=${formatNumber(Number(value))}`} />
          </g>
        ))}
      </g>
      <polygon points={parallelogram} fill="#22d3ee" opacity={0.26 + scale * 0.22} stroke="#67e8f9" strokeWidth="5" />
      <Text x="560" y="112" value={`det=${formatNumber(det)}`} />
      <Text x="560" y="158" value={Math.abs(det) < 0.3 ? "singular" : "invertible"} />
      <Text x="545" y="300" value="area / volume scale" />
    </g>
  );
}

function IsometricGeometryVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const px = 380 + params.a * 26;
  const py = 210 - params.b * 18;
  const pz = params.c * 18;
  return (
    <g>
      <Arrow x1={160} y1={280} x2={620} y2={280} color="#67e8f9" label="x" />
      <Arrow x1={160} y1={280} x2={300} y2={120} color="#facc15" label="y" />
      <Arrow x1={160} y1={280} x2={160} y2={80} color="#a78bfa" label="z" />
      <polygon points={`300,250 570,210 620,275 350,318`} fill="#22d3ee" opacity="0.16" stroke="#67e8f9" strokeWidth="3" />
      <line x1="450" y1="244" x2="520" y2="118" stroke="#f59e0b" strokeWidth="5" />
      <circle cx={px + pz * 0.4} cy={py - pz} r="11" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      <Text x="560" y="88" value={formula.visualizerType === "differential-geometry" ? "tangent / normal" : "line / plane / point"} />
    </g>
  );
}

function NumberSenseVisual({ params }: { params: FormulaParameters }) {
  const value = Math.max(1, Math.min(99, Math.round(Math.abs(params.a * 10 + params.b))));
  const tens = Math.floor(value / 10);
  const ones = value % 10;
  return (
    <g>
      <line x1="100" y1="290" x2="650" y2="290" stroke="#e0f2fe" strokeWidth="5" />
      <circle cx={100 + value * 5.5} cy="290" r="13" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      {Array.from({ length: tens }, (_, i) => <rect key={i} x={120 + i * 34} y="94" width="24" height="120" rx="8" fill="#22d3ee" opacity="0.74" />)}
      {Array.from({ length: ones }, (_, i) => <circle key={i} cx={450 + (i % 5) * 32} cy={118 + Math.floor(i / 5) * 36} r="12" fill="#a78bfa" />)}
      <Text x="190" y="62" value={`${tens} tens`} />
      <Text x="520" y="62" value={`${ones} ones`} />
      <Text x="382" y="334" value={`number ${value}`} />
    </g>
  );
}

function FractionPercentVisual({ params }: { params: FormulaParameters }) {
  const denominator = Math.max(2, Math.min(12, Math.round(params.n)));
  const numerator = Math.max(1, Math.min(denominator, Math.round(Math.abs(params.a))));
  return (
    <g>
      {Array.from({ length: denominator }, (_, index) => (
        <rect key={index} x={120 + index * 42} y="120" width="36" height="120" rx="8" fill={index < numerator ? "#22d3ee" : "#1e293b"} stroke="#67e8f9" strokeWidth="2" />
      ))}
      {Array.from({ length: 100 }, (_, index) => (
        <rect key={index} x={170 + (index % 20) * 18} y={278 + Math.floor(index / 20) * 14} width="14" height="10" rx="2" fill={index < Math.round((numerator / denominator) * 100) ? "#f59e0b" : "#334155"} />
      ))}
      <Text x="380" y="76" value={`${numerator}/${denominator} = ${formatNumber(numerator / denominator)}`} />
      <Text x="580" y="330" value={`${Math.round((numerator / denominator) * 100)}%`} />
    </g>
  );
}

function CommercialMathVisual({ params }: { params: FormulaParameters }) {
  const price = Math.max(20, Math.round(Math.abs(params.n * 20)));
  const discount = Math.round(params.p);
  const finalPrice = price * (1 - discount / 100) * (1 + Math.max(0, params.b) / 100);
  return (
    <g>
      <rect x="120" y="80" width="250" height="250" rx="20" fill="#f8fafc" opacity="0.92" />
      {["Marked price", "Discount", "Tax", "Final bill"].map((label, index) => <text key={label} x="150" y={128 + index * 46} fill="#0f172a" fontSize="18" fontWeight="800">{label}</text>)}
      {[price, discount, Math.max(0, params.b), finalPrice].map((value, index) => <text key={index} x="330" y={128 + index * 46} fill="#0369a1" fontSize="18" fontWeight="900" textAnchor="end">{index === 0 || index === 3 ? formatNumber(value) : `${formatNumber(value)}%`}</text>)}
      <path d={`M470 300 V${300 - price * 0.35} M540 300 V${300 - finalPrice * 0.35}`} stroke="#22d3ee" strokeWidth="38" strokeLinecap="round" />
      <Text x="505" y="70" value="simple bill model" />
    </g>
  );
}

function SpeedWorkVisual({ params }: { params: FormulaParameters }) {
  const distance = Math.max(70, Math.min(500, Math.abs(params.a * params.n) * 9));
  const fill = Math.max(20, Math.min(190, params.p * 1.9));
  return (
    <g>
      <line x1="120" y1="145" x2="650" y2="145" stroke="#e0f2fe" strokeWidth="5" />
      <circle cx={120 + distance} cy="145" r="16" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      <rect x="180" y="230" width="180" height="100" rx="16" fill="#0f172a" stroke="#67e8f9" strokeWidth="4" />
      <rect x="180" y={330 - fill / 2} width="180" height={fill / 2} rx="14" fill="#22d3ee" opacity="0.68" />
      <Arrow x1={450} y1={295} x2={600} y2={295 - params.b * 10} color="#f59e0b" label="rate" />
      <Text x="380" y="88" value="distance / time / work rate" />
    </g>
  );
}

function MentalMathVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const base = Math.max(10, Math.round(Math.abs(params.n)) * 10);
  const offset = Math.round(params.a);
  return (
    <g>
      <rect x="110" y="92" width="540" height="210" rx="28" fill="#0f172a" stroke="#67e8f9" strokeWidth="4" />
      <Text x="230" y="150" value={`base ${base}`} />
      <Text x="380" y="150" value={`offset ${offset}`} />
      <Text x="530" y="150" value={formula.id === "square-ending-5" ? "append 25" : "shortcut"} />
      <path d="M185 210 H575" stroke="#facc15" strokeWidth="5" strokeDasharray="10 8" />
      <Text x="380" y="250" value="normal method vs shortcut steps" />
    </g>
  );
}

function PreAlgebraVisual({ params }: { params: FormulaParameters }) {
  return (
    <g>
      <line x1="380" y1="105" x2="380" y2="285" stroke="#e0f2fe" strokeWidth="6" />
      <line x1="220" y1="150" x2="540" y2="150" stroke="#e0f2fe" strokeWidth="5" />
      <rect x="170" y={190 - params.a * 5} width="130" height="54" rx="14" fill="#22d3ee" opacity="0.74" />
      <rect x="460" y={190 - params.b * 5} width="130" height="54" rx="14" fill="#a78bfa" opacity="0.74" />
      <Text x="235" y={218 - params.a * 5} value="ax+b" />
      <Text x="525" y={218 - params.b * 5} value="c" />
      <Text x="380" y="318" value="balance equation model" />
    </g>
  );
}

function ModularClockVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const mod = Math.max(5, Math.min(26, Math.round(params.n)));
  const active = ((Math.round(params.a * params.b) % mod) + mod) % mod;
  return (
    <g>
      <circle cx="300" cy="190" r="118" fill="#22d3ee" opacity="0.12" stroke="#67e8f9" strokeWidth="4" />
      {Array.from({ length: mod }, (_, index) => {
        const angle = (index / mod) * Math.PI * 2 - Math.PI / 2;
        const x = 300 + Math.cos(angle) * 96;
        const y = 190 + Math.sin(angle) * 96;
        return <circle key={index} cx={x} cy={y} r={index === active ? 13 : 7} fill={index === active ? "#facc15" : "#a78bfa"} />;
      })}
      <Text x="560" y="116" value={`mod ${mod}`} />
      <Text x="560" y="166" value={`remainder ${active}`} />
      <Text x="560" y="230" value={formula.visualizerType === "cryptography" ? "toy learning model" : "clock arithmetic"} />
    </g>
  );
}

function EuclideanTheoremVisual({ params }: { params: FormulaParameters }) {
  const apexX = 350 + params.a * 12;
  const apexY = 100 + params.b * 8;
  return (
    <g>
      <polygon points={`150,290 610,290 ${apexX},${apexY}`} fill="#22d3ee" opacity="0.3" stroke="#e0f2fe" strokeWidth="5" />
      <line x1={apexX} y1={apexY} x2={380} y2="290" stroke="#facc15" strokeWidth="4" strokeDasharray="8 8" />
      <circle cx="610" cy="290" r="92" fill="none" stroke="#f472b6" strokeWidth="4" opacity="0.8" />
      <Text x="250" y="310" value="a" />
      <Text x="500" y="310" value="b" />
      <Text x="380" y="78" value="toggle theorem conditions" />
    </g>
  );
}

function ConicFunctionVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const e = Math.max(0.2, Math.min(1.8, Math.abs(params.a) / 4));
  const curve = Array.from({ length: 120 }, (_, index) => {
    const t = (index / 119) * Math.PI * 2;
    const x = 380 + Math.cos(t) * 150;
    const y = 190 + Math.sin(t) * 90 * e;
    return `${x},${y}`;
  }).join(" ");
  return (
    <g>
      <polyline points={curve} fill="none" stroke="#67e8f9" strokeWidth="5" />
      <line x1="165" y1="190" x2="595" y2="190" stroke="#facc15" strokeWidth="3" strokeDasharray="9 8" />
      <circle cx={380 - 80 * e} cy="190" r="10" fill="#f59e0b" />
      <circle cx={380 + 80 * e} cy="190" r="10" fill="#f59e0b" />
      <Text x="555" y="92" value={formula.visualizerType === "precalculus" ? "transform / inverse" : `e=${formatNumber(e)}`} />
    </g>
  );
}

function OptimizationNumericalVisual({ params, formula }: { params: FormulaParameters; formula: FormulaVisualizerEntry }) {
  const curve = Array.from({ length: 120 }, (_, index) => {
    const x = -5 + (index / 119) * 10;
    const y = 0.28 * (x - params.a / 2) ** 2 + Math.sin(x + params.b) * 0.7;
    return `${380 + x * 52},${300 - y * 34}`;
  }).join(" ");
  const stepX = 380 + params.a * 34;
  return (
    <g>
      <polyline points={curve} fill="none" stroke="#67e8f9" strokeWidth="5" />
      <Arrow x1={stepX + 70} y1={116} x2={stepX} y2={168} color="#facc15" label="step" />
      <circle cx={stepX} cy="170" r="12" fill="#f59e0b" stroke="#fff7ed" strokeWidth="4" />
      <Text x="560" y="300" value={formula.visualizerType === "numerical-methods" ? "iteration table" : "objective value"} />
    </g>
  );
}

function VectorFieldVisual({ params }: { params: FormulaParameters }) {
  return (
    <g>
      {Array.from({ length: 8 }, (_, row) =>
        Array.from({ length: 12 }, (_, col) => {
          const x = 110 + col * 50;
          const y = 75 + row * 34;
          const dx = Math.sin(row + params.a) * 12;
          const dy = Math.cos(col + params.b) * 12;
          return <Arrow key={`${row}-${col}`} x1={x} y1={y} x2={x + dx} y2={y + dy} color="#67e8f9" label="" />;
        }),
      )}
      <Text x="575" y="330" value="gradient / divergence / curl" />
    </g>
  );
}

function LinearAlgebraAdvancedVisual({ params }: { params: FormulaParameters }) {
  const v1 = { x: 380 + params.a * 32, y: 210 - params.b * 24 };
  const v2 = { x: 380 + params.c * 42, y: 210 - params.n * 6 };
  return (
    <g>
      <line x1="110" y1="210" x2="650" y2="210" stroke="#94a3b8" strokeWidth="3" />
      <line x1="380" y1="60" x2="380" y2="330" stroke="#94a3b8" strokeWidth="3" />
      <polygon points={`380,210 ${v1.x},${v1.y} ${v1.x + v2.x - 380},${v1.y + v2.y - 210} ${v2.x},${v2.y}`} fill="#22d3ee" opacity="0.16" stroke="#67e8f9" strokeWidth="3" />
      <Arrow x1={380} y1={210} x2={v1.x} y2={v1.y} color="#22d3ee" label="basis 1" />
      <Arrow x1={380} y1={210} x2={v2.x} y2={v2.y} color="#f59e0b" label="basis 2" />
      <Text x="570" y="92" value="span / projection" />
    </g>
  );
}

function CayleyTableVisual({ params }: { params: FormulaParameters }) {
  const mod = Math.max(3, Math.min(7, Math.round(Math.abs(params.n / 2))));
  return (
    <g transform="translate(190 72)">
      {Array.from({ length: mod + 1 }, (_, r) =>
        Array.from({ length: mod + 1 }, (_, c) => {
          const label = r === 0 && c === 0 ? "+" : r === 0 ? String(c - 1) : c === 0 ? String(r - 1) : String((r + c - 2) % mod);
          return (
            <g key={`${r}-${c}`} transform={`translate(${c * 58} ${r * 42})`}>
              <rect width="52" height="36" rx="8" fill={r === 0 || c === 0 ? "#facc15" : "#22d3ee"} opacity={r === 0 || c === 0 ? 0.9 : 0.28} stroke="#e0f2fe" />
              <text x="26" y="23" fill="#f8fafc" fontSize="15" fontWeight="900" textAnchor="middle">{label}</text>
            </g>
          );
        }),
      )}
      <Text x="415" y="220" value={`Z_${mod} Cayley table`} />
    </g>
  );
}

function ComplexMappingVisual({ params }: { params: FormulaParameters }) {
  return (
    <g>
      <rect x="110" y="80" width="220" height="220" rx="20" fill="#22d3ee" opacity="0.12" stroke="#67e8f9" />
      <rect x="430" y="80" width="220" height="220" rx="20" fill="#a78bfa" opacity="0.12" stroke="#ddd6fe" />
      {Array.from({ length: 5 }, (_, i) => <line key={`l-${i}`} x1={135 + i * 40} y1="100" x2={135 + i * 40 + params.a * 5} y2="280" stroke="#67e8f9" />)}
      {Array.from({ length: 5 }, (_, i) => <path key={`m-${i}`} d={`M455 ${105 + i * 38} C520 ${90 + params.a * 8}, 560 ${230 - params.b * 6}, 625 ${105 + i * 38}`} fill="none" stroke="#facc15" strokeWidth="3" />)}
      <Text x="220" y="330" value="z-plane" />
      <Text x="540" y="330" value="w=f(z)" />
    </g>
  );
}

function TopologyVisual({ params }: { params: FormulaParameters }) {
  const r = Math.max(40, Math.min(130, params.p * 1.3));
  return (
    <g>
      <path d="M150 210 C140 80, 300 60, 350 145 C420 58, 610 110, 590 245 C500 330, 280 330, 150 210Z" fill="#22d3ee" opacity="0.18" stroke="#67e8f9" strokeWidth="4" />
      <circle cx={370 + params.a * 18} cy={200 - params.b * 12} r={r} fill="#f59e0b" opacity="0.15" stroke="#facc15" strokeWidth="4" strokeDasharray="8 8" />
      <circle cx={370 + params.a * 18} cy={200 - params.b * 12} r="10" fill="#facc15" />
      <Text x="575" y="94" value="open ball / neighborhood" />
      <Text x="240" y="310" value="connected region" />
    </g>
  );
}

function DiscreteMathVisual({ params }: { params: FormulaParameters }) {
  const truth = params.p > 50;
  return (
    <g>
      {[0, 1, 2, 3].map((i) => <circle key={i} cx={190 + i * 120} cy={130 + (i % 2) * 110} r="28" fill="#22d3ee" opacity="0.72" stroke="#e0f2fe" strokeWidth="3" />)}
      <line x1="190" y1="130" x2="310" y2="240" stroke="#facc15" strokeWidth="4" />
      <line x1="310" y1="240" x2="430" y2="130" stroke="#facc15" strokeWidth="4" />
      <line x1="430" y1="130" x2="550" y2="240" stroke="#facc15" strokeWidth="4" />
      <rect x="160" y="305" width="420" height="48" rx="14" fill="#0f172a" stroke="#67e8f9" />
      <Text x="370" y="330" value={`p=>q is ${truth ? "true" : "check q"}`} />
    </g>
  );
}

function DynamicalSystemsVisual({ params }: { params: FormulaParameters }) {
  const r = Math.max(1, Math.min(4, Math.abs(params.a) / 2 + 2));
  const points: string[] = [];
  let x = Math.max(0.05, Math.min(0.95, params.p / 100));
  for (let i = 0; i < 45; i += 1) {
    x = r * x * (1 - x);
    points.push(`${120 + i * 11},${300 - x * 210}`);
  }
  return (
    <g>
      <polyline points={points.join(" ")} fill="none" stroke="#67e8f9" strokeWidth="4" />
      <line x1="120" y1="300" x2="640" y2="300" stroke="#94a3b8" />
      <Text x="550" y="96" value={`r=${formatNumber(r)}`} />
      <Text x="550" y="140" value="time series / stability" />
    </g>
  );
}

function PdeVisual({ params }: { params: FormulaParameters }) {
  const time = params.p / 100;
  return (
    <g>
      {Array.from({ length: 24 }, (_, index) => {
        const heat = Math.exp(-time * 2) * Math.sin((index / 23) * Math.PI) * 130;
        return <rect key={index} x={110 + index * 22} y={300 - heat} width="18" height={heat} rx="5" fill={`hsl(${190 - heat / 2}, 85%, 58%)`} />;
      })}
      <path d={`M120 130 C240 ${80 + params.a * 8}, 360 ${180 + params.b * 10}, 620 ${110 + params.c * 12}`} fill="none" stroke="#facc15" strokeWidth="5" />
      <Text x="380" y="70" value="heat bar / wave string" />
    </g>
  );
}

function TransformVisual({ params }: { params: FormulaParameters }) {
  const harmonics = [1, 2, 3, 4, 5];
  const wave = Array.from({ length: 130 }, (_, index) => {
    const x = (index / 129) * Math.PI * 4;
    const y = harmonics.reduce((sum, h) => sum + Math.sin(h * x) * (params.p / 100) / h, 0);
    return `${90 + index * 4.6},${190 - y * 54}`;
  }).join(" ");
  return (
    <g>
      <polyline points={wave} fill="none" stroke="#67e8f9" strokeWidth="5" />
      {harmonics.map((h, index) => <rect key={h} x={520 + index * 24} y={290 - (params.p / h)} width="18" height={params.p / h} fill="#facc15" />)}
      <Text x="570" y="92" value="frequency spectrum" />
      <Text x="250" y="310" value="signal reconstruction" />
    </g>
  );
}

function MathematicalPhysicsVisual({ params }: { params: FormulaParameters }) {
  const path = `M110 290 Q${310 + params.a * 20} ${70 - params.b * 6} 650 290`;
  return (
    <g>
      <path d={path} fill="none" stroke="#67e8f9" strokeWidth="5" />
      <circle cx="300" cy={155 - params.b * 4} r="15" fill="#facc15" stroke="#fff7ed" strokeWidth="4" />
      <rect x="130" y="320" width={Math.max(30, Math.abs(params.a) * 36)} height="20" rx="10" fill="#f59e0b" />
      <path d={`M500 210 C540 ${165 + params.c * 12}, 590 ${255 - params.c * 12}, 635 210`} fill="none" stroke="#a78bfa" strokeWidth="5" />
      <Text x="560" y="92" value="motion / energy / wave" />
    </g>
  );
}

function InformationTheoryVisual({ params }: { params: FormulaParameters }) {
  const p = Math.max(0.01, Math.min(0.99, params.p / 100));
  const entropy = -(p * Math.log2(p) + (1 - p) * Math.log2(1 - p));
  return (
    <g>
      <rect x="140" y={300 - p * 170} width="80" height={p * 170} rx="12" fill="#22d3ee" />
      <rect x="250" y={300 - (1 - p) * 170} width="80" height={(1 - p) * 170} rx="12" fill="#a78bfa" />
      <rect x="460" y={300 - entropy * 170} width="120" height={entropy * 170} rx="16" fill="#facc15" />
      <Text x="185" y="330" value="P(0)" />
      <Text x="295" y="330" value="P(1)" />
      <Text x="520" y="330" value={`H=${formatNumber(entropy)}`} />
    </g>
  );
}

function MachineLearningVisual({ params }: { params: FormulaParameters }) {
  const slope = params.a / 3;
  return (
    <g>
      {Array.from({ length: 16 }, (_, index) => {
        const x = 120 + (index % 8) * 62;
        const y = 105 + Math.floor(index / 8) * 110 + Math.sin(index) * 22;
        return <circle key={index} cx={x} cy={y} r="9" fill={index % 3 ? "#22d3ee" : "#f59e0b"} />;
      })}
      <line x1="120" y1={240 - slope * 80} x2="610" y2={120 + slope * 80} stroke="#facc15" strokeWidth="5" />
      <path d={`M130 320 C250 ${250 - params.a * 10}, 400 ${300 - params.b * 8}, 620 ${180 + params.c * 12}`} fill="none" stroke="#a78bfa" strokeWidth="5" />
      <Text x="555" y="80" value="model / loss / gradient" />
    </g>
  );
}

function isPhase2Visual(type: FormulaVisualizerEntry["visualizerType"]) {
  return ["number-system", "complex", "sequence", "combinatorics", "set-logic", "function", "linear-programming", "polynomial", "inequality", "distribution"].includes(type);
}

function isPhase3Visual(type: FormulaVisualizerEntry["visualizerType"]) {
  return [
    "limits-continuity",
    "differential-equations",
    "determinant",
    "three-d-geometry",
    "early-number-sense",
    "fraction-percent",
    "commercial-math",
    "speed-work",
    "mental-math",
    "pre-algebra",
    "number-theory",
    "euclidean-geometry",
    "analytic-geometry",
    "precalculus",
    "calculus-applications",
    "multivariable-calculus",
    "advanced-linear-algebra",
    "abstract-algebra",
    "real-analysis",
    "complex-analysis",
    "topology",
    "differential-geometry",
    "discrete-math",
    "optimization",
    "numerical-methods",
    "dynamical-systems",
    "pde",
    "transforms",
    "mathematical-physics",
    "information-theory",
    "machine-learning",
    "cryptography",
  ].includes(type);
}

function Arrow({ x1, y1, x2, y2, color, label }: { x1: number; y1: number; x2: number; y2: number; color: string; label: string }) {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const head = 12;
  return (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth="5" strokeLinecap="round" />
      <path d={`M${x2} ${y2} L${x2 - head * Math.cos(angle - 0.45)} ${y2 - head * Math.sin(angle - 0.45)} L${x2 - head * Math.cos(angle + 0.45)} ${y2 - head * Math.sin(angle + 0.45)} Z`} fill={color} />
      <Text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 10} value={label} />
    </g>
  );
}

function Grid() {
  return (
    <g opacity="0.22">
      {Array.from({ length: 13 }, (_, index) => <line key={`v-${index}`} x1={80 + index * 50} y1="50" x2={80 + index * 50} y2="330" stroke="#67e8f9" />)}
      {Array.from({ length: 7 }, (_, index) => <line key={`h-${index}`} x1="80" y1={70 + index * 40} x2="680" y2={70 + index * 40} stroke="#67e8f9" />)}
    </g>
  );
}

function Text({ x, y, value }: { x: number | string; y: number | string; value: string }) {
  return <text x={x} y={y} fill="#f8fafc" fontSize="20" fontWeight="900" textAnchor="middle" dominantBaseline="middle">{value}</text>;
}

function InfoTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-white/5">
      <p className="text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">{label}</p>
      <p className="mt-1 truncate text-sm font-black text-slate-950 dark:text-white">{value}</p>
    </div>
  );
}

function computeResult(formula: FormulaVisualizerEntry, params: FormulaParameters) {
  const { a, b, c, n, p } = params;
  const iteration = Math.max(0, Math.round(n));
  if (formula.id === "sierpinski-retained-count") return 8 ** iteration;
  if (formula.id === "sierpinski-new-removed") return iteration === 0 ? 0 : 8 ** (iteration - 1);
  if (formula.id === "sierpinski-total-removed") return iteration === 0 ? 0 : (8 ** iteration - 1) / 7;
  if (formula.id === "sierpinski-side-scale") return 1 / 3 ** iteration;
  if (formula.id === "sierpinski-small-area") return 1 / 9 ** iteration;
  if (formula.id === "sierpinski-retained-area") return (8 / 9) ** iteration;
  if (formula.id === "sierpinski-removed-area") return 1 - (8 / 9) ** iteration;
  if (formula.id === "solid-top-projection") return Math.abs(a) > 0 ? 1 : 0;
  if (formula.id === "solid-front-projection" || formula.id === "solid-side-projection") return Math.max(Math.abs(a), Math.abs(b), Math.abs(c));
  if (formula.id === "equivalent-ratios") return Math.abs(a * n - b * c) < 1e-9 ? 1 : 0;
  if (formula.id === "cross-multiplication") return a * n - b * c;
  if (formula.id === "missing-fourth-term") return (b * c) / Math.max(0.001, a);
  if (formula.id === "representative-fraction") return Math.max(1, Math.abs(b * 100000) / Math.max(0.001, Math.abs(a)));
  if (formula.id === "actual-distance-map-scale") return Math.abs(a * b) / 100000;
  if (formula.id === "map-distance-actual-scale") return (Math.abs(a) * 100000) / Math.max(1, Math.abs(b));
  if (formula.id === "multi-term-ratio-share") return (Math.abs(a) / Math.max(1, Math.abs(a) + Math.abs(b) + Math.abs(c))) * Math.abs(n);
  if (formula.id === "ratio-to-percentage") return (Math.abs(a) / Math.max(1, Math.abs(a) + Math.abs(b) + Math.abs(c))) * 100;
  if (formula.id === "ratio-to-pie-angle") return (Math.abs(a) / Math.max(1, Math.abs(a) + Math.abs(b) + Math.abs(c))) * 360;
  if (formula.id === "direct-proportion") return a * b;
  if (formula.id === "inverse-proportion") return Math.abs(a * b) / Math.max(0.001, Math.abs(c));
  if (formula.id === "constant-check") return Math.abs(a * b - c * n);
  if (formula.id === "sin-ratio") return Math.sin((Math.max(5, Math.min(85, p)) / 180) * Math.PI);
  if (formula.id === "cos-ratio") return Math.cos((Math.max(5, Math.min(85, p)) / 180) * Math.PI);
  if (formula.id === "tan-ratio") return Math.tan((Math.max(5, Math.min(85, p)) / 180) * Math.PI);
  if (formula.id === "pythagorean-identity") {
    const angle = (Math.max(5, Math.min(85, p)) / 180) * Math.PI;
    return Math.sin(angle) ** 2 + Math.cos(angle) ** 2;
  }
  if (formula.id === "tan-identity") {
    const angle = (Math.max(5, Math.min(85, p)) / 180) * Math.PI;
    return Math.sin(angle) / Math.max(0.001, Math.cos(angle));
  }
  if (formula.id === "sine-rule") return Math.abs(a) / Math.max(0.001, Math.sin((Math.max(5, Math.min(85, p)) / 180) * Math.PI));
  if (formula.id === "cosine-rule") return Math.sqrt(Math.max(0, a ** 2 + b ** 2 - 2 * a * b * Math.cos((Math.max(5, Math.min(85, p)) / 180) * Math.PI)));
  if (formula.id === "angle-sum-sine") {
    const firstAngle = (Math.max(5, Math.min(85, p)) / 180) * Math.PI;
    const secondAngle = (Math.max(5, Math.min(85, Math.abs(a) * 10)) / 180) * Math.PI;
    return Math.sin(firstAngle + secondAngle);
  }
  switch (formula.visualizerType) {
    case "area":
      return formula.id.includes("difference") ? a * a - b * b : (a + b) ** 2;
    case "geometry":
      return formula.id.includes("circle") || formula.id.includes("sector") || formula.id.includes("arc") ? Math.PI * Math.abs(a) * Math.abs(a) * (p / 100 || 1) : Math.abs(a * b) / 2;
    case "coordinate":
      return Math.sqrt((a - c) ** 2 + (b - n / 2) ** 2);
    case "calculus":
      return 2 * a + b;
    case "matrix":
      return a * (n / 2) - b * c;
    case "vector":
      return a * c + b * (n / 2);
    case "probability":
      return Math.max(0, Math.min(1, p / 100));
    case "statistics": {
      const values = [a, b, c, n / 2, p / 10];
      return values.reduce((sum, value) => sum + value, 0) / values.length;
    }
    case "mensuration":
      return formula.id.includes("volume") ? Math.abs(a * b * Math.max(1, c)) : Math.abs(a * b);
    case "number-system": {
      const n = Math.max(1, Math.round(Math.abs(params.n)));
      const a = Math.round(params.a);
      const b = Math.max(1, Math.round(Math.abs(params.b)));
      if (formula.id === "prime-factorization" || formula.id === "divisibility-9") return n;
      if (formula.id === "lcm") return (Math.abs(a) * b) / gcdInt(a, b);
      if (formula.id === "euclid-division") return a % b;
      if (formula.id === "decimal-terminating") {
        let remaining = n;
        while (remaining % 2 === 0) remaining /= 2;
        while (remaining % 5 === 0) remaining /= 5;
        return remaining === 1 ? 1 : 0;
      }
      if (formula.id === "rational-form") return a / b;
      if (formula.id === "irrational-root") return Math.sqrt(n);
      return gcdInt(a, b);
    }
    case "complex":
      return Math.sqrt(a ** 2 + b ** 2);
    case "sequence":
      return a + (Math.max(1, Math.round(n)) - 1) * b;
    case "combinatorics":
      return comb(Math.max(1, Math.round(n)), Math.max(0, Math.min(Math.round(n), Math.round(Math.abs(b)))));
    case "set-logic":
      return p > 50 || b >= 0 ? 1 : 0;
    case "function":
    case "polynomial":
      return a * b + c;
    case "linear-programming":
      return a * 2 + b * 3;
    case "inequality":
      return c - b;
    case "distribution":
      return Math.max(0, Math.min(1, p / 100));
    case "limits-continuity":
    case "real-analysis":
      return Math.sin(a) + b / 4;
    case "differential-equations":
      return Math.max(0, Math.abs(c) * Math.exp(a / 6));
    case "determinant":
      return a * n - b * c;
    case "three-d-geometry":
    case "differential-geometry":
      return Math.sqrt(a ** 2 + b ** 2 + c ** 2);
    case "early-number-sense":
      return Math.max(1, Math.round(Math.abs(a * 10 + b)));
    case "fraction-percent":
      return Math.max(1, Math.round(Math.abs(a))) / Math.max(2, Math.round(n));
    case "commercial-math":
      return Math.max(20, Math.abs(n * 20)) * (1 - p / 100) * (1 + Math.max(0, b) / 100);
    case "speed-work":
      return Math.abs(a * n) / Math.max(1, Math.abs(b));
    case "mental-math":
      return formula.id.includes("square") ? (Math.round(Math.abs(n)) * 10 + 5) ** 2 : Math.round(Math.abs(a * b * 10));
    case "pre-algebra":
      return a * b + c;
    case "number-theory":
    case "cryptography":
      return ((Math.round(a * b) % Math.max(5, Math.round(n))) + Math.max(5, Math.round(n))) % Math.max(5, Math.round(n));
    case "euclidean-geometry":
      return Math.abs(a * b) / 2;
    case "analytic-geometry":
    case "precalculus":
      return Math.max(0.2, Math.min(1.8, Math.abs(a) / 4));
    case "calculus-applications":
    case "optimization":
    case "numerical-methods":
      return (a - b) ** 2 + c;
    case "multivariable-calculus":
      return Math.sqrt(a ** 2 + b ** 2);
    case "advanced-linear-algebra":
      return Math.abs(a * n - b * c);
    case "abstract-algebra":
      return Math.max(3, Math.min(7, Math.round(Math.abs(n / 2))));
    case "complex-analysis":
      return Math.sqrt(a ** 2 + b ** 2);
    case "topology":
      return p / 100;
    case "discrete-math":
      return p > 50 || b >= 0 ? 1 : 0;
    case "dynamical-systems": {
      const r = Math.max(1, Math.min(4, Math.abs(a) / 2 + 2));
      return r * (p / 100) * (1 - p / 100);
    }
    case "pde":
      return Math.exp(-p / 60) * Math.abs(a + b);
    case "transforms":
      return Math.abs(a) + Math.abs(b) / 2;
    case "mathematical-physics":
      return Math.abs(a * n + 0.5 * b * b);
    case "information-theory": {
      const q = Math.max(0.01, Math.min(0.99, p / 100));
      return -(q * Math.log2(q) + (1 - q) * Math.log2(1 - q));
    }
    case "machine-learning":
      return Math.max(0, (a - b) ** 2 + Math.abs(c));
    default:
      return a * 0.6 + b - c;
  }
}

function buildSubstitution(formula: FormulaVisualizerEntry, params: FormulaParameters) {
  if (formula.visualizerType === "number-system" && formula.id === "prime-factorization") {
    const n = Math.max(1, Math.round(Math.abs(params.n)));
    return `n=${n} factors as ${factorLabel(n)}.`;
  }
  const values = getFormulaControlSpecs(formula)
    .map((control) => `${control.label}=${formatNumber(params[control.key])}${control.unit ?? ""}`)
    .join(", ");
  return `${values} gives ${formula.title} ≈ ${formatNumber(computeResult(formula, params))}.`;
}

function getWarning(formula: FormulaVisualizerEntry, params: FormulaParameters) {
  if (formula.visualizerType === "matrix" && Math.abs(computeResult(formula, params)) < 0.2) return "The determinant is near zero, so inverse calculations are unstable or unavailable.";
  if (formula.visualizerType === "probability" && (params.p <= 0 || params.p >= 100)) return "A probability at 0% or 100% is an edge case. Compare it with a middle value.";
  if (formula.visualizerType === "mensuration" && (params.a <= 0 || params.b <= 0)) return "Real dimensions should be positive. The visual uses absolute size but the sign is a warning.";
  if (formula.visualizerType === "sequence" && formula.id.includes("infinite") && Math.abs(params.b) >= 1) return "Infinite GP formulas need |r| < 1. Use b as the ratio and keep it between -1 and 1.";
  if (formula.visualizerType === "complex" && params.a === 0 && params.b === 0) return "The argument of 0 + 0i is undefined because the point has no direction.";
  if (formula.visualizerType === "linear-programming" && params.a < 0) return "Negative coefficients can change the best corner. Check all vertices, not only the visible high point.";
  if (formula.visualizerType === "determinant" && Math.abs(computeResult(formula, params)) < 0.5) return "The determinant is close to zero, so the matrix is near singular.";
  if (formula.visualizerType === "cryptography") return "Toy cryptography demos are for learning modular arithmetic only; they are not secure implementations.";
  if (formula.visualizerType === "fraction-percent" && params.n <= 1) return "Fractions need a denominator greater than 1. The visual clamps the denominator for safety.";
  if (formula.visualizerType === "limits-continuity" && Math.abs(params.a) < 0.2) return "Near the approach point, compare left and right behavior before deciding continuity.";
  return "";
}

function makeCurvePoints(formula: FormulaVisualizerEntry, params: FormulaParameters) {
  return Array.from({ length: 100 }, (_, index) => {
    const x = -5 + (index / 99) * 10;
    let y = params.a * x + params.b;
    if (formula.id.includes("quadratic") || formula.visualizerType === "calculus") y = 0.2 * params.a * x * x + params.b * x + params.c;
    if (formula.id.includes("gp") || formula.id.includes("exponent")) y = params.a * Math.pow(Math.max(0.2, Math.abs(params.b) / 2), x / 2);
    if (formula.id.includes("sin") || formula.id.includes("cos")) y = Math.sin(x + params.a) * 4;
    const sx = 380 + x * 48;
    const sy = Math.max(50, Math.min(330, 190 - y * 16));
    return `${sx},${sy}`;
  }).join(" ");
}

function makeBars(params: FormulaParameters) {
  const count = Math.max(2, Math.min(18, Math.round(params.n)));
  const width = 460 / count;
  return Array.from({ length: count }, (_, index) => {
    const x = 150 + index * width;
    const h = Math.max(16, Math.min(180, 36 + Math.abs(Math.sin(index + params.a)) * 120));
    return { x, y: 190 - h, w: width - 3, h };
  });
}

function formatNumber(value: number) {
  if (!Number.isFinite(value)) return "undefined";
  return Number(value.toFixed(2)).toString();
}

function gcdInt(a: number, b: number): number {
  let x = Math.max(1, Math.abs(Math.round(a)));
  let y = Math.max(1, Math.abs(Math.round(b)));
  while (y) {
    const next = x % y;
    x = y;
    y = next;
  }
  return x;
}

function comb(n: number, r: number): number {
  const total = Math.max(0, Math.round(n));
  const choose = Math.max(0, Math.min(total, Math.round(r)));
  let result = 1;
  for (let index = 1; index <= choose; index += 1) {
    result = (result * (total - choose + index)) / index;
  }
  return Math.round(result);
}

export { formulaVisualizerConfigs };
