import { type MouseEvent, useMemo, useState, type ReactNode } from "react";
import { Plus, Trash2 } from "lucide-react";
import DualPaneMathLayout from "../components/ui/DualPaneMathLayout";
import SliderControl, { SliderGroup } from "../components/ui/SliderControl";
import { compileTwoVariableExpression } from "../utils/functionParser";
import { roundTo } from "../utils/math";

type Point = { x: number; y: number; defined: boolean };

const presets = ["x", "y", "x + y", "x - y", "y * (1 - y)", "sin(x)", "x * y", "-x / y", "y - x^2", "cos(x) - y"];
const colors = ["#ef4444", "#f59e0b", "#8b5cf6", "#10b981", "#ec4899"];

export default function SlopeFieldsVisualizerPage() {
  const [expression, setExpression] = useState("x - y");
  const [draft, setDraft] = useState("x - y");
  const [x0, setX0] = useState(0);
  const [y0, setY0] = useState(1);
  const [stepSize, setStepSize] = useState(0.08);
  const [steps, setSteps] = useState(120);
  const [initials, setInitials] = useState<Point[]>([{ x: 0, y: 1, defined: true }]);

  const compiled = useMemo(() => {
    try {
      return { fn: compileTwoVariableExpression(expression), error: "" };
    } catch (error) {
      return { fn: null, error: error instanceof Error ? error.message : "Invalid differential equation" };
    }
  }, [expression]);

  const slopeField = useMemo(() => compiled.fn ? buildSlopeField(compiled.fn) : [], [compiled.fn]);
  const curves = useMemo(() => compiled.fn ? initials.map((start) => ({
    start,
    forward: solveRK4(compiled.fn!, start, stepSize, steps, 1),
    backward: solveRK4(compiled.fn!, start, stepSize, steps, -1),
  })) : [], [compiled.fn, initials, stepSize, steps]);
  const currentSlope = compiled.fn ? safeSlope(compiled.fn, x0, y0) : NaN;

  const addInitial = () => {
    setInitials((items) => [...items.slice(0, 4), { x: x0, y: y0, defined: true }]);
  };

  const handleGraphClick = (point: { x: number; y: number }) => {
    const next = { x: roundTo(point.x, 2), y: roundTo(point.y, 2), defined: true };
    setX0(next.x);
    setY0(next.y);
    setInitials((items) => items.length ? [next, ...items.slice(1)] : [next]);
  };

  return (
    <DualPaneMathLayout
      title="Differential Equation Slope Fields"
      subtitle="Visualize dy/dx = f(x,y), inspect local slopes, and trace RK4 solution curves from initial conditions."
      meta={
        <>
          <span className="rounded-full bg-cyan-100 px-3 py-2 text-xs font-black text-cyan-800 dark:bg-cyan-400/15 dark:text-cyan-200">Differential Equations</span>
          <span className="rounded-full bg-violet-100 px-3 py-2 text-xs font-black text-violet-800 dark:bg-violet-400/15 dark:text-violet-200">24 min</span>
        </>
      }
      controls={
        <div className="space-y-4">
          <label className="block">
            <span className="text-sm font-bold">dy/dx =</span>
            <div className="mt-2 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto] xl:grid-cols-1">
              <input value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") setExpression(draft); }} className="min-h-11 w-full rounded-2xl border border-slate-200 bg-white px-4 font-mono text-sm outline-none focus:border-cyan-400 dark:border-white/10 dark:bg-slate-950" />
              <button type="button" className="action-primary px-4" onClick={() => setExpression(draft)}>Plot</button>
            </div>
            {compiled.error && <p className="mt-2 rounded-xl bg-rose-50 p-3 text-sm font-semibold text-rose-700 dark:bg-rose-400/10 dark:text-rose-200">{compiled.error}</p>}
          </label>
          <SliderGroup title="Solution controls">
            <SliderControl density="compact" label="initial x0" value={x0} min={-5} max={5} step={0.05} onChange={setX0} />
            <SliderControl density="compact" label="initial y0" value={y0} min={-5} max={5} step={0.05} onChange={setY0} />
            <SliderControl density="compact" label="step size h" value={stepSize} min={0.02} max={0.25} step={0.01} onChange={setStepSize} />
            <SliderControl density="compact" label="steps" value={steps} min={20} max={260} step={5} onChange={setSteps} />
          </SliderGroup>
          <div className="grid grid-cols-2 gap-2">
            <Metric label="current slope" value={Number.isFinite(currentSlope) ? roundTo(currentSlope, 4).toString() : "undefined"} />
            <Metric label="solutions" value={`${initials.length} / 5`} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" className="action-primary justify-center" onClick={addInitial}><Plus className="h-4 w-4" />Add</button>
            <button type="button" className="action-secondary justify-center" onClick={() => setInitials([])}><Trash2 className="h-4 w-4" />Clear</button>
          </div>
        </div>
      }
      panes={[
        {
          id: "2d",
          label: "2D graph",
          title: "2D Slope Field Pane",
          description: "Click the graph to set a new initial condition. Curves solve forward and backward from each start point.",
          content: <SlopeGraph field={slopeField} curves={curves} onPick={handleGraphClick} />,
        },
        {
          id: "3d",
          label: "3D pane",
          title: "3D Direction Surface Pane",
          description: "Slope segments lift into depth so local direction and solution flow are easier to compare.",
          content: <SlopeDepthPane field={slopeField} curves={curves} />,
        },
      ]}
      insights={
        <div className="space-y-4">
          <div className="space-y-3 text-sm leading-6 text-slate-600 dark:text-slate-300">
            <p>At every point <strong>(x,y)</strong>, the differential equation gives a slope.</p>
            <p>The small line segment shows the direction a solution would move through that point.</p>
            <p>A solution curve follows the local slope everywhere. The initial condition selects one curve from the family.</p>
            <p>RK4 samples several slopes inside each step, so the curve is smoother than basic Euler stepping.</p>
          </div>
          <div className="grid grid-cols-1 gap-2">
            {presets.map((preset) => (
              <button key={preset} type="button" onClick={() => { setDraft(preset); setExpression(preset); }} className="cinematic-preset-button px-3 py-2 text-left font-mono text-xs">
                dy/dx = {preset}
              </button>
            ))}
          </div>
        </div>
      }
      theory={
        <div className="grid gap-4 lg:grid-cols-3">
          <TheoryPanel title="Core Idea">
            A first-order differential equation dy/dx = f(x,y) does not directly give y. It gives the slope a solution should have at each point.
          </TheoryPanel>
          <TheoryPanel title="Initial Conditions">
            Each starting point selects one curve from the family of possible solutions. Nearby starts can follow similar or very different paths depending on the field.
            <div className="mt-3 rounded-xl bg-slate-100 p-3 font-mono text-xs font-bold dark:bg-slate-950">dy/dx = f(x,y), y(x0)=y0</div>
          </TheoryPanel>
          <TheoryPanel title="How To Read This Tool">
            Click the plane or adjust x0 and y0 to set an initial condition. The small segments show local direction; the colored curve follows those directions.
          </TheoryPanel>
        </div>
      }
    />
  );
}

function TheoryPanel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white/75 p-4 text-sm leading-6 text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
      <h2 className="text-base font-black text-slate-950 dark:text-white">{title}</h2>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function SlopeGraph({ field, curves, onPick }: { field: { x: number; y: number; slope: number }[]; curves: { start: Point; forward: Point[]; backward: Point[] }[]; onPick: (point: { x: number; y: number }) => void }) {
  const width = 760, height = 520, pad = 44, min = -6, max = 6;
  const sx = (x: number) => pad + ((x - min) / (max - min)) * (width - pad * 2);
  const sy = (y: number) => height - pad - ((y - min) / (max - min)) * (height - pad * 2);
  const handleClick = (event: MouseEvent<SVGSVGElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = min + (((event.clientX - rect.left) / rect.width) * width - pad) / (width - pad * 2) * (max - min);
    const y = min + (height - pad - ((event.clientY - rect.top) / rect.height) * height) / (height - pad * 2) * (max - min);
    onPick({ x, y });
  };
  return (
    <svg viewBox="0 0 760 520" onClick={handleClick} className="h-[360px] w-full cursor-crosshair rounded-2xl bg-slate-50 dark:bg-slate-950 sm:h-[520px]">
      {grid(width, height, pad)}
      <line x1={sx(0)} x2={sx(0)} y1={pad} y2={height - pad} stroke="#0f172a" strokeWidth="2" />
      <line x1={pad} x2={width - pad} y1={sy(0)} y2={sy(0)} stroke="#0f172a" strokeWidth="2" />
      {field.map((p, i) => {
        const angle = Math.atan(p.slope);
        const len = 18;
        return <line key={i} x1={sx(p.x) - Math.cos(angle) * len / 2} y1={sy(p.y) + Math.sin(angle) * len / 2} x2={sx(p.x) + Math.cos(angle) * len / 2} y2={sy(p.y) - Math.sin(angle) * len / 2} stroke="#0891b2" strokeWidth="3" strokeLinecap="round" opacity="0.78" />;
      })}
      {curves.map((curve, i) => <g key={i}><path d={path([...curve.backward].reverse(), sx, sy)} fill="none" stroke={colors[i % colors.length]} strokeWidth="4" /><path d={path(curve.forward, sx, sy)} fill="none" stroke={colors[i % colors.length]} strokeWidth="4" /><circle cx={sx(curve.start.x)} cy={sy(curve.start.y)} r="8" fill={colors[i % colors.length]} stroke="#0f172a" strokeWidth="2" /></g>)}
    </svg>
  );
}

function SlopeDepthPane({ field, curves }: { field: { x: number; y: number; slope: number }[]; curves: { start: Point; forward: Point[]; backward: Point[] }[] }) {
  const project = (x: number, y: number, z: number) => ({
    x: 380 + x * 34 + z * 18,
    y: 245 - y * 24 - z * 16,
  });
  const sparseField = field.filter((_, index) => index % 2 === 0);
  const path3d = (points: Point[]) => points.filter((point) => point.defined).map((point, index) => {
    const projected = project(point.x, point.y, Math.sin(point.x * 0.6) * 0.4);
    return `${index ? "L" : "M"}${projected.x},${projected.y}`;
  }).join(" ");

  return (
    <svg viewBox="0 0 760 460" className="cinematic-svg-stage sm:h-[460px]">
      <defs>
        <linearGradient id="slope-depth-bg" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0%" stopColor="#082f49" />
          <stop offset="60%" stopColor="#0f172a" />
          <stop offset="100%" stopColor="#020617" />
        </linearGradient>
      </defs>
      <rect width="760" height="460" fill="url(#slope-depth-bg)" />
      <polygon points="116,350 590,350 660,292 186,292" fill="#0f766e" opacity="0.2" stroke="#67e8f9" strokeWidth="2" />
      {sparseField.map((point, index) => {
        const start = project(point.x, point.y, -0.25);
        const end = project(point.x + 0.22, point.y + Math.max(-1, Math.min(1, point.slope)) * 0.22, 0.25);
        return <line key={index} x1={start.x} y1={start.y} x2={end.x} y2={end.y} stroke="#67e8f9" strokeWidth="3" strokeLinecap="round" opacity="0.65" />;
      })}
      {curves.map((curve, index) => (
        <g key={index}>
          <path d={path3d([...curve.backward].reverse())} fill="none" stroke={colors[index % colors.length]} strokeWidth="5" />
          <path d={path3d(curve.forward)} fill="none" stroke={colors[index % colors.length]} strokeWidth="5" />
        </g>
      ))}
      <text x="82" y="82" fill="#f8fafc" fontSize="30" fontWeight="900">3D direction field</text>
      <text x="84" y="118" fill="#bae6fd" fontSize="16" fontWeight="700">Local slope arrows are lifted into depth to reveal solution flow.</text>
      <text x="84" y="404" fill="#f8fafc" fontSize="18" fontWeight="900">solution curves: {curves.length}</text>
    </svg>
  );
}

function buildSlopeField(fn: (x: number, y: number) => number) {
  const points = [];
  for (let x = -5; x <= 5; x += 0.8) {
    for (let y = -5; y <= 5; y += 0.8) {
      const slope = safeSlope(fn, x, y);
      if (Number.isFinite(slope)) points.push({ x, y, slope: Math.max(-8, Math.min(8, slope)) });
    }
  }
  return points;
}

function solveRK4(fn: (x: number, y: number) => number, start: Point, h: number, steps: number, direction: 1 | -1) {
  const result = [start];
  let x = start.x, y = start.y;
  const step = h * direction;
  for (let i = 0; i < steps; i += 1) {
    const k1 = safeSlope(fn, x, y);
    const k2 = safeSlope(fn, x + step / 2, y + step * k1 / 2);
    const k3 = safeSlope(fn, x + step / 2, y + step * k2 / 2);
    const k4 = safeSlope(fn, x + step, y + step * k3);
    if (![k1, k2, k3, k4].every(Number.isFinite)) break;
    y += (step / 6) * (k1 + 2 * k2 + 2 * k3 + k4);
    x += step;
    if (!Number.isFinite(y) || Math.abs(y) > 50 || x < -7 || x > 7) break;
    result.push({ x, y, defined: true });
  }
  return result;
}

function safeSlope(fn: (x: number, y: number) => number, x: number, y: number) {
  try {
    const slope = fn(x, y);
    return Number.isFinite(slope) ? slope : NaN;
  } catch {
    return NaN;
  }
}

function path(points: Point[], sx: (x: number) => number, sy: (y: number) => number) {
  return points.filter((p) => p.defined).map((p, i) => `${i ? "L" : "M"}${sx(p.x)},${sy(p.y)}`).join(" ");
}

function grid(width: number, height: number, pad: number) {
  return <g>{Array.from({ length: 13 }).map((_, i) => <line key={`v-${i}`} x1={pad + i * (width - pad * 2) / 12} x2={pad + i * (width - pad * 2) / 12} y1={pad} y2={height - pad} stroke="#cbd5e1" opacity="0.65" />)}{Array.from({ length: 13 }).map((_, i) => <line key={`h-${i}`} x1={pad} x2={width - pad} y1={pad + i * (height - pad * 2) / 12} y2={pad + i * (height - pad * 2) / 12} stroke="#cbd5e1" opacity="0.65" />)}</g>;
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl bg-slate-100 p-3 dark:bg-white/10"><p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{label}</p><p className="mt-1 break-words font-mono text-sm font-bold">{value}</p></div>;
}
