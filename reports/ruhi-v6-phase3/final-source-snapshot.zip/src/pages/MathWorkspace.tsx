import {CinematicThreePreview} from '../math-robo/animation/CinematicThreePreview';
import {cinematicPreview} from '../math-robo/animation/RuhiCinematicMotionEngine';
import {registerRoboUnprojector,registerRoboSpatialProvider,readSVGSpatialObjects} from '../math-robo/character/spatialAwareness';
import {useRoboThreeAwareness} from '../math-robo/character/useRoboThreeAwareness';
import {registerRoboProjector,svgClientPoint} from '../math-robo/character/workspaceAdapter';
import {roboEvents} from '../math-robo/character/engine';
import { ImmersiveBoundary, useImmersiveAdapter } from "../workspace/immersive/ImmersiveInteractionManager";
import { identityTransform, screenTarget, transformDelta } from "../workspace/immersive/types";
import WorkspaceChromeThemeToggle from "../components/workspace/WorkspaceChromeThemeToggle";
import { readWorkspaceChromeTheme, type WorkspaceChromeTheme } from "../workspace/workspaceChromeTheme";
import { GeometryAppearanceControls, type GeometryPaint } from "../components/workspace/GeometryAppearance";
import { OrbitControls } from "@react-three/drei";
import { type ThreeEvent, useFrame, useThree } from "@react-three/fiber";
import { AlertTriangle, Box, Braces, Camera, Check, CheckCircle2, ChevronDown, Circle, CircleDot, Copy, Download, Eraser, Eye, EyeOff, FileText, Filter, FunctionSquare, Grid3X3, Home, Info, Keyboard, LineChart, ListTree, Magnet, Maximize2, Menu, Mic, MoreHorizontal, MousePointer2, Move, Orbit, PanelLeftClose, PanelLeftOpen, PanelRightClose, PanelRightOpen, Pentagon, Pin, Play, Plus, Presentation, Redo2, Rotate3D, RotateCcw, Ruler, Save, Search, Settings, Share2, Sigma, Slash, SlidersHorizontal, Sparkles, Table2, Trash2, Undo2, User, WandSparkles, X, ZoomIn, ZoomOut, type LucideIcon } from "lucide-react";
import { KeyboardEvent, MouseEvent as ReactMouseEvent, PointerEvent, WheelEvent, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import * as THREE from "three";
import { casCommandRegistrySummary, searchCasCommands } from "../cas/casCommandRegistry";
import { geogebraCasParitySummary } from "../cas/casGeoGebraParity";
import {
  casNotebookExamples,
  createNotebookCell,
  evaluateNotebookCellInState,
  evaluateNotebookCells,
  operationOptions,
  serializeCasNotebookMarkdown,
  starterNotebookCells,
  type EvaluationMode,
  type NotebookCell,
  type NotebookOperation,
  type NotebookState,
} from "../cas/casNotebookEngine";
import { readCasNotebookState, saveCasNotebookState } from "../cas/casNotebookPersistence";
import ThreeSceneWrapper from "../components/three/ThreeSceneWrapper";
import VectorWorkbench3D from "../components/workspace/VectorWorkbench3D";
import MathKeyboardInput from "../components/math-keyboard/MathKeyboardInput";
import GeometryWorkspacePanel, { MAX_GEOMETRY_CAMERA_HEIGHT, MAX_GEOMETRY_CAMERA_WIDTH, type GeometryCamera, type GeometryGraphSettings } from "../components/workspace/panels/GeometryWorkspacePanel";
import GraphWorkspacePanel, { type PlotItem, type PlotKind, type ResultTableRow } from "../components/workspace/panels/GraphWorkspacePanel";
import InspectorPanel from "../components/workspace/InspectorPanel";
import ObjectList, { type ObjectListAction } from "../components/workspace/ObjectList";
import SectionCard from "../components/ui/SectionCard";
import SliderControl from "../components/ui/SliderControl";
import TopicHeader from "../components/ui/TopicHeader";
import MathExpression from "../components/ui/MathExpression";
import { affineConstraintPoint } from "../workspace/geometryAffineConstraint";
import FunctionGraphCanvas, { type FunctionGraphSeries, type FunctionGraphView } from "../components/math-lab/FunctionGraphCanvas";
import { approximateRoots, sampleFunction } from "../utils/mathEngine/graphSampler";
import { roundTo } from "../utils/math";
import { symbolicDerivative, symbolicExpand, symbolicFactor, symbolicIntegral, symbolicLimit, symbolicPartialFractions, symbolicPolynomialDivide, symbolicSimplify, symbolicSolve, symbolicSubstitute, symbolicSystemSolve, trySymbolic } from "../utils/symbolic";
import { commandExamplesFor, commandRegistrySummary, normalizeCommandName, resolveCommandSpec } from "../workspace/commandRegistry";
import { useIntelligenceWorkspace,isKnownRoboObject } from '../offline-intelligence/workspaceBridge';
import { addIntelligenceGeometry, nativeGeometryCommands } from '../offline-intelligence/geometryAdapter';
import { commandTransform3d } from '../offline-intelligence/solidAdapter';
import {outlineVertices} from '../offline-intelligence/commands';
import type { VisualCommand } from '../offline-intelligence/commands';
import DirectedObject3D from '../offline-intelligence/DirectedObject3D';
import { createIntelligenceShapeGeometry, intelligenceMeshMeasurement } from '../offline-intelligence/shapeGeometry3d';
import { validateGraphExpression, isGraphValidationBlocking } from "../workspace/graphValidation";
import { createAnimationAction, describeTransformAction, parseStyleAction, parseTransformCommand } from "../workspace/actionCommandKernel";
import { assessConstruction, commandDocsForPackages, objectAwareTutorResponse, productionReadinessPlan, validateGuidedTaskResponse, type UnitLabPackage } from "../workspace/beyondGeoGebraKernel";
import { createDefaultLesson, lessonStepKinds, lessonSummary, type ClassroomLesson, type LessonStep } from "../workspace/classroomAuthoring";
import { criticalGapImplementationPhases } from "../workspace/criticalGapPhases";
import { createMathObject } from "../workspace/coreObjects";
import { buildDynamicObjectGraph, graphHealthSummary, type DynamicObjectGraph, type DynamicObjectKind } from "../workspace/dynamicObjectKernel";
import { generateValueTable, inferPlotKind, regressionModel, stripInequality, type RegressionModel } from "../components/workspace/panels/graphPanelUtils";
import { contextMenuForObject, type ExportPreset, type ImageWorkflowSpec, type ProtocolPlaybackPlan, type SliderObject, type SnapCandidate, type StyleBarControl, type TabletControlSpec, type WorkflowObjectType } from "../workspace/highPriorityWorkflowKernel";
import { DEFAULT_TRACE_MAX_SAMPLES, appendTraceSample, nextTraceLabel, seedTraceSamples, traceDefinition } from "../workspace/locusTraceKernel";
import { applyObjectProperties, evaluateObjectProperties } from "../workspace/objectProperties";
import { certifyGeometryConstruction } from "../workspace/geometryConstructionCertification";
import {
  circle as kernelCircle,
  distanceBetween as kernelDistance,
  intersectObjects as kernelIntersectObjects,
  line as kernelLine,
  parseConicEquation,
  parseKernelPoint,
  point as kernelPoint,
  proofHintsForRelation,
  ray as kernelRay,
  relationBetween,
  segment as kernelSegment,
  vector as kernelVector,
  type KernelObject,
  type KernelPoint,
} from "../workspace/geometry2dKernel";
import {
  cone3 as kernelCone3,
  createTransformGizmo,
  cylinder3 as kernelCylinder3,
  intersect3,
  line3 as kernelLine3,
  object3Measurement,
  parsePlaneEquation,
  parsePoint3,
  parseVector3,
  plane3 as kernelPlane3,
  point3 as kernelPoint3,
  sphere3 as kernelSphere3,
  type Object3,
  type Point3,
  type TransformMode3,
} from "../workspace/geometry3dKernel";
import { createCasCard, createDynamicTable, createListObject } from "../workspace/casTableKernel";
import { clearOfflineProjectLibrary, readOfflineProjectLibrary, removeOfflineProject, saveOfflineProject, type OfflineProjectEntry } from "../workspace/offlineProjectLibrary";
import { computePracticeReport, evaluatePracticeResponse, isAssessableStep, practiceReportText, practiceStatusLabel, type PracticeResponse } from "../workspace/practiceAssessment";
import { evaluateSpreadsheetGrid, fillDownFormula, rangeToCsv } from "../workspace/spreadsheetKernel";
import { syllabusWorkspaceTemplates, type GuidedActivityPhase, type SyllabusWorkspaceTemplate } from "../workspace/syllabusWorkspaceTemplates";
import type { MathObject, MathObjectKind, MathObjectProperties, MathObjectStyle, MathTransform } from "../workspace/types";
import { useWorkspaceStore } from "../workspace/workspaceStore";
import { browserSpeechRecognitionConstructor, isBrowserSpeechInputSupported, normalizeSpokenMath, type BrowserSpeechRecognition, type SpeechInputState } from "../workspace/browserSpeechInput";
import ObjectStudioWorkspace, { type ObjectStudioItem, type ObjectStudioShape, type ObjectStudioTool } from "../graph-studio/ObjectStudioWorkspace";
import { createUnsupportedWorkspaceAction } from "../workspace/unsupportedWorkspaceAction";
import { workspaceModeNavigation } from "../workspace/workspaceModeConfig";
import { vectorMagnitude3, vectorWorkbenchResult, type Vector3Tuple, type VectorView3D } from "../workspace/vectorWorkbench3d";
import { createMathWorkspacePayload, type MathWorkspacePayload } from "../workspace/mathWorkspaces";
import { readLinkedParameters, saveLinkedParameter } from "../workspace/linkedParameters";
import { readWorkspaceTransfer, saveWorkspaceTransfer } from "../workspace/workspaceTransfer";
import CasSpreadsheetStudio from "../components/workspace/CasSpreadsheetStudio";
import ShareExportControl from "../components/workspace/ShareExportControl";
import {
  LESSON_EXTENSION,
  WORKSPACE_EXTENSION,
  parsePortableMathFile,
  sceneForLessonMode,
  type PortableWorkspaceAdapter,
  type PortableWorkspaceType,
} from "../workspace/portableWorkspace";
import {
  createGeometryTransformRequest,
  createdGeometryFromDelta,
  createNoSelectionDeleteAction,
  deleteGeometryObjectFromConstruction,
  deleteGeometrySelection,
  geometryObjectBySelection,
  geometryObjectForPointIds,
  patchGeometryObject,
  pointById,
  pointIdsForObject,
  type Construction,
  type GeoConstraint,
  type GeoLocus,
  type GeoPoint,
  type GeoStyle,
  type GeometryObjectType,
  type GeometryTransformMode,
  type SelectedGeometryObject,
} from "../workspace/geometryCommandController";
import {
  buildAngleFromPoints,
  buildCircleFromPoints,
  buildCircleThroughThreePoints,
  buildLineFromPoints,
  buildPointCreation,
  buildPolygonCompletion,
  buildPolygonDraftUpdate,
  buildTriangleCompletion,
  type GeometryLineTool,
} from "../workspace/geometryConstructionBuilder";
import {
  buildCompassCopyConstruction,
  buildDilateTransformPayload,
  buildFixedLengthSegmentConstruction,
  buildIntersectionConstruction,
  buildMidpointConstruction,
  buildMirrorTransformPayload,
  buildParallelConstruction,
  buildParallelPerpendicularFromPoints,
  buildPerpendicularConstruction,
  buildPointOnCircleConstraint,
  buildRegularPolygonConstruction,
  buildRotateTransformPayload,
  buildSelectedPointsTransform,
  buildTranslateTransformPayload,
} from "../workspace/geometryAdvancedConstructionBuilder";

type ResultCard = { id: string; input: string; interpretation: string; result: string; detail?: string; steps?: string[]; table?: ResultTableRow[]; related?: string[]; graphExpression?: string };
type SpreadsheetCellGrid = string[][];
type GeometryTool = "select" | "point" | "segment" | "ray" | "vector" | "line" | "circle" | "polygon" | "angle" | "parallel" | "perpendicular" | "midpoint" | "fixed-length" | "circle-radius" | "circle-3-points" | "on-circle" | "intersect" | "perpendicular-bisector" | "angle-bisector" | "tangent" | "polar" | "locus" | "regular-polygon" | "sector" | "arc" | "compass" | "mirror" | "rotate" | "dilate" | "translate" | "show-hide" | "lock" | "freehand" | "text" | "image" | "move-canvas" | "zoom" | "triangle" | "rectangle" | "square" | "pentagon-shape" | "hexagon" | "parallelogram" | "trapezoid" | "rhombus" | "kite" | "shape-circle" | "semicircle" | "parabola" | "ellipse" | "hyperbola" | "reflect" | "trace" | "stop-trace" | "clear-trace" | "delete" | "redo" | "reset" | "save" | "load";
type GeoLine = { id: string; a: string; b: string; kind?: 'line'|'segment'|'ray'|'vector'; style?: GeoStyle };
type GeoCircle = { id: string; center: string; edge: string; style?: GeoStyle };
type GeoPolygon = { id: string; points: string[]; style?: GeoStyle };
type WorkspaceImage = { id: string; name: string; src: string; x: number; y: number; width: number; height: number; opacity: number; locked?: boolean; visible?: boolean };
type SurfaceKind = "paraboloid" | "saddle" | "wave" | "plane" | "ripple" | "cone-surface" | "custom-z" | "parametric" | "implicit";
type SolidKind = "cube" | "cuboid" | "sphere" | "ellipsoid" | "hemisphere" | "cylinder" | "cone" | "frustum" | "torus" | "tube" | "capsule" | "prism" | "pyramid" | "tetrahedron" | "octahedron" | "dodecahedron" | "wedge" | "polyhedron";
type ThreeObjectId = "surface" | "solid" | "slice" | "point" | "vector" | "line3d" | "plane3d" | "sphere3d" | "cone3d" | "cylinder3d" | "prism3d" | "pyramid3d" | "polyhedron3d";
type Transform3D = GeometryPaint & { position: [number, number, number]; rotation: [number, number, number]; scale: number; visible: boolean; color: string; name?: string; locked?: boolean; trace?: boolean; dimensions?: [number, number, number]; opacity?: number; material?: "matte" | "glass" | "wireframe" };
type Added3DRenderKind = "surface" | "solid" | "slice" | "point" | "vector" | "line3d" | "plane3d";
type Added3DObject = { id: string; label: string; baseId: ThreeObjectId; render: Added3DRenderKind; solid?: SolidKind; surface?: SurfaceKind; transform: Transform3D; nlpCommand?: VisualCommand };
type CameraPreset3D = "free" | "top" | "front" | "right" | "isometric";
type Preset3DTransform = "center" | "ground" | "unit" | "wide" | "tall" | "xy-plane" | "xz-plane" | "yz-plane";
type GraphWorkspaceTab = "graph" | "command" | "results" | "objects" | "algebra";
type AlgebraObjectKind = "function" | "point" | "line" | "circle" | "polygon" | "arc" | "locus" | "3d";
type AlgebraObjectRef = { kind: AlgebraObjectKind; id: string };
type ObjectPropertyOverrides = Record<string, MathObjectProperties>;
type ContextMenuState = { x: number; y: number; target: SelectedGeometryObject | { type: "3d"; id: string } | { type: "algebra"; ref: AlgebraObjectRef } };
type WorkspaceView = "graph" | "geometry" | "3d" | "data" | "teach";
export type DataWorkspacePage = "overview" | "spreadsheet" | "analysis" | "cas" | "results" | "objects";
type ConstructionStep = { id: string; label: string; detail: string; createdAt: number; snapshot: Pick<WorkspaceSnapshot, "plots" | "construction" | "transforms3d" | "added3dObjects" | "deletedBase3dIds"> };
type ActivityJournalEntry = { templateId: string; phase: GuidedActivityPhase; response: string; selfCheck: "not-started" | "revisit" | "got-it"; confidence: number; updatedAt: number };
type WorkspaceSnapshot = {
  input: string;
  results: ResultCard[];
  plots: PlotItem[];
  construction: Construction;
  geometryGraphSettings?: GeometryGraphSettings;
  lockedGeometryIds?: string[];
  surface: SurfaceKind;
  surfaceExpression?: string;
  cameraPreset3d?: CameraPreset3D;
  sceneAnimationSpeed?: number;
  solid: SolidKind;
  surfaceScale: number;
  height3d: number;
  crossSection: number;
  showSurface: boolean;
  showSolid: boolean;
  autoRotate3d: boolean;
  zoom3d: number;
  transforms3d: Record<ThreeObjectId, Transform3D>;
  added3dObjects?: Added3DObject[];
  deletedBase3dIds?: ThreeObjectId[];
  images?: WorkspaceImage[];
  spreadsheet?: SpreadsheetCellGrid;
  tableRange?: { start: number; end: number; step: number };
  guidedMode?: boolean;
  guidedPhase?: GuidedActivityPhase;
  teachingMode?: boolean;
  revealStep?: number;
  controlsLocked?: boolean;
  highContrastMode?: boolean;
  performanceMode?: boolean;
  protocol?: ConstructionStep[];
  activityJournal?: Record<string, ActivityJournalEntry>;
  presentationNotes?: string;
  objectProperties?: ObjectPropertyOverrides;
};

const colors = ["#06b6d4", "#8b5cf6", "#f59e0b", "#10b981", "#ef4444", "#ec4899", "#14b8a6"];
const regressionSeed: ResultTableRow[] = [{ x: -4, y: -5.6 }, { x: -2, y: -2.2 }, { x: 0, y: 0.7 }, { x: 2, y: 4.1 }, { x: 4, y: 7.4 }];
const initialSpreadsheet: SpreadsheetCellGrid = [
  ["x", "y", "note", ""],
  ["-4", "-5.6", "sample", ""],
  ["-2", "-2.2", "", ""],
  ["0", "0.7", "", ""],
  ["2", "4.1", "", ""],
  ["4", "7.4", "=A2+B2", ""],
];
const initialConstruction: Construction = { points: [], lines: [], circles: [], polygons: [], arcs: [], loci: [], constraints: [] };
const defaultGeometryGraphSettings: GeometryGraphSettings = {
  showGrid: true,
  showAxes: true,
  showUnitLabels: true,
  showPointLabels: true,
  showMeasurements: true,
  highContrastGrid: false,
  snapToGrid: true,
  snapToObjects: true,
  gridType: "cartesian",
  minorGrid: false,
  gridSpacing: 40,
  showAxisLabels: true,
  pointCapture: "snap",
  snapStrength: 18,
};
const defaultTransforms3d: Record<ThreeObjectId, Transform3D> = {
  surface: { name: "surface", position: [0, 0, 0], rotation: [0, 0, 0], scale: 1, visible: true, color: "#22d3ee", opacity: 0.45, material: "glass" },
  solid: { name: "solid", position: [3, 0, 2.6], rotation: [0, 0, 0], scale: 1, visible: true, color: "#8b5cf6", dimensions: [2.5, 2.5, 2.5], opacity: 0.78, material: "glass" },
  slice: { name: "slice", position: [0, 0, 0], rotation: [-90, 0, 0], scale: 1, visible: true, color: "#f59e0b", dimensions: [5.5, 5.5, 0.02], opacity: 0.22, material: "glass" },
  point: { name: "P", position: [2.2, 1.4, 1.8], rotation: [0, 0, 0], scale: 1, visible: true, color: "#f59e0b", dimensions: [0.24, 0.24, 0.24], opacity: 1, material: "matte" },
  vector: { name: "v", position: [0, 0, 0], rotation: [0, 0, 0], scale: 1, visible: true, color: "#f59e0b", dimensions: [1, 1, 1], opacity: 1, material: "matte" },
  line3d: { name: "l", position: [-1.8, 0.4, 1.8], rotation: [0, 35, 0], scale: 1, visible: false, color: "#38bdf8", dimensions: [4, 0.04, 0.04], opacity: 1, material: "matte" },
  plane3d: { name: "plane", position: [0, 0.8, 0], rotation: [-20, 0, 0], scale: 1, visible: false, color: "#22c55e", dimensions: [4, 4, 0.02], opacity: 0.28, material: "glass" },
  sphere3d: { name: "sphere", position: [-2.4, 1.2, -1.8], rotation: [0, 0, 0], scale: 1, visible: false, color: "#06b6d4", dimensions: [1.4, 1.4, 1.4], opacity: 0.72, material: "glass" },
  cone3d: { name: "cone", position: [2.4, 1, -1.8], rotation: [0, 0, 0], scale: 1, visible: false, color: "#f97316", dimensions: [1.4, 2.2, 1.4], opacity: 0.78, material: "glass" },
  cylinder3d: { name: "cylinder", position: [0, 1, -2.4], rotation: [0, 0, 0], scale: 1, visible: false, color: "#a855f7", dimensions: [1.2, 2.2, 1.2], opacity: 0.78, material: "glass" },
  prism3d: { name: "prism", position: [-2.6, 0.9, 1], rotation: [0, 20, 0], scale: 1, visible: false, color: "#10b981", dimensions: [1.8, 1.5, 1.8], opacity: 0.8, material: "glass" },
  pyramid3d: { name: "pyramid", position: [2.6, 0.9, 1], rotation: [0, -20, 0], scale: 1, visible: false, color: "#eab308", dimensions: [1.8, 1.8, 1.8], opacity: 0.82, material: "glass" },
  polyhedron3d: { name: "polyhedron", position: [0, 1.2, 2.8], rotation: [20, 20, 0], scale: 1, visible: false, color: "#ec4899", dimensions: [1.4, 1.4, 1.4], opacity: 0.82, material: "wireframe" },
};
const threeObjectLabels: Record<ThreeObjectId, string> = { surface: "Surface mesh", solid: "Solid shape", slice: "Cross-section", point: "Point", vector: "Vector", line3d: "Line", plane3d: "Plane", sphere3d: "Sphere", cone3d: "Cone", cylinder3d: "Cylinder", prism3d: "Prism", pyramid3d: "Pyramid", polyhedron3d: "Polyhedron" };
const threeObjectSolidMap: Partial<Record<ThreeObjectId, SolidKind>> = { solid: "cube", sphere3d: "sphere", cone3d: "cone", cylinder3d: "cylinder", prism3d: "prism", pyramid3d: "pyramid", polyhedron3d: "polyhedron" };
const threeBaseIds = Object.keys(defaultTransforms3d) as ThreeObjectId[];
const objectStudioShapes: ObjectStudioShape[] = [
  { id: "solid:cube", label: "Cube", category: "primitives", preview: "cube" },
  { id: "solid:cuboid", label: "Cuboid", category: "primitives", preview: "cube" },
  { id: "solid:sphere", label: "Sphere", category: "primitives", preview: "sphere" },
  { id: "solid:ellipsoid", label: "Ellipsoid", category: "primitives", preview: "ellipsoid" },
  { id: "solid:hemisphere", label: "Hemisphere", category: "primitives", preview: "hemisphere" },
  { id: "solid:cylinder", label: "Cylinder", category: "primitives", preview: "cylinder" },
  { id: "solid:cone", label: "Cone", category: "primitives", preview: "cone" },
  { id: "solid:frustum", label: "Frustum", category: "primitives", preview: "frustum" },
  { id: "solid:torus", label: "Torus", category: "primitives", preview: "torus" },
  { id: "solid:tube", label: "Tube", category: "primitives", preview: "torus" },
  { id: "solid:capsule", label: "Capsule", category: "primitives", preview: "capsule" },
  { id: "solid:prism", label: "Triangular prism", category: "geometry", preview: "prism" },
  { id: "solid:pyramid", label: "Pyramid", category: "geometry", preview: "pyramid" },
  { id: "solid:tetrahedron", label: "Tetrahedron", category: "geometry", preview: "polyhedron" },
  { id: "solid:octahedron", label: "Octahedron", category: "geometry", preview: "polyhedron" },
  { id: "solid:dodecahedron", label: "Dodecahedron", category: "geometry", preview: "polyhedron" },
  { id: "solid:wedge", label: "Wedge", category: "geometry", preview: "prism" },
  { id: "solid:polyhedron", label: "Icosahedron", category: "geometry", preview: "polyhedron" },
  { id: "plane3d", label: "Plane", category: "geometry", preview: "plane" },
  { id: "surface", label: "Surface mesh", category: "geometry", preview: "surface" },
  { id: "slice", label: "Cross-section", category: "geometry", preview: "plane" },
  { id: "point", label: "Point", category: "vectors", preview: "point" },
  { id: "vector", label: "Vector", category: "vectors", preview: "vector" },
  { id: "line3d", label: "Line", category: "vectors", preview: "line" },
];
const isBase3dId = (id: string): id is ThreeObjectId => id in defaultTransforms3d;
const getFirstAvailable3dObjectId = (deletedIds: ThreeObjectId[], addedObjects: Added3DObject[]) =>
  threeBaseIds.find((id) => !deletedIds.includes(id)) ?? addedObjects[0]?.id ?? "";
const addedRenderKindForBase = (id: ThreeObjectId): Added3DRenderKind => {
  if (id === "surface") return "surface";
  if (id === "slice") return "slice";
  if (id === "point") return "point";
  if (id === "vector") return "vector";
  if (id === "line3d") return "line3d";
  if (id === "plane3d") return "plane3d";
  return "solid";
};
const geometryDefaultColor: Record<GeometryObjectType, string> = { point: "#06b6d4", line: "#8b5cf6", circle: "#06b6d4", polygon: "#f59e0b", arc: "#14b8a6", locus: "#ec4899" };
const examples = ["plot sin(x)", "Root[x^2-4]", "Extremum[x^2-4*x+1]", "Intersect[x^2, 2*x+3]", "Derivative[x^3-2*x]", "Integral[3*x^2]", "Factor[x^2-5*x+6]", "Expand[(x+2)(x+3)]", "Solve[x^2-5*x+6=0]", "Substitute[x^2+a, a=3]", "Sequence[n^2, n, 1, 6]", "Table[sin(x), -3, 3, 0.5]"];
const guidedExamples = [
  { title: "Quadratic Roots", command: "solve x^2-5*x+6=0" },
  { title: "Derivative Check", command: "derivative x^3-2*x" },
  { title: "Function Table", command: "table sin(x)" },
  { title: "Intersections", command: "intersect x^2 and 2*x+3" },
];
const formulaLibrary = [
  { topic: "Algebra", title: "Quadratic Formula", formula: "x = (-b +/- sqrt(b^2-4ac))/(2a)", command: "solve x^2-5*x+6=0" },
  { topic: "Calculus", title: "Power Rule", formula: "d/dx x^n = n*x^(n-1)", command: "derivative x^4" },
  { topic: "Calculus", title: "Power Integral", formula: "integral x^n dx = x^(n+1)/(n+1) + C", command: "integral 3*x^2" },
  { topic: "Graphing", title: "Intersection", formula: "f(x)=g(x) means f(x)-g(x)=0", command: "intersect x^2 and 2*x+3" },
  { topic: "Geometry", title: "Circle Area", formula: "A = pi r^2", command: "area circle radius 5" },
  { topic: "3D", title: "Paraboloid", formula: "z = k(x^2+y^2)", command: "plot x^2" },
];

function resolveInitialWorkspaceViewFromRoute(fallback: WorkspaceView): WorkspaceView {
  if (typeof window === "undefined") return fallback;
  const params = new URLSearchParams(window.location.search);
  const mode = (params.get("mode") ?? "").toLowerCase();
  if (mode === "3d" || mode === "space3d") return "3d";
  if (mode === "geometry" || mode === "2d") return "geometry";

  const templateId = normalizeTemplateRouteParam(params.get("template") ?? params.get("unit") ?? "");
  const template = syllabusWorkspaceTemplates.find((item) => item.id === templateId);
  if (template?.focus === "3d") return "3d";
  if (template?.focus === "geometry") return "geometry";
  return fallback;
}

export type EmbeddedMathWorkspace = {
  activityId: string;
  initialScene: unknown;
  onSceneChange?: (scene: unknown) => void;
};

function MathWorkspaceContent({ initialView = "graph", singleView = false, dataPage = "overview", embedded }: { initialView?: WorkspaceView; singleView?: boolean; dataPage?: DataWorkspacePage; embedded?: EmbeddedMathWorkspace }) {
  const location = useLocation();
  const navigate = useNavigate();
  const routePayload = (location.state as { mathWorkspacePayload?: MathWorkspacePayload } | null)?.mathWorkspacePayload;
  const routeInitialView = useMemo(() => embedded ? initialView : resolveInitialWorkspaceViewFromRoute(initialView), [initialView, embedded?.activityId]);
  const transferTarget = routeInitialView === "graph" ? "graphs" : routeInitialView === "3d" ? "graphs-3d" : routeInitialView === "geometry" ? "geometry" : "cas";
  const incomingWorkspacePayload = useMemo(() => embedded ? undefined : routePayload ?? readWorkspaceTransfer(transferTarget), [routePayload, transferTarget, embedded?.activityId]);
  const [input, setInput] = useState("plot sin(x)");
  const [results, setResults] = useState<ResultCard[]>([]);
  const [plots, setPlots] = useState<PlotItem[]>(() => {
    const expression = incomingWorkspacePayload?.objectType === "expression" || incomingWorkspacePayload?.objectType === "equation"
      ? incomingWorkspacePayload.value
      : "sin(x)";
    return [{ id: "plot-1", expression, color: colors[0], kind: inferPlotKind(expression), visible: true }];
  });
  const [tool, setTool] = useState<GeometryTool>("select");
  const [construction, setConstruction] = useState<Construction>(initialConstruction);
  const [selectedGeometry, setSelectedGeometry] = useState<SelectedGeometryObject | null>(null);
  const [workspaceImages, setWorkspaceImages] = useState<WorkspaceImage[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);
  const [selectedPointIds, setSelectedPointIds] = useState<string[]>([]);
  const [geometryObjectPicks, setGeometryObjectPicks] = useState<SelectedGeometryObject[]>([]);
  const [dragPointId, setDragPointId] = useState<string | null>(null);
  const [dragImageId, setDragImageId] = useState<string | null>(null);
  const [dragGeometry, setDragGeometry] = useState<{ object: SelectedGeometryObject; last: { x: number; y: number } } | null>(null);
  const [lockedGeometryIds, setLockedGeometryIds] = useState<string[]>([]);
  const [polygonDraft, setPolygonDraft] = useState<string[]>([]);
  const [geometryGraphSettings, setGeometryGraphSettings] = useState<GeometryGraphSettings>(defaultGeometryGraphSettings);
  const [geometryCamera, setGeometryCamera] = useState<GeometryCamera>({ x: 0, y: 0, width: 640, height: 420 });
  const geometryPanRef = useRef<{ clientX: number; clientY: number; camera: GeometryCamera } | null>(null);
  const geometryFreehandRef = useRef<string | null>(null);
  const geometryCertificationReport = useMemo(() => certifyGeometryConstruction(construction, {
    regularPolygonIds: construction.polygons.filter((polygon) => polygon.style?.label === "regular-polygon").map((polygon) => polygon.id),
  }), [construction]);
  const [surface, setSurface] = useState<SurfaceKind>("paraboloid");
  const [surfaceExpression, setSurfaceExpression] = useState(() => incomingWorkspacePayload?.objectType === "surface" ? incomingWorkspacePayload.value : "sin(x) * cos(y)");
  const [solid, setSolid] = useState<SolidKind>("cube");
  const [surfaceScale, setSurfaceScale] = useState(1);
  const [height3d, setHeight3d] = useState(2.5);
  const [crossSection, setCrossSection] = useState(0);
  const [showSurface, setShowSurface] = useState(true);
  const [showSolid, setShowSolid] = useState(true);
  const [autoRotate3d, setAutoRotate3d] = useState(false);
  const [sceneAnimationSpeed, setSceneAnimationSpeed] = useState(0.18);
  const [cameraPreset3d, setCameraPreset3d] = useState<CameraPreset3D>("isometric");
  const [zoom3d, setZoom3d] = useState(1);
  const [selected3d, setSelected3d] = useState<string>("solid");
  const [vectorA3d, setVectorA3d] = useState<Vector3Tuple>([2, 1, 0]);
  const [vectorB3d, setVectorB3d] = useState<Vector3Tuple>([0, 1, 2]);
  const [vectorView3d, setVectorView3d] = useState<VectorView3D>("sum");
  const [vectorWorkbenchVisible, setVectorWorkbenchVisible] = useState(true);
  const [vectorFocus3d, setVectorFocus3d] = useState(false);
  const [objectStudioTool, setObjectStudioTool] = useState<ObjectStudioTool>("select");
  const [objectStudioSnapEnabled, setObjectStudioSnapEnabled] = useState(true);
  const [objectStudioSnapStep, setObjectStudioSnapStep] = useState(0.25);
  const [transforms3d, setTransforms3d] = useState<Record<ThreeObjectId, Transform3D>>(defaultTransforms3d);
  const [added3dObjects, setAdded3dObjects] = useState<Added3DObject[]>([]);
  const [deletedBase3dIds, setDeletedBase3dIds] = useState<ThreeObjectId[]>([]);
  const [drag3d, setDrag3d] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);
  const [formulaSearch, setFormulaSearch] = useState("");
  const [workspaceView, setWorkspaceView] = useState<WorkspaceView>(routeInitialView);
  const [graphWorkspaceTab, setGraphWorkspaceTab] = useState<GraphWorkspaceTab>("graph");
  const [teachingMode, setTeachingMode] = useState(false);
  const [guidedMode, setGuidedMode] = useState(false);
  const [guidedPhase, setGuidedPhase] = useState<GuidedActivityPhase>("predict");
  const [activeTemplate, setActiveTemplate] = useState<SyllabusWorkspaceTemplate>(syllabusWorkspaceTemplates[0]);
  const [classroomLesson, setClassroomLesson] = useState<ClassroomLesson>(() => lessonFromTemplate(syllabusWorkspaceTemplates[0]));
  const [practiceResponses, setPracticeResponses] = useState<Record<string, PracticeResponse>>({});
  const [activityJournal, setActivityJournal] = useState<Record<string, ActivityJournalEntry>>({});
  const [presentationNotes, setPresentationNotes] = useState("");
  const [revealStep, setRevealStep] = useState(1);
  const [controlsLocked, setControlsLocked] = useState(false);
  const [highContrastMode, setHighContrastMode] = useState(false);
  const [performanceMode, setPerformanceMode] = useState(false);
  const [projectLibrary, setProjectLibrary] = useState<OfflineProjectEntry<WorkspaceSnapshot>[]>(() => readOfflineProjectLibrary<WorkspaceSnapshot>());
  const [projectStatus, setProjectStatus] = useState("Scene ready");
  const [protocol, setProtocol] = useState<ConstructionStep[]>([]);
  const [undoStack, setUndoStack] = useState<ConstructionStep[]>([]);
  const [redoStack, setRedoStack] = useState<ConstructionStep[]>([]);
  const [selectedAlgebra, setSelectedAlgebra] = useState<AlgebraObjectRef | null>(null);
  const [objectPropertyOverrides, setObjectPropertyOverrides] = useState<ObjectPropertyOverrides>({});
  const [spreadsheet, setSpreadsheet] = useState<SpreadsheetCellGrid>(initialSpreadsheet);
  const [casExpression, setCasExpression] = useState("x^2-5*x+6");
  const [casNotebookState, setCasNotebookState] = useState<NotebookState>(() => readCasNotebookState() ?? createDefaultCasNotebookState());
  const [casUndoStack, setCasUndoStack] = useState<NotebookState[]>([]);
  const [casRedoStack, setCasRedoStack] = useState<NotebookState[]>([]);
  const [selectedCasCellId, setSelectedCasCellId] = useState<string | null>(() => null);
  const [casComposerInput, setCasComposerInput] = useState(() => incomingWorkspacePayload?.value ?? "Solve[x^3 - 3*x = 2, x]");
  const [casComposerOperation, setCasComposerOperation] = useState<NotebookOperation>("solve");
  const [tableStart, setTableStart] = useState(-4);
  const [tableEnd, setTableEnd] = useState(4);
  const [tableStep, setTableStep] = useState(1);
  const svgRef = useRef<SVGSVGElement>(null);
  const graphExportRef = useRef<HTMLDivElement>(null);
  const geometryExportRef = useRef<SVGSVGElement | null>(null);
  const workspaceRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const portableImportInputRef = useRef<HTMLInputElement>(null);
  const routeStateAppliedRef = useRef("");

  useEffect(() => {
    document.documentElement.classList.toggle("workspace-high-contrast", highContrastMode);
    return () => document.documentElement.classList.remove("workspace-high-contrast");
  }, [highContrastMode]);

  useEffect(() => {
    setWorkspaceView(routeInitialView);
  }, [routeInitialView]);

  useEffect(() => {
    if (!embedded) saveCasNotebookState(casNotebookState);
  }, [casNotebookState, embedded?.activityId]);

  useEffect(() => {
    if (embedded) return;
    const match = window.location.hash.match(/project=([^&]+)/);
    if (!match) return;
    try {
      restoreWorkspaceSnapshot(JSON.parse(decodeURIComponent(escape(atob(match[1])))) as WorkspaceSnapshot);
      setProjectStatus("Share URL project loaded.");
    } catch {
      setProjectStatus("Could not load share URL project.");
    }
  // Route hash hydration must run only once on first mount.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filteredFormulas = useMemo(() => {
    const query = formulaSearch.trim().toLowerCase();
    return formulaLibrary.filter((item) => !query || [item.topic, item.title, item.formula].join(" ").toLowerCase().includes(query));
  }, [formulaSearch]);

  const workspaceObjects = useMemo(() => buildAlgebraObjects(plots, construction, transforms3d, lockedGeometryIds, added3dObjects), [plots, construction, transforms3d, lockedGeometryIds, added3dObjects]);
  const liveWorkspaceObjects = useMemo(() => [
    ...createLiveWorkspaceObjects(workspaceObjects, plots, construction, transforms3d, added3dObjects, objectPropertyOverrides),
    ...createSupplementalWorkspaceObjects(results, plots, spreadsheet, { start: tableStart, end: tableEnd, step: tableStep }),
  ], [added3dObjects, construction, objectPropertyOverrides, plots, results, spreadsheet, tableEnd, tableStart, tableStep, transforms3d, workspaceObjects]);
  const evaluatedLiveWorkspaceObjects = useMemo(() => applyObjectProperties(liveWorkspaceObjects, { variables: workspacePropertyVariables(surfaceScale, height3d, crossSection, sceneAnimationSpeed) }), [crossSection, height3d, liveWorkspaceObjects, sceneAnimationSpeed, surfaceScale]);
  const unifiedWorkspaceObjects = useWorkspaceStore((state) => state.objects);
  const unifiedSelectedObjectId = useWorkspaceStore((state) => state.selectedObjectId);
  const unifiedSelectedObjectIds = useWorkspaceStore((state) => state.selectedObjectIds);
  const upsertUnifiedWorkspaceObjects = useWorkspaceStore((state) => state.upsertObjects);
  const updateUnifiedWorkspaceObject = useWorkspaceStore((state) => state.updateObject);
  const selectUnifiedWorkspaceObject = useWorkspaceStore((state) => state.selectObject);
  const unifiedSelectedObject = useMemo(() => unifiedWorkspaceObjects.find((object) => object.id === unifiedSelectedObjectId) ?? null, [unifiedSelectedObjectId, unifiedWorkspaceObjects]);
  const selected3dTransform = useMemo(() => isBase3dId(selected3d) ? transforms3d[selected3d] : added3dObjects.find((object) => object.id === selected3d)?.transform ?? transforms3d.solid, [added3dObjects, selected3d, transforms3d]);
  const dynamicGraph = useMemo(() => buildDynamicObjectGraph(workspaceObjects.map((object) => ({
    id: `${object.ref.kind}:${object.ref.id}`,
    name: object.name,
    kind: objectKindForKernel(object.ref.kind),
    definition: object.definition,
    visible: object.visible,
    locked: object.locked,
    trace: object.trace,
    dependencies: object.dependencies,
  }))), [workspaceObjects]);
  const dynamicHealth = useMemo(() => graphHealthSummary(dynamicGraph), [dynamicGraph]);

  useEffect(() => {
    if (embedded) return;
    const editedProperties = unifiedWorkspaceObjects
      .map((object) => {
        const ref = liveRefFromMathObject(object);
        if (!ref || !hasCustomObjectProperties(object)) return null;
        return [liveWorkspaceObjectId(ref), object.properties] as const;
      })
      .filter((entry): entry is readonly [string, MathObjectProperties] => Boolean(entry?.[1]));
    if (editedProperties.length === 0) return;
    setObjectPropertyOverrides((current) => {
      let changed = false;
      const next = { ...current };
      for (const [objectId, properties] of editedProperties) {
        if (sameObjectProperties(next[objectId], properties)) continue;
        next[objectId] = properties;
        changed = true;
      }
      return changed ? next : current;
    });
  }, [unifiedWorkspaceObjects]);

  useEffect(() => {
    if (!embedded) upsertUnifiedWorkspaceObjects(evaluatedLiveWorkspaceObjects);
  }, [evaluatedLiveWorkspaceObjects, upsertUnifiedWorkspaceObjects]);

  const commandSummary = useMemo(() => commandRegistrySummary(), []);
  const practiceReport = useMemo(() => computePracticeReport(classroomLesson, practiceResponses), [classroomLesson, practiceResponses]);

  const captureStep = (label: string, detail: string): ConstructionStep => ({
    id: crypto.randomUUID(),
    label,
    detail,
    createdAt: Date.now(),
    snapshot: { plots, construction, transforms3d, added3dObjects, deletedBase3dIds },
  });

  const recordWorkspaceStep = (label: string, detail: string) => {
    if (immersive3dTransaction.current || cinematicPreview) return;
    const step = captureStep(label, detail);
    setUndoStack((current) => [step, ...current].slice(0, 80));
    setRedoStack([]);
    setProtocol((current) => [{ ...step, snapshot: { plots, construction, transforms3d, added3dObjects, deletedBase3dIds } }, ...current].slice(0, 120));
  };

  const restoreProtocolSnapshot = (step: ConstructionStep) => {
    setPlots(step.snapshot.plots ?? []);
    setConstruction(normalizeConstruction(step.snapshot.construction ?? initialConstruction));
    setTransforms3d({ ...defaultTransforms3d, ...(step.snapshot.transforms3d ?? {}) });
    setAdded3dObjects(step.snapshot.added3dObjects ?? []);
    setDeletedBase3dIds(step.snapshot.deletedBase3dIds ?? []);
  };

  const undoWorkspace = () => {
    if (workspaceView === "data" && dataPage === "cas" && casUndoStack.length) {
      const [previous, ...rest] = casUndoStack;
      setCasRedoStack((current) => [casNotebookState, ...current].slice(0, 40));
      setCasUndoStack(rest);
      setCasNotebookState(previous);
      setSelectedCasCellId(previous.cells[0]?.id ?? null);
      return;
    }
    const [step, ...rest] = undoStack;
    if (!step) return undoConstruction();
    const currentStep = captureStep(`Redo ${step.label}`, "State before undo.");
    setRedoStack((current) => [currentStep, ...current]);
    setUndoStack(rest);
    restoreProtocolSnapshot(step);
  };

  const redoWorkspace = () => {
    if (workspaceView === "data" && dataPage === "cas" && casRedoStack.length) {
      const [next, ...rest] = casRedoStack;
      setCasUndoStack((current) => [casNotebookState, ...current].slice(0, 40));
      setCasRedoStack(rest);
      setCasNotebookState(next);
      setSelectedCasCellId(next.cells[0]?.id ?? null);
      return;
    }
    const [step, ...rest] = redoStack;
    if (!step) return;
    const currentStep = captureStep(`Undo ${step.label}`, "State before redo.");
    setUndoStack((current) => [currentStep, ...current]);
    setRedoStack(rest);
    restoreProtocolSnapshot(step);
  };

  const addResultCard = (analysis: ResultCard) => setResults((current) => [analysis, ...current].slice(0, 12));

  const applyDirectDefinitionCommand = (raw: string) => {
    const functionMatch = raw.match(/^([a-z]\w*)\s*\(\s*x\s*\)\s*=\s*(.+)$/i);
    if (functionMatch) {
      const [, name, expression] = functionMatch;
      recordWorkspaceStep("Define function", `${name}(x) = ${expression}`);
      setPlots((current) => [{ id: crypto.randomUUID(), expression: expression.trim(), name, color: colors[current.length % colors.length], kind: inferPlotKind(expression), visible: true }, ...current].slice(0, 10));
      addResultCard({
        id: crypto.randomUUID(),
        input: raw,
        interpretation: "Live function definition",
        result: `${name}(x) = ${expression.trim()}`,
        detail: "The function was added to the graph and algebra object list with an editable definition.",
        related: [`Derivative[${expression.trim()}]`, `Table[${expression.trim()}, -5, 5, 1]`],
      });
      setProjectStatus(`${name}(x) linked to graph, algebra panel, inspector, and export state.`);
      return true;
    }

    const point3dMatch = raw.match(/^([A-Z]\w*)\s*=\s*\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)$/);
    if (point3dMatch) {
      const [, name, xRaw, yRaw, zRaw] = point3dMatch;
      const position: [number, number, number] = [Number(xRaw), Number(yRaw), Number(zRaw)];
      recordWorkspaceStep("Define 3D point", `${name}=(${position.join(", ")})`);
      setSelected3d("point");
      setShowSurface(true);
      setDeletedBase3dIds((current) => current.filter((id) => id !== "point"));
      setTransforms3d((current) => ({ ...current, point: { ...current.point, name, position, visible: true } }));
      addResultCard({
        id: crypto.randomUUID(),
        input: raw,
        interpretation: "Live 3D point definition",
        result: `${name}=(${position.join(", ")})`,
        detail: "The 3D point is now selectable, draggable, editable, and linked to the 3D inspector.",
      });
      setProjectStatus(`${name} created as a live 3D object.`);
      return true;
    }

    const point2dMatch = raw.match(/^([A-Z]\w*)\s*=\s*\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)$/);
    if (point2dMatch) {
      const [, label, xRaw, yRaw] = point2dMatch;
      const math = { x: Number(xRaw), y: Number(yRaw) };
      const board = mathToBoardPoint(math.x, math.y);
      const id = crypto.randomUUID();
      recordWorkspaceStep("Define point", `${label}=(${math.x}, ${math.y})`);
      setConstruction((current) => solveConstruction({ ...current, points: [...current.points, { id, ...board, label }] }, id));
      setSelectedGeometry({ type: "point", id });
      addResultCard({
        id: crypto.randomUUID(),
        input: raw,
        interpretation: "Live point definition",
        result: `${label}=(${math.x}, ${math.y})`,
        detail: "The point was placed on the geometry board and can be edited from the algebra panel or inspector.",
      });
      setProjectStatus(`${label} created as a live geometry point.`);
      return true;
    }

    const circleEquationMatch = raw.match(/^([a-z]\w*)\s*:\s*x\^2\s*\+\s*y\^2\s*=\s*(\d+(?:\.\d+)?)$/i);
    if (circleEquationMatch) {
      const [, name, radiusSquaredRaw] = circleEquationMatch;
      const radius = Math.sqrt(Number(radiusSquaredRaw));
      const center = crypto.randomUUID();
      const edge = crypto.randomUUID();
      const circle = crypto.randomUUID();
      recordWorkspaceStep("Define circle equation", `${name}: x^2+y^2=${radiusSquaredRaw}`);
      setConstruction((current) => solveConstruction({
        ...current,
        points: [
          ...current.points,
          { id: center, ...mathToBoardPoint(0, 0), label: "O" },
          { id: edge, ...mathToBoardPoint(radius, 0), label: "R" },
        ],
        circles: [...current.circles, { id: circle, center, edge, style: { label: name } }],
      }));
      setSelectedGeometry({ type: "circle", id: circle });
      addResultCard({
        id: crypto.randomUUID(),
        input: raw,
        interpretation: "Live circle definition",
        result: `${name}: center=(0,0), r=${roundTo(radius, 4)}`,
        detail: "The equation became a selectable circle with editable radius, style, and algebra definition.",
      });
      setProjectStatus(`${name} created as a live circle object.`);
      return true;
    }

    const surfaceMatch = raw.match(/^(?:surface\s+)?z\s*=\s*(.+)$/i);
    if (surfaceMatch) {
      const expression = surfaceMatch[1].trim();
      recordWorkspaceStep("Define 3D surface", `z = ${expression}`);
      setSurface("custom-z");
      setSurfaceExpression(expression);
      setShowSurface(true);
      setSelected3d("surface");
      addResultCard({
        id: crypto.randomUUID(),
        input: raw,
        interpretation: "Live 3D surface definition",
        result: `z = ${expression}`,
        detail: "The expression is rendered as an editable browser-only 3D surface.",
      });
      setProjectStatus("Custom 3D surface linked to the 3D scene and inspector.");
      return true;
    }

    return false;
  };

  const executeWorkspaceCommand = (rawInput: string) => {
    const raw = rawInput.trim();
    if (!raw) return;
    if (applyDirectDefinitionCommand(raw)) return;
    const analysis = interpretInput(raw);
    if (analysis.interpretation === "2D plot") {
      const expression = normalizePlotExpression(raw);
      const validation = validateGraphExpression(expression);
      if (isGraphValidationBlocking(validation)) {
        const unsupported = createUnsupportedWorkspaceAction("Graph expression", validation.message, validation.suggestions);
        addResultCard(unsupportedActionResultCard(raw, unsupported));
        setProjectStatus(unsupported.message);
        return;
      }
      addResultCard(analysis);
      recordWorkspaceStep("Add function", raw);
      setPlots((current) => [{ id: crypto.randomUUID(), expression, name: nextFunctionName(current), color: colors[current.length % colors.length], kind: inferPlotKind(expression), visible: true }, ...current].slice(0, 8));
      return;
    }
    addResultCard(analysis);
    if (analysis.graphExpression) {
      recordWorkspaceStep("Add CAS graph link", analysis.graphExpression);
      const validation = validateGraphExpression(analysis.graphExpression);
      if (isGraphValidationBlocking(validation)) {
        const unsupported = createUnsupportedWorkspaceAction("CAS graph link", validation.message, validation.suggestions);
        addResultCard(unsupportedActionResultCard(raw, unsupported));
        setProjectStatus(unsupported.message);
        return;
      }
      setPlots((current) => [{ id: crypto.randomUUID(), expression: analysis.graphExpression!, name: nextFunctionName(current), color: colors[current.length % colors.length], kind: inferPlotKind(analysis.graphExpression!), visible: true }, ...current].slice(0, 10));
    }
  };

  const runInput = () => executeWorkspaceCommand(input);

  const addPoint = (x: number, y: number) => {
    const snapped = snapBoardPoint({ x, y }, construction, geometryGraphSettings);
    const result = buildPointCreation(construction, snapped);
    const point = result.construction.points[result.construction.points.length - 1];
    recordWorkspaceStep("Create point", `${point.label} = (${roundTo(point.x, 1)}, ${roundTo(point.y, 1)})`);
    setConstruction((current) => solveConstruction({ ...current, points: [...current.points, point] }, result.createdPointId));
    return result.createdPointId;
  };

  const selectGeometryTool = (nextTool: GeometryTool) => {
    const transformMode = geometryTransformToolMode(nextTool);
    if (transformMode) {
      const applied = applyGeometryFigureTransform(transformMode);
      if (applied) {
        setTool("select");
        return;
      }
      setTool(nextTool);
      setSelectedPointIds([]);
      setPolygonDraft([]);
      setGeometryObjectPicks([]);
      setProjectStatus(`${geometryToolLabel(nextTool)} ready. Click a shape, or pick points on the board.`);
      return;
    }
    setTool(nextTool);
    setSelectedPointIds([]);
    setPolygonDraft([]);
    setGeometryObjectPicks([]);
    if (nextTool !== "select") setProjectStatus(`${geometryToolLabel(nextTool)} ready.`);
  };

  const applyGeometryFigureTransform = (mode: GeometryTransformMode, explicitPointIds?: string[]) => {
    const request = createGeometryTransformRequest(construction, selectedGeometry, selectedPointIds, mode);
    const uniqueIds = explicitPointIds?.length
      ? Array.from(new Set(explicitPointIds))
      : request.ok
        ? request.value.pointIds
        : construction.points.map((point) => point.id);
    if (!uniqueIds.length) {
      setProjectStatus("Create or select a shape first, then use Rotate 45, Mirror, Dilate, or Translate.");
      return false;
    }
    recordWorkspaceStep(`Transform selected ${mode}`, `${uniqueIds.length} point${uniqueIds.length === 1 ? "" : "s"} updated.`);
    setConstruction((current) => solveConstruction(buildSelectedPointsTransform(current, uniqueIds, mode).construction));
    setSelectedPointIds(uniqueIds);
    const transformedObject = selectedGeometry ?? geometryObjectForPointIds(construction, uniqueIds);
    if (transformedObject) setSelectedGeometry(transformedObject);
    setProjectStatus(`${geometryToolLabel(mode === "mirror" ? "mirror" : mode)} applied to ${uniqueIds.length} point${uniqueIds.length === 1 ? "" : "s"}.`);
    return true;
  };

  const handleImageUpload = (fileList: FileList | null) => {
    const file = fileList?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setProjectStatus("Choose a PNG, JPG, GIF, SVG, or WebP image.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const src = String(reader.result ?? "");
      const image = new Image();
      image.onload = () => {
        const maxWidth = 240;
        const ratio = image.width > 0 ? image.height / image.width : 0.65;
        const width = Math.min(maxWidth, Math.max(120, image.width || maxWidth));
        const next: WorkspaceImage = {
          id: crypto.randomUUID(),
          name: file.name.replace(/\.[^.]+$/, "") || "Image",
          src,
          x: 200,
          y: 120,
          width,
          height: Math.max(80, width * ratio),
          opacity: 0.92,
          visible: true,
        };
        recordWorkspaceStep("Add image", `${next.name} added to geometry board.`);
        setWorkspaceImages((current) => [next, ...current]);
        setSelectedImageId(next.id);
        setSelectedGeometry(null);
        setProjectStatus(`${next.name} added to the geometry board.`);
      };
      image.onerror = () => setProjectStatus("Could not read that image file.");
      image.src = src;
    };
    reader.readAsDataURL(file);
    if (imageInputRef.current) imageInputRef.current.value = "";
  };

  const handleBoardPointerDown = (event: PointerEvent<SVGSVGElement>) => {
    if (controlsLocked) return;
    setContextMenu(null);
    if (event.button === 2) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    if (event.pointerType === "touch") event.preventDefault();
    if (tool === "move-canvas") {
      geometryPanRef.current = { clientX: event.clientX, clientY: event.clientY, camera: geometryCamera };
      return;
    }
    if (tool === "zoom") {
      const anchor = clientToBoard(event);
      zoomGeometry("in", anchor ?? undefined);
      return;
    }
    if (tool === "freehand") {
      const point = clientToBoard(event);
      if (!point) return;
      const id = crypto.randomUUID();
      geometryFreehandRef.current = id;
      setConstruction((current) => ({
        ...current,
        loci: [...current.loci, { id, label: "freehand", points: [point], style: { color: "#f97316", strokeWidth: 4 } }],
      }));
      recordWorkspaceStep("Draw freehand path", "Pointer sketch added to the board.");
      return;
    }
    const target = event.target as Element;
    const imageId = target.getAttribute("data-image-id");
    if (imageId) {
      setSelectedImageId(imageId);
      setSelectedGeometry(null);
      const image = workspaceImages.find((item) => item.id === imageId);
      if (image?.locked) return;
      recordWorkspaceStep("Move image", `${image?.name ?? "Image"} dragged on geometry board.`);
      setDragImageId(imageId);
      return;
    }
    const pointId = target.getAttribute("data-point-id");
    if (pointId) {
      setSelectedGeometry({ type: "point", id: pointId });
      if (lockedGeometryIds.includes(pointId)) return;
      if (tool === "select") {
        recordWorkspaceStep("Move point", `${labelForPoint(construction, pointId)} dragged on geometry board.`);
        setDragPointId(pointId);
      }
      else handlePointPick(pointId);
      return;
    }
    const objectType = target.getAttribute("data-object-type") as GeometryObjectType | null;
    const objectId = target.getAttribute("data-object-id");
    if (objectType && objectId && tool !== "select") {
      consumeGeometryToolObject(tool, { type: objectType, id: objectId }, construction);
      return;
    }
    if (objectType && objectId && tool === "select") {
      const object = { type: objectType, id: objectId };
      setSelectedGeometry(object);
      const point = clientToBoard(event);
      if (point && !lockedGeometryIds.includes(objectId)) {
        recordWorkspaceStep("Move object", `${objectType} moved on geometry board.`);
        setDragGeometry({ object, last: point });
      }
      return;
    }
    if (["image", "delete", "redo", "reset", "save", "load"].includes(tool)) return;
    const quickCreateTools: GeometryTool[] = ["text", "triangle", "rectangle", "square", "pentagon-shape", "hexagon", "parallelogram", "trapezoid", "rhombus", "kite", "shape-circle", "semicircle", "parabola", "ellipse", "hyperbola"];
    if (quickCreateTools.includes(tool)) {
      const point = clientToBoard(event);
      if (point) createQuickGeometryObject(tool, point.x, point.y);
      return;
    }
    const point = clientToBoard(event);
    if (!point) return;
    if (tool === "point") {
      addPoint(point.x, point.y);
      return;
    }
    createPointForActiveGeometryTool(tool, point.x, point.y);
  };

  const createPointForActiveGeometryTool = (activeTool: GeometryTool, x: number, y: number) => {
    if (activeTool === "freehand") {
      createDefaultGeometryToolObject(activeTool, x, y);
      return;
    }
    const pickTools: GeometryTool[] = [
      "segment",
      "line",
      "ray",
      "vector",
      "circle",
      "polygon",
      "triangle",
      "angle",
      "parallel",
      "perpendicular",
      "midpoint",
      "fixed-length",
      "circle-radius",
      "circle-3-points",
      "on-circle",
      "intersect",
      "perpendicular-bisector",
      "angle-bisector",
      "tangent",
      "polar",
      "locus",
      "regular-polygon",
      "arc",
      "sector",
      "compass",
      "mirror",
      "reflect",
      "rotate",
      "dilate",
      "translate",
    ];
    if (!pickTools.includes(activeTool)) return;
    const snapped = snapBoardPoint({ x, y }, construction, geometryGraphSettings);
    const result = buildPointCreation(construction, snapped, { round: (value) => roundTo(value, 2) });
    const newPoint = result.construction.points[result.construction.points.length - 1];
    setConstruction((current) => solveConstruction({ ...current, points: [...current.points, newPoint] }, result.createdPointId));
    if (result.createdPointId) consumeGeometryToolPoint(activeTool, result.createdPointId, result.construction);
  };

  const createDefaultGeometryToolObject = (activeTool: GeometryTool, x: number, y: number) => {
    const supportedTools: GeometryTool[] = [
      "segment",
      "line",
      "ray",
      "vector",
      "circle",
      "polygon",
      "angle",
      "parallel",
      "perpendicular",
      "midpoint",
      "fixed-length",
      "circle-radius",
      "circle-3-points",
      "on-circle",
      "intersect",
      "perpendicular-bisector",
      "angle-bisector",
      "tangent",
      "polar",
      "locus",
      "regular-polygon",
      "arc",
      "sector",
      "compass",
      "mirror",
      "reflect",
      "rotate",
      "dilate",
      "translate",
      "freehand",
      "move-canvas",
      "zoom",
    ];
    if (!supportedTools.includes(activeTool)) return;
    recordWorkspaceStep("Create geometry tool object", `${activeTool} added from the board.`);
    setConstruction((current) => createGeometryObjectForTool(current, activeTool, x, y));
    setSelectedPointIds([]);
    setPolygonDraft([]);
    if (!["move-canvas", "zoom"].includes(activeTool)) setTool("select");
  };

  const createQuickGeometryObject = (shapeTool: GeometryTool, x: number, y: number) => {
    recordWorkspaceStep("Create geometry tool object", `${shapeTool} added from tool plate.`);
    setConstruction((current) => {
      const next = ((): Construction => {
      const base = current.points.length;
      const makePoint = (px: number, py: number, offset: number, style?: GeoStyle): GeoPoint => ({
        id: crypto.randomUUID(),
        x: roundTo(px, 2),
        y: roundTo(py, 2),
        label: shapeTool === "text" ? "Text" : nextPointLabel(current.points, base + offset - current.points.length),
        style,
      });
      if (shapeTool === "text") {
        return solveConstruction({ ...current, points: [...current.points, makePoint(x, y, 0, { label: "Text", color: "#f59e0b", size: 10 })] });
      }
      if (shapeTool === "triangle") {
        const points = [makePoint(x, y - 58, 0), makePoint(x - 64, y + 52, 1), makePoint(x + 64, y + 52, 2)];
        return solveConstruction({ ...current, points: [...current.points, ...points], polygons: [...current.polygons, { id: crypto.randomUUID(), points: points.map((point) => point.id) }] });
      }
      if (shapeTool === "rectangle") {
        const points = [makePoint(x - 70, y - 45, 0), makePoint(x + 70, y - 45, 1), makePoint(x + 70, y + 45, 2), makePoint(x - 70, y + 45, 3)];
        return solveConstruction({ ...current, points: [...current.points, ...points], polygons: [...current.polygons, { id: crypto.randomUUID(), points: points.map((point) => point.id), style: { fill: "rgba(14,165,233,.16)", color: "#22d3ee" } }] });
      }
      const polygonStyles: Partial<Record<GeometryTool, GeoStyle>> = {
        square: { fill: "rgba(34,197,94,.16)", color: "#22c55e" },
        "pentagon-shape": { fill: "rgba(168,85,247,.16)", color: "#a855f7" },
        hexagon: { fill: "rgba(20,184,166,.16)", color: "#14b8a6" },
        parallelogram: { fill: "rgba(249,115,22,.16)", color: "#f97316" },
        trapezoid: { fill: "rgba(234,179,8,.18)", color: "#eab308" },
        rhombus: { fill: "rgba(236,72,153,.16)", color: "#ec4899" },
        kite: { fill: "rgba(99,102,241,.16)", color: "#6366f1" },
      };
      const createPolygon = (offsets: Array<[number, number]>, label: string) => {
        const points = offsets.map(([dx, dy], index) => makePoint(x + dx, y + dy, index));
        return solveConstruction({
          ...current,
          points: [...current.points, ...points],
          polygons: [...current.polygons, { id: crypto.randomUUID(), points: points.map((point) => point.id), style: { ...polygonStyles[shapeTool], label } }],
        });
      };
      if (shapeTool === "square") {
        return createPolygon([[-58, -58], [58, -58], [58, 58], [-58, 58]], "square");
      }
      if (shapeTool === "pentagon-shape" || shapeTool === "hexagon") {
        const sides = shapeTool === "pentagon-shape" ? 5 : 6;
        const radius = shapeTool === "pentagon-shape" ? 72 : 78;
        const offsets = Array.from({ length: sides }, (_, index): [number, number] => {
          const angle = -Math.PI / 2 + index / sides * Math.PI * 2;
          return [Math.cos(angle) * radius, Math.sin(angle) * radius];
        });
        return createPolygon(offsets, shapeTool === "pentagon-shape" ? "pentagon" : "hexagon");
      }
      if (shapeTool === "parallelogram") {
        return createPolygon([[-76, -46], [52, -46], [76, 46], [-52, 46]], "parallelogram");
      }
      if (shapeTool === "trapezoid") {
        return createPolygon([[-48, -52], [48, -52], [86, 52], [-86, 52]], "trapezoid");
      }
      if (shapeTool === "rhombus") {
        return createPolygon([[0, -72], [82, 0], [0, 72], [-82, 0]], "rhombus");
      }
      if (shapeTool === "kite") {
        return createPolygon([[0, -86], [58, -10], [0, 82], [-38, -10]], "kite");
      }
      if (shapeTool === "shape-circle") {
        const center = makePoint(x, y, 0);
        const edge = makePoint(x + 72, y, 1);
        return solveConstruction({ ...current, points: [...current.points, center, edge], circles: [...current.circles, { id: crypto.randomUUID(), center: center.id, edge: edge.id }] });
      }
      const curvePoints = Array.from({ length: 48 }, (_, index) => {
        const t = ((index / 47) * 2 - 1);
        if (shapeTool === "semicircle") return { x: x + t * 96, y: y - Math.sqrt(Math.max(0, 1 - t * t)) * 72 + 36 };
        if (shapeTool === "parabola") return { x: x + t * 120, y: y + t * t * 90 - 60 };
        if (shapeTool === "ellipse") return { x: x + Math.cos(index / 47 * Math.PI * 2) * 110, y: y + Math.sin(index / 47 * Math.PI * 2) * 62 };
        return { x: x + t * 125, y: y + (t === 0 ? 0 : 42 / t) };
      });
      return solveConstruction({ ...current, loci: [...current.loci, { id: crypto.randomUUID(), label: shapeTool, points: curvePoints, style: { color: shapeTool === "ellipse" ? "#22d3ee" : shapeTool === "hyperbola" ? "#f97316" : shapeTool === "semicircle" ? "#10b981" : "#a78bfa", strokeWidth: 4 } }] });
      })();
      const created = createdGeometryFromDelta(current, next);
      Promise.resolve().then(() => {
        if (created.object) setSelectedGeometry(created.object);
        if (created.pointIds.length) setSelectedPointIds(created.pointIds);
      });
      return next;
    });
    setTool("select");
  };

  const handleGeometryContextMenu = (event: PointerEvent<SVGSVGElement>) => {
    if (controlsLocked) return;
    const target = event.target as Element;
    const pointId = target.getAttribute("data-point-id");
    const objectType = (target.getAttribute("data-object-type") as GeometryObjectType | null) ?? (pointId ? "point" : null);
    const objectId = target.getAttribute("data-object-id") ?? pointId;
    if (!objectType || !objectId) return;
    event.preventDefault();
    const targetObject = { type: objectType, id: objectId };
    setSelectedGeometry(targetObject);
    setContextMenu({ x: event.clientX, y: event.clientY, target: targetObject });
  };

  const handlePointPick = (pointId: string) => {
    if (consumeGeometryToolPointWithObjectPick(tool, pointId, construction)) return;
    consumeGeometryToolPoint(tool, pointId, construction);
  };

  const consumeGeometryToolPointWithObjectPick = (activeTool: GeometryTool, pointId: string, constructionContext: Construction) => {
    const pickedObject = geometryObjectPicks[0];
    if (!pickedObject) return false;
    if ((activeTool === "parallel" || activeTool === "perpendicular") && pickedObject.type === "line") {
      recordWorkspaceStep(`Create ${activeTool}`, `${geometryObjectLabel(constructionContext, pickedObject)} through ${labelForPoint(constructionContext, pointId)}`);
      setConstruction((current) => {
        const result = activeTool === "parallel"
          ? buildParallelConstruction(current, pickedObject.id, pointId)
          : buildPerpendicularConstruction(current, pickedObject.id, pointId);
        return solveConstruction(result.construction);
      });
      setGeometryObjectPicks([]);
      setSelectedPointIds([]);
      return true;
    }
    if (activeTool === "on-circle" && pickedObject.type === "circle") {
      recordWorkspaceStep("Constrain point to circle", `${labelForPoint(constructionContext, pointId)} on ${geometryObjectLabel(constructionContext, pickedObject)}`);
      setConstruction((current) => solveConstruction(buildPointOnCircleConstraint(current, pointId, pickedObject.id).construction, pointId));
      setGeometryObjectPicks([]);
      setSelectedPointIds([]);
      return true;
    }
    if ((activeTool === "tangent" || activeTool === "polar") && pickedObject.type === "circle") {
      recordWorkspaceStep(`Create ${activeTool}`, `${labelForPoint(constructionContext, pointId)} with ${geometryObjectLabel(constructionContext, pickedObject)}`);
      setConstruction((current) => activeTool === "tangent" ? addTangentAtPoint(current, pointId, pickedObject.id) : addPolarLine(current, pointId, pickedObject.id));
      setGeometryObjectPicks([]);
      setSelectedPointIds([]);
      return true;
    }
    return false;
  };

  const consumeGeometryToolObject = (activeTool: GeometryTool, object: SelectedGeometryObject, constructionContext: Construction) => {
    setSelectedGeometry(object);
    const transformMode = geometryTransformToolMode(activeTool);
    if (transformMode) {
      const ids = pointIdsForObject(constructionContext, object);
      if (ids.length && applyGeometryFigureTransform(transformMode, ids)) {
        setTool("select");
        return;
      }
    }
    if (activeTool === "intersect" && (object.type === "line" || object.type === "circle")) {
      const next = [...geometryObjectPicks.filter((item) => !(item.type === object.type && item.id === object.id)), object].slice(-2);
      setGeometryObjectPicks(next);
      if (next.length === 2) {
        recordWorkspaceStep("Create selected intersections", `${geometryObjectLabel(constructionContext, next[0])} with ${geometryObjectLabel(constructionContext, next[1])}`);
        setConstruction((current) => solveConstruction(buildIntersectionConstruction(current, next[0].id, next[1].id, { firstType: next[0].type as "line" | "circle", secondType: next[1].type as "line" | "circle" }).construction));
        setGeometryObjectPicks([]);
      }
      return;
    }
    if ((activeTool === "parallel" || activeTool === "perpendicular") && object.type === "line") {
      setGeometryObjectPicks([object]);
      setSelectedPointIds([]);
      setProjectStatus(`${geometryObjectLabel(constructionContext, object)} picked. Pick a point for the through-point.`);
      return;
    }
    if (activeTool === "on-circle" && object.type === "circle") {
      setGeometryObjectPicks([object]);
      setSelectedPointIds([]);
      setProjectStatus(`${geometryObjectLabel(constructionContext, object)} picked. Pick a point to constrain on it.`);
      return;
    }
    if ((activeTool === "tangent" || activeTool === "polar") && object.type === "circle") {
      setGeometryObjectPicks([object]);
      setSelectedPointIds([]);
      setProjectStatus(`${geometryObjectLabel(constructionContext, object)} picked. Pick a point for ${activeTool}.`);
      return;
    }
    setProjectStatus(`${geometryToolLabel(activeTool)} needs a ${geometryToolExpectedPick(activeTool)}.`);
  };

  const consumeGeometryToolPoint = (activeTool: GeometryTool, pointId: string, constructionContext: Construction) => {
    if (activeTool === "line" || activeTool === "segment" || activeTool === "ray" || activeTool === "vector") {
      const next = [...selectedPointIds, pointId].slice(-2);
      const result = buildLineFromPoints(constructionContext, next, { tool: activeTool as GeometryLineTool });
      setSelectedPointIds(result.selectedPointIds ?? next);
      if (next.length === 2 && next[0] !== next[1]) {
        recordWorkspaceStep(`Create ${activeTool}`, `${labelForPoint(constructionContext, next[0])}${labelForPoint(constructionContext, next[1])}`);
        setConstruction((current) => buildLineFromPoints(current, next, { tool: activeTool as GeometryLineTool }).construction);
        setSelectedPointIds([]);
      } else if (result.status) {
        setProjectStatus(result.status.message);
      }
    }
    if (activeTool === "circle" || activeTool === "circle-radius") {
      const next = [...selectedPointIds, pointId].slice(-2);
      const result = buildCircleFromPoints(constructionContext, next, { tool: activeTool });
      setSelectedPointIds(result.selectedPointIds ?? next);
      if (next.length === 2 && next[0] !== next[1]) {
        recordWorkspaceStep(activeTool === "circle-radius" ? "Create circle by radius" : "Create circle", `Center ${labelForPoint(constructionContext, next[0])}, edge ${labelForPoint(constructionContext, next[1])}`);
        setConstruction((current) => buildCircleFromPoints(current, next, { tool: activeTool }).construction);
        setSelectedPointIds([]);
      } else if (result.status) {
        setProjectStatus(result.status.message);
      }
    }
    if (activeTool === "circle-3-points" || activeTool === "angle") {
      const next = [...selectedPointIds, pointId].slice(-3);
      const result = activeTool === "angle" ? buildAngleFromPoints(constructionContext, next) : buildCircleThroughThreePoints(constructionContext, next);
      setSelectedPointIds(result.selectedPointIds ?? next);
      if (next.length === 3 && new Set(next).size === 3) {
        const angleDetail = activeTool === "angle"
          ? `${labelForPoint(constructionContext, next[0])}-${labelForPoint(constructionContext, next[1])}-${labelForPoint(constructionContext, next[2])}: vertex ${labelForPoint(constructionContext, next[1])}`
          : next.map((id) => labelForPoint(constructionContext, id)).join(", ");
        recordWorkspaceStep(activeTool === "angle" ? "Create measured angle" : "Create circle through 3 points", angleDetail);
        setConstruction((current) => {
          const built = activeTool === "angle" ? buildAngleFromPoints(current, next) : buildCircleThroughThreePoints(current, next);
          return solveConstruction(built.construction);
        });
        setSelectedPointIds([]);
        if (activeTool === "angle") setProjectStatus(`Angle measured: ${angleDetail}. Drag any of the three points to update it live.`);
      } else if (result.status) {
        setProjectStatus(result.status.message);
      }
    }
    if (activeTool === "polygon" || activeTool === "triangle") {
      if (activeTool === "triangle") {
        const next = polygonDraft.includes(pointId) ? polygonDraft : [...polygonDraft, pointId];
        if (next.length >= 3) {
          const trianglePoints = next.slice(0, 3);
          recordWorkspaceStep("Create triangle", "3 vertices");
          setConstruction((current) => solveConstruction(buildTriangleCompletion(current, trianglePoints).construction));
          setPolygonDraft([]);
        } else {
          const result = buildPolygonDraftUpdate(constructionContext, polygonDraft, pointId);
          setPolygonDraft(result.polygonDraft ?? next);
          if (result.status) setProjectStatus(result.status.message);
        }
        return;
      }

      const closesPolygon = polygonDraft.length >= 3 && pointId === polygonDraft[0];
      if (closesPolygon) {
        recordWorkspaceStep("Create polygon", `${polygonDraft.length} vertices`);
        setConstruction((current) => solveConstruction(buildPolygonCompletion(current, polygonDraft).construction));
        setPolygonDraft([]);
        return;
      }
      if (polygonDraft.includes(pointId)) return;
      const result = buildPolygonDraftUpdate(constructionContext, polygonDraft, pointId);
      setPolygonDraft(result.polygonDraft ?? [...polygonDraft, pointId]);
      if (result.status) setProjectStatus(result.status.message);
    }
    if (activeTool === "parallel" || activeTool === "perpendicular") {
      const next = [...selectedPointIds, pointId].slice(-3);
      setSelectedPointIds(next);
      if (next.length === 3 && next[0] !== next[1] && next[2] !== next[0] && next[2] !== next[1]) {
        recordWorkspaceStep(`Create ${activeTool}`, `Through ${labelForPoint(constructionContext, next[2])}`);
        setConstruction((current) => solveConstruction(buildParallelPerpendicularFromPoints(current, activeTool, next).construction));
        setSelectedPointIds([]);
      }
    }
    if (activeTool === "midpoint" || activeTool === "fixed-length") {
      const next = [...selectedPointIds, pointId].slice(-2);
      setSelectedPointIds(next);
      if (next.length === 2 && next[0] !== next[1]) {
        recordWorkspaceStep(activeTool === "midpoint" ? "Create midpoint" : "Fix length", `${labelForPoint(constructionContext, next[0])}${labelForPoint(constructionContext, next[1])}`);
        setConstruction((current) => {
          const result = activeTool === "midpoint"
            ? buildMidpointConstruction(current, next)
            : buildFixedLengthSegmentConstruction(current, next[0], next[1]);
          return solveConstruction(result.construction);
        });
        setSelectedPointIds([]);
      }
    }
    if (activeTool === "on-circle") {
      recordWorkspaceStep("Constrain point to circle", labelForPoint(constructionContext, pointId));
      setConstruction((current) => solveConstruction(buildPointOnCircleConstraint(current, pointId).construction, pointId));
      setSelectedPointIds([]);
    }
    if (activeTool === "intersect") {
      recordWorkspaceStep("Create intersection", "Intersection of latest two lines.");
      setConstruction((current) => solveConstruction(buildIntersectionConstruction(current).construction));
      setSelectedPointIds([]);
    }
    if (activeTool === "perpendicular-bisector") {
      const next = [...selectedPointIds, pointId].slice(-2);
      setSelectedPointIds(next);
      if (next.length === 2 && next[0] !== next[1]) {
        recordWorkspaceStep("Create perpendicular bisector", `${labelForPoint(constructionContext, next[0])}${labelForPoint(constructionContext, next[1])}`);
        setConstruction((current) => addPerpendicularBisector(current, next[0], next[1]));
        setSelectedPointIds([]);
      }
    }
    if (activeTool === "angle-bisector" || activeTool === "arc" || activeTool === "sector" || activeTool === "compass" || activeTool === "mirror" || activeTool === "reflect" || activeTool === "translate") {
      const needed = 3;
      const next = [...selectedPointIds, pointId].slice(-needed);
      setSelectedPointIds(next);
      if (next.length === needed && new Set(next).size === needed) {
        const toolLabel = activeTool === "reflect" ? "mirror" : activeTool;
        recordWorkspaceStep(`Create ${toolLabel}`, next.map((id) => labelForPoint(constructionContext, id)).join(", "));
        setConstruction((current) => {
          if (activeTool === "angle-bisector") return addAngleBisector(current, next[0], next[1], next[2]);
          if (activeTool === "arc" || activeTool === "sector") return addArcOrSector(current, next[0], next[1], next[2], activeTool === "sector");
          if (activeTool === "compass") return solveConstruction(buildCompassCopyConstruction(current, next[0], next[1], next[2]).construction);
          if (activeTool === "mirror" || activeTool === "reflect") return solveConstruction(buildMirrorTransformPayload(current, next[0], next[1], next[2]).construction);
          return solveConstruction(buildTranslateTransformPayload(current, next[0], next[1], next[2]).construction);
        });
        setSelectedPointIds([]);
        setProjectStatus(`${geometryToolLabel(toolLabel)} created from ${needed} points.`);
      } else {
        setProjectStatus(`${geometryToolLabel(activeTool)}: pick ${needed - next.length} more point${needed - next.length === 1 ? "" : "s"}.`);
      }
    }
    if (activeTool === "rotate" || activeTool === "dilate") {
      const needed = 2;
      const next = [...selectedPointIds, pointId].slice(-needed);
      setSelectedPointIds(next);
      if (next.length === needed && next[0] !== next[1]) {
        recordWorkspaceStep(`Create ${activeTool}`, `${labelForPoint(constructionContext, next[0])} about ${labelForPoint(constructionContext, next[1])}`);
        setConstruction((current) => solveConstruction(activeTool === "rotate"
          ? buildRotateTransformPayload(current, next[0], next[1], 45).construction
          : buildDilateTransformPayload(current, next[0], next[1], 1.5).construction));
        setSelectedPointIds([]);
        setProjectStatus(`${geometryToolLabel(activeTool)} created. First point transformed around the second point.`);
      } else {
        setProjectStatus(`${geometryToolLabel(activeTool)}: pick the center point.`);
      }
    }
    if (activeTool === "tangent" || activeTool === "polar" || activeTool === "locus") {
      recordWorkspaceStep(`Create ${activeTool}`, labelForPoint(constructionContext, pointId));
      setConstruction((current) => {
        if (activeTool === "tangent") return addTangentAtPoint(current, pointId);
        if (activeTool === "polar") return addPolarLine(current, pointId);
        if (activeTool === "locus") return addLocusForPoint(current, pointId);
        return current;
      });
      setSelectedPointIds([]);
    }
    if (activeTool === "regular-polygon") {
      const next = [...selectedPointIds, pointId].slice(-2);
      setSelectedPointIds(next);
      if (next.length === 2 && next[0] !== next[1]) {
        recordWorkspaceStep("Create regular polygon", `${labelForPoint(constructionContext, next[0])}${labelForPoint(constructionContext, next[1])}`);
        setConstruction((current) => solveConstruction(buildRegularPolygonConstruction(current, next, 5).construction));
        setSelectedPointIds([]);
      }
    }
  };

  const handleBoardPointerMove = (event: PointerEvent<SVGSVGElement>) => {
    if (geometryPanRef.current) {
      if (event.pointerType === "touch") event.preventDefault();
      const rect = event.currentTarget.getBoundingClientRect();
      const start = geometryPanRef.current;
      const scaleX = start.camera.width / rect.width;
      const scaleY = start.camera.height / rect.height;
      setGeometryCamera({
        ...start.camera,
        x: start.camera.x - (event.clientX - start.clientX) * scaleX,
        y: start.camera.y - (event.clientY - start.clientY) * scaleY,
      });
      return;
    }
    if (geometryFreehandRef.current) {
      if (event.pointerType === "touch") event.preventDefault();
      const point = clientToBoard(event);
      if (!point) return;
      const freehandId = geometryFreehandRef.current;
      setConstruction((current) => ({
        ...current,
        loci: current.loci.map((locus) => {
          if (locus.id !== freehandId) return locus;
          const previous = locus.points[locus.points.length - 1];
          if (previous && Math.hypot(point.x - previous.x, point.y - previous.y) < 2) return locus;
          return { ...locus, points: [...locus.points, point] };
        }),
      }));
      return;
    }
    if (!dragPointId && !dragGeometry && !dragImageId) return;
    if (event.pointerType === "touch") event.preventDefault();
    const point = clientToBoard(event);
    if (!point) return;
    if (dragImageId) {
      setWorkspaceImages((current) => current.map((image) => image.id === dragImageId ? { ...image, x: roundTo(point.x - image.width / 2, 2), y: roundTo(point.y - image.height / 2, 2) } : image));
    }
    if (dragPointId) {
      setConstruction((current) => recordTraceSampleForPoint(solveConstruction({
        ...current,
        points: current.points.map((item) => item.id === dragPointId ? { ...item, x: point.x, y: point.y } : item),
      }, dragPointId), dragPointId));
    }
    if (dragGeometry) {
      const dx = point.x - dragGeometry.last.x;
      const dy = point.y - dragGeometry.last.y;
      const pointIds = pointIdsForObject(construction, dragGeometry.object);
      setConstruction((current) => {
        const solved = solveConstruction({
          ...current,
          points: current.points.map((item) => pointIds.includes(item.id) ? { ...item, x: item.x + dx, y: item.y + dy } : item),
        });
        return pointIds.reduce((next, pointId) => recordTraceSampleForPoint(next, pointId), solved);
      });
      setDragGeometry({ ...dragGeometry, last: point });
    }
  };

  const gestureGeometryTransforms=useRef(new Map<string,ReturnType<typeof identityTransform>>());
  const immersiveGeometry = useImmersiveAdapter(workspaceView === "geometry" ? {
    clearSelection:()=>{setSelectedGeometry(null);setSelectedPointIds([]);},
    gestureObjects:()=>{
      const objects:SelectedGeometryObject[]=[...construction.points.map(o=>({type:'point' as const,id:o.id})),...construction.lines.map(o=>({type:'line' as const,id:o.id})),...construction.circles.map(o=>({type:'circle' as const,id:o.id})),...construction.polygons.map(o=>({type:'polygon' as const,id:o.id})),...construction.arcs.map(o=>({type:'arc' as const,id:o.id}))];
      const registered=objects.map((object,index)=>{
       const ids=object.type==='point'?[object.id]:pointIdsForObject(construction,object);const locked=lockedGeometryIds.includes(object.id)||ids.some(id=>lockedGeometryIds.includes(id));
       const name=object.type==='point'?`Point ${construction.points.find(p=>p.id===object.id)?.label||index+1}`:object.type==='polygon'?(ids.length===3?'Triangle':`Polygon (${ids.length} sides)`):object.type[0].toUpperCase()+object.type.slice(1);
       return {id:object.id,name,kind:'2d' as const,capabilities:{move:!locked,scale:!locked&&object.type!=='point',rotate:!locked&&object.type!=='point',tilt:false,reset:!locked},
        read:()=>gestureGeometryTransforms.current.get(object.id)??identityTransform(),
        write:(t:ReturnType<typeof identityTransform>)=>{const old=gestureGeometryTransforms.current.get(object.id)??identityTransform();const d=transformDelta(t,old);gestureGeometryTransforms.current.set(object.id,t);setConstruction(current=>{const ps=current.points.filter(p=>ids.includes(p.id));if(!ps.length)return current;const cx=ps.reduce((n,p)=>n+p.x,0)/ps.length,cy=ps.reduce((n,p)=>n+p.y,0)/ps.length;const a=-d.rotation[2],cos=Math.cos(a),sin=Math.sin(a),units=geometryGraphSettings.gridSpacing??40;return {...current,points:current.points.map(p=>{if(!ids.includes(p.id))return p;const x=(p.x-cx)*d.scale,y=(p.y-cy)*d.scale;return {...p,x:cx+x*cos-y*sin+d.position[0]*units,y:cy+x*sin+y*cos-d.position[1]*units};})};});},
        captureReset:()=>{const saved=construction.points.filter(p=>ids.includes(p.id)).map(p=>({...p}));const original=gestureGeometryTransforms.current.get(object.id)??identityTransform();return()=>{gestureGeometryTransforms.current.set(object.id,original);setConstruction(current=>({...current,points:current.points.map(p=>saved.find(q=>q.id===p.id)??p)}));};},
        select:(selected:boolean)=>{if(selected){setSelectedGeometry(object);setSelectedPointIds(ids);}else{setSelectedGeometry(null);setSelectedPointIds([]);}},
       };
      });
      const axes=[...svgRef.current?.querySelectorAll<SVGElement>("[data-gesture-axis]")??[]].map(el=>({id:`geometry-${el.dataset.gestureAxis}`,name:el.dataset.gestureAxis!,kind:"2d" as const,capabilities:{move:false,scale:false,rotate:false,tilt:false,reset:false},read:identityTransform,write:()=>undefined,select:(selected:boolean)=>el.classList.toggle("gesture-axis-selected",selected)}));
      return [...registered,...axes];
    },
    kind: "2d", boardExtent:()=>[geometryCamera.width/(geometryGraphSettings.gridSpacing??40),geometryCamera.height/(geometryGraphSettings.gridSpacing??40)],element: () => svgRef.current,
    targets: () => {
      const board = svgRef.current; const rect = board?.getBoundingClientRect(); const matrix = board?.getScreenCTM();
      if (!rect || !matrix) return [];
      const targetPoint=(id:string,x:number,y:number,radius:number,locked:boolean,kind:"body"|"vertex"|"edge")=>{const screen=new DOMPoint(x,y).matrixTransform(matrix);return screenTarget(id,(screen.x-rect.left)/rect.width,(screen.y-rect.top)/rect.height,radius,locked,kind);};
      const points=construction.points.filter(p=>p.style?.visible!==false).map(p=>{const t=targetPoint(p.id,p.x,p.y,.035,lockedGeometryIds.includes(p.id),"vertex");t.allowedInteractions={translate:true};return t;});
      const objects:SelectedGeometryObject[]=[...construction.lines.map(o=>({type:"line" as const,id:o.id})),...construction.circles.map(o=>({type:"circle" as const,id:o.id})),...construction.polygons.map(o=>({type:"polygon" as const,id:o.id})),...construction.arcs.map(o=>({type:"arc" as const,id:o.id}))];
      for(const object of objects){const ids=pointIdsForObject(construction,object),ps=construction.points.filter(p=>ids.includes(p.id));if(!ps.length)continue;
        const x=ps.reduce((sum,p)=>sum+p.x,0)/ps.length,y=ps.reduce((sum,p)=>sum+p.y,0)/ps.length;
        const target=targetPoint(object.id,x,y,.055,lockedGeometryIds.includes(object.id)||ids.some(id=>lockedGeometryIds.includes(id)),"body");
        for(let i=0;i<ps.length;i++){const from=ps[i],to=ps[(i+1)%ps.length];for(let j=1;j<8;j++){const zone=targetPoint(object.id,from.x+(to.x-from.x)*j/8,from.y+(to.y-from.y)*j/8,.025,false,"edge");target.preferredGrabZones.push({...zone.preferredGrabZones[0],id:`${object.id}:${i}:${j}`});}}
        if(object.type==="circle"){const circle=construction.circles.find(c=>c.id===object.id)!,center=construction.points.find(p=>p.id===circle.center)!,edge=construction.points.find(p=>p.id===circle.edge)!;const radius=Math.hypot(edge.x-center.x,edge.y-center.y);for(let i=0;i<24;i++){const t=i*Math.PI/12,zone=targetPoint(object.id,center.x+radius*Math.cos(t),center.y+radius*Math.sin(t),.025,false,"edge");target.preferredGrabZones.push({...zone.preferredGrabZones[0],id:`${object.id}:rim:${i}`});}}
        points.push(target);
      }
      return points;
    },
    transform: () => identityTransform(),
    select: id => { const type=construction.points.some(p=>p.id===id)?"point":construction.lines.some(p=>p.id===id)?"line":construction.circles.some(p=>p.id===id)?"circle":construction.polygons.some(p=>p.id===id)?"polygon":"arc";setSelectedGeometry({type,id});setSelectedPointIds(type==="point"?[id]:pointIdsForObject(construction,{type,id})); },
    apply: (state,result,previous) => {
      if (!result.transform || !state.targetObjectId || lockedGeometryIds.includes(state.targetObjectId)) return;
      const id=state.targetObjectId;const delta=transformDelta(result.transform,previous);
      const dx=delta.position[0]*geometryCamera.width/8,dy=-delta.position[1]*geometryCamera.height/8;
      const type=construction.points.some(p=>p.id===id)?"point":construction.lines.some(p=>p.id===id)?"line":construction.circles.some(p=>p.id===id)?"circle":construction.polygons.some(p=>p.id===id)?"polygon":"arc";
      const ids=type==="point"?[id]:pointIdsForObject(construction,{type,id});if(ids.some(i=>lockedGeometryIds.includes(i)))return;
      setConstruction(current=>{const ps=current.points.filter(p=>ids.includes(p.id));const center={x:ps.reduce((sum,p)=>sum+p.x,0)/Math.max(1,ps.length),y:ps.reduce((sum,p)=>sum+p.y,0)/Math.max(1,ps.length)};const angle=-delta.rotation[2],cos=Math.cos(angle),sin=Math.sin(angle);
        const next={...current,points:current.points.map(p=>{if(!ids.includes(p.id))return p;const x=(p.x-center.x)*delta.scale,y=(p.y-center.y)*delta.scale;return {...p,x:center.x+x*cos-y*sin+dx,y:center.y+x*sin+y*cos+dy};})};
        return ids.reduce((model,pointId)=>recordTraceSampleForPoint(model,pointId),solveConstruction(next,ids[0]));});
    },
    navigate: (delta,scale) => setGeometryCamera(c => ({...c,x:c.x-delta[0]*c.width,y:c.y-delta[1]*c.height,width:Math.min(MAX_GEOMETRY_CAMERA_WIDTH,Math.max(80,c.width/scale)),height:Math.min(MAX_GEOMETRY_CAMERA_HEIGHT,Math.max(60,c.height/scale))})),
  } : null);

  const clientToBoard = (event: PointerEvent<SVGSVGElement>) => {
    const svg = svgRef.current;
    if (!svg) return null;
    const matrix = svg.getScreenCTM();
    if (!matrix) return null;
    const point = svg.createSVGPoint();
    point.x = event.clientX;
    point.y = event.clientY;
    const transformed = point.matrixTransform(matrix.inverse());
    return { x: transformed.x, y: transformed.y };
  };

  const undoConstruction = () => {
    setConstruction((current) => {
      if (current.polygons.length) return { ...current, polygons: current.polygons.slice(0, -1) };
      if (current.circles.length) return { ...current, circles: current.circles.slice(0, -1) };
      if (current.lines.length) return { ...current, lines: current.lines.slice(0, -1) };
      if (current.points.length) return { ...current, points: current.points.slice(0, -1) };
      return current;
    });
  };

  const handlePlotsChange = (nextPlots: PlotItem[]) => {
    recordWorkspaceStep("Edit graph object", "Graph list changed from graph panel.");
    setPlots(nextPlots);
  };

  const updateSelectedGeometryStyle = (patch: GeoStyle) => {
    if (!selectedGeometry) return;
    recordWorkspaceStep("Edit geometry style", `${selectedGeometry.type} properties changed.`);
    setConstruction((current) => patchGeometryObject(current, selectedGeometry, { style: patch }));
  };

  const updateSelectedPoint = (patch: Partial<GeoPoint>) => {
    if (!selectedGeometry || selectedGeometry.type !== "point") return;
    recordWorkspaceStep("Edit point definition", `${labelForPoint(construction, selectedGeometry.id)} changed.`);
    setConstruction((current) => recordTraceSampleForPoint(solveConstruction({ ...current, points: current.points.map((point) => point.id === selectedGeometry.id ? { ...point, ...patch } : point) }, selectedGeometry.id), selectedGeometry.id));
  };

  const updateSelectedPointByDelta = (pointId: string, dx: number, dy: number) => {
    if (lockedGeometryIds.includes(pointId)) return;
    setConstruction((current) => recordTraceSampleForPoint(solveConstruction({
      ...current,
      points: current.points.map((point) => point.id === pointId ? { ...point, x: point.x + dx, y: point.y + dy } : point),
    }, pointId), pointId));
  };

  const updateSelectedImage = (patch: Partial<WorkspaceImage>) => {
    if (!selectedImageId) return;
    recordWorkspaceStep("Edit image", `${workspaceImages.find((image) => image.id === selectedImageId)?.name ?? "Image"} properties changed.`);
    setWorkspaceImages((current) => current.map((image) => image.id === selectedImageId ? { ...image, ...patch } : image));
  };

  const deleteSelectedImage = () => {
    if (!selectedImageId) return;
    recordWorkspaceStep("Delete image", `${workspaceImages.find((image) => image.id === selectedImageId)?.name ?? "Image"} removed.`);
    setWorkspaceImages((current) => current.filter((image) => image.id !== selectedImageId));
    setSelectedImageId(null);
  };

  const updateSelectedCircleRadius = (radiusUnits: number) => {
    if (!selectedGeometry || selectedGeometry.type !== "circle") return;
    recordWorkspaceStep("Edit circle definition", `Radius set to ${radiusUnits}.`);
    setConstruction((current) => {
      const circle = current.circles.find((item) => item.id === selectedGeometry.id);
      const center = circle ? pointById(current.points, circle.center) : null;
      const edge = circle ? pointById(current.points, circle.edge) : null;
      if (!circle || !center || !edge) return current;
      const vector = normalize(edge.x - center.x, edge.y - center.y);
      return solveConstruction({
        ...current,
        points: current.points.map((point) => point.id === edge.id ? { ...point, x: center.x + vector.x * radiusUnits * 40, y: center.y + vector.y * radiusUnits * 40 } : point),
      });
    });
  };

  const resolveSelectedGeometryObject = (object = selectedGeometry) =>
    object ?? geometryObjectForPointIds(construction, selectedPointIds);

  const deleteGeometryObject = (object = resolveSelectedGeometryObject()) => {
    if (!object) return;
    recordWorkspaceStep("Delete geometry object", `${object.type} removed.`);
    setConstruction((current) => {
      const result = deleteGeometrySelection(current, object);
      return result.ok ? result.value : current;
    });
    setSelectedGeometry(null);
    setContextMenu(null);
  };

  const zoomGeometry = (direction: "in" | "out", anchor?: { x: number; y: number }) => {
    setGeometryCamera((current) => {
      const factor = direction === "in" ? 0.8 : 1.25;
      const nextWidth = Math.max(16, Math.min(MAX_GEOMETRY_CAMERA_WIDTH, current.width * factor));
      const nextHeight = Math.max(10.5, Math.min(MAX_GEOMETRY_CAMERA_HEIGHT, current.height * factor));
      const focus = anchor ?? { x: current.x + current.width / 2, y: current.y + current.height / 2 };
      return {
        x: focus.x - (focus.x - current.x) * (nextWidth / current.width),
        y: focus.y - (focus.y - current.y) * (nextHeight / current.height),
        width: nextWidth,
        height: nextHeight,
      };
    });
  };

  const resetGeometryView = () => setGeometryCamera({ x: 0, y: 0, width: 640, height: 420 });
  const fitGeometryView = () => {
    const visiblePoints = construction.points.filter((point) => point.style?.visible !== false);
    const imageCorners = workspaceImages
      .filter((image) => image.visible !== false)
      .flatMap((image) => [
        { x: image.x, y: image.y },
        { x: image.x + image.width, y: image.y + image.height },
      ]);
    const points = [...visiblePoints, ...imageCorners];
    if (!points.length) {
      resetGeometryView();
      return;
    }
    const minX = Math.min(...points.map((point) => point.x));
    const maxX = Math.max(...points.map((point) => point.x));
    const minY = Math.min(...points.map((point) => point.y));
    const maxY = Math.max(...points.map((point) => point.y));
    const padding = Math.max(48, Math.max(maxX - minX, maxY - minY) * 0.12);
    let width = Math.max(160, maxX - minX + padding * 2);
    let height = Math.max(105, maxY - minY + padding * 2);
    const boardRatio = 640 / 420;
    if (width / height > boardRatio) height = width / boardRatio;
    else width = height * boardRatio;
    setGeometryCamera({
      x: (minX + maxX) / 2 - width / 2,
      y: (minY + maxY) / 2 - height / 2,
      width,
      height,
    });
  };
  const handleGeometryWheel = (event: WheelEvent<SVGSVGElement>) => {
    event.preventDefault();
    const anchor = clientToBoard(event as unknown as PointerEvent<SVGSVGElement>);
    zoomGeometry(event.deltaY < 0 ? "in" : "out", anchor ?? undefined);
  };
  const handleGeometryKeyDown = (event: KeyboardEvent<SVGSVGElement>) => {
    if ((event.ctrlKey || event.metaKey) && (event.key === "+" || event.key === "=" || event.key === "-")) {
      event.preventDefault();
      zoomGeometry(event.key === "-" ? "out" : "in");
    } else if (event.key === "0") {
      event.preventDefault();
      resetGeometryView();
    }
  };

  const duplicateGeometryObject = (object = selectedGeometry) => {
    if (!object) return;
    recordWorkspaceStep("Duplicate geometry object", `${object.type} duplicated.`);
    setConstruction((current) => duplicateGeometryObjectInConstruction(current, object));
    setContextMenu(null);
  };

  const restoreGeometryObject = (object = selectedGeometry) => {
    if (!object) return;
    recordWorkspaceStep("Restore geometry object", `${object.type} style restored.`);
    setConstruction((current) => patchGeometryObject(current, object, { style: {} }));
    setContextMenu(null);
  };

  const toggleGeometryLock = (object = resolveSelectedGeometryObject()) => {
    if (!object) return;
    recordWorkspaceStep("Toggle geometry lock", `${object.type} lock changed.`);
    setLockedGeometryIds((current) => current.includes(object.id) ? current.filter((id) => id !== object.id) : [...current, object.id]);
    setContextMenu(null);
  };

  const toggleSelectedGeometryVisibility = () => {
    const selection = resolveSelectedGeometryObject();
    if (!selection) return;
    const object = geometryObjectBySelection(construction, selection);
    setSelectedGeometry(selection);
    updateSelectedGeometryStyle({ ...(object?.style ?? {}), visible: object?.style?.visible === false });
  };

  const toggleGeometryVisibility = (object: SelectedGeometryObject) => {
    const geometry = geometryObjectBySelection(construction, object);
    recordWorkspaceStep("Toggle geometry visibility", `${object.type} visibility changed.`);
    setConstruction((current) => patchGeometryObject(current, object, { style: { ...(geometry?.style ?? {}), visible: geometry?.style?.visible === false } }));
    setSelectedGeometry(object);
    setSelectedImageId(null);
  };

  const setSelectedGeometryTrace = (enabled: boolean) => {
    const selection = resolveSelectedGeometryObject();
    if (!selection) return;
    setSelectedGeometry(selection);
    recordWorkspaceStep(enabled ? "Start geometry trace" : "Stop geometry trace", `${selection.type} trace ${enabled ? "enabled" : "stopped"}.`);
    setConstruction((current) => setGeometryTrace(current, selection, enabled));
  };

  const clearGeometryTrace = () => {
    recordWorkspaceStep("Clear geometry trace", "Generated trace paths removed and trace flags stopped.");
    setConstruction(clearTracePaths);
  };

  const add3dSceneObject = (baseId: ThreeObjectId, options: { solid?: SolidKind; surface?: SurfaceKind; label?: string } = {}) => {
    const render = addedRenderKindForBase(baseId);
    const count = added3dObjects.length + 1;
    const id = `scene3d-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const baseTransform = defaultTransforms3d[baseId];
    const label = options.label ?? options.solid ?? options.surface ?? threeObjectLabels[baseId];
    const offset = ((count - 1) % 5 - 2) * 0.72;
    const rowOffset = Math.floor((count - 1) / 5) * 0.55;
    const nextTransform: Transform3D = {
      ...baseTransform,
      name: `${label} ${count}`,
      visible: true,
      color: colors[count % colors.length],
      position: [roundTo(baseTransform.position[0] + offset, 2), roundTo(baseTransform.position[1] + 0.1, 2), roundTo(baseTransform.position[2] + rowOffset, 2)],
      dimensions: baseTransform.dimensions ? [...baseTransform.dimensions] as [number, number, number] : undefined,
    };
    const next: Added3DObject = { id, label: nextTransform.name ?? `${label} ${count}`, baseId, render, solid: options.solid ?? threeObjectSolidMap[baseId], surface: options.surface, transform: nextTransform };
    recordWorkspaceStep("Add 3D object", `${next.label} added to the 3D scene.`);
    setAdded3dObjects((current) => [...current, next]);
    setSelected3d(id);
    setShowSurface((current) => current || render === "surface");
    setShowSolid((current) => current || render === "solid");
    return id;
  };

  const immersive3dTransaction = useRef(false);
  const geometryAwareness=useRef({construction,selectedGeometry});geometryAwareness.current={construction,selectedGeometry};
  useEffect(()=>{if(workspaceView!=='geometry')return;return registerRoboSpatialProvider('geometry2d',anchor=>readSVGSpatialObjects(svgRef.current,anchor,(id,kind)=>{const c=geometryAwareness.current.construction;let label:string|undefined;if(kind==='point')label=c.points.find(p=>p.id===id)?.label;else if(kind==='circle'){const circle=c.circles.find(o=>o.id===id);const center=c.points.find(p=>p.id===circle?.center);label=center?`Circle ${center.label}`:undefined;}else if(kind==='line'){const line=c.lines.find(o=>o.id===id);const a=c.points.find(p=>p.id===line?.a),b=c.points.find(p=>p.id===line?.b);label=a&&b?`${a.label}${b.label}`:undefined;}else if(kind==='polygon'){const index=c.polygons.findIndex(o=>o.id===id);if(index>=0)label=`Polygon ${index+1}`;}return {label,selected:geometryAwareness.current.selectedGeometry?.id===id};}));},[workspaceView]);
  useEffect(()=>{if(workspaceView!=='geometry')return;return registerRoboUnprojector('geometry2d',point=>{const svg=svgRef.current,matrix=svg?.getScreenCTM();if(!svg||!matrix)return;const rect=svg.getBoundingClientRect();if(point.x<rect.left||point.x>rect.right||point.y<rect.top||point.y>rect.bottom)return;const p=new DOMPoint(point.x,point.y).matrixTransform(matrix.inverse());return [(p.x-320)/40,(210-p.y)/40];});},[workspaceView]);
  useEffect(()=>{if(workspaceView!=='geometry')return;return registerRoboProjector('geometry2d',p=>svgClientPoint(svgRef.current,{x:320+p[0]*40,y:210-p[1]*40}));},[workspaceView]);
  useEffect(()=>{if(workspaceView!=='geometry'||!selectedGeometry)return;const point=construction.points.find(p=>p.id===selectedGeometry.id);const object=nativeGeometryCommands(construction).find(o=>o.objectId===selectedGeometry.id);const boardPoint=point??(object?.points[0]?{x:320+object.points[0][0]*40,y:210-object.points[0][1]*40}:undefined);if(boardPoint)roboEvents.emit({type:'workspace',kind:'selection',target:()=>svgClientPoint(svgRef.current,boardPoint)});},[workspaceView,selectedGeometry,construction]);
  useIntelligenceWorkspace(workspaceView === '3d' ? 'geometry3d' : 'geometry2d', command => {
    if(command.roboClearAll){recordWorkspaceStep('Clear all workspace objects',command.kind);if(workspaceView==='geometry'){setConstruction(structuredClone(initialConstruction));setLockedGeometryIds([]);setSelectedGeometry(null);setSelectedPointIds([]);}else{setDeletedBase3dIds([...threeBaseIds]);setAdded3dObjects([]);setSelected3d('');setDrag3d(null);}return;}
    if(workspaceView==='geometry'&&command.roboLocked!==undefined){const ids=command.roboNativeIds?[...command.roboNativeIds.points,...(command.roboNativeIds.shape?[command.roboNativeIds.shape]:[])]:[...command.points.map((_,i)=>`${command.objectId}-p${i}`),`${command.objectId}-shape`];setLockedGeometryIds(previous=>command.roboLocked?[...new Set([...previous,...ids])]:previous.filter(id=>!ids.includes(id)));}
    if(command.roboControl==='deselect'){setSelectedGeometry(null);setSelectedPointIds([]);setSelected3d('');return;}
    if(command.roboControl==='select'){
      if(workspaceView==='geometry')setSelectedGeometry({type:command.kind==='circle'?'circle':['line','ray','vector'].includes(command.kind)?'line':command.kind==='point'?'point':'polygon',id:command.roboNativeIds?.shape??(command.roboNativeIds?command.roboNativeIds.points[0]:`${command.objectId}-${command.kind==='point'?'p0':'shape'}`)});
      else setSelected3d(command.objectId!);return;
    }
    if(command.roboControl==='delete'||command.roboControl==='visibility'){
      recordWorkspaceStep(command.roboControl==='delete'?'Delete Robo object':'Set Robo visibility',command.kind);
      if(workspaceView==='geometry')setConstruction(current=>addIntelligenceGeometry(current,command));
      else if(command.roboControl==='delete')setAdded3dObjects(current=>current.filter(object=>object.id!==command.objectId));
      else setAdded3dObjects(current=>current.map(object=>object.id===command.objectId?{...object,transform:{...object.transform,visible:command.roboVisible??true}}:object));
      return;
    }
    if (workspaceView === 'geometry') {
      if(command.action==='update'&&!construction.points.some(p=>command.roboNativeIds?command.roboNativeIds.points.includes(p.id):p.id.startsWith(`${command.objectId}-`))&&!construction.loci.some(p=>p.id.startsWith(`${command.objectId}-`)))return 'The last Ruhi object was removed. Create an object again before editing it.';
      recordWorkspaceStep('Draw with offline intelligence', command.kind);
      setConstruction(current=>solveConstruction(addIntelligenceGeometry(current,command)));
      return;
    }
    const id=command.objectId??crypto.randomUUID();
    if(command.action==='update'&&!added3dObjects.some(object=>object.id===id))return 'The last Ruhi object was removed. Create an object again before editing it.';
    const baseId:ThreeObjectId=['line','ray','vector'].includes(command.kind)?'line3d':command.kind==='point'?'point':'solid';
    recordWorkspaceStep(command.action==='update'?'Edit Robo object':'Create Robo object',command.kind);
      const next:Added3DObject={id,label:command.roboLabel??command.kind,baseId,render:['line','ray','vector'].includes(command.kind)?'line3d':command.kind==='point'?'point':'solid',nlpCommand:command,transform:{...defaultTransforms3d[baseId],...commandTransform3d(command),scale:command.scale??1,visible:command.roboVisible??true,name:command.kind,locked:command.roboLocked??false}};
    setAdded3dObjects(current=>[...current.filter(object=>object.id!==id),next]);setSelected3d(id);setShowSolid(true);
  }, !embedded && (workspaceView==='geometry'||workspaceView==='3d'), command=>{
    if(workspaceView==='geometry') {
      if(['ray','vector'].includes(command.kind)&&!construction.lines.some(line=>line.id===(command.roboNativeIds?.shape??`${command.objectId}-shape`)&&(line.kind??line.style?.label)===command.kind))return undefined;
        const actual=command.roboNativeIds?command.roboNativeIds.points.flatMap(id=>construction.points.filter(point=>point.id===id)):construction.points.filter(point=>point.id.startsWith(`${command.objectId}-p`));
      if(!actual.length&&!construction.loci.some(locus=>locus.id.startsWith(`${command.objectId}-`)))return undefined;
      const vertices=actual.map(point=>[(point.x-320)/40,(210-point.y)/40,0]);
      if(command.kind==='circle'&&vertices.length>=2) {
        return {command:{...command,points:[vertices[0].slice(0,2)],radius:Math.hypot(vertices[1][0]-vertices[0][0],vertices[1][1]-vertices[0][1]),scale:1,rotation:[0,0,0]}};
      }
        const materialized=['line','ray','vector'].includes(command.kind)||command.kind==='point'?{...command,points:vertices.map(p=>p.slice(0,2)),rotation:[0,0,0] as [number,number,number],scale:1}:command;
        return {command:materialized,vertices:vertices.length?vertices:undefined};
    }
    const actual=added3dObjects.find(object=>object.id===command.objectId);
    if(!actual)return undefined;
      return {command:{...command,points:['ray','vector','triangle','polygon'].includes(command.kind)?command.points.map(p=>p.map((n,i)=>n+actual.transform.position[i]-commandTransform3d(command).position[i])):command.kind==='line'?command.points:[actual.transform.position],rotation:command.kind==='line'?command.rotation:actual.transform.rotation,scale:actual.transform.scale,color:actual.transform.color,roboVisible:actual.transform.visible}};
    },()=>workspaceView==='geometry'?{commands:nativeGeometryCommands(construction,id=>isKnownRoboObject('geometry2d',id)).map(command=>({...command,roboLocked:command.roboNativeIds?.points.some(id=>lockedGeometryIds.includes(id))??false})),selectedIds:selectedGeometry?[(isKnownRoboObject('geometry2d',selectedGeometry.id)?selectedGeometry.id.replace(/-(?:shape|p\d+)$/,''):selectedGeometry.id)]:undefined}:{commands:added3dObjects.flatMap(o=>o.nlpCommand?[{...o.nlpCommand,objectId:o.id,points:['ray','vector','triangle','polygon'].includes(o.nlpCommand.kind)?o.nlpCommand.points.map(p=>p.map((n,i)=>n+o.transform.position[i]-commandTransform3d(o.nlpCommand!).position[i])):o.nlpCommand.kind==='line'?o.nlpCommand.points:[o.transform.position],rotation:o.nlpCommand.kind==='line'?o.nlpCommand.rotation:o.transform.rotation,scale:o.transform.scale,roboLocked:o.transform.locked}]:[]),selectedIds:selected3d?[selected3d]:undefined});
  useEffect(() => {
    const begin = () => { if(workspaceView === "3d" || workspaceView === "geometry") { recordWorkspaceStep("Hand gesture", "Transform object with hand controls."); immersive3dTransaction.current=true; } };
    const end = () => { immersive3dTransaction.current=false; };
    window.addEventListener("immersive-transaction-start",begin);window.addEventListener("immersive-transaction-end",end);
    return () => {window.removeEventListener("immersive-transaction-start",begin);window.removeEventListener("immersive-transaction-end",end);};
  }, [workspaceView, transforms3d, added3dObjects]);
  const update3dTransform = (id: string, patch: Partial<Transform3D>) => {
    const currentTransform = isBase3dId(id) ? transforms3d[id] : added3dObjects.find((object) => object.id === id)?.transform;
    const changesGeometry = "position" in patch || "rotation" in patch || "scale" in patch || "dimensions" in patch;
    if (!currentTransform || (currentTransform.locked && changesGeometry)) return;
    if (!immersive3dTransaction.current) recordWorkspaceStep("Edit 3D object", `${currentTransform.name ?? id} transform changed.`);
    if (isBase3dId(id)) setTransforms3d((current) => ({ ...current, [id]: { ...current[id], ...patch } }));
    else setAdded3dObjects((current) => current.map((object) => object.id === id ? { ...object, label: patch.name ?? object.label, transform: { ...object.transform, ...patch } } : object));
  };

  const update3dVector = (id: string, key: "position" | "rotation", index: number, value: number) => {
    const currentTransform = isBase3dId(id) ? transforms3d[id] : added3dObjects.find((object) => object.id === id)?.transform;
    if (!currentTransform || currentTransform.locked) return;
    if (isBase3dId(id)) {
      setTransforms3d((current) => {
        const next = [...current[id][key]] as [number, number, number];
        next[index] = value;
        return { ...current, [id]: { ...current[id], [key]: next } };
      });
      return;
    }
    setAdded3dObjects((current) => current.map((object) => {
      if (object.id !== id) return object;
      const next = [...object.transform[key]] as [number, number, number];
      next[index] = value;
      return { ...object, transform: { ...object.transform, [key]: next } };
    }));
  };

  const apply3dTransformPreset = (preset: Preset3DTransform, id = selected3d) => {
    if (!id) {
      const unsupported = createUnsupportedWorkspaceAction("3D preset", "No 3D object is selected for the preset.", ["Select a 3D object from the scene or object list.", "Use Restore to bring back a hidden base object."]);
      setProjectStatus(unsupported.message);
      return;
    }
    const currentTransform = isBase3dId(id) ? transforms3d[id] : added3dObjects.find((object) => object.id === id)?.transform;
    if (!currentTransform || currentTransform.locked) return;
    const patch: Partial<Transform3D> = {};
    if (preset === "center") patch.position = [0, 0, 0];
    if (preset === "ground") patch.position = [currentTransform.position[0], 0, currentTransform.position[2]];
    if (preset === "unit") patch.dimensions = [1, 1, 1];
    if (preset === "wide") patch.dimensions = [2.6, 1, 1.4];
    if (preset === "tall") patch.dimensions = [1.2, 2.6, 1.2];
    if (preset === "xy-plane") patch.rotation = [0, 0, 0];
    if (preset === "xz-plane") patch.rotation = [-90, 0, 0];
    if (preset === "yz-plane") patch.rotation = [0, 90, 0];
    update3dTransform(id, patch);
    setProjectStatus(`${currentTransform.name ?? id} preset applied.`);
  };

  const restore3dObject = (id = selected3d) => {
    const target = isBase3dId(id) ? transforms3d[id] : added3dObjects.find((object) => object.id === id)?.transform;
    recordWorkspaceStep("Restore 3D object", `${target?.name ?? id} restored.`);
    if (isBase3dId(id)) {
      setDeletedBase3dIds((current) => current.filter((deletedId) => deletedId !== id));
      setTransforms3d((current) => ({ ...current, [id]: defaultTransforms3d[id] }));
    }
    else setAdded3dObjects((current) => current.map((object) => object.id === id ? { ...object, transform: { ...defaultTransforms3d[object.baseId], name: object.label, visible: true, color: object.transform.color } } : object));
    setContextMenu(null);
  };

  const delete3dObject = (id = selected3d) => {
    const target = isBase3dId(id) ? transforms3d[id] : added3dObjects.find((object) => object.id === id)?.transform;
    recordWorkspaceStep("Delete 3D object", `${target?.name ?? id} deleted from the scene.`);
    if (isBase3dId(id)) {
      setDeletedBase3dIds((current) => current.includes(id) ? current : [...current, id]);
      setTransforms3d((current) => ({ ...current, [id]: { ...current[id], visible: false } }));
      if (selected3d === id) {
        setSelected3d(getFirstAvailable3dObjectId([...deletedBase3dIds, id], added3dObjects));
      }
    }
    else {
      setAdded3dObjects((current) => current.filter((object) => object.id !== id));
      if (selected3d === id) {
        setSelected3d(getFirstAvailable3dObjectId(deletedBase3dIds, added3dObjects.filter((object) => object.id !== id)));
      }
    }
    setProjectStatus(`${target?.name ?? id} deleted from the scene.`);
    setContextMenu(null);
  };

  const clear3dObjects = () => {
    if (deletedBase3dIds.length === threeBaseIds.length && added3dObjects.length === 0) return;
    recordWorkspaceStep("Clear 3D scene", "Removed all objects from the 3D scene.");
    setDeletedBase3dIds([...threeBaseIds]);
    setAdded3dObjects([]);
    setSelected3d("");
    setDrag3d(null);
    setProjectStatus("3D scene cleared. Add a shape to begin again.");
  };

  const duplicate3dObject = (id = selected3d) => {
    const existing = isBase3dId(id) ? { baseId: id, render: addedRenderKindForBase(id), solid: threeObjectSolidMap[id], surface: id === "surface" ? surface : undefined, label: transforms3d[id].name ?? threeObjectLabels[id], transform: transforms3d[id] } : added3dObjects.find((object) => object.id === id);
    if (!existing) return;
    recordWorkspaceStep("Duplicate 3D object", `${existing.transform.name ?? existing.label} duplicated.`);
    const count = added3dObjects.length + 1;
    const nextId = `scene3d-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const nextTransform: Transform3D = { ...existing.transform, name: `${existing.label ?? "Object"} copy`, visible: true, position: [roundTo(existing.transform.position[0] + 0.55, 2), roundTo(existing.transform.position[1] + 0.25, 2), roundTo(existing.transform.position[2] + 0.55, 2)], dimensions: existing.transform.dimensions ? [...existing.transform.dimensions] as [number, number, number] : undefined };
    const next: Added3DObject = { id: nextId, label: nextTransform.name ?? `Object ${count}`, baseId: existing.baseId, render: existing.render, solid: existing.solid, surface: existing.surface, transform: nextTransform };
    setAdded3dObjects((current) => [...current, next]);
    setSelected3d(nextId);
    setContextMenu(null);
  };

  const saveConstruction = () => {
    localStorage.setItem(embedded ? `geometry-studio-workspace:${embedded.activityId}` : "math-universe-workspace-construction", JSON.stringify(embedded ? { workspaceSnapshot: snapshot(), geometryCamera } : { construction, geometryGraphSettings }));
    setProjectStatus("Geometry construction saved in this browser.");
  };
  const restoreSavedConstruction = () => {
    try {
      const saved = localStorage.getItem(embedded ? `geometry-studio-workspace:${embedded.activityId}` : "math-universe-workspace-construction");
      if (!saved) { setProjectStatus("No saved construction found in this browser yet."); return; }
      const data = JSON.parse(saved);
      const restored = embedded ? data.workspaceSnapshot?.construction : data.construction;
      if (!restored || !Array.isArray(restored.points) || !Array.isArray(restored.lines)) throw new Error("Invalid construction");
      recordWorkspaceStep("Restore saved construction", "Restored the geometry saved in this browser.");
      setConstruction(normalizeConstruction(restored));
      if (!embedded && data.geometryGraphSettings) setGeometryGraphSettings(data.geometryGraphSettings);
      if (embedded && data.geometryCamera) setGeometryCamera(data.geometryCamera);
      setSelectedGeometry(null); setSelectedPointIds([]);
      setProjectStatus("Saved construction restored.");
    } catch { setProjectStatus("Saved construction could not be restored. The stored data is invalid."); }
  };
  const snapshot = (): WorkspaceSnapshot => ({ input, results, plots, construction, geometryGraphSettings, lockedGeometryIds, surface, surfaceExpression, cameraPreset3d, sceneAnimationSpeed, solid, surfaceScale, height3d, crossSection, showSurface, showSolid, autoRotate3d, zoom3d, transforms3d, added3dObjects, deletedBase3dIds, images: workspaceImages, spreadsheet, tableRange: { start: tableStart, end: tableEnd, step: tableStep }, guidedMode, guidedPhase, teachingMode, revealStep, controlsLocked, highContrastMode, performanceMode, protocol, activityJournal, presentationNotes, objectProperties: objectPropertyOverrides });
  const saveWorkspace = () => {
    localStorage.setItem(embedded ? `geometry-studio-workspace:${embedded.activityId}` : "math-universe-workspace-full", JSON.stringify(embedded ? { workspaceSnapshot: snapshot(), geometryCamera } : snapshot()));
    setProjectStatus("Workspace saved in this browser.");
  };
  const restoreWorkspaceSnapshot = (data: WorkspaceSnapshot) => {
    setInput(data.input ?? "");
    setResults(data.results ?? []);
    setPlots(data.plots ?? []);
    setConstruction(normalizeConstruction(data.construction ?? initialConstruction));
    setGeometryGraphSettings({ ...defaultGeometryGraphSettings, ...(data.geometryGraphSettings ?? {}) });
    setLockedGeometryIds(data.lockedGeometryIds ?? []);
    setSurface(data.surface ?? "paraboloid");
    setSurfaceExpression(data.surfaceExpression ?? "sin(x) * cos(y)");
    setCameraPreset3d(data.cameraPreset3d ?? "isometric");
    setSceneAnimationSpeed(data.sceneAnimationSpeed ?? 0.18);
    setSolid(data.solid ?? "cube");
    setSurfaceScale(data.surfaceScale ?? 1);
    setHeight3d(data.height3d ?? 2.5);
    setCrossSection(data.crossSection ?? 0);
    setShowSurface(data.showSurface ?? true);
    setShowSolid(data.showSolid ?? true);
    setAutoRotate3d(data.autoRotate3d ?? true);
    setZoom3d(data.zoom3d ?? 1);
    setTransforms3d({ ...defaultTransforms3d, ...(data.transforms3d ?? {}) });
    setAdded3dObjects(data.added3dObjects ?? []);
    setDeletedBase3dIds(data.deletedBase3dIds ?? []);
    setSelected3d(getFirstAvailable3dObjectId(data.deletedBase3dIds ?? [], data.added3dObjects ?? []));
    setWorkspaceImages(data.images ?? []);
    setSelectedImageId(null);
    setSpreadsheet(data.spreadsheet ?? initialSpreadsheet);
    setCasExpression(stripInequality(data.plots?.find((plot) => plot.visible !== false)?.expression ?? casExpression));
    setTableStart(data.tableRange?.start ?? -4);
    setTableEnd(data.tableRange?.end ?? 4);
    setTableStep(data.tableRange?.step ?? 1);
    setGuidedMode(data.guidedMode ?? false);
    setGuidedPhase(data.guidedPhase ?? "predict");
    setTeachingMode(data.teachingMode ?? false);
    setRevealStep(data.revealStep ?? 1);
    setControlsLocked(data.controlsLocked ?? false);
    setHighContrastMode(data.highContrastMode ?? false);
    setPerformanceMode(data.performanceMode ?? false);
    setProtocol(data.protocol ?? []);
    setActivityJournal(data.activityJournal ?? {});
    setPresentationNotes(data.presentationNotes ?? "");
    setObjectPropertyOverrides(data.objectProperties ?? {});
    setUndoStack([]);
    setRedoStack([]);
  };
  const loadWorkspace = () => {
    const saved = localStorage.getItem(embedded ? `geometry-studio-workspace:${embedded.activityId}` : "math-universe-workspace-full");
    if (!saved) {
      setProjectStatus("No saved workspace found in this browser yet.");
      return;
    }
    try {
      const parsed = JSON.parse(saved);
      restoreWorkspaceSnapshot(embedded ? parsed.workspaceSnapshot : parsed);
      if (embedded && parsed.geometryCamera) setGeometryCamera(parsed.geometryCamera);
      setProjectStatus("Saved workspace loaded.");
    } catch {
      setProjectStatus("Saved workspace could not be loaded. The stored project data is invalid.");
    }
  };
  const exportWorkspaceJson = () => downloadText("math-workspace.json", JSON.stringify(snapshot(), null, 2), "application/json");
  const exportResultsCsv = () => downloadText("math-workspace-results.csv", resultsToCsv(results), "text/csv");
  const exportShareUrl = async () => {
    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(snapshot()))));
    const url = `${window.location.origin}${window.location.pathname}#project=${encoded}`;
    await navigator.clipboard?.writeText(url);
    setProjectStatus("Shareable URL copied to clipboard.");
  };
  const exportWorksheetPdf = () => downloadText("math-workspace-worksheet.pdf", createWorksheetPdf(classroomLesson, activeTemplate, results), "application/pdf");
  const exportLessonPack = () => downloadText("math-universe-lesson-pack.json", JSON.stringify(createLessonPack(activeTemplate, classroomLesson, snapshot(), activityJournal, results, presentationNotes), null, 2), "application/json");
  const exportActivityJournal = () => downloadText("math-universe-activity-journal.csv", activityJournalToCsv(activityJournal), "text/csv");
  const exportPracticeReport = () => downloadText("math-universe-teacher-assessment.txt", practiceReportText(classroomLesson, practiceResponses, practiceReport), "text/plain");
  const updateLesson = (patch: Partial<ClassroomLesson>) => setClassroomLesson((current) => ({ ...current, ...patch, updatedAt: Date.now() }));
  const updateLessonStep = (stepId: string, patch: Partial<LessonStep>) => setClassroomLesson((current) => ({
    ...current,
    updatedAt: Date.now(),
    steps: current.steps.map((step) => step.id === stepId ? { ...step, ...patch } : step),
  }));
  const addLessonStep = (kind: LessonStep["kind"] = "question") => setClassroomLesson((current) => ({
    ...current,
    updatedAt: Date.now(),
    steps: [
      ...current.steps,
      {
        id: crypto.randomUUID(),
        kind,
        title: kind === "check" ? "Exit ticket check" : "New lesson move",
        prompt: kind === "teacher-note" ? "Teacher move, board note, or misconception to watch." : "Ask students to explain what they see and why it is true.",
        command: kind === "explore" ? input : undefined,
        expected: kind === "question" || kind === "check" ? current.objective : undefined,
      },
    ],
  }));
  const duplicateLessonStep = (stepId: string) => setClassroomLesson((current) => {
    const source = current.steps.find((step) => step.id === stepId);
    if (!source) return current;
    const index = current.steps.findIndex((step) => step.id === stepId);
    const copy: LessonStep = { ...source, id: crypto.randomUUID(), title: `${source.title} copy` };
    return {
      ...current,
      updatedAt: Date.now(),
      steps: [...current.steps.slice(0, index + 1), copy, ...current.steps.slice(index + 1)],
    };
  });
  const removeLessonStep = (stepId: string) => {
    setClassroomLesson((current) => current.steps.length <= 1 ? current : {
      ...current,
      updatedAt: Date.now(),
      steps: current.steps.filter((step) => step.id !== stepId),
    });
    setPracticeResponses((current) => {
      const next = { ...current };
      delete next[stepId];
      return next;
    });
  };
  const checkLessonStep = (step: LessonStep, answer: string) => {
    const response = evaluatePracticeResponse(step, answer);
    setPracticeResponses((current) => ({ ...current, [step.id]: response }));
  };
  const copyTeacherPresentationUrl = async () => {
    const url = `${window.location.origin}${window.location.pathname}?template=${encodeURIComponent(activeTemplate.id)}&mode=guided&teacher=1`;
    await navigator.clipboard?.writeText(url);
    setProjectStatus("Teacher presentation URL copied.");
  };
  const exportGeometrySvg = () => {
    const svg = geometryExportRef.current;
    if (!svg) return;
    downloadText("geometry-construction.svg", svg.outerHTML, "image/svg+xml");
  };
  const exportGeometryPng = () => {
    const svg = geometryExportRef.current;
    if (!svg) return;
    const image = new Image();
    const svgUrl = URL.createObjectURL(new Blob([svg.outerHTML], { type: "image/svg+xml" }));
    image.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = 1280;
      canvas.height = 840;
      const context = canvas.getContext("2d");
      if (!context) return;
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(svgUrl);
      canvas.toBlob((blob) => blob && downloadBlob("geometry-construction.png", blob), "image/png");
    };
    image.src = svgUrl;
  };
  const saveProjectToLibrary = () => {
    const title = `${activeTemplate.unit} workspace`;
    const entry: OfflineProjectEntry<WorkspaceSnapshot> = {
      id: crypto.randomUUID(),
      title,
      unit: activeTemplate.unit,
      savedAt: Date.now(),
      summary: `${construction.points.length} points, ${plots.length} plots, ${results.length} results`,
      snapshot: snapshot(),
    };
    setProjectLibrary(saveOfflineProject(entry));
    setProjectStatus(`${title} saved offline in this browser.`);
  };
  const restoreProject = (entry: OfflineProjectEntry<WorkspaceSnapshot>) => {
    restoreWorkspaceSnapshot(entry.snapshot);
    setProjectStatus(`${entry.title} restored.`);
  };
  const deleteProject = (id: string) => {
    setProjectLibrary(removeOfflineProject<WorkspaceSnapshot>(id));
    setProjectStatus("Project removed from offline library.");
  };
  const clearProjects = () => {
    clearOfflineProjectLibrary();
    setProjectLibrary([]);
    setProjectStatus("Offline project library cleared.");
  };
  const applyTemplate = (template: SyllabusWorkspaceTemplate) => {
    setActiveTemplate(template);
    setClassroomLesson(lessonFromTemplate(template));
    setPracticeResponses({});
    setInput(template.command);
    setTeachingMode(true);
    setGuidedMode(true);
    setGuidedPhase("predict");
    setRevealStep(1);
    if (template.focus === "3d") {
      setWorkspaceView("3d");
      setSurface("paraboloid");
      setSolid("cylinder");
      setShowSurface(true);
      setShowSolid(true);
      setAutoRotate3d(false);
      setCrossSection(0.6);
    }
    if (template.focus === "geometry") {
      setWorkspaceView("geometry");
      setConstruction(templateConstruction(template.id));
    }
    runGuidedExample(template.command);
    setProjectStatus(`${template.unit} template loaded with guided activity mode.`);
  };
  const updateGuidedActivityEntry = (patch: Partial<ActivityJournalEntry>) => {
    const key = activityJournalKey(activeTemplate.id, guidedPhase);
    setActivityJournal((current) => ({
      ...current,
      [key]: {
        ...defaultActivityJournalEntry(activeTemplate.id, guidedPhase),
        ...(current[key] ?? {}),
        ...patch,
        templateId: activeTemplate.id,
        phase: guidedPhase,
        updatedAt: Date.now(),
      },
    }));
  };

  const markGuidedPhaseComplete = () => {
    updateGuidedActivityEntry({ selfCheck: "got-it", confidence: Math.max(activityJournal[activityJournalKey(activeTemplate.id, guidedPhase)]?.confidence ?? 50, 80) });
    const order: GuidedActivityPhase[] = ["predict", "manipulate", "check", "reflect"];
    const next = order[Math.min(order.length - 1, order.indexOf(guidedPhase) + 1)];
    setGuidedPhase(next);
    setRevealStep(Math.max(revealStep, order.indexOf(next) + 1));
  };

  const runGuidedExample = (command: string) => {
    setInput(command);
    const analysis = interpretInput(command);
    setResults((current) => [analysis, ...current].slice(0, 12));
    if (analysis.interpretation === "2D plot") {
      recordWorkspaceStep("Run guided graph", command);
      const expression = normalizePlotExpression(command);
      setPlots((current) => [{ id: crypto.randomUUID(), expression, name: nextFunctionName(current), color: colors[current.length % colors.length], kind: inferPlotKind(expression), visible: true }, ...current].slice(0, 8));
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const routeKey = params.toString();
    if (!routeKey || routeStateAppliedRef.current === routeKey) return;
    routeStateAppliedRef.current = routeKey;

    const templateId = normalizeTemplateRouteParam(params.get("template") ?? params.get("unit") ?? "");
    const template = syllabusWorkspaceTemplates.find((item) => item.id === templateId);
    if (template) applyTemplate(template);

    const mode = (params.get("mode") ?? "").toLowerCase();
    if (mode === "3d" || mode === "space3d") {
      setSurface("custom-z");
      setSurfaceExpression(params.get("surface") ?? surfaceExpression);
      setShowSurface(true);
      setShowSolid(true);
      setAutoRotate3d(false);
      setSelected3d("surface");
      setProjectStatus("3D workspace mode loaded from URL.");
    } else if (mode === "geometry" || mode === "2d") {
      setTool("select");
      setProjectStatus("Geometry workspace mode loaded from URL.");
    } else if (mode === "guided") {
      setGuidedMode(true);
      setTeachingMode(true);
      setGuidedPhase("predict");
      setProjectStatus("Guided activity mode loaded from URL.");
    }

    if (params.get("teacher") === "1" || params.get("panel") === "teacher") {
      setTeachingMode(true);
      setControlsLocked(true);
      setRevealStep(1);
    }
    if (params.get("panel") === "export") setProjectStatus("Export tools are ready.");
    if (params.get("highContrast") === "1") setHighContrastMode(true);

    const command = params.get("command");
    if (command) {
      const decoded = decodeURIComponent(command);
      setInput(decoded);
      executeWorkspaceCommand(decoded);
    }
  // Query-string hydration must run only once so it does not replay commands after user edits.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectWorkspaceObject = (ref: AlgebraObjectRef) => {
    setSelectedAlgebra(ref);
    selectUnifiedWorkspaceObject(liveWorkspaceObjectId(ref));
    if (ref.kind === "point" || ref.kind === "line" || ref.kind === "circle" || ref.kind === "polygon") setSelectedGeometry({ type: ref.kind, id: ref.id });
    if (ref.kind === "3d" && (isBase3dId(ref.id) || added3dObjects.some((object) => object.id === ref.id))) setSelected3d(ref.id);
  };

  const renameWorkspaceObject = (ref: AlgebraObjectRef, name: string) => {
    const clean = name.trim().slice(0, 18);
    if (!clean) return;
    recordWorkspaceStep("Rename object", `${objectDisplayName(workspaceObjects, ref)} renamed to ${clean}.`);
    if (ref.kind === "function") setPlots((current) => current.map((plot) => plot.id === ref.id ? { ...plot, name: clean } : plot));
    else if (ref.kind === "3d" && isBase3dId(ref.id)) {
      const id = ref.id;
      setTransforms3d((current) => ({ ...current, [id]: { ...current[id], name: clean } }));
    }
    else if (ref.kind === "3d") setAdded3dObjects((current) => current.map((object) => object.id === ref.id ? { ...object, label: clean, transform: { ...object.transform, name: clean } } : object));
    else setConstruction((current) => renameGeometryObject(current, ref, clean));
  };

  const editWorkspaceDefinition = (ref: AlgebraObjectRef, definition: string) => {
    recordWorkspaceStep("Edit object definition", `${objectDisplayName(workspaceObjects, ref)} = ${definition}`);
    if (ref.kind === "function") {
      const expression = normalizeFunctionDefinition(definition);
      setPlots((current) => current.map((plot) => plot.id === ref.id && !plot.locked ? { ...plot, expression, kind: inferPlotKind(expression) } : plot));
    } else if (ref.kind === "point") {
      const coords = parsePointDefinition(definition);
      if (coords) setConstruction((current) => solveConstruction({ ...current, points: current.points.map((point) => point.id === ref.id ? { ...point, x: coords.x, y: coords.y } : point) }, ref.id));
    } else if (ref.kind === "line") {
      const line = parseLineDefinition(definition);
      if (line) setConstruction((current) => updateLineFromEquation(current, ref.id, line.m, line.b));
    } else if (ref.kind === "circle") {
      const circle = parseCircleDefinition(definition);
      if (circle) setConstruction((current) => updateCircleFromDefinition(current, ref.id, circle));
    } else if (ref.kind === "3d") {
      const transform = parse3dDefinition(definition);
      if (transform && isBase3dId(ref.id)) {
        const id = ref.id;
        setTransforms3d((current) => ({ ...current, [id]: { ...current[id], ...transform } }));
      }
      else if (transform) setAdded3dObjects((current) => current.map((object) => object.id === ref.id ? { ...object, transform: { ...object.transform, ...transform } } : object));
    }
  };

  const patchWorkspaceObject = (ref: AlgebraObjectRef, patch: { visible?: boolean; locked?: boolean; trace?: boolean }) => {
    recordWorkspaceStep("Edit object flags", `${objectDisplayName(workspaceObjects, ref)} flags changed.`);
    if (ref.kind === "function") setPlots((current) => current.map((plot) => plot.id === ref.id ? { ...plot, ...patch } : plot));
    else if (ref.kind === "3d" && isBase3dId(ref.id)) {
      const id = ref.id;
      setTransforms3d((current) => ({ ...current, [id]: { ...current[id], ...patch } }));
    }
    else if (ref.kind === "3d") setAdded3dObjects((current) => current.map((object) => object.id === ref.id ? { ...object, transform: { ...object.transform, ...patch } } : object));
    else {
      setConstruction((current) => {
        const target = { type: ref.kind as GeometryObjectType, id: ref.id };
        const object = geometryObjectBySelection(current, target);
        const withStyle = patchGeometryObject(current, target, { style: { ...(object?.style ?? {}), visible: patch.visible, trace: patch.trace } });
        return typeof patch.trace === "boolean" ? setGeometryTrace(withStyle, target, patch.trace) : withStyle;
      });
      if (typeof patch.locked === "boolean") setLockedGeometryIds((current) => patch.locked ? Array.from(new Set([...current, ref.id])) : current.filter((id) => id !== ref.id));
    }
  };

  const duplicateWorkspaceObject = (ref: AlgebraObjectRef) => {
    if (ref.kind === "function") {
      const plot = plots.find((item) => item.id === ref.id);
      if (!plot) return;
      recordWorkspaceStep("Duplicate function", plot.name ?? plot.expression);
      setPlots((current) => [{ ...plot, id: crypto.randomUUID(), name: nextFunctionName(current), expression: plot.expression, color: colors[current.length % colors.length] }, ...current]);
    } else if (ref.kind === "3d") duplicate3dObject(ref.id);
    else duplicateGeometryObject({ type: ref.kind as GeometryObjectType, id: ref.id });
  };

  const deleteWorkspaceObject = (ref: AlgebraObjectRef) => {
    if (ref.kind === "function") {
      recordWorkspaceStep("Delete function", objectDisplayName(workspaceObjects, ref));
      setPlots((current) => current.filter((plot) => plot.id !== ref.id));
    } else if (ref.kind === "3d") delete3dObject(ref.id);
    else deleteGeometryObject({ type: ref.kind as GeometryObjectType, id: ref.id });
  };

  useEffect(() => {
    const object = unifiedWorkspaceObjects.find((item) => item.id === unifiedSelectedObjectId);
    const ref = object ? liveRefFromMathObject(object) : null;
    if (!ref || sameRef(selectedAlgebra, ref)) return;
    setSelectedAlgebra(ref);
    if (ref.kind === "point" || ref.kind === "line" || ref.kind === "circle" || ref.kind === "polygon" || ref.kind === "arc" || ref.kind === "locus") {
      setSelectedGeometry({ type: ref.kind, id: ref.id });
    }
    if (ref.kind === "3d" && (isBase3dId(ref.id) || added3dObjects.some((item) => item.id === ref.id))) {
      setSelected3d(ref.id);
    }
  }, [added3dObjects, selectedAlgebra, unifiedSelectedObjectId, unifiedWorkspaceObjects]);

  const applyUnifiedStylePatch = (ref: AlgebraObjectRef, style: MathObjectStyle) => {
    const color = style.color ?? style.stroke;
    if (ref.kind === "function") {
      setPlots((current) => current.map((plot) => plot.id === ref.id ? { ...plot, color: color ?? plot.color } : plot));
      return;
    }
    if (ref.kind === "3d") {
      const material = style.material === "glass" || style.material === "wireframe" || style.material === "matte" ? style.material : undefined;
      update3dTransform(ref.id, { color: color ?? undefined, opacity: style.opacity, material, paint: style.paint, secondaryColor: style.secondaryColor, pattern: style.pattern });
      return;
    }
    setConstruction((current) => {
      const selected = { type: ref.kind as GeometryObjectType, id: ref.id };
      const existing = geometryObjectBySelection(current, selected)?.style ?? {};
      return patchGeometryObject(current, selected, {
        style: {
          ...existing,
          color: color ?? existing.color,
          fill: style.fill ?? existing.fill,
          strokeWidth: style.strokeWidth ?? existing.strokeWidth,
          lineStyle: style.lineStyle ?? existing.lineStyle,
          paint: style.paint ?? existing.paint,
          secondaryColor: style.secondaryColor ?? existing.secondaryColor,
          pattern: style.pattern ?? existing.pattern,
          opacity: style.opacity ?? existing.opacity,
          labelMode: style.labelVisible === false ? "hidden" : existing.labelMode,
        },
      });
    });
  };

  const applyUnifiedTransformPatch = (ref: AlgebraObjectRef, transform: MathTransform) => {
    if (ref.kind !== "3d") return;
    const scale = Math.max(0.05, (transform.scale.x + transform.scale.y + transform.scale.z) / 3);
    update3dTransform(ref.id, {
      position: [transform.position.x, transform.position.y, transform.position.z],
      rotation: [transform.rotation.x, transform.rotation.y, transform.rotation.z],
      scale,
    });
  };

  const applyUnifiedLabelProperty = (ref: AlgebraObjectRef, properties: MathObjectProperties) => {
    const labelMode = properties.labelMode;
    if (ref.kind === "function") return;
    if (ref.kind === "3d") {
      if (typeof properties.caption === "string" && properties.caption.trim()) update3dTransform(ref.id, { name: properties.caption.trim() });
      return;
    }
    const selected = { type: ref.kind as GeometryObjectType, id: ref.id };
    setConstruction((current) => {
      const existing = geometryObjectBySelection(current, selected)?.style ?? {};
      const nextMode: GeoStyle["labelMode"] = labelMode === "name-value" ? "both" : labelMode === "caption" ? "value" : labelMode === "hidden" ? "hidden" : "name";
      return patchGeometryObject(current, selected, { style: { ...existing, label: properties.caption || existing.label, labelMode: nextMode } });
    });
  };

  const applyUnifiedPropertiesPatch = (ref: AlgebraObjectRef, object: MathObject, properties: MathObjectProperties) => {
    const mergedProperties = { ...object.properties, ...properties };
    const objectId = liveWorkspaceObjectId(ref);
    setObjectPropertyOverrides((current) => ({ ...current, [objectId]: mergedProperties }));
    const evaluated = evaluateObjectProperties({ ...object, properties: mergedProperties }, { variables: workspacePropertyVariables(surfaceScale, height3d, crossSection, sceneAnimationSpeed) });
    updateUnifiedWorkspaceObject(object.id, {
      properties: mergedProperties,
      visible: evaluated.visible,
      status: evaluated.visible ? "ready" : "hidden",
      style: evaluated.style,
      metadata: {
        ...object.metadata,
        evaluatedLabel: evaluated.label,
        caption: evaluated.caption,
        layer: evaluated.layer,
      },
    });
    applyUnifiedStylePatch(ref, evaluated.style);
    if (evaluated.visible !== object.visible) patchWorkspaceObject(ref, { visible: evaluated.visible });
    if (properties.labelMode || properties.caption) applyUnifiedLabelProperty(ref, mergedProperties);
    setProjectStatus(`${object.label} object properties updated.`);
  };

  const handleUnifiedObjectAction = (action: ObjectListAction, object: MathObject) => {
    const ref = liveRefFromMathObject(object);
    if (!ref) return;
    if (action === "show" || action === "hide") patchWorkspaceObject(ref, { visible: action === "show" });
    if (action === "duplicate") duplicateWorkspaceObject(ref);
    if (action === "remove") deleteWorkspaceObject(ref);
    if (action === "restore") {
      if (ref.kind === "3d") restore3dObject(ref.id);
      else if (ref.kind === "function") patchWorkspaceObject(ref, { visible: true, locked: false, trace: false });
      else restoreGeometryObject({ type: ref.kind as GeometryObjectType, id: ref.id });
    }
  };

  const handleUnifiedObjectChange = (object: MathObject, patch: Partial<MathObject>) => {
    const ref = liveRefFromMathObject(object);
    if (!ref) return;
    if (typeof patch.label === "string" && patch.label !== object.label) renameWorkspaceObject(ref, patch.label);
    if (typeof patch.value === "string" && patch.value !== object.value) editWorkspaceDefinition(ref, patch.value);
    const flagPatch: { visible?: boolean; locked?: boolean; trace?: boolean } = {};
    if (typeof patch.visible === "boolean") flagPatch.visible = patch.visible;
    if (typeof patch.locked === "boolean") flagPatch.locked = patch.locked;
    if (Object.keys(flagPatch).length > 0) patchWorkspaceObject(ref, flagPatch);
    if (patch.style) applyUnifiedStylePatch(ref, patch.style);
    if (patch.transform) applyUnifiedTransformPatch(ref, patch.transform);
    if (patch.properties) applyUnifiedPropertiesPatch(ref, object, patch.properties);
  };

  const clearWorkspaceSelection = useCallback(() => {
    setTool("select");
    setSelectedGeometry(null);
    setSelectedImageId(null);
    setSelectedAlgebra(null);
    setSelectedPointIds([]);
    setGeometryObjectPicks([]);
    setPolygonDraft([]);
    setDragPointId(null);
    setDragImageId(null);
    setDragGeometry(null);
    setDrag3d(null);
    setSelected3d("");
    setContextMenu(null);
    setProjectStatus("Selection cleared. Tool returned to Select.");
  }, []);

  const deleteSelectedWorkspaceItems = () => {
    if (selectedImageId) {
      deleteSelectedImage();
      setProjectStatus("Selected image deleted.");
      return true;
    }
    if (selectedGeometry) {
      deleteGeometryObject(selectedGeometry);
      setProjectStatus("Selected geometry object deleted.");
      return true;
    }
    if (selectedPointIds.length) {
      recordWorkspaceStep("Delete selected points", `${selectedPointIds.length} point${selectedPointIds.length === 1 ? "" : "s"} removed.`);
      setConstruction((current) => selectedPointIds.reduce((next, id) => deleteGeometryObjectFromConstruction(next, { type: "point", id }), current));
      setSelectedPointIds([]);
      setSelectedGeometry(null);
      setProjectStatus("Selected points deleted.");
      return true;
    }
    if (selectedAlgebra) {
      deleteWorkspaceObject(selectedAlgebra);
      setSelectedAlgebra(null);
      setProjectStatus("Selected algebra object deleted.");
      return true;
    }
    if (selected3d) {
      delete3dObject(selected3d);
      setSelected3d("");
      setProjectStatus(isBase3dId(selected3d) ? "Selected 3D object hidden." : "Selected 3D object deleted.");
      return true;
    }
    return false;
  };

  const replayConstructionStep = (step: ConstructionStep) => {
    restoreProtocolSnapshot(step);
    setProjectStatus(`Replayed: ${step.label}`);
  };
  const runWorkspaceShortcut = useCallback((event: Pick<KeyboardEvent, "key" | "ctrlKey" | "metaKey" | "shiftKey" | "preventDefault">) => {
    if (event.key === "Escape") {
      event.preventDefault();
      clearWorkspaceSelection();
      return;
    }
    if (event.key === "Delete" || event.key === "Backspace") {
      const deleted = deleteSelectedWorkspaceItems();
      event.preventDefault();
      if (!deleted) {
        const unsupported = createNoSelectionDeleteAction();
        setProjectStatus(unsupported.message);
      }
      return;
    }
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key) && selectedGeometry?.type === "point") {
      event.preventDefault();
      const delta = event.shiftKey ? 10 : 2;
      const dx = event.key === "ArrowLeft" ? -delta : event.key === "ArrowRight" ? delta : 0;
      const dy = event.key === "ArrowUp" ? -delta : event.key === "ArrowDown" ? delta : 0;
      updateSelectedPointByDelta(selectedGeometry.id, dx, dy);
      return;
    }
    if (!(event.ctrlKey || event.metaKey)) return;
    if (event.key.toLowerCase() === "z") {
      event.preventDefault();
      if (event.shiftKey) redoWorkspace();
      else undoWorkspace();
    }
    if (event.key.toLowerCase() === "y") {
      event.preventDefault();
      redoWorkspace();
    }
    if (event.key.toLowerCase() === "s") {
      event.preventDefault();
      saveWorkspace();
    }
    if (event.key.toLowerCase() === "o") {
      event.preventDefault();
      loadWorkspace();
    }
    if (event.key.toLowerCase() === "enter") {
      event.preventDefault();
      runInput();
    }
  // Legacy workspace actions intentionally close over the current snapshot state.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clearWorkspaceSelection, deleteSelectedWorkspaceItems, selectedGeometry]);

  useEffect(() => {
    const onDocumentKeyDown = (event: globalThis.KeyboardEvent) => {
      if (isTypingTarget(event.target)) return;
      runWorkspaceShortcut(event);
    };
    document.addEventListener("keydown", onDocumentKeyDown);
    return () => document.removeEventListener("keydown", onDocumentKeyDown);
  }, [runWorkspaceShortcut]);

  const transformSelectedGeometryPoints = (mode: GeometryTransformMode) => {
    applyGeometryFigureTransform(mode);
  };

  const activeFunctionPlot = plots.find((plot) => plot.visible !== false && (plot.kind ?? inferPlotKind(plot.expression)) === "function") ?? plots[0];
  const selectedCasCell = casNotebookState.cells.find((cell) => cell.id === selectedCasCellId) ?? casNotebookState.cells.find((cell) => cell.output) ?? casNotebookState.cells[0];
  const casNotebookExport = useMemo(() => serializeCasNotebookMarkdown(casNotebookState), [casNotebookState]);
  const commitCasNotebook = (next: NotebookState) => {
    setCasUndoStack((current) => [casNotebookState, ...current].slice(0, 40));
    setCasRedoStack([]);
    setCasNotebookState(next);
  };
  const updateCasCell = (id: string, patch: Partial<NotebookCell>) => {
    const cells = casNotebookState.cells.map((cell) => (cell.id === id ? { ...cell, ...patch } : cell));
    commitCasNotebook({ ...casNotebookState, cells: evaluateNotebookCells(cells, casNotebookState.assumptions, casNotebookState.mode) });
  };
  const runCasCell = (id: string) => {
    setSelectedCasCellId(id);
    commitCasNotebook({ ...casNotebookState, cells: evaluateNotebookCellInState(id, casNotebookState.cells, casNotebookState.assumptions, casNotebookState.mode) });
  };
  const runCasNotebook = () => {
    commitCasNotebook({ ...casNotebookState, cells: evaluateNotebookCells(casNotebookState.cells, casNotebookState.assumptions, casNotebookState.mode) });
  };
  const addCasCell = (input = casComposerInput, operation = casComposerOperation) => {
    const nextCell = createNotebookCell(input, operation);
    setSelectedCasCellId(nextCell.id);
    const cells = [nextCell, ...casNotebookState.cells].slice(0, 40);
    commitCasNotebook({ ...casNotebookState, cells: evaluateNotebookCells(cells, casNotebookState.assumptions, casNotebookState.mode) });
  };
  const duplicateCasCell = (cell: NotebookCell) => addCasCell(cell.input, cell.operation);
  const deleteCasCell = (id: string) => {
    commitCasNotebook({ ...casNotebookState, cells: casNotebookState.cells.filter((cell) => cell.id !== id) });
    setSelectedCasCellId((current) => current === id ? null : current);
  };
  const reorderCasCells = (orderedIds: string[]) => {
    const byId = new Map(casNotebookState.cells.map((cell) => [cell.id, cell]));
    const cells = orderedIds.map((id) => byId.get(id)).filter((cell): cell is NotebookCell => Boolean(cell));
    if (cells.length === casNotebookState.cells.length) commitCasNotebook({ ...casNotebookState, cells });
  };
  const resetCasNotebook = () => {
    const next = createDefaultCasNotebookState();
    commitCasNotebook(next);
    setSelectedCasCellId(next.cells[0]?.id ?? null);
  };
  const setCasMode = (mode: EvaluationMode) => commitCasNotebook({ ...casNotebookState, mode, cells: evaluateNotebookCells(casNotebookState.cells, casNotebookState.assumptions, mode) });
  const setCasAssumptions = (assumptions: string) => commitCasNotebook({ ...casNotebookState, assumptions, cells: evaluateNotebookCells(casNotebookState.cells, assumptions, casNotebookState.mode) });
  const sendCasCellToGraph = (cell: NotebookCell) => {
    const expression = graphableExpressionFromCasCell(cell);
    const payload = createMathWorkspacePayload({
      sourceWorkspace: "cas",
      objectType: "expression",
      label: cell.input || "CAS expression",
      value: expression,
      metadata: { operation: cell.operation },
    });
    saveWorkspaceTransfer(payload, "graphs");
    navigate("/workspace/graph", {
      state: { mathWorkspacePayload: payload },
    });
  };

  const resizeSelectedGeometry = (direction: "increase" | "decrease") => {
    const selection = resolveSelectedGeometryObject();
    if (!selection) {
      setProjectStatus("Select a 2D geometry object before resizing.");
      return;
    }
    if (lockedGeometryIds.includes(selection.id)) {
      setProjectStatus("Selected geometry object is locked.");
      return;
    }
    setSelectedGeometry(selection);
    const factor = direction === "increase" ? 1.12 : 0.88;
    recordWorkspaceStep("Resize geometry object", `${geometryObjectLabel(construction, selection)} ${direction === "increase" ? "enlarged" : "reduced"}.`);
    if (selection.type === "point") {
      const point = pointById(construction.points, selection.id);
      const currentSize = point?.style?.size ?? 1;
      updateSelectedGeometryStyle({ ...(point?.style ?? {}), size: roundTo(Math.max(0.4, Math.min(3.5, currentSize * factor)), 2) });
      setProjectStatus(`${point?.label ?? "Point"} marker resized.`);
      return;
    }
    setConstruction((current) => resizeGeometryObjectInConstruction(current, selection, factor));
    setProjectStatus(`${geometryObjectLabel(construction, selection)} resized.`);
  };
  const exportCasNotebook = () => {
    const blob = new Blob([casNotebookExport], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "computer-algebra-studio.md";
    link.click();
    URL.revokeObjectURL(url);
  };
  const runDataCommand = (command: string) => {
    setInput(command);
    const analysis = interpretInput(command);
    setResults((current) => [analysis, ...current].slice(0, 12));
    if (analysis.graphExpression) {
      setCasExpression(stripInequality(analysis.graphExpression));
      setPlots((current) => [{ id: crypto.randomUUID(), expression: analysis.graphExpression!, color: colors[current.length % colors.length], kind: inferPlotKind(analysis.graphExpression!), visible: true }, ...current].slice(0, 10));
    }
  };
  const _addSpreadsheetScatter = (points: ResultTableRow[]) => {
    recordWorkspaceStep("Add spreadsheet scatter", `${points.length} spreadsheet points linked to graph.`);
    setPlots((current) => [{ id: crypto.randomUUID(), expression: "spreadsheet data", color: "#ec4899", kind: "scatter" as PlotKind, points, visible: true }, ...current].slice(0, 10));
  };
  const _addSpreadsheetRegression = (model: RegressionModel, points: ResultTableRow[]) => {
    const regression = regressionModel(points, model);
    recordWorkspaceStep("Add spreadsheet regression", `${model} regression from spreadsheet.`);
    setPlots((current) => [{ id: crypto.randomUUID(), expression: regression.expression, color: "#14b8a6", kind: "regression" as PlotKind, points, visible: true }, ...current].slice(0, 10));
    setResults((current) => [{ id: crypto.randomUUID(), input: `${model} regression`, interpretation: "Spreadsheet regression", result: regression.expression, detail: regression.detail, table: points.slice(0, 12), graphExpression: regression.expression }, ...current].slice(0, 12));
  };
  const dataOverviewCards = [
    { title: "Spreadsheet", text: "Editable cells, formulas, scatter plots, and regression.", route: "/workspace/data/spreadsheet", concept: "Tables" },
    { title: "Function Analysis", text: "Roots, extrema, intercepts, derivative, integral, and table commands.", route: "/workspace/data/analysis", concept: "Functions" },
    { title: "CAS Workbench", text: "Exact algebra actions for simplify, factor, solve, limits, substitution, and systems.", route: "/workspace/data/cas", concept: "Algebra" },
    { title: "Results", text: "Exact results, numeric checks, and generated tables.", route: "/workspace/data/results", concept: "Solutions" },
    { title: "Object Registry", text: "Shared graph, CAS, table, spreadsheet, geometry, and 3D objects.", route: "/workspace/data/objects", concept: "Linked Objects" },
  ];

  const singleViewCasStudio = singleView && workspaceView === "data" && dataPage === "cas";
  const singleViewSpreadsheetStudio = singleView && workspaceView === "data" && dataPage === "spreadsheet";
  const singleViewStudio = singleView && (workspaceView === "graph" || workspaceView === "3d" || workspaceView === "geometry" || singleViewCasStudio || singleViewSpreadsheetStudio);
  const workspaceRootClass = `relative ${singleViewStudio ? `${workspaceView === "graph" ? "math-workspace-single-graph min-h-full" : "h-full min-h-0 overflow-hidden"}` : singleView ? "space-y-2 pt-0" : "space-y-2 pt-14 xl:pt-12"}`;
  const portableWorkspaceType: PortableWorkspaceType = workspaceView === "geometry" ? "2d-geometry" : workspaceView === "3d" ? "3d-geometry" : singleViewCasStudio ? "cas" : "2d-graph";
  const portableAdapter: PortableWorkspaceAdapter = {
    workspaceType: portableWorkspaceType,
    engine: portableWorkspaceType === "cas" ? "math-universe-symbolic-notebook" : portableWorkspaceType === "2d-graph" ? "math-universe-graph-workspace" : portableWorkspaceType === "3d-geometry" ? "math-universe-three-workspace" : "math-universe-geometry-workspace",
    engineVersion: "1.0.2",
    title: () => portableWorkspaceType === "cas" ? "Computer Algebra Studio" : portableWorkspaceType === "2d-graph" ? "2D Graph Workspace" : portableWorkspaceType === "3d-geometry" ? "3D Geometry Workspace" : "2D Geometry Workspace",
    serializeScene: () => ({
      workspaceSnapshot: snapshot(),
      ...(portableWorkspaceType === "2d-geometry" ? { geometryCamera } : {}),
      ...(portableWorkspaceType === "2d-graph" ? { linkedParameters: readLinkedParameters() } : {}),
      ...(portableWorkspaceType === "cas" ? { casNotebookState, selectedCasCellId, composerInput: casComposerInput, composerOperation: casComposerOperation } : {}),
      workspaceType: portableWorkspaceType,
    }),
    deserializeScene: (scene) => {
      if (!scene || typeof scene !== "object") throw new Error("The imported scene is missing or invalid.");
      const record = scene as { workspaceSnapshot?: WorkspaceSnapshot; linkedParameters?: Record<string, { name?: string; value?: number; min?: number; max?: number; step?: number; integer?: boolean }>; casNotebookState?: NotebookState; selectedCasCellId?: string | null; composerInput?: string; composerOperation?: NotebookOperation };
      if (!record.workspaceSnapshot) throw new Error("The imported scene does not contain a compatible workspace snapshot.");
      restoreWorkspaceSnapshot(record.workspaceSnapshot);
      if (portableWorkspaceType === "2d-graph" && record.linkedParameters && typeof record.linkedParameters === "object") {
        Object.entries(record.linkedParameters).slice(0, 100).forEach(([key, parameter]) => {
          const name = String(parameter.name ?? key).replace(/[^A-Za-z0-9_]/g, "").slice(0, 32);
          const value = Number(parameter.value), min = Number(parameter.min), max = Number(parameter.max), step = Number(parameter.step);
          if (name && [value, min, max, step].every(Number.isFinite) && min <= max && step > 0) saveLinkedParameter({ name, value: Math.min(max, Math.max(min, value)), min, max, step, integer: Boolean(parameter.integer) });
        });
      }
      if (portableWorkspaceType === "cas" && record.casNotebookState?.cells && Array.isArray(record.casNotebookState.cells)) {
        const assumptions = String(record.casNotebookState.assumptions ?? "").slice(0, 2_000);
        const mode: EvaluationMode = record.casNotebookState.mode === "numeric" ? "numeric" : "exact";
        const cells = record.casNotebookState.cells.slice(0, 200).map(cell => ({ ...cell, input: String(cell.input ?? "").slice(0, 20_000) }));
        setCasNotebookState({ assumptions, mode, cells: evaluateNotebookCells(cells, assumptions, mode) });
        setSelectedCasCellId(record.selectedCasCellId ?? cells[0]?.id ?? null);
        setCasComposerInput(String(record.composerInput ?? "").slice(0, 20_000));
        if (record.composerOperation && operationOptions.some(option => option.value === record.composerOperation)) setCasComposerOperation(record.composerOperation);
      }
      setProjectStatus("Portable workspace restored.");
    },
    validateScene: (scene) => !scene || typeof scene !== "object" || !("workspaceSnapshot" in scene) ? ["The imported scene does not contain a compatible workspace snapshot."] : [],
    getImageTarget: (scope) => {
      if (portableWorkspaceType === "2d-geometry") return geometryExportRef.current ?? workspaceRef.current;
      if (portableWorkspaceType === "2d-graph") return graphExportRef.current ?? workspaceRef.current;
      if (portableWorkspaceType === "cas") return workspaceRef.current?.querySelector(scope === "entire" ? ".cas-notebook-scroll" : ".cas-studio-center") as HTMLElement | null;
      const canvas = workspaceRef.current?.querySelector("canvas");
      return canvas?.parentElement ?? workspaceRef.current;
    },
    getSceneSummary: () => portableWorkspaceType === "cas"
      ? { objectCount: casNotebookState.cells.length, expressionCount: casNotebookState.cells.length, description: `${casNotebookState.cells.length} CAS calculations` }
      : portableWorkspaceType === "2d-graph"
        ? { objectCount: plots.length, expressionCount: plots.length, description: `${plots.length} plotted expressions` }
        : portableWorkspaceType === "3d-geometry"
          ? { objectCount: Object.keys(transforms3d).length + added3dObjects.length - deletedBase3dIds.length, expressionCount: showSurface ? 1 : 0, description: `${added3dObjects.length} added 3D objects` }
          : { objectCount: construction.points.length + construction.lines.length + construction.circles.length + construction.polygons.length, expressionCount: 0, description: `${construction.points.length} points and ${construction.lines.length + construction.circles.length + construction.polygons.length} constructions` },
    canMerge: false,
  };

  // Embedded activities hydrate only their own scene and never consume another
  // workspace's pending transfer or save over the standalone project.
  const embeddedHydrated = useRef(false);
  const embeddedCallback = useRef(embedded?.onSceneChange);
  embeddedCallback.current = embedded?.onSceneChange;
  useEffect(() => {
    const routeScene = (location.state as { embeddedWorkspaceScene?: unknown } | null)?.embeddedWorkspaceScene;
    if (!embedded && !routeScene) return;
    let scene = embedded?.initialScene ?? routeScene;
    if (embedded) {
      try { const saved = localStorage.getItem(`geometry-studio-workspace:${embedded.activityId}`); if (saved) scene = JSON.parse(saved); } catch { /* Use the supplied example if storage is unavailable or invalid. */ }
    }
    if (!scene || typeof scene !== "object" || !("workspaceSnapshot" in scene)) return;
    const record = scene as { workspaceSnapshot: WorkspaceSnapshot; geometryCamera?: GeometryCamera };
    if (!record.workspaceSnapshot || typeof record.workspaceSnapshot !== "object") return;
    restoreWorkspaceSnapshot(record.workspaceSnapshot);
    if (record.geometryCamera) setGeometryCamera(record.geometryCamera);
    embeddedHydrated.current = true;
    // The host remounts the workspace when changing activities or resetting.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [embedded?.activityId]);
  useEffect(() => {
    if (!embedded || !embeddedHydrated.current) return;
    const timeout = window.setTimeout(() => {
      const scene = { workspaceSnapshot: snapshot(), geometryCamera, workspaceType: portableWorkspaceType };
      try { localStorage.setItem(`geometry-studio-workspace:${embedded.activityId}`, JSON.stringify(scene)); } catch { /* The workspace remains editable without storage. */ }
      embeddedCallback.current?.(scene);
    }, 120);
    return () => window.clearTimeout(timeout);
    // Persist the scene fields used by geometry activities, including clearing.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [embedded?.activityId, construction, geometryCamera, geometryGraphSettings, workspaceImages, transforms3d, solid, surface, surfaceExpression, surfaceScale, height3d, crossSection, showSurface, showSolid, added3dObjects, deletedBase3dIds]);

  const openPortableWorkspaceImport = () => {
    if (portableImportInputRef.current) portableImportInputRef.current.value = "";
    portableImportInputRef.current?.click();
  };

  const importPortableWorkspaceFile = async (file: File | null) => {
    if (!file) return;
    setProjectStatus("Validating workspace file…");
    try {
      const result = await parsePortableMathFile(await file.text(), file.name, file.type);
      if (!result.ok) {
        setProjectStatus(result.error);
        return;
      }
      if (result.file.workspace.type !== portableAdapter.workspaceType) {
        setProjectStatus(`This file belongs to ${result.file.workspace.type}, not ${portableAdapter.workspaceType}.`);
        return;
      }
      const mode = result.file.lesson?.openMode ?? "practice";
      const scene = sceneForLessonMode(result.file, mode);
      const warnings = portableAdapter.validateScene?.(scene) ?? [];
      if (warnings.length) {
        setProjectStatus(warnings[0]);
        return;
      }
      await portableAdapter.deserializeScene(scene, "replace");
      setProjectStatus(`${result.file.document.title} imported successfully${result.warnings.length ? ` with ${result.warnings.length} warning${result.warnings.length === 1 ? "" : "s"}` : ""}.`);
    } catch (error) {
      setProjectStatus(error instanceof Error ? error.message : "The workspace file could not be imported.");
    } finally {
      if (portableImportInputRef.current) portableImportInputRef.current.value = "";
    }
  };

  return (
    <div ref={workspaceRef} className={workspaceRootClass}>
      <input
        ref={portableImportInputRef}
        type="file"
        className="hidden"
        accept={`${WORKSPACE_EXTENSION},${LESSON_EXTENSION},application/vnd.mathapp.workspace,application/vnd.mathapp.lesson,application/json`}
        aria-label="Import workspace file"
        onChange={(event) => void importPortableWorkspaceFile(event.target.files?.[0] ?? null)}
      />

      {!singleViewStudio && <WorkspaceMainMenu active={workspaceView} onChange={setWorkspaceView} docked={singleView} />}
      {!singleView && <TopicHeader title="Math Workspace" subtitle="A unified workspace for graphing, commands, results, and dynamic geometric construction." difficulty="All levels" estimatedMinutes={45} />}

      {!singleView && <WorkspaceModeTabs active={workspaceView} onChange={setWorkspaceView} />}
      {!singleViewStudio && <CompactWorkspaceBar
        activeTemplate={activeTemplate}
        teachingMode={teachingMode}
        compact={singleView}
        onSave={saveWorkspace}
        onLoad={loadWorkspace}
        onUndo={undoWorkspace}
        onRedo={redoWorkspace}
        onExportJson={exportWorkspaceJson}
        onExportPng={exportGeometryPng}
        onShare={exportShareUrl}
        onToggleTeach={() => {
          setTeachingMode((value) => !value);
          setWorkspaceView("teach");
        }}
      />}
      {!singleView && workspaceView !== "3d" && <WorkspaceShortcutStrip />}

      {workspaceView === "teach" && <SectionCard title="Teaching, Library, And Export" description="Launch syllabus workspaces, guide students, present steps, and manage browser-only projects.">
        <div data-testid="workspace-teacher-surface">
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={saveWorkspace} className="action-secondary"><Save className="h-4 w-4" />Save workspace</button>
              <button type="button" onClick={loadWorkspace} className="action-secondary"><Download className="h-4 w-4" />Load workspace</button>
              <button type="button" onClick={saveProjectToLibrary} className="action-secondary"><Save className="h-4 w-4" />Save offline</button>
              <button type="button" onClick={exportWorkspaceJson} className="action-secondary"><Download className="h-4 w-4" />Export JSON</button>
              <button type="button" onClick={exportResultsCsv} className="action-secondary"><Download className="h-4 w-4" />Export CSV</button>
              <button type="button" onClick={exportGeometryPng} className="action-secondary"><Download className="h-4 w-4" />Export PNG</button>
              <button type="button" onClick={exportGeometrySvg} className="action-secondary"><Download className="h-4 w-4" />Export geometry SVG</button>
              <button type="button" onClick={exportWorksheetPdf} className="action-secondary"><Download className="h-4 w-4" />Worksheet PDF</button>
              <button type="button" onClick={exportLessonPack} className="action-secondary"><Download className="h-4 w-4" />Lesson pack</button>
              <button type="button" onClick={exportActivityJournal} className="action-secondary"><Download className="h-4 w-4" />Journal CSV</button>
              <button type="button" onClick={exportShareUrl} className="action-secondary"><Download className="h-4 w-4" />Share URL</button>
              <button type="button" onClick={copyTeacherPresentationUrl} className="action-secondary"><Presentation className="h-4 w-4" />Teacher link</button>
              <button type="button" onClick={() => setTeachingMode((value) => !value)} className={teachingMode ? "action-primary" : "action-secondary"}><Presentation className="h-4 w-4" />Teaching mode</button>
              <button type="button" onClick={undoWorkspace} className="action-secondary"><RotateCcw className="h-4 w-4" />Undo {undoStack[0]?.label ?? "change"}</button>
              <button type="button" onClick={redoWorkspace} className="action-secondary"><RotateCcw className="h-4 w-4" />Redo {redoStack[0]?.label ?? "change"}</button>
            </div>
            <SyllabusTemplatePanel templates={syllabusWorkspaceTemplates} active={activeTemplate.id} onApply={applyTemplate} />
            <GuidedActivityPanel active={guidedMode} phase={guidedPhase} template={activeTemplate} journal={activityJournal} onToggle={() => setGuidedMode((value) => !value)} onPhase={setGuidedPhase} onJournal={updateGuidedActivityEntry} onCompletePhase={markGuidedPhaseComplete} />
            <TeacherLessonStudio
              lesson={classroomLesson}
              report={practiceReport}
              responses={practiceResponses}
              onLessonChange={updateLesson}
              onStepChange={updateLessonStep}
              onResponseChange={(stepId, answer) => setPracticeResponses((current) => ({ ...current, [stepId]: { stepId, answer } }))}
              onCheck={checkLessonStep}
              onLaunchCommand={runGuidedExample}
              onAddStep={addLessonStep}
              onDuplicateStep={duplicateLessonStep}
              onRemoveStep={removeLessonStep}
              onExport={exportPracticeReport}
            />
            <TeacherPresentationPanel active={teachingMode} locked={controlsLocked} revealStep={revealStep} lesson={classroomLesson} template={activeTemplate} notes={presentationNotes} responses={practiceResponses} report={practiceReport} journal={activityJournal} onToggle={setTeachingMode} onLock={setControlsLocked} onReveal={setRevealStep} onNotes={setPresentationNotes} onCopyLink={copyTeacherPresentationUrl} />
            <OfflineProjectLibraryPanel projects={projectLibrary} onSave={saveProjectToLibrary} onRestore={restoreProject} onDelete={deleteProject} onClear={clearProjects} />
            {teachingMode && (
              <div className="rounded-2xl bg-cyan-50 p-4 text-sm leading-6 text-slate-700 dark:bg-cyan-400/10 dark:text-cyan-50">
                <p className="font-bold">Teacher presentation mode is active</p>
                <p>{controlsLocked ? "Student-facing controls are locked for explanation and reveal steps." : "Controls are open for live manipulation and discussion."}</p>
              </div>
            )}
            <div>
              <h3 className="font-bold">Guided Examples</h3>
              <div className="mt-3 grid gap-2 md:grid-cols-2">
                {guidedExamples.map((example) => <button key={example.title} type="button" onClick={() => runGuidedExample(example.command)} className="rounded-2xl border border-slate-200 bg-white/70 p-4 text-left transition hover:border-cyan-300 dark:border-white/10 dark:bg-white/5"><p className="font-semibold">{example.title}</p><p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400">{example.command}</p></button>)}
              </div>
            </div>
          </div>
          <div>
            <label className="block">
              <span className="flex items-center gap-2 text-sm font-semibold"><Search className="h-4 w-4 text-cyan-500" />Formula Library</span>
              <input value={formulaSearch} onChange={(event) => setFormulaSearch(event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-white/10 dark:bg-slate-950" placeholder="Search formula, topic, command..." />
            </label>
            <div className="mt-3 max-h-[360px] space-y-2 overflow-y-auto pr-1">
              {filteredFormulas.map((item) => (
                <button key={item.title} type="button" onClick={() => setInput(item.command)} className="w-full rounded-2xl bg-slate-100 p-3 text-left transition hover:bg-cyan-100 dark:bg-white/10 dark:hover:bg-cyan-300/15">
                  <p className="text-xs font-bold uppercase text-cyan-600 dark:text-cyan-300">{item.topic}</p>
                  <p className="mt-1 font-semibold">{item.title}</p>
                  <p className="mt-1 text-xs font-semibold text-slate-600 dark:text-slate-300">
                    <MathExpression value={item.formula} />
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>
        </div>
      </SectionCard>}

      {workspaceView === "graph" && <SectionCard title="Graph, CAS, And Algebra" description="Type commands, graph expressions, inspect results, and manage objects in focused tabs." compact={singleView} className={singleView ? "graph-workspace-card" : undefined} visualizationTools={singleView ? false : "auto"}>
        <div className="graph-workspace-tabs mb-3 mobile-safe-scroll thin-scrollbar">
          <span className="sr-only">Workspace command keyboard</span>
          <div className="inline-flex min-w-full gap-1.5 rounded-xl border border-slate-200 bg-white/80 p-1 dark:border-white/10 dark:bg-white/5 md:min-w-0">
            {[
              { id: "graph" as const, label: "Graph", icon: <LineChart className="h-4 w-4" /> },
              { id: "command" as const, label: "Command", icon: <FunctionSquare className="h-4 w-4" /> },
              { id: "results" as const, label: `Results ${results.length}`, icon: <Search className="h-4 w-4" /> },
              { id: "objects" as const, label: `${unifiedWorkspaceObjects.length} Objects`, icon: <Box className="h-4 w-4" /> },
              { id: "algebra" as const, label: "Algebra", icon: <ListTree className="h-4 w-4" /> },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setGraphWorkspaceTab(tab.id)}
                className={`inline-flex min-h-10 shrink-0 items-center justify-center gap-2 rounded-lg px-3 text-sm font-black transition ${graphWorkspaceTab === tab.id ? "bg-cyan-500 text-white shadow-sm dark:bg-cyan-300 dark:text-slate-950" : "text-slate-500 hover:bg-cyan-50 hover:text-cyan-800 dark:text-slate-300 dark:hover:bg-cyan-300/10 dark:hover:text-cyan-100"}`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {graphWorkspaceTab === "graph" && (
          <div ref={graphExportRef} className="graph-workspace-panel-host">
            <GraphWorkspacePanel
              plots={plots}
              colors={colors}
              regressionSeed={regressionSeed}
              onChange={handlePlotsChange}
              tableRange={{ start: tableStart, end: tableEnd, step: tableStep }}
              onTableRangeChange={({ start, end, step }) => {
                setTableStart(start);
                setTableEnd(end);
                setTableStep(step);
              }}
            />
          </div>
        )}

        {graphWorkspaceTab === "command" && (
          <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_280px]">
            <MathKeyboardInput
              value={input}
              onChange={setInput}
              onSubmit={runInput}
              label="Workspace command keyboard"
              placeholder="plot sin(x), solve x^2-5*x+6=0, derivative x^3"
              mode="command"
              examples={examples}
              onExample={setInput}
              defaultCompact
            />
            <div className="rounded-2xl bg-slate-100 p-3 text-sm leading-6 text-slate-600 dark:bg-white/10 dark:text-slate-300">
              <p className="font-black text-slate-950 dark:text-white">Fast commands</p>
              <p className="mt-1">Try plot, solve, factor, derivative, integral, table, roots, extrema, or intersection.</p>
            </div>
          </div>
        )}

        {graphWorkspaceTab === "results" && (
          <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_280px]">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-bold">Results</h2>
                <button type="button" onClick={() => setResults([])} className="rounded-full bg-slate-100 p-2 dark:bg-white/10" title="Clear results" aria-label="Clear results"><Trash2 className="h-4 w-4" /></button>
              </div>
              {results.length === 0 ? <EmptyPanel text="Run a command to see interpretation, exact result, numeric checks, and related output." /> : results.map((result) => <ResultCardView key={result.id} result={result} />)}
            </div>
            <div className="rounded-2xl bg-slate-100 p-3 text-sm font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300">
              Results stay here so the graph canvas keeps its space.
            </div>
          </div>
        )}

        {graphWorkspaceTab === "objects" && (
          <UnifiedWorkspacePanel
            objects={unifiedWorkspaceObjects}
            selectedObject={unifiedSelectedObject}
            selectedObjectId={unifiedSelectedObjectId}
            selectedObjectIds={unifiedSelectedObjectIds}
            onObjectAction={handleUnifiedObjectAction}
            onObjectChange={handleUnifiedObjectChange}
          />
        )}

        {graphWorkspaceTab === "algebra" && (
          <AlgebraObjectsPanel
            objects={workspaceObjects}
            selected={selectedAlgebra}
            protocol={protocol}
            graph={dynamicGraph}
            graphHealth={dynamicHealth}
            commandSummary={commandSummary}
            onSelect={selectWorkspaceObject}
            onRename={renameWorkspaceObject}
            onEditDefinition={editWorkspaceDefinition}
            onPatch={patchWorkspaceObject}
            onDuplicate={duplicateWorkspaceObject}
            onDelete={deleteWorkspaceObject}
            onReplay={replayConstructionStep}
            onContextMenu={(event, ref) => {
              event.preventDefault();
              setSelectedAlgebra(ref);
              setContextMenu({ x: event.clientX, y: event.clientY, target: { type: "algebra", ref } });
            }}
          />
        )}
      </SectionCard>}

      {workspaceView === "data" && dataPage === "cas" && (
        <CasStudioWorkspaceV2
          state={casNotebookState}
          selectedCell={selectedCasCell}
          composerInput={casComposerInput}
          composerOperation={casComposerOperation}
          exportMarkdown={casNotebookExport}
          results={results}
          onSelectCell={setSelectedCasCellId}
          onUpdateCell={updateCasCell}
          onRunCell={runCasCell}
          onRunAll={runCasNotebook}
          onAddCell={addCasCell}
          onDuplicateCell={duplicateCasCell}
          onDeleteCell={deleteCasCell}
          onReorderCells={reorderCasCells}
          onReset={resetCasNotebook}
          onModeChange={setCasMode}
          onAssumptionsChange={setCasAssumptions}
          onComposerInputChange={setCasComposerInput}
          onComposerOperationChange={setCasComposerOperation}
          onDataCommand={runDataCommand}
          onSendToGraph={sendCasCellToGraph}
          onExport={exportCasNotebook}
          onUndo={undoWorkspace}
          onRedo={redoWorkspace}
          onShare={exportShareUrl}
          shareControl={<ShareExportControl adapter={portableAdapter} className="portable-share-inline cas-header-share" />}
        />
      )}

      {workspaceView === "data" && dataPage === "spreadsheet" && (
        <CasSpreadsheetStudio legacyGrid={spreadsheet} onLegacyGridChange={setSpreadsheet} />
      )}

      {workspaceView === "data" && dataPage !== "cas" && dataPage !== "spreadsheet" && <SectionCard title={dataPage === "overview" ? "Data Workspace" : dataWorkspacePageTitle(dataPage)} description="Explore tables, symbolic algebra, function behavior, exact solutions, and linked mathematical objects." headerAction={<DataWorkspaceNav active={dataPage} />} compact={singleView}>
        <div data-testid="workspace-data-surface">
        {dataPage === "overview" && (
          <div className="space-y-3">
            <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-5">
              {dataOverviewCards.map((card) => (
                <Link key={card.route} to={card.route} className="rounded-xl border border-slate-200 bg-white p-3 text-left transition hover:-translate-y-0.5 hover:border-cyan-300 hover:bg-cyan-50 dark:border-white/10 dark:bg-slate-950/60 dark:hover:border-cyan-300/30 dark:hover:bg-cyan-300/10">
                  <p className="text-xs font-black uppercase tracking-wide text-cyan-600 dark:text-cyan-300">{card.concept}</p>
                  <h3 className="mt-2 font-bold text-slate-950 dark:text-white">{card.title}</h3>
                  <p className="mt-2 text-sm leading-5 text-slate-600 dark:text-slate-300">{card.text}</p>
                </Link>
              ))}
            </div>
          </div>
        )}
        {dataPage === "analysis" && (
          <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
            <FunctionAnalysisPanel plot={activeFunctionPlot} onCommand={runDataCommand} />
            <CasResultsPanel results={results} onClear={() => setResults([])} />
          </div>
        )}
        {dataPage === "results" && <CasResultsPanel results={results} onClear={() => setResults([])} />}
        {dataPage === "objects" && (
          <UnifiedWorkspacePanel
            objects={unifiedWorkspaceObjects}
            selectedObject={unifiedSelectedObject}
            selectedObjectId={unifiedSelectedObjectId}
            selectedObjectIds={unifiedSelectedObjectIds}
            onObjectAction={handleUnifiedObjectAction}
            onObjectChange={handleUnifiedObjectChange}
          />
        )}
        </div>
      </SectionCard>}

      {workspaceView === "3d" && (
        <ObjectStudioWorkspace
          shareControl={<ShareExportControl adapter={portableAdapter} className="portable-share-inline" />}
          vectorWorkbench={<VectorWorkbench3D a={vectorA3d} b={vectorB3d} view={vectorView3d} visible={vectorWorkbenchVisible} focus={vectorFocus3d} onA={setVectorA3d} onB={setVectorB3d} onView={setVectorView3d} onVisible={setVectorWorkbenchVisible} onFocus={setVectorFocus3d} />}
          vectorFocus={vectorFocus3d}
          onVectorFocus={setVectorFocus3d}
          scene={(
            <ThreeSceneWrapper height="100%" mobileHeight="100%" cameraPosition={typeof window !== "undefined" && window.matchMedia("(max-width: 620px)").matches ? [15, 12, 18] : [10, 8, 12]} showHint={false} interactionLabel="Drag objects, orbit, pan, and zoom">
              <ambientLight intensity={0.75} />
              <directionalLight position={[5, 6, 4]} intensity={1.2} />
              <Workspace3DScene
                surface={surface}
                surfaceExpression={surfaceExpression}
                solid={solid}
                surfaceScale={surfaceScale}
                solidSize={height3d}
                crossSection={crossSection}
                showSurface={showSurface}
                showSolid={showSolid}
                autoRotate={autoRotate3d}
                animationSpeed={sceneAnimationSpeed}
                zoom={zoom3d}
                performanceMode={performanceMode}
                cameraPreset={cameraPreset3d}
                selected={selected3d}
                transforms={transforms3d}
                addedObjects={added3dObjects}
                dragging={drag3d}
                interactionTool={objectStudioTool}
                snapStep={objectStudioSnapEnabled ? objectStudioSnapStep : 0}
                vectorWorkbench={{ a: vectorA3d, b: vectorB3d, view: vectorView3d, visible: vectorWorkbenchVisible, focus: vectorFocus3d }}
                onSelect={setSelected3d}
                onDrag={setDrag3d}
                onTransform={update3dTransform}
                onContextMenu={(event, id) => {
                  event.stopPropagation();
                  setSelected3d(id);
                  setContextMenu({ x: event.nativeEvent.clientX, y: event.nativeEvent.clientY, target: { type: "3d", id } });
                }}
              />
              <OrbitControls
                enableDamping
                enabled={!immersiveGeometry?.session && !drag3d && ["select", "orbit", "pan", "zoom"].includes(objectStudioTool)}
                enableRotate={objectStudioTool === "select" || objectStudioTool === "orbit"}
                enablePan={objectStudioTool === "select" || objectStudioTool === "pan"}
                enableZoom={objectStudioTool === "select" || objectStudioTool === "zoom"}
                mouseButtons={{
                  LEFT: objectStudioTool === "pan" ? THREE.MOUSE.PAN : objectStudioTool === "zoom" ? THREE.MOUSE.DOLLY : THREE.MOUSE.ROTATE,
                  MIDDLE: THREE.MOUSE.DOLLY,
                  RIGHT: THREE.MOUSE.PAN,
                }}
              />
            </ThreeSceneWrapper>
          )}
          objects={[
            ...threeBaseIds.filter((id) => !deletedBase3dIds.includes(id)).map((id): ObjectStudioItem => ({ id, label: threeObjectLabels[id], kind: id, transform: transforms3d[id], added: false })),
            ...added3dObjects.map((object): ObjectStudioItem => ({ id: object.id, label: object.label, kind: object.baseId, transform: object.transform, added: true })),
          ]}
          selectedId={selected3d}
          selectedTransform={selected3dTransform}
          shapes={objectStudioShapes}
          projectStatus={projectStatus}
          canUndo={undoStack.length > 0}
          canRedo={redoStack.length > 0}
          cameraPreset={cameraPreset3d}
          zoom={zoom3d}
          autoRotate={autoRotate3d}
          animationSpeed={sceneAnimationSpeed}
          tool={objectStudioTool}
          snapEnabled={objectStudioSnapEnabled}
          snapStep={objectStudioSnapStep}
          measurement={objectStudioMeasurement(
            selected3d,
            selected3dTransform,
            selected3d === "solid" ? solid : isBase3dId(selected3d) ? threeObjectSolidMap[selected3d] : added3dObjects.find((object) => object.id === selected3d)?.solid,
            added3dObjects.find(object=>object.id===selected3d)?.nlpCommand,
          )}
          onUndo={undoWorkspace}
          onRedo={redoWorkspace}
          onSave={saveWorkspace}
          onLoad={loadWorkspace}
          onExport={exportWorkspaceJson}
          onAdd={(shapeId) => {
            if (shapeId.startsWith("solid:")) {
              const solidKind = shapeId.slice(6) as SolidKind;
              const shape = objectStudioShapes.find((item) => item.id === shapeId);
              add3dSceneObject("solid", { solid: solidKind, label: shape?.label ?? solidKind });
            }
            else {
              const baseId = shapeId as ThreeObjectId;
              add3dSceneObject(baseId, { solid: threeObjectSolidMap[baseId], label: threeObjectLabels[baseId] });
            }
          }}
          onSelect={setSelected3d}
          onClearSelection={() => { setSelected3d(""); setDrag3d(null); }}
          onTransform={update3dTransform}
          onVector={update3dVector}
          onDuplicate={duplicate3dObject}
          onDelete={delete3dObject}
          onClear={clear3dObjects}
          onRestore={restore3dObject}
          onPreset={apply3dTransformPreset}
          onCamera={setCameraPreset3d}
          onZoom={setZoom3d}
          onAutoRotate={setAutoRotate3d}
          onAnimationSpeed={setSceneAnimationSpeed}
          onTool={setObjectStudioTool}
          onSnapEnabled={setObjectStudioSnapEnabled}
          onSnapStep={setObjectStudioSnapStep}
        />
      )}

      {workspaceView === "geometry" && (singleView ? (
        <GeometryWorkspacePanel
          shareControl={<ShareExportControl adapter={portableAdapter} className="portable-share-inline" />}
          activeTool={tool}
          construction={construction}
          selectedGeometry={selectedGeometry}
          selectedPointIds={selectedPointIds}
          polygonDraft={polygonDraft}
          geometryObjectPicks={geometryObjectPicks}
          constructionAccuracyReport={geometryCertificationReport}
          workspaceImages={workspaceImages}
          selectedImageId={selectedImageId}
          graphSettings={geometryGraphSettings}
          camera={geometryCamera}
          boardRef={svgRef}
          imageInputRef={imageInputRef}
          onImageUpload={handleImageUpload}
          onToolChange={selectGeometryTool}
          onSelectAll={() => setSelectedPointIds(construction.points.map((point) => point.id))}
          onMoveSelected={() => transformSelectedGeometryPoints("translate")}
          onRotateSelected={() => transformSelectedGeometryPoints("rotate")}
          onDilateSelected={() => transformSelectedGeometryPoints("dilate")}
          onResizeSelected={resizeSelectedGeometry}
          onUndo={undoWorkspace}
          onRedo={redoWorkspace}
          onDeleteSelected={() => deleteGeometryObject()}
          onShowHide={toggleSelectedGeometryVisibility}
          onLockSelected={() => toggleGeometryLock()}
          onTraceSelected={() => setSelectedGeometryTrace(true)}
          onStopTrace={() => setSelectedGeometryTrace(false)}
          onClearTrace={clearGeometryTrace}
          onReset={() => { recordWorkspaceStep("Clear geometry", "Removed all 2D geometry objects."); setConstruction(initialConstruction); setSelectedGeometry(null); setSelectedPointIds([]); setPolygonDraft([]); setGeometryObjectPicks([]); }}
          onSave={saveConstruction}
          onRestoreSaved={restoreSavedConstruction}
          onLoad={openPortableWorkspaceImport}
          onExport={exportGeometryPng}
          onGraphSettingsChange={setGeometryGraphSettings}
          onZoom={zoomGeometry}
          onFitView={fitGeometryView}
          onResetView={resetGeometryView}
          onBoardWheel={handleGeometryWheel}
          onBoardKeyDown={handleGeometryKeyDown}
          onClearPendingPicks={() => { setGeometryObjectPicks([]); setSelectedPointIds([]); setPolygonDraft([]); }}
          onBoardPointerDown={handleBoardPointerDown}
          onBoardPointerMove={handleBoardPointerMove}
          onBoardPointerUp={(event) => { event.currentTarget.releasePointerCapture(event.pointerId); geometryPanRef.current = null; geometryFreehandRef.current = null; setDragPointId(null); setDragGeometry(null); setDragImageId(null); }}
          onBoardPointerLeave={() => { geometryPanRef.current = null; geometryFreehandRef.current = null; setDragPointId(null); setDragGeometry(null); setDragImageId(null); }}
          onBoardContextMenu={handleGeometryContextMenu}
          onGeometryExportRef={(node) => { geometryExportRef.current = node; }}
          onSelectGeometry={(selection) => { setSelectedGeometry(selection); setSelectedImageId(null); }}
          onToggleGeometryVisibility={toggleGeometryVisibility}
          protocolEntries={protocol}
          onReplayProtocol={(index) => { const step = [...protocol].reverse()[index]; if (step) restoreProtocolSnapshot(step); }}
          constructionHelp={<ConstructionHelp tool={tool} />}
          objectInspector={(
            <GeometryObjectPanel
                selected={selectedGeometry}
                construction={construction}
                locked={selectedGeometry ? lockedGeometryIds.includes(selectedGeometry.id) : false}
                onPointChange={updateSelectedPoint}
                onStyleChange={updateSelectedGeometryStyle}
                onRadiusChange={updateSelectedCircleRadius}
                onDuplicate={duplicateGeometryObject}
                onDelete={deleteGeometryObject}
                onRestore={restoreGeometryObject}
                onToggleLock={toggleGeometryLock}
              />
          )}
          imageInspector={(
            <ImageObjectPanel
                image={workspaceImages.find((image) => image.id === selectedImageId) ?? null}
                onChange={updateSelectedImage}
                onDelete={deleteSelectedImage}
              />
          )}
          constructionProtocol={<ConstructionProtocolPanel protocol={protocol} onReplay={restoreProtocolSnapshot} />}
          unifiedObjectsPanel={(
            <UnifiedWorkspacePanel
                objects={unifiedWorkspaceObjects}
                selectedObject={unifiedSelectedObject}
                selectedObjectId={unifiedSelectedObjectId}
                selectedObjectIds={unifiedSelectedObjectIds}
                onObjectAction={handleUnifiedObjectAction}
                onObjectChange={handleUnifiedObjectChange}
              />
          )}
          measurementsPanel={<Measurements construction={construction} />}
          constraintsPanel={<ConstraintPanel construction={construction} />}
        />
      ) : (
        <SectionCard title="Geometry Constructor" description="Create points, lines, circles, polygons, drag points, and inspect live measurements.">
          <GeometryWorkspacePanel
          shareControl={<ShareExportControl adapter={portableAdapter} className="portable-share-inline" />}
            activeTool={tool}
            construction={construction}
            selectedGeometry={selectedGeometry}
            selectedPointIds={selectedPointIds}
            polygonDraft={polygonDraft}
            geometryObjectPicks={geometryObjectPicks}
            constructionAccuracyReport={geometryCertificationReport}
            workspaceImages={workspaceImages}
            selectedImageId={selectedImageId}
          graphSettings={geometryGraphSettings}
          camera={geometryCamera}
            boardRef={svgRef}
            imageInputRef={imageInputRef}
            onImageUpload={handleImageUpload}
            onToolChange={selectGeometryTool}
            onSelectAll={() => setSelectedPointIds(construction.points.map((point) => point.id))}
            onMoveSelected={() => transformSelectedGeometryPoints("translate")}
            onRotateSelected={() => transformSelectedGeometryPoints("rotate")}
            onDilateSelected={() => transformSelectedGeometryPoints("dilate")}
            onResizeSelected={resizeSelectedGeometry}
            onUndo={undoWorkspace}
            onRedo={redoWorkspace}
            onDeleteSelected={() => deleteGeometryObject()}
            onShowHide={toggleSelectedGeometryVisibility}
            onLockSelected={() => toggleGeometryLock()}
            onTraceSelected={() => setSelectedGeometryTrace(true)}
            onStopTrace={() => setSelectedGeometryTrace(false)}
            onClearTrace={clearGeometryTrace}
            onReset={() => { recordWorkspaceStep("Clear geometry", "Removed all 2D geometry objects."); setConstruction(initialConstruction); setSelectedGeometry(null); setSelectedPointIds([]); setPolygonDraft([]); setGeometryObjectPicks([]); }}
            onSave={saveConstruction}
            onRestoreSaved={restoreSavedConstruction}
            onLoad={openPortableWorkspaceImport}
            onExport={exportGeometryPng}
          onGraphSettingsChange={setGeometryGraphSettings}
          onZoom={zoomGeometry}
          onFitView={fitGeometryView}
          onResetView={resetGeometryView}
          onBoardWheel={handleGeometryWheel}
          onBoardKeyDown={handleGeometryKeyDown}
            onClearPendingPicks={() => { setGeometryObjectPicks([]); setSelectedPointIds([]); setPolygonDraft([]); }}
            onBoardPointerDown={handleBoardPointerDown}
            onBoardPointerMove={handleBoardPointerMove}
          onBoardPointerUp={(event) => { event.currentTarget.releasePointerCapture(event.pointerId); geometryPanRef.current = null; geometryFreehandRef.current = null; setDragPointId(null); setDragGeometry(null); setDragImageId(null); }}
          onBoardPointerLeave={() => { geometryPanRef.current = null; geometryFreehandRef.current = null; setDragPointId(null); setDragGeometry(null); setDragImageId(null); }}
            onBoardContextMenu={handleGeometryContextMenu}
            onGeometryExportRef={(node) => { geometryExportRef.current = node; }}
            onSelectGeometry={(selection) => { setSelectedGeometry(selection); setSelectedImageId(null); }}
            onToggleGeometryVisibility={toggleGeometryVisibility}
            protocolEntries={protocol}
            onReplayProtocol={(index) => { const step = [...protocol].reverse()[index]; if (step) restoreProtocolSnapshot(step); }}
            sidebar={(
              <>
                <ConstructionHelp tool={tool} />
                <GeometryObjectPanel
                  selected={selectedGeometry}
                  construction={construction}
                  locked={selectedGeometry ? lockedGeometryIds.includes(selectedGeometry.id) : false}
                  onPointChange={updateSelectedPoint}
                  onStyleChange={updateSelectedGeometryStyle}
                  onRadiusChange={updateSelectedCircleRadius}
                  onDuplicate={duplicateGeometryObject}
                  onDelete={deleteGeometryObject}
                  onRestore={restoreGeometryObject}
                  onToggleLock={toggleGeometryLock}
                />
                <ImageObjectPanel
                  image={workspaceImages.find((image) => image.id === selectedImageId) ?? null}
                  onChange={updateSelectedImage}
                  onDelete={deleteSelectedImage}
                />
                <ConstructionProtocolPanel protocol={protocol} onReplay={restoreProtocolSnapshot} />
                <Measurements construction={construction} />
                <ConstraintPanel construction={construction} />
              </>
            )}
          />
        </SectionCard>
      ))}
      {contextMenu && (
        <ObjectContextMenu
          state={contextMenu}
          onClose={() => setContextMenu(null)}
          onDuplicate={() => {
            if (contextMenu.target.type === "algebra") duplicateWorkspaceObject(contextMenu.target.ref);
            else if (contextMenu.target.type === "3d") duplicate3dObject(contextMenu.target.id);
            else duplicateGeometryObject(contextMenu.target);
            setContextMenu(null);
          }}
          onDelete={() => {
            if (contextMenu.target.type === "algebra") deleteWorkspaceObject(contextMenu.target.ref);
            else if (contextMenu.target.type === "3d") delete3dObject(contextMenu.target.id);
            else deleteGeometryObject(contextMenu.target);
            setContextMenu(null);
          }}
          onRestore={() => {
            if (contextMenu.target.type === "algebra") patchWorkspaceObject(contextMenu.target.ref, { visible: true, trace: false });
            else if (contextMenu.target.type === "3d") restore3dObject(contextMenu.target.id);
            else restoreGeometryObject(contextMenu.target);
            setContextMenu(null);
          }}
          onLock={() => {
            if (contextMenu.target.type === "algebra") patchWorkspaceObject(contextMenu.target.ref, { locked: true });
            else if (contextMenu.target.type === "3d") update3dTransform(contextMenu.target.id, { locked: !selected3dTransform.locked });
            else toggleGeometryLock(contextMenu.target);
            setContextMenu(null);
          }}
          onRename={() => {
            const target = contextMenu.target;
            const ref = target.type === "algebra" ? target.ref : target.type === "3d" ? { kind: "3d" as const, id: target.id } : { kind: target.type, id: target.id };
            const next = window.prompt("Rename object", objectDisplayName(workspaceObjects, ref));
            if (next) renameWorkspaceObject(ref, next);
            setContextMenu(null);
          }}
          onTrace={() => {
            const target = contextMenu.target;
            const ref = target.type === "algebra" ? target.ref : target.type === "3d" ? { kind: "3d" as const, id: target.id } : { kind: target.type, id: target.id };
            patchWorkspaceObject(ref, { trace: true });
            setContextMenu(null);
          }}
        />
      )}
    </div>
  );
}

function interpretInput(input: string): ResultCard {
  const normalized = input.trim();
  try {
    const command = parseWorkspaceCommand(normalized);
    if (command.name === "plot") {
      const expression = normalizePlotExpression(command.args.join(", ") || normalized);
      return { id: crypto.randomUUID(), input, interpretation: "2D plot", result: `Added y = ${expression}`, detail: "The expression is plotted over x from -10 to 10." };
    }
    if (command.name === "solve") return solveCommand(command.args[0] ?? "", input);
    if (command.name === "solvesystem") return solveSystemCommand(command.args, input);
    if (command.name === "root") return rootsCommand(command.args[0] ?? "", input);
    if (command.name === "extremum") return extremaCommand(command.args[0] ?? "", input);
    if (command.name === "intersect") return intersectCommand(command.args.join(" and "), input);
    if (command.name === "relation") return relationCommand(command.args, input);
    if (command.name === "distance") return distanceCommand(command.args, input);
    if (command.name === "angle") return angleCommand(command.args, input);
    if (command.name === "conic") return conicCommand(command.args.join(","), input);
    if (command.name === "line" || command.name === "segment" || command.name === "ray") return linearObjectCommand(command.name, command.args, input);
    if (command.name === "tangent") return tangentCommand(command.args, input);
    if (command.name === "locus") return locusCommand(command.args, input);
    if (command.name === "table") return tableCommand(command.args, input);
    if (command.name === "dynamictable") return dynamicTableCommand(command.args, input);
    if (command.name === "sequence") return sequenceCommand(command.args, input);
    if (command.name === "list") return listCommand(command.args, input);
    if (command.name === "filldown") return fillDownCommand(command.args, input);
    if (command.name === "rangecsv") return rangeCsvCommand(command.args, input);
    if (command.name === "cas") return casLinkedCommand(command.args, input);
    if (command.name === "substitute") return substituteCommand(command.args, input);
    if (command.name === "simplify") return simplifyCommand(command.args[0] ?? "", input);
    if (command.name === "expand") return expandCommand(command.args[0] ?? "", input);
    if (command.name === "partialfractions") return partialFractionsCommand(command.args, input);
    if (command.name === "polynomialdivide") return polynomialDivideCommand(command.args, input);
    if (command.name === "limit") return limitCommand(command.args, input);
    if (command.name === "series") return seriesCommand(command.args, input);
    if (command.name === "matrix") return matrixCommand(command.args.join(","), input);
    if (command.name === "determinant") return determinantCommand(command.args.join(","), input);
    if (command.name === "transpose") return transposeCommand(command.args.join(","), input);
    if (command.name === "inverse") return inverseCommand(command.args.join(","), input);
    if (command.name === "plane") return plane3dCommand(command.args, input);
    if (command.name === "sphere" || command.name === "cone" || command.name === "cylinder") return solid3dCommand(command.name, command.args, input);
    if (command.name === "slice") return slice3dCommand(command.args, input);
    if (command.name === "gizmo") return gizmoCommand(command.args, input);
    if (command.name === "measure3d") return measure3dCommand(command.args, input);
    if (command.name === "rotate" || command.name === "translate" || command.name === "dilate" || command.name === "mirror") return transformActionCommand(command.name, command.args, input);
    if (command.name === "setcolor" || command.name === "showlabel" || command.name === "setvisible" || command.name === "settrace" || command.name === "setopacity") return styleActionCommand(command.name, command.args, input);
    if (command.name === "startanimation" || command.name === "stopanimation") return animationActionCommand(command.name, command.args, input);
    if (command.name === "point") return definitionCommandCard(input, "2D point definition", "Use A=(x,y) in the input bar to create a live draggable point.");
    if (command.name === "vector") return vectorCommand(command.args, input);
    if (command.name === "circle") return definitionCommandCard(input, "Circle definition", "Use c: x^2+y^2=16 or the circle tool to create a live circle.");
    if (command.name === "surface") return definitionCommandCard(input, "3D surface definition", "Use z=sin(x)*cos(y) or mode=3d to create a live surface.");
    if (command.name === "slider") return definitionCommandCard(input, "Slider definition", "Slider objects are registered in the dynamic kernel and will drive animation bindings in Phase 4.");
    if (command.name === "derivative") {
      const expression = command.args[0] ?? "";
      const symbolic = trySymbolic(() => symbolicDerivative(expression));
      const derivative = symbolic?.result ?? derivativeText(expression);
      return { id: crypto.randomUUID(), input, interpretation: symbolic ? "Symbolic derivative" : "Derivative", result: derivative, detail: symbolic?.detail ?? "Symbolic support for common polynomial, sine, and cosine expressions.", steps: symbolic?.steps ?? derivativeSteps(expression, derivative), related: [`plot ${expression}`, `plot ${derivative}`], graphExpression: derivative };
    }
    if (command.name === "integral") {
      const expression = command.args[0] ?? "";
      const symbolic = trySymbolic(() => symbolicIntegral(expression));
      const integral = symbolic?.result ?? integralText(expression);
      const graphExpression = integral.replace(/\s*\+\s*C$/, "");
      return { id: crypto.randomUUID(), input, interpretation: symbolic ? "Symbolic integral" : "Indefinite integral", result: integral, detail: symbolic?.detail ?? "Power-rule antiderivative support for common polynomial terms.", steps: symbolic?.steps ?? integralSteps(expression, integral), related: [`derivative ${graphExpression}`, `plot ${graphExpression}`], graphExpression };
    }
    if (command.name === "factor") return factorCommand(command.args[0] ?? "", input);
    if (/^area\s+circle\s+radius\s+/i.test(normalized)) {
      const radius = Number(normalized.replace(/^area\s+circle\s+radius\s+/i, ""));
      return { id: crypto.randomUUID(), input, interpretation: "Circle area", result: `Area = ${roundTo(Math.PI * radius * radius, 4)}`, detail: `Formula: A = pi r^2 with r = ${radius}.`, steps: [`Use A = pi r^2.`, `Substitute r = ${radius}.`, `A = pi * ${radius}^2 = ${roundTo(Math.PI * radius * radius, 4)}.`] };
    }
    const value = evaluateMathExpression(normalized, 0);
    return { id: crypto.randomUUID(), input, interpretation: "Calculator", result: `${roundTo(value, 10)}`, detail: "Numeric evaluation with constants, trig, logs, powers, roots, and arithmetic." };
  } catch (error) {
    return parserErrorCard(input, error);
  }
}

function parseWorkspaceCommand(input: string): { name: string; args: string[] } {
  const bracket = input.match(/^([a-z]+)\s*(?:\[|\()(.*)(?:\]|\))$/i);
  if (bracket) return { name: commandAlias(bracket[1]), args: splitCommandArgs(bracket[2]) };
  const word = input.match(/^([a-z]+)\s+(.+)$/i);
  if (word) {
    const name = commandAlias(word[1]);
    if (name === "table") return { name, args: splitLooseTableArgs(word[2]) };
    if (name === "intersect") return { name, args: word[2].split(/\s+and\s+|,/i).map((part) => part.trim()).filter(Boolean) };
    if (name === "sequence") return { name, args: splitLooseSequenceArgs(word[2]) };
    if (name === "substitute") return { name, args: splitLooseSubstituteArgs(word[2]) };
    return { name, args: [word[2].trim()] };
  }
  return { name: "calculator", args: [input] };
}

function commandAlias(name: string) {
  const compact = name.toLowerCase();
  const resolved = normalizeCommandName(compact);
  if (!resolved) throw new Error(`Unknown command "${name}".`);
  return resolved;
}

function splitCommandArgs(value: string) {
  const args: string[] = [];
  let current = "";
  let depth = 0;
  for (const char of value) {
    if (char === "(" || char === "[") depth += 1;
    if (char === ")" || char === "]") depth -= 1;
    if (char === "," && depth === 0) {
      args.push(current.trim());
      current = "";
    } else current += char;
  }
  if (current.trim()) args.push(current.trim());
  return args;
}

function splitLooseTableArgs(value: string) {
  const commaArgs = splitCommandArgs(value);
  if (commaArgs.length > 1) return commaArgs;
  const natural = value.match(/^(.+?)\s+from\s+(-?\d+(?:\.\d+)?)\s+to\s+(-?\d+(?:\.\d+)?)(?:\s+step\s+(-?\d+(?:\.\d+)?))?$/i);
  if (natural) return [natural[1], natural[2], natural[3], natural[4] ?? "1"];
  const named = value.match(/^(.+?)\s+start\s*=\s*(-?\d+(?:\.\d+)?)\s+end\s*=\s*(-?\d+(?:\.\d+)?)(?:\s+step\s*=\s*(-?\d+(?:\.\d+)?))?$/i);
  if (named) return [named[1], named[2], named[3], named[4] ?? "1"];
  const match = value.match(/^(.+?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)$/);
  return match ? [match[1], match[2], match[3], match[4]] : [value.trim()];
}

function splitLooseSequenceArgs(value: string) {
  const commaArgs = splitCommandArgs(value);
  if (commaArgs.length > 1) return commaArgs;
  const range = value.match(/^(.+?)\s+([a-z]\w*)\s*=\s*(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)(?:\s+step\s+(-?\d+(?:\.\d+)?))?$/i);
  if (range) return [range[1], range[2], range[3], range[4], range[5] ?? "1"];
  const natural = value.match(/^(.+?)\s+for\s+([a-z]\w*)\s+from\s+(-?\d+(?:\.\d+)?)\s+to\s+(-?\d+(?:\.\d+)?)(?:\s+step\s+(-?\d+(?:\.\d+)?))?$/i);
  if (natural) return [natural[1], natural[2], natural[3], natural[4], natural[5] ?? "1"];
  return [value.trim(), "n", "1", "10", "1"];
}

function splitLooseSubstituteArgs(value: string) {
  const commaArgs = splitCommandArgs(value);
  if (commaArgs.length > 1) return commaArgs;
  const natural = value.split(/\s+with\s+/i);
  if (natural.length < 2) return [value.trim()];
  const assignments = natural.slice(1).join(" with ").split(/\s*,\s*|\s+and\s+/i).map((part) => part.trim()).filter(Boolean);
  return [natural[0].trim(), ...assignments];
}

function parserErrorCard(input: string, error: unknown): ResultCard {
  const message = error instanceof Error ? error.message : "Unsupported input";
  const suggestions = suggestCommands(input);
  const unsupported = createUnsupportedWorkspaceAction("Workspace command", message, suggestions);
  return unsupportedActionResultCard(input, unsupported);
}

function unsupportedActionResultCard(input: string, unsupported: ReturnType<typeof createUnsupportedWorkspaceAction>): ResultCard {
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Unsupported workspace action",
    result: unsupported.message,
    detail: `${unsupported.reason} Try: ${unsupported.suggestions.join("  |  ")}`,
    steps: [
      "No workspace state was changed.",
      "Use Command[arguments] or command arguments.",
      "Use * for multiplication when the expression is ambiguous.",
    ],
  };
}

function suggestCommands(input: string) {
  const lower = input.toLowerCase();
  const registryExamples = commandExamplesFor(lower, 4);
  if (registryExamples.length) return registryExamples;
  if (lower.includes("der")) return ["Derivative[x^3-2*x]", "plot 3*x^2-2"];
  if (lower.includes("int")) return ["Integral[3*x^2]", "Table[x^2, -3, 3, 1]"];
  if (lower.includes("inter")) return ["Intersect[x^2, 2*x+3]"];
  if (lower.includes("table")) return ["Table[sin(x), -3, 3, 0.5]"];
  return ["Root[x^2-4]", "Solve[x^2-5*x+6=0]", "Sequence[n^2, n, 1, 6]"];
}

function normalizeTemplateRouteParam(value: string) {
  return value.trim().toLowerCase().replace(/_/g, "-").replace(/\s+/g, "-");
}

function normalizePlotExpression(input: string) {
  return input.replace(/^plot\s+/i, "").replace(/^y\s*=\s*/i, "").trim();
}

function mathToBoardPoint(x: number, y: number) {
  return { x: 320 + x * 40, y: 210 - y * 40 };
}

function evaluateMathExpression(expression: string, x: number) {
  const safe = expression
    .replace(/\^/g, "**")
    .replace(/\bpi\b/gi, "Math.PI")
    .replace(/\be\b/g, "Math.E")
    .replace(/\bsin\b/gi, "Math.sin")
    .replace(/\bcos\b/gi, "Math.cos")
    .replace(/\btan\b/gi, "Math.tan")
    .replace(/\basin\b/gi, "Math.asin")
    .replace(/\bacos\b/gi, "Math.acos")
    .replace(/\batan\b/gi, "Math.atan")
    .replace(/\bsqrt\b/gi, "Math.sqrt")
    .replace(/\bcbrt\b/gi, "Math.cbrt")
    .replace(/\babs\b/gi, "Math.abs")
    .replace(/\bln\b/gi, "Math.log")
    .replace(/\blog\b/gi, "Math.log10")
    .replace(/\bexp\b/gi, "Math.exp");
  if (!/^[0-9x+\-*/().,\s*MATHPIEabceghilnopqrstxyz]+$/i.test(safe) || /[;={}\]'"[]/.test(safe)) throw new Error("Unsupported expression");
  return Function("x", `"use strict"; return (${safe});`)(x) as number;
}

function solveCommand(equation: string, input: string): ResultCard {
  const [left, right = "0"] = equation.split("=");
  const symbolic = isAlgebraicSolveCandidate(equation) ? trySymbolic(() => symbolicSolve(equation.includes("=") ? equation : `${equation}=0`)) : null;
  const f = (x: number) => evaluateMathExpression(left, x) - evaluateMathExpression(right, x);
  const roots: number[] = [];
  for (let x = -50; x < 50; x += 0.25) {
    const y1 = f(x);
    const y2 = f(x + 0.25);
    if (Math.abs(y1) < 1e-6) roots.push(x);
    if (Number.isFinite(y1) && Number.isFinite(y2) && y1 * y2 < 0) roots.push(bisect(f, x, x + 0.25));
  }
  const unique = Array.from(new Set(roots.map((root) => roundTo(root, 5)))).slice(0, 8);
  const quadratic = parseQuadratic(`${left}-(${right})`);
  if (symbolic) return { id: crypto.randomUUID(), input, interpretation: "Symbolic equation solve", result: symbolic.result, detail: symbolic.detail, steps: [...symbolic.steps, unique.length ? `Numeric verification: x ≈ ${unique.join(", ")}.` : "Numeric scan did not find additional real roots in [-50, 50]."], related: [`plot ${left}-(${right})`, `roots ${left}-(${right})`] };
  return { id: crypto.randomUUID(), input, interpretation: "Equation solve", result: unique.length ? `x = ${unique.join(", ")}` : "No real roots found in [-50, 50]", detail: "Numeric sign-change solver over a bounded interval.", steps: quadratic ? quadraticSteps(quadratic.a, quadratic.b, quadratic.c) : [`Move all terms to one side: ${left} - (${right}) = 0.`, "Scan the graph for sign changes.", "Refine each sign change with bisection."], related: [`plot ${left}-(${right})`, `roots ${left}-(${right})`] };
}

function isAlgebraicSolveCandidate(equation: string) {
  return !/\b(sin|cos|tan|asin|acos|atan|log|ln|exp|sqrt)\s*\(/i.test(equation);
}

function solveSystemCommand(args: string[], input: string): ResultCard {
  const equations = args.map((arg) => arg.trim()).filter(Boolean);
  if (equations.length < 2) throw new Error("Use SolveSystem[x+y=5, x-y=1].");
  const variables = Array.from(new Set(equations.join(",").match(/\b[a-z]\b/gi)?.map((item) => item.toLowerCase()) ?? [])).slice(0, equations.length);
  const symbolic = trySymbolic(() => symbolicSystemSolve(equations, variables));
  if (!symbolic) throw new Error("System solve needs supported algebraic equations.");
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Symbolic system solve",
    result: symbolic.result,
    detail: symbolic.detail,
    steps: symbolic.steps,
    related: equations.map((equation) => `plot ${equation.includes("=") ? equation.replace("=", "-(") + ")" : equation}`),
  };
}

function factorCommand(expression: string, input: string): ResultCard {
  const symbolic = trySymbolic(() => symbolicFactor(expression));
  if (symbolic) return { id: crypto.randomUUID(), input, interpretation: "Symbolic factor", result: symbolic.result, detail: symbolic.detail, steps: symbolic.steps, related: [`expand ${symbolic.result}`, `solve ${expression}=0`, `plot ${expression}`] };
  const quadratic = parseQuadratic(expression);
  if (!quadratic) return { id: crypto.randomUUID(), input, interpretation: "Factor", result: "Factoring currently supports quadratics like x^2-5*x+6.", detail: "Try expand, solve, roots, table, or plot for non-quadratic expressions." };
  const roots = quadraticRoots(quadratic.a, quadratic.b, quadratic.c);
  if (!roots) return { id: crypto.randomUUID(), input, interpretation: "Factor", result: "No real linear factorization", detail: "The discriminant is negative, so real linear factors are unavailable.", steps: quadraticSteps(quadratic.a, quadratic.b, quadratic.c) };
  const [r1, r2] = roots;
  const factor = quadratic.a === 1 ? `(x ${signed(-r1)}) (x ${signed(-r2)})` : `${quadratic.a}(x ${signed(-r1)}) (x ${signed(-r2)})`;
  return { id: crypto.randomUUID(), input, interpretation: "Factor", result: factor, detail: "Quadratic factorization from computed roots.", steps: [`Identify a=${quadratic.a}, b=${quadratic.b}, c=${quadratic.c}.`, `Find roots: x=${roundTo(r1, 5)} and x=${roundTo(r2, 5)}.`, `Build factors from roots: (x-r1)(x-r2).`], related: [`solve ${expression}=0`, `plot ${expression}`] };
}

function rootsCommand(expression: string, input: string): ResultCard {
  return solveCommand(`${expression}=0`, input);
}

function extremaCommand(expression: string, input: string): ResultCard {
  const candidates: { x: number; y: number }[] = [];
  let previousX = -10;
  let previousSlope = numericDerivative(expression, previousX);
  for (let x = -9.95; x <= 10; x += 0.05) {
    const slope = numericDerivative(expression, x);
    if (Number.isFinite(slope) && Number.isFinite(previousSlope) && slope * previousSlope < 0) {
      const root = bisect((value) => numericDerivative(expression, value), previousX, x);
      candidates.push({ x: roundTo(root, 4), y: roundTo(evaluateMathExpression(expression, root), 4) });
    }
    previousX = x;
    previousSlope = slope;
  }
  const unique = candidates.filter((point, index) => candidates.findIndex((candidate) => Math.abs(candidate.x - point.x) < 0.02) === index).slice(0, 8);
  return { id: crypto.randomUUID(), input, interpretation: "Extrema", result: unique.length ? unique.map((point) => `(${point.x}, ${point.y})`).join(", ") : "No local extrema found in [-10, 10]", detail: "Numeric derivative sign-change search.", steps: ["Approximate f'(x) with a centered difference.", "Find where f'(x) changes sign.", "Evaluate f(x) at those candidate x-values."], table: unique };
}

function intersectCommand(body: string, input: string): ResultCard {
  const parts = body.split(/\s+and\s+|,/i).map((part) => part.trim()).filter(Boolean);
  if (parts.length !== 2) throw new Error("Use: intersect expression1 and expression2");
  const kernelObjects = parseTwoKernelObjects(parts);
  if (kernelObjects) {
    const hits = kernelIntersectObjects(kernelObjects[0], kernelObjects[1]);
    return {
      id: crypto.randomUUID(),
      input,
      interpretation: "Kernel intersection",
      result: hits.length ? hits.map((hit) => `(${roundTo(hit.x, 5)}, ${roundTo(hit.y, 5)})${hit.multiplicity === 2 ? " tangent" : ""}`).join(", ") : "No supported intersections",
      detail: hits.length ? `${hits[0].source} solver with boundary checks and multiplicity.` : "No intersection found for the supported object pair.",
      table: hits.map((hit) => ({ x: roundTo(hit.x, 5), y: roundTo(hit.y, 5), label: hit.source })),
      steps: ["Parse both objects into the 2D kernel.", "Solve the correct intersection system.", "Filter by segment/ray boundaries and dedupe points."],
    };
  }
  const [left, right] = parts;
  const f = (x: number) => evaluateMathExpression(left, x) - evaluateMathExpression(right, x);
  const intersections: ResultTableRow[] = [];
  for (let x = -20; x < 20; x += 0.1) {
    const y1 = f(x);
    const y2 = f(x + 0.1);
    if (Number.isFinite(y1) && Number.isFinite(y2) && y1 * y2 < 0) {
      const root = bisect(f, x, x + 0.1);
      intersections.push({ x: roundTo(root, 4), y: roundTo(evaluateMathExpression(left, root), 4) });
    }
  }
  const unique = intersections.filter((point, index) => intersections.findIndex((candidate) => Math.abs(candidate.x - point.x) < 0.02) === index).slice(0, 8);
  return { id: crypto.randomUUID(), input, interpretation: "Intersection", result: unique.length ? unique.map((point) => `(${point.x}, ${point.y})`).join(", ") : "No intersections found in [-20, 20]", detail: "Solves expression1 - expression2 = 0 numerically.", steps: [`Set ${left} = ${right}.`, `Solve ${left} - (${right}) = 0.`, "Evaluate either expression at each solution."], table: unique, related: [`plot ${left}`, `plot ${right}`] };
}

function relationCommand(args: string[], input: string): ResultCard {
  const objects = parseTwoKernelObjects(args);
  if (!objects) throw new Error("Use Relation[Line[(0,0),(1,1)], Line[(0,1),(1,2)]] or Relation[x^2+y^2=9, Line[(-3,0),(3,0)]].");
  const result = relationBetween(objects[0], objects[1]);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Geometry relation",
    result: `${result.relation} (${Math.round(result.confidence * 100)}%)`,
    detail: result.detail,
    steps: proofHintsForRelation(result),
  };
}

function distanceCommand(args: string[], input: string): ResultCard {
  const points = args.map(parsePointArgument).filter(Boolean) as KernelPoint[];
  if (points.length < 2) throw new Error("Use Distance[(0,0), (3,4)].");
  const value = kernelDistance(points[0], points[1]);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Distance",
    result: `${roundTo(value, 6)}`,
    detail: "Distance kernel uses sqrt((x2-x1)^2 + (y2-y1)^2).",
    steps: [`dx = ${roundTo(points[1].x - points[0].x, 6)}.`, `dy = ${roundTo(points[1].y - points[0].y, 6)}.`, `distance = ${roundTo(value, 6)}.`],
  };
}

function angleCommand(args: string[], input: string): ResultCard {
  const points = args.map(parsePointArgument).filter(Boolean) as KernelPoint[];
  if (points.length < 3) throw new Error("Use Angle[(1,0), (0,0), (0,1)].");
  const a = points[0], vertex = points[1], b = points[2];
  const va = kernelVector(vertex, a);
  const vb = kernelVector(vertex, b);
  const dot = va.x * vb.x + va.y * vb.y;
  const magnitude = Math.hypot(va.x, va.y) * Math.hypot(vb.x, vb.y) || 1;
  const degrees = THREE.MathUtils.radToDeg(Math.acos(Math.max(-1, Math.min(1, dot / magnitude))));
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Angle",
    result: `${roundTo(degrees, 4)} deg`,
    detail: "Angle kernel uses vector dot product around the middle point.",
    steps: ["Build vectors from the vertex.", "Compute dot product and magnitudes.", "Apply arccos(dot / |a||b|)."],
  };
}

function conicCommand(body: string, input: string): ResultCard {
  const item = parseConicEquation(body);
  if (!item) throw new Error("Use Conic[x^2/9+y^2/4=1], Conic[x^2+y^2=16], or Conic[y=x^2].");
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Conic",
    result: `${item.type}: ${formatConicCoefficients(item.coefficients)}`,
    detail: "Conic registered as Ax^2 + Bxy + Cy^2 + Dx + Ey + F = 0 for intersection and relation tools.",
    steps: ["Normalize the equation.", "Classify by discriminant B^2 - 4AC.", "Store coefficients for line/conic intersections."],
  };
}

function linearObjectCommand(name: string, args: string[], input: string): ResultCard {
  const points = args.map(parsePointArgument).filter(Boolean) as KernelPoint[];
  if (points.length < 2) throw new Error(`Use ${name}[pointA, pointB], for example ${name}[(0,0),(4,3)].`);
  const object = name === "segment" ? kernelSegment(points[0], points[1]) : name === "ray" ? kernelRay(points[0], points[1]) : kernelLine(points[0], points[1]);
  const length = kernelDistance(object.a, object.b);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: `${name[0].toUpperCase()}${name.slice(1)} object`,
    result: `${name} through (${object.a.x}, ${object.a.y}) and (${object.b.x}, ${object.b.y})`,
    detail: `${name} length/vector magnitude reference: ${roundTo(length, 6)}.`,
    steps: ["Parse two coordinate points.", "Create a boundary-aware linear object.", "Expose it to intersection and relation commands."],
  };
}

function vectorCommand(args: string[], input: string): ResultCard {
  const points = args.map(parsePointArgument).filter(Boolean) as KernelPoint[];
  if (points.length < 2) throw new Error("Use Vector[(0,0), (3,2)].");
  const value = kernelVector(points[0], points[1]);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Vector",
    result: `<${roundTo(value.x, 6)}, ${roundTo(value.y, 6)}>`,
    detail: `Magnitude = ${roundTo(Math.hypot(value.x, value.y), 6)}.`,
    steps: ["Subtract start coordinates from end coordinates.", "Use the result as translation direction or slope evidence."],
  };
}

function tangentCommand(args: string[], input: string): ResultCard {
  const pointArg = parsePointArgument(args[0] ?? "");
  const conicArg = parseKernelObject(args[1] ?? "");
  if (!pointArg || !conicArg) throw new Error("Use Tangent[(3,0), x^2+y^2=9].");
  const probe = kernelLine(kernelPoint(pointArg.x - 1, pointArg.y), kernelPoint(pointArg.x + 1, pointArg.y));
  const relation = relationBetween(probe, conicArg);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Tangent helper",
    result: relation.relation === "tangent" ? "horizontal tangent candidate" : "tangent construction registered",
    detail: "Phase 2 exposes tangent checks through the relation/intersection kernel; canvas construction uses the Tangent tool.",
    steps: ["Parse point and conic.", "Probe tangent multiplicity.", ...proofHintsForRelation(relation).slice(0, 2)],
  };
}

function locusCommand(args: string[], input: string): ResultCard {
  const center = parsePointArgument(args[0] ?? "") ?? kernelPoint(0, 0);
  const radius = 2;
  const table = Array.from({ length: 24 }, (_, index) => {
    const theta = (index / 24) * Math.PI * 2;
    return { x: roundTo(center.x + Math.cos(theta) * radius, 4), y: roundTo(center.y + Math.sin(theta) * radius, 4), label: "locus" };
  });
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Locus",
    result: `${table.length} sample points`,
    detail: "Browser-only locus sampling registered for trace/proof workflows.",
    steps: ["Choose a driving parameter.", "Sample positions around the path.", "Dedupe and render as a trace object."],
    table,
  };
}

function tableCommand(args: string[] | string, input: string): ResultCard {
  const parts = Array.isArray(args) ? args : [args];
  const expression = parts[0] ?? "x";
  const start = Number(parts[1] ?? -4);
  const end = Number(parts[2] ?? 4);
  const step = Math.abs(Number(parts[3] ?? 1)) || 1;
  const table = generateValueTable(expression, start, end, step);
  return { id: crypto.randomUUID(), input, interpretation: "Editable value table", result: `Generated ${table.length} rows`, detail: `x from ${start} to ${end} by ${step}. Change the table range controls in the graph panel for live tables.`, table, related: [`plot ${expression}`], graphExpression: expression };
}

function dynamicTableCommand(args: string[], input: string): ResultCard {
  const numericTail = args.slice(-3).map(Number);
  const hasRange = numericTail.every((value) => Number.isFinite(value));
  const expressions = (hasRange ? args.slice(0, -3) : args).map((item) => item.trim()).filter(Boolean);
  const [start, end, step] = hasRange ? numericTail : [-4, 4, 1];
  const dynamic = createDynamicTable(expressions.length ? expressions : ["x"], start, end, step, evaluateMathExpression);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Dynamic table view",
    result: `${dynamic.rows.length} rows for ${dynamic.expressions.join(", ")}`,
    detail: `Highlights roots/intercepts and exports ${dynamic.exportCsv.length} CSV characters.`,
    table: dynamic.rows.map((row) => ({ x: row.x, y: row.values[dynamic.expressions[0]], label: row.highlight ? "highlight" : "" })),
    related: dynamic.expressions.map((expression) => `plot ${expression}`),
    graphExpression: dynamic.expressions[0],
    steps: dynamic.classroomTasks,
  };
}

function sequenceCommand(args: string[], input: string): ResultCard {
  const [expression = "n", variable = "n", startRaw = "1", endRaw = "10", stepRaw = "1"] = args;
  const start = Number(startRaw);
  const end = Number(endRaw);
  const step = Math.abs(Number(stepRaw)) || 1;
  const rows: ResultTableRow[] = [];
  for (let value = start; value <= end && rows.length < 120; value += step) {
    const xExpression = expression.replace(new RegExp(`\\b${variable}\\b`, "g"), `(${value})`);
    rows.push({ x: value, y: roundTo(evaluateMathExpression(xExpression, value), 6), label: variable });
  }
  return { id: crypto.randomUUID(), input, interpretation: "Sequence", result: rows.map((row) => row.y).join(", "), detail: `${expression}, ${variable} = ${start}...${end}`, table: rows };
}

function listCommand(args: string[], input: string): ResultCard {
  const list = createListObject(args);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "List object",
    result: `[${list.values.join(", ")}]`,
    detail: `n=${list.length}, sum=${roundTo(list.sum, 6)}, mean=${roundTo(list.mean, 6)}, min=${list.min}, max=${list.max}`,
    steps: ["Parse numeric list entries.", "Store as a reusable list object.", "Expose summary values for spreadsheet and table workflows."],
  };
}

function fillDownCommand(args: string[], input: string): ResultCard {
  const [source = "D6", range = "D7:D12"] = args;
  const preview = fillDownFormula(initialSpreadsheet, source, range);
  const evaluated = evaluateSpreadsheetGrid(preview);
  const csv = rangeToCsv(evaluated.values, range);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Spreadsheet fill down",
    result: `${source} filled into ${range}`,
    detail: evaluated.errors.length ? evaluated.errors.map((error) => `${error.cell}: ${error.message}`).join("; ") : "Formula references were shifted relative to each destination cell.",
    steps: ["Read the source formula.", "Shift cell references by row/column offset.", "Evaluate the filled range and prepare CSV export."],
    table: csv.split("\n").map((line, index) => ({ x: index + 1, y: line.length, label: "csv" })),
  };
}

function rangeCsvCommand(args: string[], input: string): ResultCard {
  const range = args[0] ?? "A1:C6";
  const evaluated = evaluateSpreadsheetGrid(initialSpreadsheet);
  const csv = rangeToCsv(evaluated.values, range);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Spreadsheet range CSV",
    result: `${csv.split("\n").filter(Boolean).length} rows exported`,
    detail: csv || "No valid range data.",
    steps: ["Evaluate spreadsheet formulas.", `Read range ${range}.`, "Return CSV-ready text for export."],
  };
}

function casLinkedCommand(args: string[], input: string): ResultCard {
  const [command = "Simplify", expression = "x"] = args;
  const card = createCasCard(command, expression);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Linked CAS card",
    result: card.result,
    detail: card.detail,
    steps: [...card.steps, ...card.verificationPrompts],
    related: card.linkedGraphExpressions.map((expression) => `plot ${expression}`),
    graphExpression: card.linkedGraphExpressions[0],
  };
}

function substituteCommand(args: string[], input: string): ResultCard {
  const [expression = "", ...assignments] = args;
  const symbolicAssignments = assignments.map((assignment) => {
    const [name, ...rest] = assignment.split("=");
    const value = rest.join("=").trim();
    return name?.trim() && value ? { name: name.trim(), value } : null;
  }).filter(Boolean) as { name: string; value: string }[];
  const symbolic = symbolicAssignments.length ? trySymbolic(() => symbolicSubstitute(expression, symbolicAssignments)) : null;
  if (symbolic) return { id: crypto.randomUUID(), input, interpretation: "Symbolic substitute", result: symbolic.result, detail: symbolic.detail, steps: symbolic.steps, related: [`simplify ${symbolic.result}`, `plot ${symbolic.result}`], graphExpression: /[xy]/i.test(symbolic.result) ? symbolic.result : undefined };
  let substituted = expression;
  assignments.forEach((assignment) => {
    const [name, value] = assignment.split("=").map((part) => part.trim());
    if (name && value) substituted = substituted.replace(new RegExp(`\\b${escapeRegExp(name)}\\b`, "g"), `(${value})`);
  });
  const simplified = trySymbolic(() => symbolicSimplify(substituted));
  const result = simplified?.result ?? `${roundTo(evaluateMathExpression(substituted, 0), 10)}`;
  return { id: crypto.randomUUID(), input, interpretation: "Substitute", result, detail: `${expression} -> ${substituted}`, steps: [`Start with ${expression}.`, `Apply ${assignments.join(", ")}.`, `Simplify/evaluate ${substituted}.`] };
}

function simplifyCommand(expression: string, input: string): ResultCard {
  const symbolic = trySymbolic(() => symbolicSimplify(expression));
  if (symbolic) return { id: crypto.randomUUID(), input, interpretation: "Symbolic simplify", result: symbolic.result, detail: symbolic.detail, steps: symbolic.steps };
  const compact = expression.replace(/\s+/g, "");
  const polynomial = parsePolynomial(compact);
  if (polynomial) {
    const result = polynomialToText(polynomial);
    return { id: crypto.randomUUID(), input, interpretation: "Simplify", result, detail: "Combined like polynomial terms.", steps: ["Group terms by matching powers of x.", "Add coefficients for each power.", "Rewrite terms from highest power to constant."] };
  }
  const value = evaluateMathExpression(expression, 0);
  return { id: crypto.randomUUID(), input, interpretation: "Simplify", result: `${roundTo(value, 10)}`, detail: "Numeric simplification." };
}

function expandCommand(expression: string, input: string): ResultCard {
  const symbolic = trySymbolic(() => symbolicExpand(expression));
  if (symbolic) return { id: crypto.randomUUID(), input, interpretation: "Symbolic expand", result: symbolic.result, detail: symbolic.detail, steps: symbolic.steps, related: [`factor ${symbolic.result}`] };
  const match = expression.replace(/\s+/g, "").match(/^\(x([+-]\d+(?:\.\d+)?)\)\(x([+-]\d+(?:\.\d+)?)\)$/);
  if (!match) return { id: crypto.randomUUID(), input, interpretation: "Expand", result: "Expansion currently supports forms like (x+2)(x+3).", detail: "Try: expand (x+2)(x+3)" };
  const a = Number(match[1]);
  const b = Number(match[2]);
  const result = `x^2 ${signed(a + b)}*x ${signed(a * b)}`;
  return { id: crypto.randomUUID(), input, interpretation: "Expand", result, steps: [`Use (x+a)(x+b)=x^2+(a+b)x+ab.`, `a=${a}, b=${b}.`, `a+b=${roundTo(a + b, 4)}, ab=${roundTo(a * b, 4)}.`], related: [`factor ${result}`] };
}

function partialFractionsCommand(args: string[], input: string): ResultCard {
  const [expression = "", variable = "x"] = args;
  const symbolic = trySymbolic(() => symbolicPartialFractions(expression, variable));
  if (!symbolic) throw new Error("Use PartialFractions[(3*x+5)/((x+1)(x+2))].");
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Symbolic partial fractions",
    result: symbolic.result,
    detail: symbolic.detail,
    steps: symbolic.steps,
    related: [`simplify ${symbolic.result}`, `plot ${expression}`],
  };
}

function polynomialDivideCommand(args: string[], input: string): ResultCard {
  const [dividend = "", divisor = "", variable = "x"] = args;
  if (!dividend || !divisor) throw new Error("Use PolynomialDivide[x^3-1, x-1].");
  const symbolic = trySymbolic(() => symbolicPolynomialDivide(dividend, divisor, variable));
  if (!symbolic) throw new Error("Polynomial division needs valid dividend and divisor expressions.");
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Symbolic polynomial division",
    result: symbolic.result,
    detail: symbolic.detail,
    steps: symbolic.steps,
    related: [`expand (${divisor})*(${symbolic.result.split(",")[0]})`, `plot ${dividend}`],
  };
}

function limitCommand(args: string[], input: string): ResultCard {
  const [expression = "sin(x)/x", variable = "x", targetRaw = "0"] = args;
  const target = Number(targetRaw);
  const symbolic = trySymbolic(() => symbolicLimit(expression, variable, targetRaw));
  const offsets = [1e-1, 1e-2, 1e-3, 1e-4];
  const table = offsets.map((offset) => {
    const left = evaluateMathExpression(expression.replace(new RegExp(`\\b${escapeRegExp(variable)}\\b`, "g"), `(${target - offset})`), target - offset);
    const right = evaluateMathExpression(expression.replace(new RegExp(`\\b${escapeRegExp(variable)}\\b`, "g"), `(${target + offset})`), target + offset);
    return { x: offset, y: roundTo((left + right) / 2, 8), label: `h=${offset}` };
  });
  const estimate = table.at(-1)?.y ?? NaN;
  if (symbolic) {
    return {
      id: crypto.randomUUID(),
      input,
      interpretation: "Symbolic limit",
      result: `lim ${variable}->${targetRaw} ${expression} = ${symbolic.result}`,
      detail: `${symbolic.detail} Numeric check: ${Number.isFinite(estimate) ? estimate : "unavailable"}.`,
      steps: [...symbolic.steps, "Compare the shrinking h table to the exact result."],
      table,
      graphExpression: expression,
    };
  }
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Limit",
    result: Number.isFinite(estimate) ? `lim ${variable}->${target} ${expression} = ${estimate}` : "Limit estimate unavailable",
    detail: "Two-sided numeric limit estimate. Exact symbolic limits are queued for the CAS expansion phase.",
    steps: [`Approach ${target} from the left and right.`, "Average the two finite estimates for each shrinking step.", "Compare the rows to see whether the values stabilize."],
    table,
    graphExpression: expression,
  };
}

function seriesCommand(args: string[], input: string): ResultCard {
  const [expression = "sin(x)", variable = "x", centerRaw = "0", orderRaw = "5"] = args;
  const center = Number(centerRaw);
  const order = Math.max(1, Math.min(8, Math.round(Number(orderRaw) || 5)));
  const compact = expression.replace(/\s+/g, "").toLowerCase();
  let result = `${expression} near ${variable}=${center}`;
  if (center === 0 && compact === "sin(x)") result = Array.from({ length: Math.ceil(order / 2) }, (_, index) => {
    const n = index * 2 + 1;
    return `${index % 2 ? "-" : "+"} x^${n}/${factorial(n)}`;
  }).join(" ").replace(/^\+\s*/, "");
  else if (center === 0 && compact === "cos(x)") result = Array.from({ length: Math.ceil((order + 1) / 2) }, (_, index) => {
    const n = index * 2;
    return `${index % 2 ? "-" : "+"} x^${n}/${factorial(n)}`;
  }).join(" ").replace(/^\+\s*/, "");
  else if (center === 0 && compact === "e^x") result = Array.from({ length: order + 1 }, (_, n) => `x^${n}/${factorial(n)}`).join(" + ");
  else result = "Series template registered; exact expansion for this expression lands in the CAS expansion phase.";
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Series",
    result,
    detail: `Taylor-style approximation request for ${expression} around ${center} to order ${order}.`,
    steps: ["Choose the expansion center.", "Use derivatives at the center as coefficients.", "Build polynomial terms up to the requested order."],
    related: [`plot ${expression}`],
  };
}

function matrixCommand(body: string, input: string): ResultCard {
  const matrix = parseMatrixLiteral(body);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Matrix",
    result: formatMatrix(matrix),
    detail: `${matrix.length} by ${matrix[0]?.length ?? 0} matrix object parsed for CAS/spreadsheet linking.`,
    steps: ["Read rows inside brackets.", "Convert every entry to a numeric cell.", "Register the matrix as an algebra object in the dynamic kernel."],
  };
}

function determinantCommand(body: string, input: string): ResultCard {
  const matrix = parseMatrixLiteral(body);
  const value = determinant(matrix);
  return { id: crypto.randomUUID(), input, interpretation: "Determinant", result: `${roundTo(value, 8)}`, detail: `det(${formatMatrix(matrix)})`, steps: ["Check the matrix is square.", "Apply recursive expansion for small matrices.", "Return the signed area/volume scaling factor."] };
}

function transposeCommand(body: string, input: string): ResultCard {
  const matrix = parseMatrixLiteral(body);
  const transposed = matrix[0].map((_, column) => matrix.map((row) => row[column]));
  return { id: crypto.randomUUID(), input, interpretation: "Transpose", result: formatMatrix(transposed), detail: "Rows and columns swapped.", steps: ["Read each column of the original matrix.", "Write it as a row in the new matrix."] };
}

function inverseCommand(body: string, input: string): ResultCard {
  const matrix = parseMatrixLiteral(body);
  if (matrix.length !== 2 || matrix[0].length !== 2 || matrix[1].length !== 2) throw new Error("Inverse currently supports 2 by 2 matrices.");
  const det = determinant(matrix);
  if (Math.abs(det) < 1e-9) throw new Error("Matrix is singular; determinant is zero.");
  const [[a, b], [c, d]] = matrix;
  const inverse = [[d / det, -b / det], [-c / det, a / det]];
  return { id: crypto.randomUUID(), input, interpretation: "Inverse", result: formatMatrix(inverse), detail: `1/det with det=${roundTo(det, 8)}.`, steps: ["For [[a,b],[c,d]], inverse is 1/(ad-bc) * [[d,-b],[-c,a]].", `det=${roundTo(det, 8)}.`, "Scale the adjugate matrix."] };
}

function plane3dCommand(args: string[], input: string): ResultCard {
  const plane = parsePlane3dArgs(args);
  if (!plane) throw new Error("Use Plane[(0,0,1), (0,0,1)] or Plane[z=1].");
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "3D plane",
    result: `point=(${formatPoint3(plane.point)}), normal=<${formatPoint3(plane.normal)}>`,
    detail: "Plane registered in the 3D kernel for slicing, intersections, and transform overlays.",
    steps: ["Parse a point and normal vector.", "Normalize the normal.", "Store plane as point-normal form."],
  };
}

function solid3dCommand(name: string, args: string[], input: string): ResultCard {
  const object = parseSolid3d(name, args);
  const measurement = object3Measurement(object);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "3D solid",
    result: `${measurement.label}: V=${roundTo(measurement.volume, 5)}, SA=${roundTo(measurement.surfaceArea, 5)}`,
    detail: measurement.detail,
    steps: ["Parse center/radius/height parameters.", "Create a true 3D object in kernel form.", "Compute volume and surface area for overlays."],
  };
}

function slice3dCommand(args: string[], input: string): ResultCard {
  const [solidText = "Sphere[(0,0,0),3]", planeText = "z=0"] = args.length >= 2 ? args : splitKernelObjectPair(args.join(","));
  const solid = parseObject3(solidText);
  const plane = parseObject3(planeText);
  if (!solid || !plane) throw new Error("Use Slice[Sphere[(0,0,0), 3], z=1].");
  const hits = intersect3(solid, plane);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "3D slice",
    result: hits.length ? hits.map(formatIntersection3).join("; ") : "No 3D intersection",
    detail: "3D kernel slice using line-plane, plane-plane, or sphere-plane intersection rules.",
    steps: ["Parse 3D objects.", "Select the correct intersection solver.", "Return point, line, or circular cross-section overlay."],
  };
}

function gizmoCommand(args: string[], input: string): ResultCard {
  const mode = ((args[0] ?? "translate").toLowerCase() as TransformMode3);
  if (!["translate", "rotate", "scale"].includes(mode)) throw new Error("Use Gizmo[translate], Gizmo[rotate], or Gizmo[scale].");
  const handles = createTransformGizmo(mode);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "3D transform gizmo",
    result: handles.map((handle) => `${handle.label} snap=${handle.snapStep}`).join(", "),
    detail: "Axis/ring/scale handle metadata for the selected 3D object. Visual handles are represented in the 3D readout and ready for canvas binding.",
    steps: ["Choose transform mode.", "Create axis-specific handles.", "Apply snap increments for precise classroom manipulation."],
  };
}

function measure3dCommand(args: string[], input: string): ResultCard {
  const object = parseObject3(args.join(","));
  if (!object) throw new Error("Use Measure3D[Sphere[(0,0,0), 3]] or Measure3D[Cylinder[(0,0,0), 2, 5]].");
  const measurement = object3Measurement(object);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "3D measurement",
    result: `${measurement.label}: V=${roundTo(measurement.volume, 5)}, SA=${roundTo(measurement.surfaceArea, 5)}`,
    detail: measurement.detail,
    steps: ["Recognize object type.", "Apply the matching 3D measurement formula.", "Expose result for labels and overlays."],
  };
}

function transformActionCommand(name: string, args: string[], input: string): ResultCard {
  const action = parseTransformCommand(name, args);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Dynamic transform action",
    result: describeTransformAction(action),
    detail: "Transformation commands now produce exact before/after coordinates and are ready for selected-object binding in Geometry and Algebra views.",
    table: [
      { x: roundTo(action.source.x, 6), y: roundTo(action.source.y, 6), label: "source" },
      { x: roundTo(action.result.x, 6), y: roundTo(action.result.y, 6), label: action.kind },
    ],
    steps: transformSteps(action.kind),
  };
}

function styleActionCommand(name: string, args: string[], input: string): ResultCard {
  const action = parseStyleAction(name, args);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Object style action",
    result: `${action.objectName}: ${Object.entries(action.patch).map(([key, value]) => `${key}=${value}`).join(", ")}`,
    detail: "The same style action shape is used by Geometry, 3D, Algebra, and the Inspector so object menus stay consistent.",
    steps: ["Resolve the object by name.", "Validate the requested style value.", "Apply the patch through the unified object/inspector action channel."],
  };
}

function animationActionCommand(name: string, args: string[], input: string): ResultCard {
  const action = createAnimationAction(name, args);
  return {
    id: crypto.randomUUID(),
    input,
    interpretation: "Animation action",
    result: `${action.target}: ${action.playing ? "playing" : "paused"} at ${action.speed}x`,
    detail: action.detail,
    steps: ["Resolve the target slider or scene.", "Set playback state.", "Keep the action browser-only so it can run offline in a saved project."],
  };
}

function transformSteps(kind: "rotate" | "translate" | "dilate" | "mirror") {
  const steps = {
    rotate: ["Move the point into center-relative coordinates.", "Apply the 2D rotation matrix.", "Move the result back to the original center."],
    translate: ["Read the movement vector.", "Add dx to x and dy to y.", "Return the translated coordinate."],
    dilate: ["Measure the point from the center.", "Multiply the center-relative vector by the scale factor.", "Return the scaled coordinate."],
    mirror: ["Project the point onto the mirror axis.", "Double the projection and subtract the original point.", "Return the reflected coordinate."],
  };
  return steps[kind];
}

function definitionCommandCard(input: string, interpretation: string, detail: string): ResultCard {
  const specName = input.match(/^([a-z]+)/i)?.[1] ?? "";
  const spec = specName ? resolveCommandSpec(specName) : null;
  return {
    id: crypto.randomUUID(),
    input,
    interpretation,
    result: spec?.signature ?? "Registered constructor",
    detail,
    steps: spec ? [`${spec.name} is registered in the ${spec.group} command group.`, spec.description, `Example: ${spec.examples[0] ?? spec.signature}`] : undefined,
  };
}

function parseTwoKernelObjects(args: string[]) {
  const pair = args.length >= 2 ? args : splitKernelObjectPair(args.join(","));
  if (pair.length < 2) return null;
  const first = parseKernelObject(pair[0]);
  const second = parseKernelObject(pair[1]);
  return first && second ? [first, second] as [KernelObject, KernelObject] : null;
}

function splitKernelObjectPair(value: string) {
  const output: string[] = [];
  let current = "";
  let depth = 0;
  for (const char of value) {
    if (char === "[" || char === "(") depth += 1;
    if (char === "]" || char === ")") depth -= 1;
    if (char === "," && depth === 0) {
      output.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  if (current.trim()) output.push(current.trim());
  return output;
}

function parseKernelObject(value: string): KernelObject | null {
  const trimmed = value.trim();
  const linear = trimmed.match(/^(line|segment|ray)\s*(?:\[|\()(.*)(?:\]|\))$/i);
  if (linear) {
    const points = splitKernelObjectPair(linear[2]).map(parsePointArgument).filter(Boolean) as KernelPoint[];
    if (points.length < 2) return null;
    if (linear[1].toLowerCase() === "segment") return kernelSegment(points[0], points[1]);
    if (linear[1].toLowerCase() === "ray") return kernelRay(points[0], points[1]);
    return kernelLine(points[0], points[1]);
  }
  const circleMatch = trimmed.match(/^circle\s*(?:\[|\()(.*)(?:\]|\))$/i);
  if (circleMatch) {
    const parts = splitKernelObjectPair(circleMatch[1]);
    const center = parsePointArgument(parts[0] ?? "");
    const radius = Number(parts[1]);
    if (center && Number.isFinite(radius)) return kernelCircle(center, radius);
  }
  const conicBody = trimmed.match(/^conic\s*(?:\[|\()(.*)(?:\]|\))$/i)?.[1] ?? trimmed;
  const parsedConic = parseConicEquation(conicBody);
  if (parsedConic) return parsedConic;
  return null;
}

function parsePointArgument(value: string) {
  return parseKernelPoint(value.replace(/^point\s*(?:\[|\()(.*)(?:\]|\))$/i, "$1"));
}

function formatConicCoefficients(coefficients: [number, number, number, number, number, number]) {
  const labels = ["A", "B", "C", "D", "E", "F"];
  return coefficients.map((value, index) => `${labels[index]}=${roundTo(value, 6)}`).join(", ");
}

function parsePlane3dArgs(args: string[]) {
  const body = args.join(",");
  const equationPlane = parsePlaneEquation(body);
  if (equationPlane) return equationPlane;
  const parts = args.length >= 2 ? args : splitKernelObjectPair(body);
  const point = parsePoint3(parts[0] ?? "");
  const normal = parseVector3(parts[1] ?? "");
  return point && normal ? kernelPlane3(point, normal) : null;
}

function parseObject3(value: string): Object3 | null {
  const trimmed = value.trim();
  const planeMatch = trimmed.match(/^plane\s*(?:\[|\()(.*)(?:\]|\))$/i);
  if (planeMatch) return parsePlane3dArgs(splitKernelObjectPair(planeMatch[1]));
  const lineMatch = trimmed.match(/^line3?d?\s*(?:\[|\()(.*)(?:\]|\))$/i);
  if (lineMatch) {
    const parts = splitKernelObjectPair(lineMatch[1]);
    const origin = parsePoint3(parts[0] ?? "");
    const direction = parseVector3(parts[1] ?? "");
    return origin && direction ? kernelLine3(origin, direction) : null;
  }
  const solidMatch = trimmed.match(/^(sphere|cylinder|cone)\s*(?:\[|\()(.*)(?:\]|\))$/i);
  if (solidMatch) return parseSolid3d(solidMatch[1].toLowerCase(), splitKernelObjectPair(solidMatch[2]));
  return parsePlaneEquation(trimmed);
}

function parseSolid3d(name: string, args: string[]): Object3 {
  const center = parsePoint3(args[0] ?? "") ?? kernelPoint3(0, 0, 0);
  const radius = Number(args[1] ?? 1);
  const height = Number(args[2] ?? radius * 2);
  if (!Number.isFinite(radius)) throw new Error("3D solid radius must be numeric.");
  if (name === "sphere") return kernelSphere3(center, radius);
  if (!Number.isFinite(height)) throw new Error("3D solid height must be numeric.");
  if (name === "cylinder") return kernelCylinder3(center, radius, height);
  if (name === "cone") return kernelCone3(center, radius, height);
  throw new Error(`Unsupported 3D solid "${name}".`);
}

function formatPoint3(point: Point3) {
  return `${roundTo(point.x, 4)}, ${roundTo(point.y, 4)}, ${roundTo(point.z, 4)}`;
}

function formatIntersection3(hit: ReturnType<typeof intersect3>[number]) {
  if (hit.kind === "point") return `point (${formatPoint3(hit.point)})`;
  if (hit.kind === "line") return `line point=(${formatPoint3(hit.line.point)}), dir=<${formatPoint3(hit.line.direction)}>`;
  return `circle center=(${formatPoint3(hit.center)}), r=${roundTo(hit.radius, 5)}`;
}

function parseMatrixLiteral(body: string) {
  const normalized = body.trim().replace(/^Matrix/i, "");
  const rowMatches = Array.from(normalized.matchAll(/\[([^\][]+)\]/g)).map((match) => match[1]);
  const rows = rowMatches.length ? rowMatches : normalized.replace(/^\[|\]$/g, "").split(/\s*;\s*/);
  const matrix = rows.map((row) => row.split(/\s*,\s*/).map((cell) => Number(cell.trim()))).filter((row) => row.length > 0);
  if (!matrix.length || matrix.some((row) => row.some((value) => !Number.isFinite(value)))) throw new Error("Use a numeric matrix like [[1,2],[3,4]].");
  const width = matrix[0].length;
  if (matrix.some((row) => row.length !== width)) throw new Error("Every matrix row must have the same length.");
  return matrix;
}

function formatMatrix(matrix: number[][]) {
  return `[${matrix.map((row) => `[${row.map((value) => roundTo(value, 6)).join(", ")}]`).join(", ")}]`;
}

function determinant(matrix: number[][]): number {
  if (matrix.length !== matrix[0]?.length) throw new Error("Determinant requires a square matrix.");
  if (matrix.length === 1) return matrix[0][0];
  if (matrix.length === 2) return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
  return matrix[0].reduce((sum, value, column) => {
    const minor = matrix.slice(1).map((row) => row.filter((_, index) => index !== column));
    return sum + (column % 2 ? -1 : 1) * value * determinant(minor);
  }, 0);
}

function factorial(n: number): number {
  return n <= 1 ? 1 : n * factorial(n - 1);
}

function derivativeText(expression: string) {
  const compact = expression.replace(/\s+/g, "");
  if (compact === "sin(x)") return "cos(x)";
  if (compact === "cos(x)") return "-sin(x)";
  if (compact === "x") return "1";
  const terms = compact.replace(/-/g, "+-").split("+").filter(Boolean);
  const derived = terms.map((term) => {
    const power = term.match(/^(-?\d*\.?\d*)?\*?x\^(\d+)$/);
    if (power) {
      const coeff = power[1] === "" || power[1] === undefined ? 1 : power[1] === "-" ? -1 : Number(power[1]);
      const exponent = Number(power[2]);
      return `${roundTo(coeff * exponent, 4)}*x^${exponent - 1}`;
    }
    const linear = term.match(/^(-?\d*\.?\d*)?\*?x$/);
    if (linear) return `${linear[1] === "" || linear[1] === undefined ? 1 : linear[1] === "-" ? -1 : Number(linear[1])}`;
    if (/^-?\d+(\.\d+)?$/.test(term)) return "";
    return `d/dx(${term})`;
  }).filter(Boolean).join(" + ").replace(/\+\s-/g, "- ");
  return derived || "0";
}

function derivativeSteps(expression: string, derivative: string) {
  return ["Split the expression into terms.", "Apply the power rule d/dx(ax^n)=a*n*x^(n-1).", `Result: ${derivative}.`, `Original expression: ${expression}.`];
}

function integralText(expression: string) {
  const compact = expression.replace(/\s+/g, "");
  if (compact === "cos(x)") return "sin(x) + C";
  if (compact === "sin(x)") return "-cos(x) + C";
  const terms = compact.replace(/-/g, "+-").split("+").filter(Boolean);
  const integrated = terms.map((term) => {
    const power = term.match(/^(-?\d*\.?\d*)?\*?x\^(\d+)$/);
    if (power) {
      const coeff = power[1] === "" || power[1] === undefined ? 1 : power[1] === "-" ? -1 : Number(power[1]);
      const exponent = Number(power[2]);
      return `${roundTo(coeff / (exponent + 1), 5)}*x^${exponent + 1}`;
    }
    const linear = term.match(/^(-?\d*\.?\d*)?\*?x$/);
    if (linear) {
      const coeff = linear[1] === "" || linear[1] === undefined ? 1 : linear[1] === "-" ? -1 : Number(linear[1]);
      return `${roundTo(coeff / 2, 5)}*x^2`;
    }
    if (/^-?\d+(\.\d+)?$/.test(term)) return `${term}*x`;
    return `integral(${term})`;
  }).filter(Boolean).join(" + ").replace(/\+\s-/g, "- ");
  return `${integrated || "0"} + C`;
}

function integralSteps(expression: string, integral: string) {
  return ["Split the expression into terms.", "Apply integral of ax^n = a*x^(n+1)/(n+1).", "Add the constant of integration C.", `Result: ${integral}.`, `Original expression: ${expression}.`];
}

function parseQuadratic(expression: string) {
  const polynomial = parsePolynomial(expression);
  if (!polynomial) return null;
  const a = polynomial[2] ?? 0;
  const b = polynomial[1] ?? 0;
  const c = polynomial[0] ?? 0;
  const otherPowers = Object.keys(polynomial).map(Number).filter((power) => power > 2 && Math.abs(polynomial[power]) > 1e-9);
  if (Math.abs(a) < 1e-9 || otherPowers.length) return null;
  return { a, b, c };
}

function parsePolynomial(expression: string): Record<number, number> | null {
  const compact = expression.replace(/\s+/g, "").replace(/\*/g, "");
  if (!/^[x0-9+\-.^]+$/.test(compact)) return null;
  const terms = compact.replace(/-/g, "+-").split("+").filter(Boolean);
  const polynomial: Record<number, number> = {};
  for (const term of terms) {
    const powerMatch = term.match(/^(-?\d*\.?\d*)?x\^(\d+)$/);
    const linearMatch = term.match(/^(-?\d*\.?\d*)?x$/);
    const constantMatch = term.match(/^-?\d+(\.\d+)?$/);
    if (powerMatch) {
      const coeff = coefficientFromText(powerMatch[1]);
      const power = Number(powerMatch[2]);
      polynomial[power] = (polynomial[power] ?? 0) + coeff;
    } else if (linearMatch) {
      polynomial[1] = (polynomial[1] ?? 0) + coefficientFromText(linearMatch[1]);
    } else if (constantMatch) {
      polynomial[0] = (polynomial[0] ?? 0) + Number(term);
    } else return null;
  }
  return polynomial;
}

function coefficientFromText(value: string | undefined) {
  if (value === undefined || value === "") return 1;
  if (value === "-") return -1;
  return Number(value);
}

function polynomialToText(polynomial: Record<number, number>) {
  return Object.entries(polynomial)
    .map(([powerText, coefficient]) => ({ power: Number(powerText), coefficient }))
    .filter(({ coefficient }) => Math.abs(coefficient) > 1e-9)
    .sort((a, b) => b.power - a.power)
    .map(({ power, coefficient }, index) => {
      const abs = Math.abs(roundTo(coefficient, 6));
      const sign = coefficient < 0 ? (index === 0 ? "-" : " - ") : (index === 0 ? "" : " + ");
      if (power === 0) return `${sign}${abs}`;
      if (power === 1) return `${sign}${abs === 1 ? "" : `${abs}*`}x`;
      return `${sign}${abs === 1 ? "" : `${abs}*`}x^${power}`;
    }).join("") || "0";
}

function quadraticRoots(a: number, b: number, c: number) {
  const discriminant = b * b - 4 * a * c;
  if (discriminant < 0) return null;
  const sqrt = Math.sqrt(discriminant);
  return [(-b + sqrt) / (2 * a), (-b - sqrt) / (2 * a)];
}

function quadraticSteps(a: number, b: number, c: number) {
  const discriminant = b * b - 4 * a * c;
  return [`Identify a=${a}, b=${b}, c=${c}.`, `Compute discriminant D=b^2-4ac=${roundTo(discriminant, 5)}.`, "Use x=(-b +/- sqrt(D))/(2a).", discriminant >= 0 ? "D is nonnegative, so the real roots are shown." : "D is negative, so there are no real roots."];
}

function signed(value: number) {
  return value < 0 ? `- ${roundTo(Math.abs(value), 5)}` : `+ ${roundTo(value, 5)}`;
}

function numericDerivative(expression: string, x: number) {
  const h = 0.0001;
  return (evaluateMathExpression(expression, x + h) - evaluateMathExpression(expression, x - h)) / (2 * h);
}

function bisect(f: (x: number) => number, left: number, right: number) {
  let lo = left, hi = right;
  for (let i = 0; i < 32; i += 1) {
    const mid = (lo + hi) / 2;
    if (f(lo) * f(mid) <= 0) hi = mid;
    else lo = mid;
  }
  return (lo + hi) / 2;
}

function MiniNumber({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <label className="rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
      {label}
      <input type="number" value={value} onChange={(event) => onChange(Number(event.target.value))} className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono dark:border-white/10 dark:bg-slate-900" />
    </label>
  );
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function LegacySpreadsheetPanel({ grid, onChange, onScatter, onRegression }: { grid: SpreadsheetCellGrid; onChange: (grid: SpreadsheetCellGrid) => void; onScatter: (points: ResultTableRow[]) => void; onRegression: (model: RegressionModel, points: ResultTableRow[]) => void }) {
  const evaluated = useMemo(() => evaluateSpreadsheetGrid(grid), [grid]);
  const points = useMemo(() => spreadsheetPoints(evaluated.values), [evaluated]);
  const exportCsv = () => {
    const maxColumns = Math.max(...evaluated.values.map((row) => row.length), 1);
    const range = `A1:${columnName(maxColumns - 1)}${Math.max(evaluated.values.length, 1)}`;
    downloadText("workspace-spreadsheet.csv", rangeToCsv(evaluated.values, range), "text/csv");
  };
  const updateCell = (row: number, col: number, value: string) => {
    onChange(grid.map((cells, rowIndex) => rowIndex === row ? cells.map((cell, colIndex) => colIndex === col ? value : cell) : cells));
  };
  const addRow = () => onChange([...grid, Array.from({ length: grid[0]?.length ?? 4 }, () => "")]);
  const addColumn = () => onChange(grid.map((row) => [...row, ""]));

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-slate-950/60">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-bold">Spreadsheet grid</h3>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={addRow} className="action-secondary py-2">Add row</button>
          <button type="button" onClick={addColumn} className="action-secondary py-2">Add column</button>
          <button type="button" onClick={() => onScatter(points)} className="action-primary py-2">Plot data</button>
          <button type="button" onClick={exportCsv} className="action-secondary py-2"><Download className="h-4 w-4" />CSV</button>
        </div>
      </div>
      <div className="mobile-safe-scroll mt-3 overflow-auto rounded-2xl border border-slate-200 dark:border-white/10">
        <table className="min-w-[620px] w-full text-left text-xs">
          <thead className="bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-300">
            <tr><th className="p-2">#</th>{grid[0]?.map((_, index) => <th key={index} className="p-2">{columnName(index)}</th>)}</tr>
          </thead>
          <tbody>
            {grid.map((row, rowIndex) => (
              <tr key={rowIndex} className="border-t border-slate-200 dark:border-white/10">
                <td className="bg-slate-50 p-2 font-bold text-slate-500 dark:bg-white/5">{rowIndex + 1}</td>
                {row.map((cell, colIndex) => (
                  <td key={colIndex} className="p-1 align-top">
                    <input aria-label={`${columnName(colIndex)}${rowIndex + 1}`} value={cell} onChange={(event) => updateCell(rowIndex, colIndex, event.target.value)} className="w-full rounded-lg border border-slate-200 bg-white px-2 py-1 font-mono dark:border-white/10 dark:bg-slate-900" />
                    {cell.startsWith("=") && <p className="mt-1 truncate px-1 font-mono text-[11px] text-cyan-600 dark:text-cyan-300">{evaluated.values[rowIndex]?.[colIndex] ?? ""}</p>}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {(["linear", "quadratic", "exponential", "polynomial"] as RegressionModel[]).map((model) => <button key={model} type="button" onClick={() => onRegression(model, points)} className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-bold capitalize dark:bg-white/10">{model}</button>)}
      </div>
      {evaluated.errors.length > 0 && <p className="mt-3 rounded-xl bg-amber-50 p-2 text-xs font-bold text-amber-800 dark:bg-amber-400/10 dark:text-amber-100">{evaluated.errors.map((error) => `${error.cell}: ${error.message}`).join("; ")}</p>}
      <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Formulas start with = and can reference cells like A2+B2. First two numeric columns become graph/regression data.</p>
    </div>
  );
}

function FunctionAnalysisPanel({ plot, onCommand }: { plot?: PlotItem; onCommand: (command: string) => void }) {
  const expression = stripInequality(plot?.expression ?? "x^2-4");
  const analysis = useMemo(() => analyzeFunction(expression), [expression]);
  return (
    <div className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-slate-950/60">
      <h3 className="font-bold">Function analysis</h3>
      <p className="font-mono text-sm text-slate-500 dark:text-slate-400">f(x) = {expression}</p>
      <div className="grid gap-2">
        <InfoPill title="Roots" text={analysis.roots || "No real roots found in [-20,20]."} />
        <InfoPill title="Intercepts" text={analysis.intercepts} />
        <InfoPill title="Extrema" text={analysis.extrema || "No local extrema found in [-10,10]."} />
        <InfoPill title="Domain hint" text={analysis.domainHint} />
        <InfoPill title="Derivative" text={analysis.derivative} />
        <InfoPill title="Integral" text={analysis.integral} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => onCommand(`Derivative[${expression}]`)} className="action-secondary py-2">Derivative</button>
        <button type="button" onClick={() => onCommand(`Integral[${expression}]`)} className="action-secondary py-2">Integral</button>
        <button type="button" onClick={() => onCommand(`Root[${expression}]`)} className="action-secondary py-2">Roots</button>
        <button type="button" onClick={() => onCommand(`Table[${expression}, -4, 4, 1]`)} className="action-secondary py-2">Table</button>
      </div>
    </div>
  );
}

const casDepthActions = [
  { label: "Simplify", command: (expression: string) => `Simplify[${expression}]`, tone: "cyan" },
  { label: "Factor", command: (expression: string) => `Factor[${expression}]`, tone: "violet" },
  { label: "Expand", command: () => "Expand[(x+2)(x+3)]", tone: "cyan" },
  { label: "Solve", command: (expression: string) => `Solve[${expression}=0]`, tone: "violet" },
  { label: "System", command: () => "SolveSystem[x+y=5, x-y=1]", tone: "cyan" },
  { label: "Limit", command: () => "Limit[sin(x)/x, x, 0]", tone: "violet" },
  { label: "Partial", command: () => "PartialFractions[(3*x+5)/((x+1)(x+2))]", tone: "cyan" },
  { label: "Divide", command: () => "PolynomialDivide[x^3-1, x-1]", tone: "violet" },
  { label: "Substitute", command: (expression: string) => `Substitute[${expression}, x=3]`, tone: "cyan" },
  { label: "CAS Card", command: (expression: string) => `CAS[Factor, ${expression}]`, tone: "violet" },
] as const;

function LegacyCasDepthPanel({ expression, onExpressionChange, onCommand }: { expression: string; onExpressionChange: (expression: string) => void; onCommand: (command: string) => void }) {
  const cleanExpression = expression || "x^2-5*x+6";
  const casSummary = useMemo(() => casCommandRegistrySummary(), []);
  const geogebraSummary = useMemo(() => geogebraCasParitySummary(), []);
  const commandMatches = useMemo(() => {
    const matches = searchCasCommands(cleanExpression, 6);
    return matches.length ? matches : searchCasCommands("", 6);
  }, [cleanExpression]);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-slate-950/60">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-black uppercase tracking-wide text-cyan-600 dark:text-cyan-300">CAS Depth</p>
          <h3 className="mt-1 font-bold">Exact algebra workbench</h3>
        </div>
        <FunctionSquare className="h-5 w-5 text-cyan-500" />
      </div>
      <label className="mt-3 block rounded-xl bg-slate-100 px-3 py-2 dark:bg-white/10">
        <span className="text-[11px] font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">Expression</span>
        <input
          value={expression}
          onChange={(event) => onExpressionChange(event.target.value)}
          className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm font-bold text-slate-900 dark:border-white/10 dark:bg-slate-900 dark:text-white"
          placeholder="x^2-5*x+6"
        />
      </label>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {casDepthActions.map((action) => (
          <button
            key={action.label}
            type="button"
            onClick={() => onCommand(action.command(cleanExpression))}
            title={action.command(cleanExpression)}
            className={`rounded-xl border px-3 py-2 text-left text-xs font-black transition hover:-translate-y-0.5 ${action.tone === "cyan" ? "border-cyan-200 bg-cyan-50 text-cyan-800 hover:bg-cyan-100 dark:border-cyan-400/20 dark:bg-cyan-400/10 dark:text-cyan-100" : "border-violet-200 bg-violet-50 text-violet-800 hover:bg-violet-100 dark:border-violet-400/20 dark:bg-violet-400/10 dark:text-violet-100"}`}
          >
            {action.label}
          </button>
        ))}
      </div>
      <div className="mt-3 rounded-xl border border-cyan-200 bg-cyan-50 p-3 dark:border-cyan-300/20 dark:bg-cyan-300/10">
        <p className="text-[11px] font-black uppercase tracking-wide text-cyan-700 dark:text-cyan-100">Phase 1 CAS foundation</p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          <span className="mini-chip">{casSummary.implemented} implemented</span>
          <span className="mini-chip">{casSummary.partial} partial</span>
          <span className="mini-chip">{casSummary.planned} planned</span>
          <span className="mini-chip">{geogebraSummary.covered}/{geogebraSummary.geogebraTotal} CAS commands</span>
          <span className="mini-chip">{geogebraSummary.missingByPriority.P0} P0 gaps</span>
        </div>
        <div className="mt-3 grid gap-1.5">
          {commandMatches.slice(0, 4).map((command) => (
            <button
              key={command.name}
              type="button"
              onClick={() => onCommand(command.examples[0])}
              className="rounded-lg bg-white px-2.5 py-2 text-left text-[11px] font-bold text-slate-700 transition hover:bg-cyan-100 dark:bg-slate-950/80 dark:text-slate-200 dark:hover:bg-cyan-300/15"
              title={command.description}
            >
              <span className="font-black text-cyan-700 dark:text-cyan-100">{command.name}</span>
              <span className="ml-2 uppercase text-slate-400">{command.support}</span>
              <span className="mt-0.5 block truncate font-mono">{command.examples[0]}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="mt-3 grid gap-2 text-xs font-bold text-slate-500 dark:text-slate-400">
        <p>Exact: algebra, calculus, systems</p>
        <p>Linked: result cards, graph, table</p>
      </div>
    </div>
  );
}

function CasResultsPanel({ results, onClear }: { results: ResultCard[]; onClear: () => void }) {
  return (
    <div className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-slate-950/60">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-[11px] font-black uppercase tracking-wide text-cyan-600 dark:text-cyan-300">CAS Timeline</p>
          <h3 className="mt-1 font-bold">Exact results</h3>
        </div>
        <button type="button" onClick={onClear} className="rounded-full bg-slate-100 p-2 dark:bg-white/10" title="Clear CAS results" aria-label="Clear CAS results"><Trash2 className="h-4 w-4" /></button>
      </div>
      {results.length === 0 ? (
        <EmptyPanel text="Run a CAS command to show exact steps, tables, and graph links here." />
      ) : (
        <div className="max-h-[520px] space-y-3 overflow-y-auto pr-1">
          {results.slice(0, 6).map((result) => <ResultCardView key={result.id} result={result} />)}
        </div>
      )}
    </div>
  );
}

function spreadsheetPoints(grid: SpreadsheetCellGrid) {
  return grid.slice(1).map((row) => ({ x: Number(row[0]), y: Number(row[1]) })).filter((point) => Number.isFinite(point.x) && Number.isFinite(point.y));
}

function columnName(index: number) {
  let name = "";
  let current = index + 1;
  while (current > 0) {
    const rem = (current - 1) % 26;
    name = String.fromCharCode(65 + rem) + name;
    current = Math.floor((current - 1) / 26);
  }
  return name;
}

function _columnIndex(name: string) {
  return name.split("").reduce((sum, char) => sum * 26 + char.charCodeAt(0) - 64, 0) - 1;
}

function analyzeFunction(expression: string) {
  const roots = solveCommand(`${expression}=0`, `Root[${expression}]`).result;
  const extrema = extremaCommand(expression, `Extremum[${expression}]`).result;
  const yIntercept = safeEvaluate(expression, 0);
  const derivative = trySymbolic(() => symbolicDerivative(expression))?.result ?? derivativeText(expression);
  const integral = trySymbolic(() => symbolicIntegral(expression))?.result ?? integralText(expression);
  return {
    roots,
    extrema,
    intercepts: `y-intercept ${Number.isFinite(yIntercept) ? roundTo(yIntercept, 5) : "undefined"}`,
    domainHint: domainHint(expression),
    derivative,
    integral,
  };
}

function safeEvaluate(expression: string, x: number) {
  try {
    return evaluateMathExpression(expression, x);
  } catch {
    return Number.NaN;
  }
}

function domainHint(expression: string) {
  const hints: string[] = [];
  if (/sqrt\s*\(/i.test(expression)) hints.push("square-root radicand must be nonnegative");
  if (/log|ln/i.test(expression)) hints.push("log input must be positive");
  if (/\//.test(expression)) hints.push("denominators cannot be zero");
  return hints.length ? hints.join("; ") : "all real x unless a hidden denominator/domain restriction appears";
}

function ResultCardView({ result }: { result: ResultCard }) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <p className="text-xs font-bold uppercase text-cyan-600 dark:text-cyan-300">{result.interpretation}</p>
      <p className="mt-2 text-sm font-semibold text-slate-500 dark:text-slate-400"><MathExpression value={result.input} /></p>
      <p className="mt-3 text-lg font-bold"><MathExpression value={result.result} /></p>
      {result.detail && <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{result.detail}</p>}
      {result.steps && (
        <ol className="mt-3 space-y-1 rounded-2xl bg-slate-100 p-3 text-sm leading-6 text-slate-600 dark:bg-white/10 dark:text-slate-300">
          {result.steps.map((step, index) => <li key={`${step}-${index}`}><span className="font-bold text-cyan-600 dark:text-cyan-300">{index + 1}.</span> <MathExpression value={step} /></li>)}
        </ol>
      )}
      {result.table && result.table.length > 0 && (
        <div className="mt-3 overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-100 text-xs uppercase text-slate-500 dark:bg-white/10 dark:text-slate-400"><tr><th className="px-3 py-2">x</th><th className="px-3 py-2">y</th></tr></thead>
            <tbody>{result.table.map((row, index) => <tr key={`${row.x}-${index}`} className="border-t border-slate-200 dark:border-white/10"><td className="px-3 py-2 font-mono">{row.x}</td><td className="px-3 py-2 font-mono">{row.y}</td></tr>)}</tbody>
          </table>
        </div>
      )}
      {result.related && (
        <div className="mt-3 flex flex-wrap gap-2">
          {result.related.map((item) => <span key={item} className="mini-chip">{item}</span>)}
        </div>
      )}
    </article>
  );
}

function EmptyPanel({ text }: { text: string }) {
  return <div className="rounded-2xl bg-slate-100 p-5 text-sm leading-6 text-slate-600 dark:bg-white/10 dark:text-slate-300">{text}</div>;
}

function normalizeColor(value?: string) {
  const match = value?.match(/^#[0-9a-f]{6}/i);
  return match?.[0] ?? null;
}

type AlgebraObjectRow = {
  ref: AlgebraObjectRef;
  name: string;
  definition: string;
  visible: boolean;
  locked: boolean;
  trace: boolean;
  dependencies: string[];
};

function liveWorkspaceObjectId(ref: AlgebraObjectRef) {
  return `live:${ref.kind}:${ref.id}`;
}

function liveRefFromMathObject(object: MathObject): AlgebraObjectRef | null {
  const refKind = object.metadata?.refKind;
  const refId = object.metadata?.refId;
  if (typeof refKind === "string" && typeof refId === "string" && isAlgebraObjectKind(refKind)) {
    return { kind: refKind, id: refId };
  }
  const [, kind, ...idParts] = object.id.split(":");
  if (object.id.startsWith("live:") && isAlgebraObjectKind(kind) && idParts.length > 0) {
    return { kind, id: idParts.join(":") };
  }
  return null;
}

function isAlgebraObjectKind(value: string): value is AlgebraObjectKind {
  return ["function", "point", "line", "circle", "polygon", "arc", "locus", "3d"].includes(value);
}

function mathObjectKindForLiveRef(ref: AlgebraObjectRef): MathObjectKind {
  if (ref.kind !== "3d") return ref.kind === "locus" ? "geometry" : ref.kind;
  if (ref.id.includes("surface")) return "surface";
  if (ref.id.includes("plane") || ref.id === "slice") return "plane";
  if (ref.id === "point") return "point";
  if (ref.id === "vector") return "vector";
  if (ref.id.includes("line")) return "line";
  return "solid";
}

function liveCategoryForRef(ref: AlgebraObjectRef): NonNullable<MathObject["definition"]>["category"] {
  if (ref.kind === "function") return "graph";
  if (ref.kind === "3d") return "geometry3d";
  return "geometry2d";
}

function liveLinkedViewsForRef(ref: AlgebraObjectRef) {
  if (ref.kind === "function") return ["Graph", "Algebra", "Inspector"];
  if (ref.kind === "3d") return ["3D", "Algebra", "Inspector"];
  return ["Geometry", "Algebra", "Inspector"];
}

function workspacePropertyVariables(surfaceScale: number, solidHeight: number, crossSection: number, animationSpeed: number) {
  return {
    a: surfaceScale,
    b: solidHeight,
    scale: surfaceScale,
    height: solidHeight,
    z: crossSection,
    speed: animationSpeed,
  };
}

function hasCustomObjectProperties(object: MathObject) {
  const properties = object.properties;
  if (!properties) return false;
  return properties.label !== object.label
    || Boolean(properties.caption?.trim())
    || (properties.layer ?? 0) !== 0
    || (properties.labelMode ?? "name") !== "name"
    || Boolean(properties.conditionalVisibility?.trim())
    || Boolean(properties.dynamicColor)
    || Boolean(properties.dynamicStyle?.opacity?.trim())
    || Boolean(properties.dynamicStyle?.strokeWidth?.trim());
}

function sameObjectProperties(left: MathObjectProperties | undefined, right: MathObjectProperties | undefined) {
  return JSON.stringify(left ?? {}) === JSON.stringify(right ?? {});
}

function liveWorkspaceStyle(row: AlgebraObjectRow, plots: PlotItem[], construction: Construction, transforms3d: Record<ThreeObjectId, Transform3D>, added3dObjects: Added3DObject[]): MathObjectStyle {
  if (row.ref.kind === "function") {
    const plot = plots.find((item) => item.id === row.ref.id);
    return { color: plot?.color ?? "#06b6d4", stroke: plot?.color ?? "#06b6d4", strokeWidth: 2.5, opacity: row.visible ? 1 : 0.35, labelVisible: true };
  }
  if (row.ref.kind === "3d") {
    const transform = liveTransform3d(row.ref.id, transforms3d, added3dObjects);
    return { ...transform, color: transform?.color ?? "#8b5cf6", stroke: transform?.color ?? "#8b5cf6", opacity: transform?.opacity ?? 1, material: transform?.material ?? "matte", labelVisible: true };
  }
  const style = geometryStyleForRef(row.ref, construction);
  return { ...style, lineStyle: style?.lineStyle ?? (style?.dashArray ? "dashed" : "solid"), color: style?.color ?? "#06b6d4", fill: style?.fill, stroke: style?.color ?? "#0f172a", strokeWidth: style?.strokeWidth ?? 2, opacity: style?.opacity ?? 1, labelVisible: style?.labelMode !== "hidden" };
}

function liveWorkspaceTransform(row: AlgebraObjectRow, transforms3d: Record<ThreeObjectId, Transform3D>, added3dObjects: Added3DObject[]): Partial<MathTransform> | undefined {
  if (row.ref.kind !== "3d") return undefined;
  const transform = liveTransform3d(row.ref.id, transforms3d, added3dObjects);
  if (!transform) return undefined;
  return {
    position: { x: transform.position[0], y: transform.position[1], z: transform.position[2] },
    rotation: { x: transform.rotation[0], y: transform.rotation[1], z: transform.rotation[2] },
    scale: { x: transform.scale, y: transform.scale, z: transform.scale },
  };
}

function liveWorkspaceGeometry(row: AlgebraObjectRow, construction: Construction, transforms3d: Record<ThreeObjectId, Transform3D>, added3dObjects: Added3DObject[]): MathObject["geometry"] {
  if (row.ref.kind === "point") {
    const point = pointById(construction.points, row.ref.id);
    return point ? { type: "point", position: { x: point.x, y: point.y, z: 0 } } : { type: "none" };
  }
  if (row.ref.kind === "line") {
    const line = construction.lines.find((item) => item.id === row.ref.id);
    const a = line ? pointById(construction.points, line.a) : null;
    const b = line ? pointById(construction.points, line.b) : null;
    return a && b ? { type: "line", start: { x: a.x, y: a.y, z: 0 }, end: { x: b.x, y: b.y, z: 0 } } : { type: "none" };
  }
  if (row.ref.kind === "circle") {
    const circle = construction.circles.find((item) => item.id === row.ref.id);
    const center = circle ? pointById(construction.points, circle.center) : null;
    const edge = circle ? pointById(construction.points, circle.edge) : null;
    return center && edge ? { type: "circle", center: { x: center.x, y: center.y, z: 0 }, radius: distance(center, edge) } : { type: "none" };
  }
  if (row.ref.kind === "polygon") {
    const polygon = construction.polygons.find((item) => item.id === row.ref.id);
    const vertices = polygon?.points.map((id) => pointById(construction.points, id)).filter((point): point is GeoPoint => Boolean(point)) ?? [];
    return vertices.length >= 3 ? { type: "polygon", vertices: vertices.map((point) => ({ x: point.x, y: point.y, z: 0 })) } : { type: "none" };
  }
  if (row.ref.kind === "arc") {
    const arc = construction.arcs.find((item) => item.id === row.ref.id);
    const center = arc ? pointById(construction.points, arc.center) : null;
    const start = arc ? pointById(construction.points, arc.start) : null;
    const end = arc ? pointById(construction.points, arc.end) : null;
    if (!center || !start || !end) return { type: "none" };
    return {
      type: "arc",
      center: { x: center.x, y: center.y, z: 0 },
      radius: distance(center, start),
      startAngle: Math.atan2(start.y - center.y, start.x - center.x),
      endAngle: Math.atan2(end.y - center.y, end.x - center.x),
    };
  }
  if (row.ref.kind === "3d") {
    const transform = liveTransform3d(row.ref.id, transforms3d, added3dObjects);
    const dimensions = transform?.dimensions ?? [transform?.scale ?? 1, transform?.scale ?? 1, transform?.scale ?? 1];
    if (mathObjectKindForLiveRef(row.ref) === "surface") return { type: "surface", expression: row.definition };
    if (mathObjectKindForLiveRef(row.ref) === "plane") return { type: "plane", point: { x: transform?.position[0] ?? 0, y: transform?.position[1] ?? 0, z: transform?.position[2] ?? 0 }, normal: { x: 0, y: 0, z: 1 }, width: dimensions[0], height: dimensions[1] };
    return { type: "solid", solid: "cuboid", dimensions: { x: dimensions[0], y: dimensions[1], z: dimensions[2] } };
  }
  return { type: "none" };
}

function createLiveWorkspaceObjects(rows: AlgebraObjectRow[], plots: PlotItem[], construction: Construction, transforms3d: Record<ThreeObjectId, Transform3D>, added3dObjects: Added3DObject[], propertyOverrides: ObjectPropertyOverrides): MathObject[] {
  return rows.map((row) => createMathObject({
    id: liveWorkspaceObjectId(row.ref),
    kind: mathObjectKindForLiveRef(row.ref),
    dimension: row.ref.kind === "3d" ? "3d" : row.ref.kind === "function" ? "abstract" : "2d",
    role: row.ref.kind === "function" ? "algebra" : "construction",
    label: row.name,
    value: row.definition,
    summary: row.dependencies.length > 0 ? `Depends on ${row.dependencies.join(", ")}` : undefined,
    visible: row.visible,
    locked: row.locked,
    style: liveWorkspaceStyle(row, plots, construction, transforms3d, added3dObjects),
    transform: liveWorkspaceTransform(row, transforms3d, added3dObjects),
    geometry: liveWorkspaceGeometry(row, construction, transforms3d, added3dObjects),
    properties: propertyOverrides[liveWorkspaceObjectId(row.ref)],
    definition: { source: row.definition, expression: row.definition, category: liveCategoryForRef(row.ref), parentIds: row.dependencies },
    dependencies: row.dependencies.map((dependency) => ({ id: dependency, label: dependency, role: "parent" })),
    linkedViews: liveLinkedViewsForRef(row.ref),
    metadata: { source: "live-workspace", refKind: row.ref.kind, refId: row.ref.id, trace: row.trace },
    interactivity: { editable: true, draggable: row.ref.kind !== "function", resizable: row.ref.kind === "3d", rotatable: row.ref.kind === "3d", selectable: true },
  }));
}

function createSupplementalWorkspaceObjects(results: ResultCard[], plots: PlotItem[], spreadsheet: SpreadsheetCellGrid, tableRange: { start: number; end: number; step: number }): MathObject[] {
  const visibleFunctionPlots = plots
    .filter((plot) => plot.visible !== false && (plot.kind ?? inferPlotKind(plot.expression)) === "function")
    .slice(0, 4);
  const tableObjects = visibleFunctionPlots.map((plot) => {
    const table = createDynamicTable([plot.expression], tableRange.start, tableRange.end, tableRange.step, safeEvaluate);
    const linkedPlotId = liveWorkspaceObjectId({ kind: "function", id: plot.id });
    return createMathObject({
      id: `workspace-table:${plot.id}`,
      kind: "table",
      dimension: "abstract",
      role: "algebra",
      label: `${plot.name ?? plot.expression} table`,
      value: `${table.rows.length} rows from x=${table.start} to ${table.end}`,
      summary: "Dynamic value table linked to a graph object in the shared workspace model.",
      visible: plot.visible !== false,
      definition: { source: `Table[${plot.expression}, ${table.start}, ${table.end}, ${table.step}]`, command: "Table", expression: plot.expression, category: "spreadsheet", parentIds: [linkedPlotId] },
      dependencies: [{ id: linkedPlotId, label: plot.name ?? plot.expression, role: "source" }],
      linkedViews: ["Graph", "Table", "Spreadsheet", "Inspector"],
      metadata: {
        source: "live-workspace",
        supplemental: "dynamic-table",
        rows: table.rows.length,
        csvPreview: table.exportCsv.split("\n").slice(0, 4).join("\n"),
      },
      interactivity: { selectable: true, editable: false, draggable: false, resizable: false, rotatable: false },
    });
  });

  const spreadsheetEvaluation = evaluateSpreadsheetGrid(spreadsheet);
  const spreadsheetObject = createMathObject({
    id: "workspace-spreadsheet:grid",
    kind: "dataset",
    dimension: "abstract",
    role: "algebra",
    label: "Spreadsheet grid",
    value: `${spreadsheet.length} rows x ${Math.max(...spreadsheet.map((row) => row.length), 0)} columns`,
    summary: spreadsheetEvaluation.errors.length
      ? `${spreadsheetEvaluation.errors.length} spreadsheet formula issue${spreadsheetEvaluation.errors.length === 1 ? "" : "s"} detected.`
      : "Spreadsheet cells are evaluated into the same shared object graph as graph and CAS outputs.",
    visible: true,
    definition: { source: "Spreadsheet grid", command: "Spreadsheet", category: "spreadsheet", parentIds: [] },
    linkedViews: ["Spreadsheet", "Table", "Graph", "Inspector"],
    metadata: {
      source: "live-workspace",
      supplemental: "spreadsheet",
      rows: spreadsheet.length,
      columns: Math.max(...spreadsheet.map((row) => row.length), 0),
      errors: spreadsheetEvaluation.errors.length,
      csvPreview: rangeToCsv(spreadsheetEvaluation.values, `A1:${columnNameForWorkspace(Math.max(...spreadsheet.map((row) => row.length), 1) - 1)}${spreadsheet.length}`).split("\n").slice(0, 6).join("\n"),
    },
    interactivity: { selectable: true, editable: true, draggable: false, resizable: false, rotatable: false },
  });

  const resultObjects = results.slice(0, 8).map((result, index) => createMathObject({
    id: `workspace-cas-result:${result.id}`,
    kind: "result",
    dimension: "abstract",
    role: "result",
    label: result.interpretation || `CAS result ${index + 1}`,
    value: result.result,
    summary: result.detail,
    visible: true,
    definition: { source: result.input, command: result.interpretation, expression: result.graphExpression ?? result.input, category: "cas", parentIds: result.graphExpression ? matchingPlotDependencies(result.graphExpression, plots) : [] },
    dependencies: result.graphExpression ? matchingPlotDependencies(result.graphExpression, plots).map((id) => ({ id, label: id, role: "source" })) : [],
    linkedViews: ["CAS", "Algebra", "Graph", "Table", "Inspector"],
    metadata: {
      source: "live-workspace",
      supplemental: "cas-result",
      resultIndex: index + 1,
      stepCount: result.steps?.length ?? 0,
      tableRows: result.table?.length ?? 0,
    },
    interactivity: { selectable: true, editable: false, draggable: false, resizable: false, rotatable: false },
  }));

  return [...tableObjects, spreadsheetObject, ...resultObjects];
}

function matchingPlotDependencies(expression: string, plots: PlotItem[]) {
  const normalizedExpression = expression.replace(/\s+/g, "");
  return plots
    .filter((plot) => plot.expression.replace(/\s+/g, "") === normalizedExpression)
    .map((plot) => liveWorkspaceObjectId({ kind: "function", id: plot.id }));
}

function columnNameForWorkspace(index: number) {
  let name = "";
  let value = Math.max(0, index) + 1;
  while (value > 0) {
    const remainder = (value - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    value = Math.floor((value - 1) / 26);
  }
  return name || "A";
}

function geometryStyleForRef(ref: AlgebraObjectRef, construction: Construction): GeoStyle | undefined {
  if (ref.kind === "point") return pointById(construction.points, ref.id)?.style;
  if (ref.kind === "line") return construction.lines.find((item) => item.id === ref.id)?.style;
  if (ref.kind === "circle") return construction.circles.find((item) => item.id === ref.id)?.style;
  if (ref.kind === "polygon") return construction.polygons.find((item) => item.id === ref.id)?.style;
  if (ref.kind === "arc") return construction.arcs.find((item) => item.id === ref.id)?.style;
  if (ref.kind === "locus") return construction.loci.find((item) => item.id === ref.id)?.style;
  return undefined;
}

function liveTransform3d(id: string, transforms3d: Record<ThreeObjectId, Transform3D>, added3dObjects: Added3DObject[]) {
  if (isBase3dId(id)) return transforms3d[id];
  return added3dObjects.find((object) => object.id === id)?.transform;
}

function UnifiedWorkspacePanel({
  objects,
  selectedObject,
  selectedObjectId,
  selectedObjectIds,
  onObjectAction,
  onObjectChange,
}: {
  objects: MathObject[];
  selectedObject: MathObject | null;
  selectedObjectId: string | null;
  selectedObjectIds: string[];
  onObjectAction: (action: ObjectListAction, object: MathObject) => void;
  onObjectChange: (object: MathObject, patch: Partial<MathObject>) => void;
}) {
  return (
    <CollapsibleSideCard id="workspace-unified-registry-panel" title="Unified Dynamic Workspace" subtitle="Graph, geometry, CAS, tables, spreadsheet, and 3D registry" meta={<span className="mini-chip">{objects.length} objects</span>} className="workspace-unified-registry-card border-cyan-200/80 bg-white/85 dark:border-cyan-300/20 dark:bg-slate-950/50">
      <ObjectList objects={objects} selectedObjectId={selectedObjectId} selectedObjectIds={selectedObjectIds} onObjectAction={onObjectAction} />
      <InspectorPanel object={selectedObject} onObjectChange={onObjectChange} />
    </CollapsibleSideCard>
  );
}

function WorkspaceMainMenu({ active, onChange, docked = false }: { active: WorkspaceView; onChange: (view: WorkspaceView) => void; docked?: boolean }) {
  const modules: Array<{ id: WorkspaceView; label: string; route: string; icon: JSX.Element }> = workspaceModeNavigation.map((config) => ({
    id: workspaceViewForMode(config.mode),
    label: config.title,
    route: config.routePath,
    icon: workspaceModeIcon(config.mode),
  }));
  const links = [
    { label: "All workspace", route: "/workspace" },
    { label: "Shapes", route: "/shapes" },
    { label: "Formulas", route: "/formulas" },
    { label: "Syllabus", route: "/syllabus" },
    { label: "Home", route: "/" },
  ];

  return (
    <nav className={`${docked ? "sticky top-1 z-30 w-fit max-w-full" : "fixed left-3 right-3 top-2 z-50"} rounded-xl border border-slate-200 bg-white/95 p-1.5 shadow-xl shadow-slate-200/40 backdrop-blur dark:border-white/10 dark:bg-slate-950/95 dark:shadow-black/20`} aria-label="Workspace main menu" data-testid="workspace-tool-rail">
      <div className="flex min-w-0 items-center justify-between gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-1.5">
          <span className="shrink-0 rounded-lg bg-cyan-500 px-2.5 py-1.5 text-[11px] font-black uppercase tracking-wide text-slate-950 shadow-lg shadow-cyan-500/20">Menu</span>
          <div className="flex min-w-0 gap-1.5 overflow-x-auto overscroll-x-contain">
            {modules.map((module) => (
              <Link
                key={module.id}
                to={module.route}
                onClick={() => onChange(module.id)}
                className={`inline-flex min-h-9 shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-black transition ${
                  active === module.id
                    ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950"
                    : "bg-slate-100 text-slate-700 hover:bg-cyan-100 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-300/15"
                }`}
              >
                {module.icon}
                {module.label}
              </Link>
            ))}
          </div>
        </div>
        <div className="hidden max-w-[38%] gap-1.5 overflow-x-auto overscroll-x-contain lg:flex">
          {links.map((item) => (
            <Link key={item.route} to={item.route} className="inline-flex min-h-9 shrink-0 items-center rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs font-bold text-slate-700 transition hover:bg-cyan-100 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-300/15">
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}

function isTypingTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  const tag = target.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target.isContentEditable;
}

function WorkspaceShortcutStrip() {
  const shortcuts = [
    ["Esc", "deselect"],
    ["Delete", "delete selected"],
    ["Arrow keys", "nudge 2D point"],
    ["Shift+Arrow", "fast nudge"],
    ["Ctrl+Z / Y", "undo / redo"],
    ["Ctrl+Enter", "run command"],
  ];
  return (
    <div className="flex flex-wrap gap-2 rounded-2xl border border-slate-200 bg-white/70 p-2 text-xs font-bold text-slate-600 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
      {shortcuts.map(([key, label]) => (
        <span key={key} className="inline-flex items-center gap-2 rounded-xl bg-slate-100 px-3 py-2 dark:bg-white/10">
          <kbd className="rounded-md bg-white px-2 py-1 font-black text-slate-900 shadow-sm dark:bg-slate-950 dark:text-white">{key}</kbd>
          <span>{label}</span>
        </span>
      ))}
    </div>
  );
}

function WorkspaceModeTabs({ active, onChange }: { active: WorkspaceView; onChange: (view: WorkspaceView) => void }) {
  const views: { id: WorkspaceView; label: string; icon: JSX.Element }[] = [
    { id: "graph", label: "Graph + Algebra", icon: <FunctionSquare className="h-4 w-4" /> },
    { id: "geometry", label: "2D Geometry", icon: <Pentagon className="h-4 w-4" /> },
    { id: "3d", label: "3D", icon: <Box className="h-4 w-4" /> },
    { id: "data", label: "CAS + Tables", icon: <LineChart className="h-4 w-4" /> },
    { id: "teach", label: "Teach", icon: <Presentation className="h-4 w-4" /> },
  ];
  return (
    <div className="sticky top-12 z-20 rounded-xl border border-slate-200 bg-white/95 p-1.5 shadow-sm backdrop-blur dark:border-white/10 dark:bg-slate-950/95">
      <div className="mobile-safe-scroll flex gap-1.5 overflow-x-auto">
        {views.map((view) => (
          <button
            key={view.id}
            type="button"
            onClick={() => onChange(view.id)}
            className={`flex min-h-9 shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition ${active === view.id ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950" : "bg-slate-100 text-slate-700 hover:bg-cyan-100 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-300/15"}`}
          >
            {view.icon}
            {view.label}
          </button>
        ))}
      </div>
    </div>
  );
}

const dataWorkspaceNavItems: { id: DataWorkspacePage; label: string; route: string }[] = [
  { id: "overview", label: "Overview", route: "/workspace/data/overview" },
  { id: "spreadsheet", label: "Spreadsheet", route: "/workspace/data/spreadsheet" },
  { id: "analysis", label: "Analysis", route: "/workspace/data/analysis" },
  { id: "cas", label: "CAS", route: "/workspace/data/cas" },
  { id: "results", label: "Results", route: "/workspace/data/results" },
  { id: "objects", label: "Objects", route: "/workspace/data/objects" },
];

function dataWorkspacePageTitle(page: DataWorkspacePage) {
  return dataWorkspaceNavItems.find((item) => item.id === page)?.label ?? "Data Workspace";
}

function DataWorkspaceNav({ active }: { active: DataWorkspacePage }) {
  return (
    <nav className="flex max-w-full flex-wrap gap-1.5" aria-label="Data workspace pages">
      {dataWorkspaceNavItems.map((item) => (
        <Link
          key={item.id}
          to={item.route}
          className={`rounded-full px-3 py-2 text-xs font-black uppercase tracking-wide transition ${active === item.id ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950" : "bg-slate-100 text-slate-700 hover:bg-cyan-100 hover:text-cyan-900 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-300/15 dark:hover:text-cyan-50"}`}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}

function CompactWorkspaceBar({ activeTemplate, teachingMode, compact = false, onSave, onLoad, onUndo, onRedo, onExportJson, onExportPng, onShare, onToggleTeach }: { activeTemplate: SyllabusWorkspaceTemplate; teachingMode: boolean; compact?: boolean; onSave: () => void; onLoad: () => void; onUndo: () => void; onRedo: () => void; onExportJson: () => void; onExportPng: () => void; onShare: () => void; onToggleTeach: () => void }) {
  const actionButtons = (
    <>
      <button type="button" onClick={onSave} className="action-secondary py-2"><Save className="h-4 w-4" />Save</button>
      <button type="button" onClick={onLoad} className="action-secondary py-2"><Download className="h-4 w-4" />Load</button>
      <button type="button" onClick={onUndo} className="action-secondary py-2"><RotateCcw className="h-4 w-4" />Undo</button>
      <button type="button" onClick={onRedo} className="action-secondary py-2"><RotateCcw className="h-4 w-4" />Redo</button>
      <button type="button" onClick={onExportJson} className="action-secondary py-2"><Download className="h-4 w-4" />JSON</button>
      <button type="button" onClick={onExportPng} className="action-secondary py-2"><Download className="h-4 w-4" />PNG</button>
      <button type="button" onClick={onShare} className="action-secondary py-2"><Download className="h-4 w-4" />URL</button>
      <button type="button" onClick={onToggleTeach} className={teachingMode ? "action-primary py-2" : "action-secondary py-2"}><Presentation className="h-4 w-4" />Teach</button>
    </>
  );

  return (
    <div className={compact ? "rounded-xl border border-slate-200 bg-white/80 p-2 dark:border-white/10 dark:bg-white/5" : "rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-white/10 dark:bg-white/5"} data-testid="workspace-command-bar">
      <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <span className="mini-chip">{activeTemplate.unit}</span>
        </div>
        {compact ? (
          <details className="relative ml-auto">
            <summary className="list-none rounded-xl border border-cyan-100 bg-white/90 px-3 py-2 text-xs font-black text-slate-800 shadow-sm transition hover:border-cyan-300 hover:bg-cyan-50 dark:border-white/10 dark:bg-white/10 dark:text-slate-100">
              Actions
            </summary>
            <div className="absolute right-0 z-30 mt-2 grid w-[min(88vw,360px)] grid-cols-2 gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl shadow-cyan-950/15 dark:border-white/10 dark:bg-slate-950">
              {actionButtons}
            </div>
          </details>
        ) : (
          <div className="flex w-full min-w-0 flex-nowrap gap-2 overflow-x-auto overscroll-x-contain pb-1 lg:flex-1 lg:justify-end">
            {actionButtons}
          </div>
        )}
      </div>
    </div>
  );
}

type CasStudioWorkspaceProps = {
  state: NotebookState;
  selectedCell?: NotebookCell;
  composerInput: string;
  composerOperation: NotebookOperation;
  exportMarkdown: string;
  results: ResultCard[];
  onSelectCell: (id: string | null) => void;
  onUpdateCell: (id: string, patch: Partial<NotebookCell>) => void;
  onRunCell: (id: string) => void;
  onRunAll: () => void;
  onAddCell: (input?: string, operation?: NotebookOperation) => void;
  onDuplicateCell: (cell: NotebookCell) => void;
  onDeleteCell: (id: string) => void;
  onReorderCells: (orderedIds: string[]) => void;
  onReset: () => void;
  onModeChange: (mode: EvaluationMode) => void;
  onAssumptionsChange: (assumptions: string) => void;
  onComposerInputChange: (value: string) => void;
  onComposerOperationChange: (operation: NotebookOperation) => void;
  onDataCommand: (command: string) => void;
  onSendToGraph: (cell: NotebookCell) => void;
  onExport: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onShare: () => void;
  shareControl?: ReactNode;
};

function LegacyCasStudioWorkspace({
  state,
  selectedCell,
  composerInput,
  composerOperation,
  exportMarkdown,
  results,
  onSelectCell,
  onUpdateCell,
  onRunCell,
  onRunAll,
  onAddCell,
  onDuplicateCell,
  onDeleteCell,
  onReset,
  onModeChange,
  onAssumptionsChange,
  onComposerInputChange,
  onComposerOperationChange,
  onDataCommand,
  onSendToGraph,
  onExport,
}: CasStudioWorkspaceProps) {
  const [workspaceQuery, setWorkspaceQuery] = useState("");
  const [mobilePanel, setMobilePanel] = useState<"notebook" | "history" | "result">("notebook");
  const variableCount = state.cells.filter((cell) => /:=/.test(cell.input)).length;
  const functionCount = state.cells.filter((cell) => /(derivative|differentiate|integrate|limit|solve|factor|expand)/i.test(cell.operation)).length;
  const selectedIndex = selectedCell ? state.cells.length - state.cells.findIndex((cell) => cell.id === selectedCell.id) : 0;
  const latestResults = results.slice(0, 4);
  const visibleCells = useMemo(() => {
    const query = workspaceQuery.trim().toLowerCase();
    if (!query) return state.cells;
    return state.cells.filter((cell) =>
      [cell.input, cell.operation, cell.output, cell.exact, ...(cell.steps ?? [])].filter(Boolean).join(" ").toLowerCase().includes(query),
    );
  }, [state.cells, workspaceQuery]);

  return (
    <div className={`cas-studio-shell mobile-panel-${mobilePanel}`} data-testid="workspace-cas-studio">
      <nav className="cas-mobile-panels" aria-label="CAS mobile panels">
        <button type="button" className={mobilePanel === "history" ? "is-active" : ""} onClick={() => setMobilePanel("history")}>History</button>
        <button type="button" className={mobilePanel === "notebook" ? "is-active" : ""} onClick={() => setMobilePanel("notebook")}>Notebook</button>
        <button type="button" className={mobilePanel === "result" ? "is-active" : ""} onClick={() => setMobilePanel("result")}>Result</button>
      </nav>
      <aside className="cas-studio-left" aria-label="CAS workspace and history">
        <button type="button" className="cas-mobile-sheet-close" onClick={() => setMobilePanel("notebook")}>Close history</button>
        <div className="cas-panel-heading">
          <div>
            <p>Computer Algebra Studio</p>
            <h3>Workspace</h3>
          </div>
          <button type="button" onClick={() => onAddCell()} title="New calculation" aria-label="New calculation"><Plus className="h-4 w-4" /></button>
        </div>
        <label className="cas-search">
          <Search className="h-4 w-4" />
          <input value={workspaceQuery} placeholder="Search expressions" onChange={(event) => setWorkspaceQuery(event.target.value)} />
        </label>
        <div className="cas-object-list">
          {visibleCells.map((cell) => {
            const active = selectedCell?.id === cell.id;
            const index = state.cells.findIndex((item) => item.id === cell.id);
            return (
              <button key={cell.id} type="button" className={`cas-object-row ${active ? "is-active" : ""}`} onClick={() => onSelectCell(cell.id)}>
                <span className="cas-object-badge">{state.cells.length - index}</span>
                <span className="min-w-0 flex-1">
                  <strong>{operationOptions.find((item) => item.value === cell.operation)?.label ?? cell.operation}</strong>
                  <small>{cell.input || "Empty calculation"}</small>
                </span>
                {cell.ok ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : cell.output ? <AlertTriangle className="h-4 w-4 text-amber-500" /> : <Pin className="h-4 w-4 text-slate-300" />}
              </button>
            );
          })}
          {!visibleCells.length && <div className="cas-empty-result">No expressions match this search.</div>}
        </div>
        <div className="cas-section-list">
          <CasSummaryRow label="Variables" value={variableCount} />
          <CasSummaryRow label="Functions" value={functionCount} />
          <CasSummaryRow label="Equations" value={state.cells.filter((cell) => /=/.test(cell.input) && !/:=/.test(cell.input)).length} />
          <CasSummaryRow label="Matrices" value={state.cells.filter((cell) => cell.operation === "matrix").length} />
          <CasSummaryRow label="Lists" value={state.cells.filter((cell) => cell.operation === "list").length} />
          <CasSummaryRow label="Saved objects" value={state.cells.length} />
        </div>
        <div className="cas-history-strip">
          <div className="cas-panel-heading compact">
            <div><p>History</p><h3>{latestResults.length || state.cells.length} recent</h3></div>
          </div>
          {(latestResults.length ? latestResults : state.cells.slice(0, 4)).map((item) => (
            "input" in item && "interpretation" in item ? (
              <button key={item.id} type="button" onClick={() => onDataCommand(item.input)}>
                <span>{item.interpretation}</span>
                <strong>{item.input}</strong>
              </button>
            ) : null
          ))}
        </div>
      </aside>

      <main className="cas-studio-center">
        <header className="cas-studio-modebar">
          {[
            ["CAS", "cas"],
            ["Graph 2D", "graph2d"],
            ["Graph 3D", "graph3d"],
            ["Geometry", "geometry"],
            ["Spreadsheet", "spreadsheet"],
            ["Probability", "probability"],
            ["Notes", "notes"],
          ].map(([label, mode]) => (
            <button
              key={mode}
              type="button"
              className={mode === "cas" ? "is-active" : mode === "spreadsheet" ? "" : "is-unavailable"}
              disabled={!["cas", "spreadsheet"].includes(mode)}
              onClick={() => mode === "spreadsheet" ? window.location.assign("/workspace/data/spreadsheet") : undefined}
              title={mode === "cas" ? "Current symbolic workspace" : mode === "spreadsheet" ? "Open spreadsheet route" : "Available as a separate workspace route"}
            >
              {mode === "cas" ? <Sigma className="h-4 w-4" /> : mode === "graph2d" ? <LineChart className="h-4 w-4" /> : mode === "graph3d" ? <Box className="h-4 w-4" /> : mode === "spreadsheet" ? <Braces className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
              {label}
            </button>
          ))}
        </header>

        <section className="cas-notebook-scroll" aria-label="CAS notebook">
          {state.cells.map((cell, index) => (
            <CasStudioNotebookBlock
              key={cell.id}
              cell={cell}
              index={state.cells.length - index}
              active={selectedCell?.id === cell.id}
              onSelect={() => onSelectCell(cell.id)}
              onRun={() => onRunCell(cell.id)}
              onChange={(patch) => onUpdateCell(cell.id, patch)}
              onDuplicate={() => onDuplicateCell(cell)}
              onDelete={() => onDeleteCell(cell.id)}
              onSendToGraph={() => onSendToGraph(cell)}
              onUseResult={() => {
                const next = cell.exact ?? cell.output ?? cell.input;
                onComposerInputChange(next);
                onAddCell(next, "simplify");
              }}
            />
          ))}
        </section>

        <section className="cas-composer">
          <div className="cas-composer-input">
            <select value={composerOperation} onChange={(event) => onComposerOperationChange(event.target.value as NotebookOperation)} aria-label="CAS operation">
              {operationOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
            </select>
            <textarea value={composerInput} onChange={(event) => onComposerInputChange(event.target.value)} placeholder="Enter symbolic expression, equation, matrix, system, units, or natural-language prompt" />
            <div className="cas-composer-tools">
              <button type="button" title="Voice input unavailable in offline workspace" disabled><Mic className="h-4 w-4" /></button>
              <button type="button" title="Equation scanning opens after confirmation workflow is connected" disabled><Camera className="h-4 w-4" /></button>
              <button type="button" title="Keyboard visible below"><Keyboard className="h-4 w-4" /></button>
              <button type="button" className="primary" onClick={() => onAddCell(composerInput, composerOperation)}><Play className="h-4 w-4" />Calculate</button>
            </div>
          </div>
          <div className="cas-keyboard">
            {["x", "y", "pi", "e", "sqrt()", "^", "| |", "log", "ln", "sin", "cos", "tan", "d/dx", "Integral[]", "Limit[]", "Solve[]", "Matrix[]", "->", "alpha", "Omega"].map((key) => (
              <button key={key} type="button" onClick={() => onComposerInputChange(`${composerInput}${key}`)}>{key}</button>
            ))}
          </div>
          <div className="cas-example-row">
            {casNotebookExamples.slice(0, 6).map((example) => (
              <button key={example.label} type="button" onClick={() => {
                onComposerInputChange(example.input);
                onComposerOperationChange(example.operation);
              }}>
                <span>{example.label}</span>
                <strong>{example.input}</strong>
              </button>
            ))}
          </div>
        </section>
      </main>

      <aside className="cas-studio-right" aria-label="CAS result inspector">
        <button type="button" className="cas-mobile-sheet-close" onClick={() => setMobilePanel("notebook")}>Close results</button>
        <div className="cas-inspector-tabs">
          {["Result", "Steps", "Properties", "Assumptions", "Related"].map((tab, index) => <button key={tab} type="button" className={index === 0 ? "is-active" : ""}>{tab}</button>)}
        </div>
        {selectedCell ? (
          <>
            <section className="cas-inspector-card">
              <div className="cas-panel-heading compact"><div><p>Exact result</p><h3>In [{selectedIndex}]</h3></div>{selectedCell.ok ? <CheckCircle2 className="h-5 w-5 text-emerald-500" /> : <AlertTriangle className="h-5 w-5 text-amber-500" />}</div>
              <div className="cas-result-box"><MathExpression value={selectedCell.exact ?? selectedCell.output ?? "Run this cell"} /></div>
              {selectedCell.numeric && <div className="cas-result-box muted"><MathExpression value={selectedCell.numeric} /></div>}
              <p>{selectedCell.detail || "Select or run a CAS block to inspect exact results, assumptions, warnings, and verification."}</p>
            </section>
            <section className="cas-inspector-card">
              <div className="cas-panel-heading compact"><div><p>Assumptions</p><h3>{state.mode} mode</h3></div></div>
              <textarea value={state.assumptions} onChange={(event) => onAssumptionsChange(event.target.value)} />
              <div className="cas-format-row">
                {(["exact", "numeric"] as EvaluationMode[]).map((mode) => <button key={mode} type="button" className={state.mode === mode ? "is-active" : ""} onClick={() => onModeChange(mode)}>{mode}</button>)}
              </div>
            </section>
            <section className="cas-inspector-card">
              <div className="cas-panel-heading compact"><div><p>Steps</p><h3>{selectedCell.steps.length || 0} transformations</h3></div></div>
              <ol className="cas-step-list">
                {(selectedCell.steps.length ? selectedCell.steps : ["Run the selected block to generate structured CAS steps."]).map((step, index) => <li key={`${selectedCell.id}-${index}`}><span>{index + 1}</span>{step}</li>)}
              </ol>
            </section>
            <section className="cas-inspector-card">
              <div className="cas-action-grid">
                <button type="button" onClick={() => navigator.clipboard?.writeText(selectedCell.exact ?? selectedCell.output ?? selectedCell.input)}><Copy className="h-4 w-4" />Copy result</button>
                <button type="button" onClick={() => onSendToGraph(selectedCell)}><LineChart className="h-4 w-4" />Plot in 2D</button>
                <button type="button" disabled title="3D plotting uses the separate Graph 3D route"><Box className="h-4 w-4" />Plot in 3D</button>
                <button type="button" onClick={onExport}><Download className="h-4 w-4" />Export</button>
                <button type="button" onClick={onRunAll}><CheckCircle2 className="h-4 w-4" />Verify all</button>
                <button type="button" disabled title="Spreadsheet insertion is available from the Spreadsheet route"><Braces className="h-4 w-4" />Spreadsheet</button>
              </div>
            </section>
            <section className="cas-ai-tutor">
              <p>AI Tutor</p>
              <strong>{selectedCell.ok ? "Verified CAS result is separate from this explanation." : "This cell needs an edit or a run."}</strong>
              <span>{selectedCell.ok ? "Try explaining why the selected transformation preserves equivalence, then verify by substitution." : "Check syntax, choose a supported operation, then rerun the block."}</span>
            </section>
          </>
        ) : (
          <EmptyPanel text="Add or select a CAS block to inspect exact results, steps, assumptions, and related actions." />
        )}
        <div className="cas-global-actions">
          <button type="button" onClick={onRunAll}><Play className="h-4 w-4" />Run all</button>
          <button type="button" onClick={onReset}><RotateCcw className="h-4 w-4" />Reset</button>
          <button type="button" onClick={onExport}><Download className="h-4 w-4" />Export notebook</button>
        </div>
        <pre className="cas-export-preview">{exportMarkdown}</pre>
      </aside>
    </div>
  );
}

// Retained while saved workspace payloads migrate to the symbolic-first studio.
void [LegacySpreadsheetPanel, LegacyCasDepthPanel, LegacyCasStudioWorkspace];

const CAS_OBJECT_COLORS = ["#7c3aed", "#2563eb", "#14b8a6", "#f97316", "#db2777", "#06b6d4", "#8b5cf6", "#16a34a"];

const CAS_DOCK_TOOLS: Array<{ label: string; operation?: NotebookOperation; route?: string; icon: LucideIcon }> = [
  { label: "Simplify", operation: "simplify", icon: Sparkles }, { label: "Factor", operation: "factor", icon: FunctionSquare },
  { label: "Expand", operation: "expand", icon: Maximize2 }, { label: "Solve", operation: "solve", icon: CheckCircle2 },
  { label: "Calculus", operation: "differentiate", icon: LineChart }, { label: "Matrices", operation: "matrix", icon: Grid3X3 },
  { label: "Units", operation: "simplify", icon: Ruler }, { label: "Statistics", route: "/workspace/data/analysis", icon: SlidersHorizontal },
  { label: "Regression", route: "/workspace/data/spreadsheet", icon: LineChart }, { label: "Inequalities", operation: "inequality", icon: Slash },
  { label: "Complex", operation: "complex-solve", icon: Circle }, { label: "Parametric", route: "/workspace/graph", icon: Move },
  { label: "Implicit", operation: "implicit-differentiate", icon: FunctionSquare }, { label: "Sliders", operation: "simplify", icon: SlidersHorizontal },
  { label: "Trace", route: "/workspace/graph", icon: MousePointer2 }, { label: "Table", route: "/workspace/data/spreadsheet", icon: Table2 },
  { label: "Animation", route: "/workspace/graph", icon: Play }, { label: "More", icon: MoreHorizontal },
];

function CasStudioWorkspaceV2(props: CasStudioWorkspaceProps) {
  const [chromeTheme,setChromeTheme]=useState<WorkspaceChromeTheme>(()=>readWorkspaceChromeTheme("math-universe-chrome-cas","light"));
  const {
    state, selectedCell, composerInput, composerOperation, onSelectCell, onUpdateCell, onRunCell, onAddCell,
    onDuplicateCell, onDeleteCell, onReorderCells, onReset, onModeChange, onAssumptionsChange,
    onComposerInputChange, onComposerOperationChange, onSendToGraph, onExport, onUndo, onRedo, onShare, shareControl,
  } = props;
  const navigate = useNavigate();
  const [workspaceQuery, setWorkspaceQuery] = useState("");
  const [workspaceTitle, setWorkspaceTitle] = useState("Untitled Workspace");
  const [mobilePanel, setMobilePanel] = useState<"canvas" | "objects" | "result">("canvas");
  const [leftPaneOpen, setLeftPaneOpen] = useState(false);
  const [rightPaneOpen, setRightPaneOpen] = useState(false);
  const [historyPaneOpen, setHistoryPaneOpen] = useState(false);
  const [inspectorTab, setInspectorTab] = useState<"result" | "steps" | "properties" | "assumptions" | "related">("result");
  const [displayMode, setDisplayMode] = useState<"2d" | "3d">("2d");
  const [graphTool, setGraphTool] = useState("select");
  const [graphView, setGraphView] = useState<FunctionGraphView>({ xMin: -5, xMax: 5, yMin: -5, yMax: 5 });
  const [traceX, setTraceX] = useState(1.4);
  const [keyboardOpen, setKeyboardOpen] = useState(true);
  const [inputMode, setInputMode] = useState<"math" | "natural">("math");
  const [statusMessage, setStatusMessage] = useState("Ready");
  const [graphPreviewOpen, setGraphPreviewOpen] = useState(false);
  const [speechState, setSpeechState] = useState<SpeechInputState>("idle");
  const [speechDraft, setSpeechDraft] = useState("");
  const [visibleObjects, setVisibleObjects] = useState<Record<string, boolean>>({});
  const [draggedCellId, setDraggedCellId] = useState<string | null>(null);
  const [angleMode, setAngleMode] = useState<"rad" | "deg">("rad");
  const [domainMode, setDomainMode] = useState<"real" | "complex">("real");
  const [precision, setPrecision] = useState(10);
  const [revealedStepCount, setRevealedStepCount] = useState(1);
  const graphHostRef = useRef<HTMLDivElement | null>(null);
  const scanInputRef = useRef<HTMLInputElement | null>(null);
  const speechRecognitionRef = useRef<BrowserSpeechRecognition | null>(null);
  const speechSupported = typeof window !== "undefined" && isBrowserSpeechInputSupported(window);
  const variableCount = state.cells.filter((cell) => /:=/.test(cell.input)).length;
  const functionCount = state.cells.filter((cell) => /x/i.test(cell.input) && !/=/.test(cell.input)).length;
  const selectedIndex = selectedCell ? state.cells.length - state.cells.findIndex((cell) => cell.id === selectedCell.id) : 0;

  useEffect(() => {
    setVisibleObjects((current) => Object.fromEntries(state.cells.map((cell) => [cell.id, current[cell.id] ?? true])));
  }, [state.cells]);

  useEffect(() => () => speechRecognitionRef.current?.abort(), []);

  useEffect(() => setRevealedStepCount(1), [selectedCell?.id]);

  const filteredCells = useMemo(() => {
    const query = workspaceQuery.trim().toLowerCase();
    return query ? state.cells.filter((cell) => `${cell.operation} ${cell.input} ${cell.output} ${cell.exact ?? ""}`.toLowerCase().includes(query)) : state.cells;
  }, [state.cells, workspaceQuery]);

  const graphSeries = useMemo<FunctionGraphSeries[]>(() => state.cells.flatMap((cell, index) => {
    if (visibleObjects[cell.id] === false) return [];
    const expression = casPlotExpression(cell);
    if (!expression) return [];
    const sampled = sampleFunction(expression, graphView.xMin, graphView.xMax, 420);
    if (sampled.error || !sampled.points.some((point) => point.valid)) return [];
    return [{ id: cell.id, label: cell.input, color: CAS_OBJECT_COLORS[index % CAS_OBJECT_COLORS.length], points: sampled.points, visible: true, style: cell.operation === "differentiate" || cell.operation === "tangent-line" ? "derivative" as const : "line" as const }];
  }).slice(0, 8), [graphView.xMax, graphView.xMin, state.cells, visibleObjects]);

  const selectedExpression = selectedCell ? casPlotExpression(selectedCell) : undefined;
  const featurePoints = useMemo(() => selectedExpression ? approximateRoots(selectedExpression, graphView.xMin, graphView.xMax).roots.map((x) => ({ x, y: 0, type: "root" as const })) : [], [graphView.xMax, graphView.xMin, selectedExpression]);
  const selectedRange = useMemo(() => {
    if (!selectedExpression) return null;
    const values = sampleFunction(selectedExpression, graphView.xMin, graphView.xMax, 180).points.map((point) => point.y).filter((value): value is number => typeof value === "number" && Number.isFinite(value));
    return values.length ? `${Math.min(...values).toFixed(2)} to ${Math.max(...values).toFixed(2)}` : null;
  }, [graphView.xMax, graphView.xMin, selectedExpression]);

  const runComposer = () => {
    if (!composerInput.trim()) return setStatusMessage("Enter an expression first");
    onAddCell(composerInput, composerOperation);
    setStatusMessage("Calculation completed");
    setInspectorTab("result");
  };
  const chooseOperation = (operation: NotebookOperation, seed?: string) => {
    onComposerOperationChange(operation);
    if (seed) onComposerInputChange(seed);
    else if (selectedCell) onComposerInputChange(selectedCell.input);
    setStatusMessage(`${operationOptions.find((item) => item.value === operation)?.label ?? operation} ready`);
  };
  const createSlider = () => {
    const assignment = selectedCell?.input.match(/^\s*([a-zA-Z])\s*:=\s*(-?\d+(?:\.\d+)?)\s*$/);
    const name = assignment?.[1] ?? "a";
    const value = Number(assignment?.[2] ?? 1);
    saveLinkedParameter({ name, value, min: -10, max: 10, step: 0.1, integer: false });
    chooseOperation("simplify", `${name} := ${value}`);
    setStatusMessage(`Linked slider ${name} created`);
  };
  const sendSelectedToSpreadsheet = () => {
    if (!selectedCell) return;
    const payload = createMathWorkspacePayload({ sourceWorkspace: "cas", objectType: "expression", label: selectedCell.input, value: selectedCell.exact ?? selectedCell.output ?? selectedCell.input, metadata: { operation: selectedCell.operation } });
    saveWorkspaceTransfer(payload, "spreadsheet");
    navigate("/workspace/data/spreadsheet", { state: { mathWorkspacePayload: payload } });
  };
  const sendSelectedToGraph3d = () => {
    if (!selectedCell) return;
    const payload = createMathWorkspacePayload({ sourceWorkspace: "cas", objectType: "surface", label: selectedCell.input, value: graphableExpressionFromCasCell(selectedCell), metadata: { operation: selectedCell.operation } });
    saveWorkspaceTransfer(payload, "graphs-3d");
    navigate("/math-lab/3d-graphing", { state: { mathWorkspacePayload: payload } });
  };
  const copySelectedFormat = async (format: "latex" | "mathml") => {
    if (!selectedCell) return;
    const value = selectedCell.exact ?? selectedCell.output ?? selectedCell.input;
    const content = format === "latex" ? value : `<math xmlns="http://www.w3.org/1998/Math/MathML"><mtext>${value.replace(/[<>&]/g, (character) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[character]!))}</mtext></math>`;
    await navigator.clipboard?.writeText(content);
    setStatusMessage(`${format === "latex" ? "LaTeX" : "MathML"} copied`);
  };
  const exportSelectedCalculation = () => {
    if (!selectedCell) return;
    const content = JSON.stringify({ version: 1, assumptions: state.assumptions, mode: state.mode, calculation: selectedCell }, null, 2);
    downloadCasArtifact(`cas-calculation-${selectedIndex}.json`, content, "application/json;charset=utf-8");
    setStatusMessage("Calculation exported");
  };
  const reorderCell = (targetId: string) => {
    if (!draggedCellId || draggedCellId === targetId) return;
    const ids = state.cells.map((cell) => cell.id);
    const from = ids.indexOf(draggedCellId);
    const to = ids.indexOf(targetId);
    if (from < 0 || to < 0) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    onReorderCells(ids);
    setDraggedCellId(null);
  };
  const startVoiceInput = () => {
    const Recognition = browserSpeechRecognitionConstructor(window);
    if (!Recognition) return;
    speechRecognitionRef.current?.abort();
    const recognition = new Recognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-IN";
    recognition.onresult = (event) => {
      setSpeechState("processing");
      setSpeechDraft(normalizeSpokenMath(event.results[0][0].transcript));
      setSpeechState("success");
    };
    recognition.onerror = (event) => {
      setSpeechState("error");
      setStatusMessage(event.error === "not-allowed" ? "Microphone permission was denied" : "Voice input could not be recognized");
    };
    recognition.onend = () => setSpeechState((current) => current === "listening" ? "idle" : current);
    speechRecognitionRef.current = recognition;
    setSpeechDraft("");
    setSpeechState("listening");
    recognition.start();
  };

  const moduleItems: Array<{ label: string; route?: string; icon: LucideIcon; current?: boolean; disabledReason?: string }> = [
    { label: "CAS", icon: Sigma, current: true }, { label: "Graph 2D", route: "/workspace/graph", icon: LineChart },
    { label: "Graph 3D", route: "/math-lab/3d-graphing", icon: Box }, { label: "Geometry", route: "/workspace/geometry", icon: Pentagon },
    { label: "Spreadsheet", route: "/workspace/data/spreadsheet", icon: Table2 }, { label: "Probability", route: "/math-lab/probability", icon: CircleDot },
  ];
  const graphTools: Array<{ id: string; label: string; icon: LucideIcon }> = [
    { id: "select", label: "Select", icon: MousePointer2 }, { id: "point", label: "Point", icon: CircleDot },
    { id: "line", label: "Line", icon: Slash }, { id: "function", label: "Function", icon: FunctionSquare },
    { id: "measure", label: "Measure", icon: Ruler }, { id: "transform", label: "Transform", icon: WandSparkles },
    { id: "more", label: "More", icon: MoreHorizontal },
  ];

  const toggleLeftPane = () => {
    setLeftPaneOpen((open) => !open);
    setMobilePanel((panel) => panel === "objects" ? "canvas" : "objects");
  };
  const toggleRightPane = () => {
    setRightPaneOpen((open) => !open);
    setMobilePanel((panel) => panel === "result" ? "canvas" : "result");
  };

  return <div data-chrome-theme={chromeTheme} className={`cas-studio-shell cas-studio-v2 mobile-panel-${mobilePanel} ${leftPaneOpen ? "is-left-pane-open" : ""} ${rightPaneOpen ? "is-right-pane-open" : ""} ${historyPaneOpen ? "is-history-pane-open" : ""}`} data-testid="workspace-cas-studio">
    <header className="cas-app-header">
      <div className="cas-brand"><span><Sigma /></span><strong>Computer Algebra Studio</strong></div>
      <input className="cas-workspace-title" value={workspaceTitle} onChange={(event) => setWorkspaceTitle(event.target.value)} aria-label="Workspace title" />
      <div className="cas-header-actions"><WorkspaceChromeThemeToggle theme={chromeTheme} storageKey="math-universe-chrome-cas" onChange={setChromeTheme}/>
        <button type="button" onClick={onUndo} aria-label="Undo" title="Undo"><Undo2 /></button><button type="button" onClick={onRedo} aria-label="Redo" title="Redo"><Redo2 /></button>
        <button type="button" className="cas-pane-toggle" onClick={toggleLeftPane} aria-expanded={leftPaneOpen || mobilePanel === "objects"} aria-controls="cas-object-explorer" title={leftPaneOpen ? "Collapse object explorer" : "Open object explorer"}>{leftPaneOpen ? <PanelLeftClose /> : <PanelLeftOpen />}<span>Objects</span></button>
        <button type="button" className="cas-pane-toggle" onClick={toggleRightPane} aria-expanded={rightPaneOpen || mobilePanel === "result"} aria-controls="cas-result-inspector" title={rightPaneOpen ? "Collapse result inspector" : "Open result inspector"}>{rightPaneOpen ? <PanelRightClose /> : <PanelRightOpen />}<span>Results</span></button>
        <button type="button" className="cas-pane-toggle cas-pane-toggle-history" onClick={() => setHistoryPaneOpen((open) => !open)} aria-expanded={historyPaneOpen} aria-controls="cas-history-workbench" title={historyPaneOpen ? "Collapse history and spreadsheet" : "Open history and spreadsheet"}><ChevronDown className={historyPaneOpen ? "" : "rotate-180"} /><span>History</span></button>
        <label className="cas-global-search"><Search /><input value={workspaceQuery} onChange={(event) => setWorkspaceQuery(event.target.value)} placeholder="Search" /></label>
        {shareControl ?? (
          <button type="button" onClick={() => { void onShare(); setStatusMessage("Share link copied"); }}><Share2 /><span>Share</span></button>
        )}
        <button type="button" onClick={onExport}><Download /><span>Export</span></button>
        <button type="button" onClick={() => { setInspectorTab("assumptions"); setRightPaneOpen(true); setMobilePanel("result"); }} aria-label="Settings"><Settings /></button>
        <button type="button" className="cas-avatar" onClick={() => setStatusMessage("Signed in workspace profile")} aria-label="User profile"><User /></button>
        <button type="button" className="cas-mobile-menu" onClick={() => { setLeftPaneOpen(true); setMobilePanel("objects"); }} aria-label="Open objects"><Menu /></button>
      </div>
    </header>

    <nav className="cas-studio-modebar" aria-label="Math workspace modules">{moduleItems.map((item) => { const Icon = item.icon; return <button key={item.label} type="button" className={item.current ? "is-active" : item.disabledReason ? "is-disabled" : ""} disabled={Boolean(item.disabledReason)} title={item.disabledReason} onClick={() => item.route && navigate(item.route)}><Icon />{item.label}</button>; })}</nav>

    <aside id="cas-object-explorer" className="cas-studio-left" aria-label="CAS object explorer">
      <button type="button" className="cas-mobile-sheet-close" onClick={() => { setLeftPaneOpen(false); setMobilePanel("canvas"); }}><X />Close objects</button>
      <div className="cas-panel-heading"><div><p>Object explorer</p><h3>{state.cells.length} objects</h3></div><button type="button" onClick={() => onAddCell()} title="Add object" aria-label="Add object"><Plus /></button></div>
      <label className="cas-search"><Search /><input value={workspaceQuery} placeholder="Search objects" onChange={(event) => setWorkspaceQuery(event.target.value)} /><button type="button" onClick={() => setWorkspaceQuery("")} aria-label="Clear filter"><Filter /></button></label>
      <div className="cas-object-list" role="list" aria-label="CAS objects">{filteredCells.map((cell) => {
        const active = selectedCell?.id === cell.id;
        const index = state.cells.findIndex((item) => item.id === cell.id);
        return <div key={cell.id} className={`cas-object-row ${active ? "is-active" : ""}`} role="listitem" draggable onDragStart={() => setDraggedCellId(cell.id)} onDragOver={(event) => event.preventDefault()} onDrop={() => reorderCell(cell.id)}>
          <button type="button" className="cas-object-main" onClick={() => { onSelectCell(cell.id); setMobilePanel("canvas"); }}><span className="cas-object-badge" style={{ background: CAS_OBJECT_COLORS[index % CAS_OBJECT_COLORS.length] }}>{state.cells.length - index}</span><FunctionSquare className="cas-object-type" /><span className="cas-object-copy"><strong>{cell.input || "Empty calculation"}</strong><small>{cell.exact ?? cell.output ?? operationOptions.find((item) => item.value === cell.operation)?.label}</small></span></button>
          <button type="button" className="cas-object-icon" onClick={() => setVisibleObjects((current) => ({ ...current, [cell.id]: current[cell.id] === false }))} aria-label={`${visibleObjects[cell.id] === false ? "Show" : "Hide"} ${cell.input}`}>{visibleObjects[cell.id] === false ? <EyeOff /> : <Eye />}</button>
          <details className="cas-object-menu"><summary aria-label="Object actions"><MoreHorizontal /></summary><div><button type="button" onClick={() => onDuplicateCell(cell)}>Duplicate</button><button type="button" onClick={() => onSendToGraph(cell)}>Open in Graph 2D</button><button type="button" onClick={() => onDeleteCell(cell.id)}>Delete</button></div></details>
        </div>;
      })}{!filteredCells.length && <div className="cas-empty-result">No objects match this search.</div>}</div>
      <div className="cas-section-list">{[["Variables", variableCount], ["Functions", functionCount], ["Equations", state.cells.filter((cell) => /=/.test(cell.input) && !/:=/.test(cell.input)).length], ["Matrices", state.cells.filter((cell) => cell.operation === "matrix").length], ["Lists", state.cells.filter((cell) => cell.operation === "list").length], ["Saved objects", state.cells.length]].map(([label, value]) => <details key={label as string}><summary><span>{label}</span><strong>{value}</strong></summary><small>{value ? `${value} linked object${value === 1 ? "" : "s"}` : "No objects yet"}</small></details>)}</div>
    </aside>

    <main className="cas-studio-center">
      <section className="cas-notebook-workspace" aria-label="CAS notebook calculations">
        <header className="cas-notebook-toolbar"><div><strong>Symbolic notebook</strong><span>{state.cells.length} calculation{state.cells.length === 1 ? "" : "s"}</span></div><div><button type="button" onClick={() => onAddCell()}><Plus />New</button><button type="button" onClick={() => setGraphPreviewOpen((value) => !value)} aria-expanded={graphPreviewOpen}><LineChart />{graphPreviewOpen ? "Close preview" : "Graph preview"}</button></div></header>
      <div className="cas-notebook-scroll">{state.cells.map((cell, index) => <CasStudioNotebookBlock key={cell.id} cell={cell} index={state.cells.length - index} active={selectedCell?.id === cell.id} onSelect={() => onSelectCell(cell.id)} onRun={() => onRunCell(cell.id)} onChange={(patch) => onUpdateCell(cell.id, patch)} onDuplicate={() => onDuplicateCell(cell)} onDelete={() => onDeleteCell(cell.id)} onSendToGraph={() => onSendToGraph(cell)} onUseResult={() => onComposerInputChange(cell.exact ?? cell.output ?? cell.input)} />)}</div>
      </section>
      {graphPreviewOpen && <section className="cas-graph-workspace cas-graph-preview" ref={graphHostRef} aria-label="CAS graph preview">
        <div className="cas-graph-topbar"><div className="cas-segmented"><button type="button" className={displayMode === "2d" ? "is-active" : ""} onClick={() => setDisplayMode("2d")}>2D</button><button type="button" className={displayMode === "3d" ? "is-active" : ""} onClick={() => setDisplayMode("3d")}>3D</button></div><div className="cas-graph-legend">{graphSeries.slice(0, 3).map((series) => <button type="button" key={series.id} onClick={() => onSelectCell(series.id)}><span style={{ background: series.color }} />{series.label}</button>)}</div></div>
        <div className="cas-graph-tools">{graphTools.map((tool) => { const Icon = tool.icon; return <button key={tool.id} type="button" className={graphTool === tool.id ? "is-active" : ""} onClick={() => { setGraphTool(tool.id); setStatusMessage(`${tool.label} tool selected`); }} title={tool.label}><Icon /><span>{tool.label}</span></button>; })}</div>
        <div className="cas-graph-actions"><button type="button" onClick={() => setGraphPreviewOpen(false)} aria-label="Close graph preview"><X /></button><button type="button" onClick={() => setGraphView((view) => zoomCasGraph(view, .78))} aria-label="Zoom in"><ZoomIn /></button><button type="button" onClick={() => setGraphView((view) => zoomCasGraph(view, 1.28))} aria-label="Zoom out"><ZoomOut /></button><button type="button" onClick={() => setGraphView({ xMin: -5, xMax: 5, yMin: -5, yMax: 5 })} aria-label="Reset graph view"><Home /></button><button type="button" onClick={() => setStatusMessage(`Grid x ${graphView.xMin.toFixed(1)} to ${graphView.xMax.toFixed(1)}`)} aria-label="Graph settings"><Settings /></button><button type="button" onClick={() => void graphHostRef.current?.requestFullscreen?.()} aria-label="Fullscreen graph"><Maximize2 /></button></div>
        <div className="cas-graph-canvas">{displayMode === "2d" ? <FunctionGraphCanvas series={graphSeries} view={graphView} selectedSeriesId={selectedCell?.id} traceX={traceX} onTraceChange={setTraceX} onViewChange={setGraphView} featurePoints={featurePoints} /> : <button type="button" className="cas-3d-preview" onClick={() => navigate("/math-lab/3d-graphing")}><Box /><strong>Open the selected expression in Graph 3D</strong><span>Use the spatial workspace for surfaces and solids.</span></button>}</div>
        <div className="cas-graph-status"><span>{graphSeries.length} visible object{graphSeries.length === 1 ? "" : "s"}</span><span>Pointer x = {traceX.toFixed(2)}</span><strong>{statusMessage}</strong></div>
      </section>}
      <section className="cas-composer"><div className="cas-composer-input">
        <select value={composerOperation} onChange={(event) => onComposerOperationChange(event.target.value as NotebookOperation)} aria-label="CAS operation">{operationOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select>
        <div className="cas-expression-field"><textarea value={composerInput} onChange={(event) => onComposerInputChange(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); runComposer(); } }} placeholder="Enter an expression, equation, matrix, or natural-language prompt" /><div className="cas-input-mode"><button type="button" className={inputMode === "math" ? "is-active" : ""} onClick={() => setInputMode("math")}>Math</button><button type="button" className={inputMode === "natural" ? "is-active" : ""} onClick={() => setInputMode("natural")}>Natural language</button></div></div>
        <div className="cas-composer-tools"><button type="button" title={speechSupported ? "Start voice input" : "Voice input is not supported in this browser."} disabled={!speechSupported} className={speechState === "listening" ? "is-active" : ""} onClick={startVoiceInput} aria-label={speechState === "listening" ? "Listening for mathematical input" : "Start voice input"}><Mic /></button><button type="button" title="Equation scanning is unavailable because no OCR engine is installed." disabled aria-label="Equation scanning unavailable"><Camera /></button><input ref={scanInputRef} hidden type="file" accept="image/*" /><button type="button" title="Toggle keyboard" className={keyboardOpen ? "is-active" : ""} onClick={() => setKeyboardOpen((value) => !value)}><Keyboard /></button><button type="button" className="primary" onClick={runComposer}><Play />Run</button></div>
      </div>{speechState === "listening" && <div className="cas-speech-review" role="status"><span>Listening...</span><button type="button" onClick={() => { speechRecognitionRef.current?.abort(); setSpeechState("idle"); }}>Cancel</button></div>}{speechDraft && <div className="cas-speech-review" role="status"><label>Recognized math<input value={speechDraft} onChange={(event) => setSpeechDraft(event.target.value)} /></label><button type="button" onClick={() => { onComposerInputChange(speechDraft); setSpeechDraft(""); setSpeechState("idle"); }}>Use input</button><button type="button" onClick={() => { setSpeechDraft(""); setSpeechState("idle"); }}>Discard</button></div>}{keyboardOpen && <div className="cas-keyboard">{["x", "y", "pi", "e", "sqrt()", "cbrt()", "^", "abs()", "log", "ln", "sin", "cos", "tan", "Integral[]", "d/dx", "Sum[]", "infinity", "->", "alpha", "Omega", "..."].map((key) => <button key={key} type="button" onClick={() => onComposerInputChange(`${composerInput}${key}`)}>{key}</button>)}</div>}</section>
    </main>

    <aside id="cas-result-inspector" className="cas-studio-right" aria-label="CAS result inspector"><button type="button" className="cas-mobile-sheet-close" onClick={() => { setRightPaneOpen(false); setMobilePanel("canvas"); }}><X />Close inspector</button>
      <div className="cas-inspector-tabs" role="tablist">{(["result", "steps", "properties", "assumptions", "related"] as const).map((tab) => <button key={tab} type="button" role="tab" aria-selected={inspectorTab === tab} className={inspectorTab === tab ? "is-active" : ""} onClick={() => setInspectorTab(tab)}>{tab[0].toUpperCase() + tab.slice(1)}</button>)}</div>
      {selectedCell ? <div className="cas-inspector-scroll">
        {inspectorTab === "result" && <><section className="cas-inspector-card"><div className="cas-panel-heading compact"><div><p>Exact solution</p><h3>In [{selectedIndex}]</h3></div>{selectedCell.ok ? <CheckCircle2 /> : <AlertTriangle />}</div><div className="cas-result-box"><MathExpression value={selectedCell.exact ?? selectedCell.output ?? "Run this object"} /><button type="button" onClick={() => void navigator.clipboard?.writeText(selectedCell.exact ?? selectedCell.output ?? selectedCell.input)} aria-label="Copy exact result"><Copy /></button></div>{selectedCell.numeric && <><p>Decimal approximation</p><div className="cas-result-box muted"><MathExpression value={selectedCell.numeric} /><button type="button" onClick={() => void navigator.clipboard?.writeText(selectedCell.numeric!)} aria-label="Copy decimal result"><Copy /></button></div></>}<p>{selectedCell.detail}</p></section><section className="cas-inspector-card"><div className="cas-panel-heading compact"><div><p>Domain and assumptions</p><h3>{domainMode === "real" ? "Real domain" : "Complex domain"}</h3></div><Info /></div><p>{state.assumptions || "No variable assumptions"}</p></section><section className="cas-action-grid"><button type="button" onClick={() => setInspectorTab("steps")}><Sparkles />Explain</button><button type="button" onClick={() => onRunCell(selectedCell.id)}><CheckCircle2 />Verify</button><button type="button" onClick={() => chooseOperation("simplify", selectedCell.input)}><RotateCcw />Alternative</button><button type="button" onClick={createSlider}><SlidersHorizontal />Create slider</button></section></>}
        {inspectorTab === "steps" && <section className="cas-inspector-card cas-steps-card"><div className="cas-panel-heading compact"><div><p>Steps</p><h3>{selectedCell.structuredSteps?.length ?? selectedCell.steps.length} transformations</h3></div></div><ol className="cas-step-list">{(selectedCell.structuredSteps?.slice(0, revealedStepCount) ?? []).map((step, index) => <li key={step.id}><span>{index + 1}</span><div><strong>{step.rule}</strong><MathExpression value={step.result} /><small>{step.explanation}</small>{step.changedTerms.length > 0 && <small>Changed: {step.changedTerms.join(", ")}</small>}{index === (selectedCell.structuredSteps?.length ?? 0) - 1 && selectedCell.ok && <small><Check />{step.verification}</small>}</div></li>)}</ol>{!selectedCell.structuredSteps?.length && <div className="cas-empty-result">Run the selected object to generate solver-backed transformations.</div>}<div className="cas-action-grid"><button type="button" disabled={revealedStepCount >= (selectedCell.structuredSteps?.length ?? 0)} onClick={() => setRevealedStepCount((count) => count + 1)}><Sparkles />Next step</button><button type="button" onClick={() => setRevealedStepCount(selectedCell.structuredSteps?.length ?? 0)}><ListTree />Show all</button><button type="button" onClick={() => onRunCell(selectedCell.id)}><CheckCircle2 />Verify</button><button type="button" onClick={() => chooseOperation("factor", selectedCell.input)}><WandSparkles />Alternative</button></div></section>}
        {inspectorTab === "properties" && <section className="cas-inspector-card cas-property-list"><div className="cas-panel-heading compact"><div><p>Object properties</p><h3>{operationOptions.find((item) => item.value === selectedCell.operation)?.label}</h3></div></div><dl><div><dt>Expression</dt><dd>{selectedCell.input}</dd></div><div><dt>Status</dt><dd>{selectedCell.ok ? "Verified" : "Needs attention"}</dd></div><div><dt>Visible range</dt><dd>{selectedRange ?? "Not graphable"}</dd></div><div><dt>Dependencies</dt><dd>{selectedCell.dependencies?.join(", ") || "None"}</dd></div><div><dt>Created</dt><dd>{selectedCell.createdAt}</dd></div></dl><div className="cas-action-grid"><button type="button" onClick={() => setVisibleObjects((current) => ({ ...current, [selectedCell.id]: current[selectedCell.id] === false }))}>{visibleObjects[selectedCell.id] === false ? <Eye /> : <EyeOff />}Visibility</button><button type="button" onClick={() => onSendToGraph(selectedCell)}><LineChart />Graph 2D</button><button type="button" onClick={() => onDuplicateCell(selectedCell)}><Copy />Duplicate</button><button type="button" onClick={() => onDeleteCell(selectedCell.id)}><Trash2 />Delete</button><button type="button" onClick={() => void copySelectedFormat("latex")}><Copy />Copy LaTeX</button><button type="button" onClick={() => void copySelectedFormat("mathml")}><Braces />Copy MathML</button><button type="button" onClick={exportSelectedCalculation}><Download />Export calculation</button></div></section>}
        {inspectorTab === "assumptions" && <section className="cas-inspector-card cas-assumptions-panel"><div className="cas-panel-heading compact"><div><p>Evaluation context</p><h3>Assumptions</h3></div></div><label>Variables<textarea value={state.assumptions} onChange={(event) => onAssumptionsChange(event.target.value)} /></label><label>Evaluation mode<div className="cas-format-row">{(["exact", "numeric"] as EvaluationMode[]).map((mode) => <button key={mode} type="button" className={state.mode === mode ? "is-active" : ""} onClick={() => onModeChange(mode)}>{mode}</button>)}</div></label><label>Domain<div className="cas-format-row">{(["real", "complex"] as const).map((mode) => <button key={mode} type="button" className={domainMode === mode ? "is-active" : ""} onClick={() => { setDomainMode(mode); onAssumptionsChange(`${state.assumptions.replace(/\b(real|complex)\b/g, "").trim()} ${mode}`.trim()); }}>{mode}</button>)}</div></label><label>Angle mode<div className="cas-format-row">{(["rad", "deg"] as const).map((mode) => <button key={mode} type="button" className={angleMode === mode ? "is-active" : ""} onClick={() => setAngleMode(mode)}>{mode === "rad" ? "Radians" : "Degrees"}</button>)}</div></label><label>Precision<input type="number" min="3" max="16" value={precision} onChange={(event) => setPrecision(Number(event.target.value))} /></label></section>}
        {inspectorTab === "related" && <section className="cas-inspector-card"><div className="cas-panel-heading compact"><div><p>Related operations</p><h3>Explore this object</h3></div></div><div className="cas-related-grid">{(["simplify", "factor", "expand", "solve", "differentiate", "integrate", "limit", "tangent-line"] as NotebookOperation[]).map((operation) => <button key={operation} type="button" onClick={() => chooseOperation(operation, selectedCell.input)}>{operationOptions.find((item) => item.value === operation)?.label}</button>)}</div><div className="cas-action-grid"><button type="button" onClick={() => onSendToGraph(selectedCell)}><LineChart />Graph 2D</button><button type="button" onClick={sendSelectedToGraph3d}><Orbit />Graph 3D</button><button type="button" onClick={sendSelectedToSpreadsheet}><Table2 />Spreadsheet</button></div></section>}
        <section className="cas-ai-tutor"><p><Sparkles />AI Tutor</p><strong>{selectedCell.ok ? `${operationOptions.find((item) => item.value === selectedCell.operation)?.label} completed successfully.` : "This object needs an edit or recalculation."}</strong><span>{selectedCell.warnings?.[0] ?? (selectedCell.ok ? `Review ${selectedCell.steps.length} solver step${selectedCell.steps.length === 1 ? "" : "s"}, then verify by substitution.` : "Check the expression syntax and selected operation before running it again.")}</span></section>
      </div> : <EmptyPanel text="Add or select a CAS object to inspect its result." />}
    </aside>

    <section id="cas-history-workbench" className="cas-history-workbench"><div className="cas-history-pane"><header><strong>History</strong><span>{state.cells.length} calculations</span><button type="button" onClick={onReset} title="Clear history"><Trash2 /></button></header><div>{state.cells.slice(0, 6).map((cell) => <button key={cell.id} type="button" onClick={() => { onSelectCell(cell.id); onComposerInputChange(cell.input); onComposerOperationChange(cell.operation); }}><FunctionSquare /><span><strong>{cell.input}</strong><small>{cell.createdAt}</small></span>{cell.ok ? <CheckCircle2 /> : <AlertTriangle />}</button>)}</div></div><div className="cas-sheet-preview"><header><strong>Spreadsheet</strong><span>{Math.min(4, state.cells.length)} x 3</span><button type="button" onClick={() => navigate("/workspace/data/spreadsheet")}>Open</button></header><table><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr></thead><tbody>{state.cells.slice(0, 4).map((cell, index) => <tr key={cell.id}><th>{index + 1}</th><td>{cell.operation}</td><td>{cell.input}</td><td>{cell.exact ?? cell.output}</td></tr>)}</tbody></table></div></section>

    <nav className="cas-tool-dock" aria-label="CAS mathematical tools"><div className="cas-tool-scroll">{CAS_DOCK_TOOLS.map((tool) => { const Icon = tool.icon; return <button key={tool.label} type="button" onClick={() => tool.route ? navigate(tool.route) : tool.operation ? chooseOperation(tool.operation) : setKeyboardOpen((value) => !value)}><Icon /><span>{tool.label}</span></button>; })}</div><div className="cas-global-controls"><button type="button" onClick={() => onModeChange(state.mode === "exact" ? "numeric" : "exact")}><span className="cas-status-dot" />{state.mode === "exact" ? "Exact" : "Numeric"}</button><button type="button" onClick={() => setAngleMode((mode) => mode === "rad" ? "deg" : "rad")}>{angleMode === "rad" ? "Radians" : "Degrees"}</button><button type="button" onClick={() => setDomainMode((mode) => mode === "real" ? "complex" : "real")}>{domainMode === "real" ? "Real" : "Complex"}</button><button type="button" onClick={() => setKeyboardOpen((value) => !value)} aria-label="Toggle keyboard"><Keyboard /></button></div></nav>
    <nav className="cas-mobile-panels"><button type="button" className={mobilePanel === "objects" ? "is-active" : ""} onClick={() => { setLeftPaneOpen(true); setMobilePanel("objects"); }}><ListTree />Objects</button><button type="button" className={mobilePanel === "canvas" ? "is-active" : ""} onClick={() => { setLeftPaneOpen(false); setRightPaneOpen(false); setMobilePanel("canvas"); }}><Sigma />Notebook</button><button type="button" className={mobilePanel === "result" ? "is-active" : ""} onClick={() => { setRightPaneOpen(true); setMobilePanel("result"); }}><CheckCircle2 />Result</button></nav>
  </div>;
}

function casPlotExpression(cell: NotebookCell) {
  const functionDefinition = cell.input.match(/^\s*[a-z]\w*\s*\(\s*x\s*\)\s*:?=\s*(.+)$/i);
  if (functionDefinition) return functionDefinition[1].trim();
  const tangent = (cell.exact ?? cell.output).match(/y\s*=\s*(.+)$/i);
  if (tangent) return tangent[1].trim();
  const source = cell.input.replace(/^Solve\[/i, "").replace(/,\s*x\s*\]$/i, "").trim();
  if (!/\bx\b/i.test(source) || /[;[\]]/.test(source)) return undefined;
  const equality = source.match(/^(.+?)=(.+)$/);
  return equality ? `(${equality[1]})-(${equality[2]})` : source;
}

function zoomCasGraph(view: FunctionGraphView, factor: number): FunctionGraphView {
  const centerX = (view.xMin + view.xMax) / 2;
  const centerY = (view.yMin + view.yMax) / 2;
  const halfWidth = (view.xMax - view.xMin) * factor / 2;
  const halfHeight = (view.yMax - view.yMin) * factor / 2;
  return { xMin: centerX - halfWidth, xMax: centerX + halfWidth, yMin: centerY - halfHeight, yMax: centerY + halfHeight };
}

function CasStudioNotebookBlock({ cell, index, active, onSelect, onRun, onChange, onDuplicate, onDelete, onSendToGraph, onUseResult }: {
  cell: NotebookCell;
  index: number;
  active: boolean;
  onSelect: () => void;
  onRun: () => void;
  onChange: (patch: Partial<NotebookCell>) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onSendToGraph: () => void;
  onUseResult: () => void;
}) {
  const [stepsOpen, setStepsOpen] = useState(index <= 2);
  return (
    <article className={`cas-notebook-block ${active ? "is-active" : ""}`} onFocus={onSelect} onClick={onSelect}>
      <div className="cas-block-header">
        <span>In [{index}]</span>
        <select aria-label={`Operation for calculation ${index}`} value={cell.operation} onChange={(event) => onChange({ operation: event.target.value as NotebookOperation })}>
          {operationOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
        </select>
        <div>
          <button type="button" onClick={onRun} title="Recalculate"><Play className="h-4 w-4" /></button>
          <button type="button" onClick={onDuplicate} title="Duplicate"><Copy className="h-4 w-4" /></button>
          <button type="button" onClick={onSendToGraph} title="Send to Graph 2D"><LineChart className="h-4 w-4" /></button>
          <button type="button" onClick={onDelete} title="Delete"><Trash2 className="h-4 w-4" /></button>
        </div>
      </div>
      <textarea value={cell.input} onChange={(event) => onChange({ input: event.target.value })} aria-label={`CAS input ${index}`} placeholder="Factor[x^3 - 3*x^2 - 4*x + 12]" />
      {cell.output ? (
        <div className="cas-block-output">
          <div className="cas-block-result">
            <p>Exact result</p>
            <strong><MathExpression value={cell.exact ?? cell.output} /></strong>
          </div>
          {cell.numeric && <div className="cas-block-result muted"><p>Decimal approximation</p><strong><MathExpression value={cell.numeric} /></strong></div>}
          {!!cell.warnings?.length && <div className="cas-warning"><AlertTriangle className="h-4 w-4" />{cell.warnings.join(" ")}</div>}
          <div className="cas-block-actions">
            <button type="button" onClick={() => setStepsOpen((value) => !value)}>{stepsOpen ? "Hide steps" : "Show steps"}</button>
            <button type="button" onClick={onUseResult}>Use result</button>
            <button type="button" onClick={onSendToGraph}>Plot in 2D</button>
          </div>
          {stepsOpen && (
            <ol className="cas-step-list">
              {cell.steps.map((step, stepIndex) => <li key={`${cell.id}-block-step-${stepIndex}`}><span>{stepIndex + 1}</span>{step}</li>)}
            </ol>
          )}
        </div>
      ) : (
        <div className="cas-empty-result">Run this block to generate exact result, decimal check, assumptions, warnings, and steps.</div>
      )}
    </article>
  );
}

function CasSummaryRow({ label, value }: { label: string; value: number }) {
  return <div className="cas-summary-row"><span>{label}</span><strong>{value}</strong></div>;
}

function createDefaultCasNotebookState(): NotebookState {
  const assumptions = "x real";
  const mode: EvaluationMode = "exact";
  const cells = starterNotebookCells.map((cell) => ({ ...cell, id: crypto.randomUUID() }));
  return {
    cells: evaluateNotebookCells(cells, assumptions, mode),
    assumptions,
    mode,
  };
}

function downloadCasArtifact(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function graphableExpressionFromCasCell(cell: NotebookCell) {
  const candidate = cell.exact || cell.output || cell.input;
  const equationMatch = candidate.match(/y\s*=\s*(.+)$/i);
  if (equationMatch) return equationMatch[1].trim();
  const solveInput = cell.input.match(/Solve\[(.+?)(?:,\s*x)?\]$/i);
  if (solveInput) return stripInequality(solveInput[1].replace(/=.+$/, ""));
  return stripInequality(candidate.replace(/^[a-z]\s*:=\s*/i, "").replace(/^x\s*=\s*/i, ""));
}

function _HighPriorityWorkflowBar({ selectedType, styleControls, protocolPlan, slider, snapCandidates, imageWorkflow, exportPresets, tablet, onAddImage, onPauseAnimation, onPlayAnimation }: { selectedType: WorkflowObjectType; styleControls: StyleBarControl[]; protocolPlan: ProtocolPlaybackPlan; slider: SliderObject; snapCandidates: (SnapCandidate & { distance: number })[]; imageWorkflow: ImageWorkflowSpec; exportPresets: ExportPreset[]; tablet: TabletControlSpec; onAddImage: () => void; onPauseAnimation: () => void; onPlayAnimation: () => void }) {
  return (
    <div className="rounded-2xl border border-cyan-200 bg-cyan-50/70 p-4 dark:border-cyan-300/20 dark:bg-cyan-400/10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-bold">High Priority Workflow Layer</h3>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Contextual style bar, protocol replay, sliders, snapping, image workflow, export presets, offline library, and tablet controls are tracked as one production workflow.</p>
        </div>
        <span className="mini-chip">{selectedType} selected</span>
      </div>
      <div className="mt-3 grid gap-3 xl:grid-cols-4">
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Style Bar</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {styleControls.map((control) => <span key={control} className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-bold dark:bg-white/10">{control}</span>)}
          </div>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Protocol</p>
          <p className="mt-2 text-sm font-bold">{protocolPlan.steps.length} steps, cursor {protocolPlan.cursor + 1}</p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{protocolPlan.canReorder ? "Dependency-safe reorder available" : protocolPlan.blockedReorders[0] ?? "Replay ready"}</p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Columns: {protocolPlan.columns.join(", ")}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Global Slider</p>
          <p className="mt-2 text-sm font-bold">{slider.name} = {roundTo(slider.value, 2)} ({slider.playing ? "playing" : "paused"})</p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Bound: {slider.boundObjects.join(", ") || "none"}</p>
          <div className="mt-2 flex gap-2">
            <button type="button" onClick={onPlayAnimation} className="rounded-full bg-slate-950 px-3 py-1 text-xs font-bold text-white dark:bg-white dark:text-slate-950">Play</button>
            <button type="button" onClick={onPauseAnimation} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold dark:bg-white/10">Pause</button>
          </div>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Snap Preview</p>
          <p className="mt-2 text-sm font-bold">{snapCandidates[0]?.label ?? "Grid"} priority {snapCandidates[0]?.priority ?? 0}</p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Touch handle {tablet.touchHandleSize}px, long press {tablet.longPressContextMenuMs}ms</p>
        </div>
      </div>
      <div className="mt-3 grid gap-3 xl:grid-cols-3">
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Images</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">{imageWorkflow.actions.join(", ")}</p>
          <button type="button" onClick={onAddImage} className="action-secondary mt-2 py-2">Add image</button>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Export Quality</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">{exportPresets.map((preset) => preset.label).join(", ")}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-cyan-700 dark:text-cyan-200">Right-Click Menu</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">{contextMenuForObject(selectedType).join(", ")}</p>
        </div>
      </div>
    </div>
  );
}

function AlgebraObjectsPanel({ objects, selected, protocol, graph, graphHealth, commandSummary, onSelect, onRename, onEditDefinition, onPatch, onDuplicate, onDelete, onReplay, onContextMenu }: { objects: AlgebraObjectRow[]; selected: AlgebraObjectRef | null; protocol: ConstructionStep[]; graph: DynamicObjectGraph; graphHealth: ReturnType<typeof graphHealthSummary>; commandSummary: ReturnType<typeof commandRegistrySummary>; onSelect: (ref: AlgebraObjectRef) => void; onRename: (ref: AlgebraObjectRef, name: string) => void; onEditDefinition: (ref: AlgebraObjectRef, definition: string) => void; onPatch: (ref: AlgebraObjectRef, patch: { visible?: boolean; locked?: boolean; trace?: boolean }) => void; onDuplicate: (ref: AlgebraObjectRef) => void; onDelete: (ref: AlgebraObjectRef) => void; onReplay: (step: ConstructionStep) => void; onContextMenu: (event: ReactMouseEvent, ref: AlgebraObjectRef) => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-bold">Unified Algebra And Object Panel</h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Edit definitions once and see graph, geometry, 3D, inspector, and protocol stay linked.</p>
        </div>
        <span className="mini-chip">{objects.length} objects</span>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-4">
        <KernelMetric label="Kernel" value={graphHealth.ready ? "Ready" : "Needs fix"} tone={graphHealth.ready ? "good" : "bad"} />
        <KernelMetric label="Dynamic links" value={`${graphHealth.dynamic}`} />
        <KernelMetric label="Dirty chain" value={`${graphHealth.dirty}`} />
        <KernelMetric label="Commands" value={`${commandSummary.implemented}/${commandSummary.total}`} />
      </div>
      <p className="mt-3 rounded-xl bg-slate-100 p-3 text-sm leading-6 text-slate-600 dark:bg-white/10 dark:text-slate-300">{graphHealth.text}</p>
      {(graph.cycles.length > 0 || graph.missingDependencies.length > 0) && (
        <div className="mt-3 rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-400/30 dark:bg-amber-400/10 dark:text-amber-100">
          {graph.cycles.map((cycle) => <p key={cycle.join("-")}>Circular dependency: {cycle.join(" -> ")}</p>)}
          {graph.missingDependencies.map((item) => <p key={`${item.object}-${item.dependency}`}>{item.object} needs missing object {item.dependency}</p>)}
        </div>
      )}
      <div className="mt-4 grid gap-2 md:grid-cols-3">
        {Object.entries(commandSummary.byGroup).slice(0, 6).map(([group, item]) => (
          <div key={group} className="rounded-xl bg-slate-100 p-3 text-xs dark:bg-white/10">
            <p className="font-bold">{group}</p>
            <p className="mt-1 text-slate-500 dark:text-slate-400">{item.implemented} live, {item.total - item.implemented} planned</p>
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="max-h-[520px] space-y-2 overflow-y-auto pr-1">
          {objects.length === 0 ? <p className="rounded-xl bg-slate-100 p-3 text-sm dark:bg-white/10">Create a graph, point, line, circle, polygon, or 3D object to see it here.</p> : objects.map((object) => (
            <div key={`${object.ref.kind}-${object.ref.id}`} onContextMenu={(event) => onContextMenu(event, object.ref)} className={`rounded-xl border p-3 ${sameRef(selected, object.ref) ? "border-cyan-400 bg-cyan-50 dark:bg-cyan-400/10" : "border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-slate-900/50"}`}>
              <div className="grid gap-2 lg:grid-cols-[150px_minmax(0,1fr)]">
                <label className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                  Name
                  <input value={object.name} onFocus={() => onSelect(object.ref)} onChange={(event) => onRename(object.ref, event.target.value)} className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 text-sm normal-case dark:border-white/10 dark:bg-slate-950" />
                </label>
                <label className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                  Definition
                  <input defaultValue={object.definition} onFocus={() => onSelect(object.ref)} onBlur={(event) => onEditDefinition(object.ref, event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); }} className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 font-mono text-sm normal-case dark:border-white/10 dark:bg-slate-950" />
                </label>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <button type="button" onClick={() => onSelect(object.ref)} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-slate-950">Select</button>
                <button type="button" onClick={() => onPatch(object.ref, { visible: !object.visible })} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-slate-950">{object.visible ? "Hide" : "Show"}</button>
                <button type="button" onClick={() => onPatch(object.ref, { locked: !object.locked })} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-slate-950">{object.locked ? "Unlock" : "Lock"}</button>
                <button type="button" onClick={() => onPatch(object.ref, { trace: !object.trace })} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-slate-950">{object.trace ? "Trace on" : "Trace"}</button>
                <button type="button" onClick={() => onDuplicate(object.ref)} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-slate-950">Duplicate</button>
                <button type="button" onClick={() => onDelete(object.ref)} className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">Delete</button>
                <span className="mini-chip">{object.ref.kind}</span>
              </div>
              <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">Depends on: {object.dependencies.length ? object.dependencies.join(", ") : "none"}</p>
            </div>
          ))}
        </div>
        <div className="rounded-2xl bg-slate-100 p-3 dark:bg-white/10">
          <h4 className="font-bold">Construction Protocol</h4>
          <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">Replay any creation/edit step to inspect how the workspace was built.</p>
          <div className="mt-3 max-h-[420px] space-y-2 overflow-y-auto">
            {protocol.length === 0 ? <p className="text-sm text-slate-500 dark:text-slate-400">No protocol steps yet.</p> : protocol.map((step, index) => (
              <button key={step.id} type="button" onClick={() => onReplay(step)} className="w-full rounded-xl bg-white p-3 text-left text-sm dark:bg-slate-950">
                <p className="font-bold">{protocol.length - index}. {step.label}</p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{step.detail}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function KernelMetric({ label, value, tone = "neutral" }: { label: string; value: string; tone?: "neutral" | "good" | "bad" }) {
  const toneClass = tone === "good" ? "text-emerald-600 dark:text-emerald-300" : tone === "bad" ? "text-amber-700 dark:text-amber-200" : "text-cyan-600 dark:text-cyan-300";
  return (
    <div className="rounded-xl bg-slate-100 p-3 dark:bg-white/10">
      <p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">{label}</p>
      <p className={`mt-1 text-lg font-black ${toneClass}`}>{value}</p>
    </div>
  );
}

function _CriticalGapPhasePanel() {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-bold">Critical Gap Implementation Phases</h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Four production phases that close the core dynamic-mathematics gaps while keeping the app browser-only.</p>
        </div>
        <span className="mini-chip">{criticalGapImplementationPhases.length} phases</span>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {criticalGapImplementationPhases.map((phase) => (
          <div key={phase.id} className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10">
            <p className="text-xs font-bold uppercase text-cyan-600 dark:text-cyan-300">Phase {phase.id}</p>
            <h4 className="mt-1 font-bold">{phase.title}</h4>
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{phase.goal}</p>
            <p className="mt-3 text-xs font-bold uppercase text-slate-500 dark:text-slate-400">Deliverables</p>
            <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">{phase.deliverables.join(", ")}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

type Space3DPaletteItem<T extends string> = { id: T; label: string; icon: LucideIcon };

const space3dSurfacePalette: Space3DPaletteItem<SurfaceKind>[] = [
  { id: "paraboloid", label: "Paraboloid", icon: Circle },
  { id: "saddle", label: "Saddle", icon: Slash },
  { id: "wave", label: "Wave", icon: LineChart },
  { id: "plane", label: "Plane", icon: Slash },
  { id: "ripple", label: "Ripple", icon: Circle },
  { id: "cone-surface", label: "Cone Surface", icon: Rotate3D },
  { id: "custom-z", label: "z=f(x,y)", icon: FunctionSquare },
  { id: "parametric", label: "Parametric", icon: Rotate3D },
  { id: "implicit", label: "Implicit", icon: Circle },
];

const space3dSolidPalette: Space3DPaletteItem<SolidKind>[] = [
  { id: "cube", label: "Cube", icon: Box },
  { id: "cuboid", label: "Cuboid", icon: Box },
  { id: "sphere", label: "Sphere", icon: Circle },
  { id: "ellipsoid", label: "Ellipsoid", icon: Circle },
  { id: "hemisphere", label: "Hemisphere", icon: Circle },
  { id: "cylinder", label: "Cylinder", icon: Rotate3D },
  { id: "cone", label: "Cone", icon: Rotate3D },
  { id: "frustum", label: "Frustum", icon: Rotate3D },
  { id: "torus", label: "Torus", icon: Rotate3D },
  { id: "tube", label: "Tube", icon: Circle },
  { id: "capsule", label: "Capsule", icon: Rotate3D },
  { id: "prism", label: "Prism", icon: Box },
  { id: "pyramid", label: "Pyramid", icon: Pentagon },
  { id: "tetrahedron", label: "Tetrahedron", icon: Pentagon },
  { id: "octahedron", label: "Octahedron", icon: Pentagon },
  { id: "dodecahedron", label: "Dodecahedron", icon: Pentagon },
  { id: "wedge", label: "Wedge", icon: Box },
  { id: "polyhedron", label: "Polyhedron", icon: Box },
];

const space3dObjectPalette: Space3DPaletteItem<ThreeObjectId>[] = [
  { id: "point", label: "Point", icon: Plus },
  { id: "vector", label: "Vector", icon: Move },
  { id: "line3d", label: "Line", icon: Slash },
  { id: "plane3d", label: "Plane", icon: Slash },
  { id: "slice", label: "Slice", icon: LineChart },
  { id: "sphere3d", label: "Sphere", icon: Circle },
  { id: "cone3d", label: "Cone", icon: Rotate3D },
  { id: "cylinder3d", label: "Cylinder", icon: Rotate3D },
  { id: "prism3d", label: "Prism", icon: Box },
  { id: "pyramid3d", label: "Pyramid", icon: Pentagon },
  { id: "polyhedron3d", label: "Polyhedron", icon: Box },
];

const space3dCameraPalette: Space3DPaletteItem<CameraPreset3D>[] = [
  { id: "top", label: "Top", icon: Rotate3D },
  { id: "front", label: "Front", icon: Rotate3D },
  { id: "right", label: "Right", icon: Rotate3D },
  { id: "isometric", label: "Iso", icon: Rotate3D },
  { id: "free", label: "Free", icon: MousePointer2 },
];

function Space3DToolPalette({
  activeObject,
  selectedTransform,
  activeSurface,
  activeSolid,
  cameraPreset,
  autoRotate,
  showSurface,
  showSolid,
  onSurface,
  onSolid,
  onObject,
  onCamera,
  onToggleSurface,
  onToggleSolid,
  onToggleRotate,
  onSelectTool,
  onZoomIn,
  onZoomOut,
  onReset,
  onNudge,
  onRotateAxis,
  onScale,
  onMaterial,
  onOpacity,
  onDuplicate,
  onDelete,
  onRestore,
  onLock,
  onTrace,
  onToggleSelectedVisibility,
}: {
  activeObject: string;
  selectedTransform: Transform3D;
  activeSurface: SurfaceKind;
  activeSolid: SolidKind;
  cameraPreset: CameraPreset3D;
  autoRotate: boolean;
  showSurface: boolean;
  showSolid: boolean;
  onSurface: (surface: SurfaceKind) => void;
  onSolid: (solid: SolidKind) => void;
  onObject: (id: ThreeObjectId) => void;
  onCamera: (preset: CameraPreset3D) => void;
  onToggleSurface: (value: boolean) => void;
  onToggleSolid: (value: boolean) => void;
  onToggleRotate: (value: boolean) => void;
  onSelectTool: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onReset: () => void;
  onNudge: (axis: 0 | 1 | 2, amount: number) => void;
  onRotateAxis: (axis: 0 | 1 | 2, amount: number) => void;
  onScale: (amount: number) => void;
  onMaterial: (material: Transform3D["material"]) => void;
  onOpacity: (opacity: number) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onRestore: () => void;
  onLock: () => void;
  onTrace: () => void;
  onToggleSelectedVisibility: () => void;
}) {
  const hasSelectedObject = Boolean(activeObject);
  const selectedMaterial = selectedTransform.material ?? "glass";
  const selectedOpacity = roundTo(selectedTransform.opacity ?? 0.8, 2);
  const transformActions: GeometryPaletteActionItem[] = [
    { id: "move-x", label: "Move X", icon: Move, action: () => onNudge(0, 0.25), disabled: !hasSelectedObject },
    { id: "move-y", label: "Move Y", icon: Move, action: () => onNudge(1, 0.25), disabled: !hasSelectedObject },
    { id: "move-z", label: "Move Z", icon: Move, action: () => onNudge(2, 0.25), disabled: !hasSelectedObject },
    { id: "rot-x", label: "Rotate X", icon: Rotate3D, action: () => onRotateAxis(0, 15), disabled: !hasSelectedObject },
    { id: "rot-y", label: "Rotate Y", icon: Rotate3D, action: () => onRotateAxis(1, 15), disabled: !hasSelectedObject },
    { id: "rot-z", label: "Rotate Z", icon: Rotate3D, action: () => onRotateAxis(2, 15), disabled: !hasSelectedObject },
    { id: "scale-up", label: "Scale +", icon: ZoomIn, action: () => onScale(0.15), disabled: !hasSelectedObject },
    { id: "scale-down", label: "Scale -", icon: ZoomOut, action: () => onScale(-0.15), disabled: !hasSelectedObject },
  ];
  const materialActions: GeometryPaletteActionItem[] = [
    { id: "matte", label: "Matte", icon: Circle, action: () => onMaterial("matte"), active: selectedMaterial === "matte", disabled: !hasSelectedObject },
    { id: "glass", label: "Glass", icon: Circle, action: () => onMaterial("glass"), active: selectedMaterial === "glass", disabled: !hasSelectedObject },
    { id: "wire", label: "Wireframe", icon: Slash, action: () => onMaterial("wireframe"), active: selectedMaterial === "wireframe", disabled: !hasSelectedObject },
    { id: "opaque", label: "Opacity 100", icon: Circle, action: () => onOpacity(1), active: selectedOpacity === 1, disabled: !hasSelectedObject },
    { id: "translucent", label: "Opacity 55", icon: Circle, action: () => onOpacity(0.55), active: selectedOpacity === 0.55, disabled: !hasSelectedObject },
    { id: "ghost", label: "Opacity 25", icon: Circle, action: () => onOpacity(0.25), active: selectedOpacity === 0.25, disabled: !hasSelectedObject },
  ];
  const objectActions: GeometryPaletteActionItem[] = [
    { id: "duplicate", label: "Duplicate", icon: Plus, action: onDuplicate, disabled: !hasSelectedObject },
    { id: "show-hide", label: selectedTransform.visible ? "Hide" : "Show", icon: Circle, action: onToggleSelectedVisibility, active: selectedTransform.visible, disabled: !hasSelectedObject },
    { id: "lock", label: selectedTransform.locked ? "Unlock" : "Lock", icon: Magnet, action: onLock, active: Boolean(selectedTransform.locked), disabled: !hasSelectedObject },
    { id: "trace", label: selectedTransform.trace ? "Trace On" : "Trace", icon: LineChart, action: onTrace, active: Boolean(selectedTransform.trace), disabled: !hasSelectedObject },
    { id: "restore", label: "Restore", icon: RotateCcw, action: onRestore, disabled: !hasSelectedObject },
    { id: "delete", label: "Delete", icon: Trash2, action: onDelete, danger: true, disabled: !hasSelectedObject },
  ];
  const sceneActions: GeometryPaletteActionItem[] = [
    { id: "toggle-surface", label: showSurface ? "Surface On" : "Surface Off", icon: Circle, action: () => onToggleSurface(!showSurface), active: showSurface },
    { id: "toggle-solid", label: showSolid ? "Solid On" : "Solid Off", icon: Box, action: () => onToggleSolid(!showSolid), active: showSolid },
    { id: "rotate", label: autoRotate ? "Pause Rotation" : "Start Rotation", icon: RotateCcw, action: () => onToggleRotate(!autoRotate), active: autoRotate },
    { id: "zoom-in", label: "Zoom In", icon: ZoomIn, action: onZoomIn },
    { id: "zoom-out", label: "Zoom Out", icon: ZoomOut, action: onZoomOut },
    { id: "reset", label: "Reset", icon: Eraser, action: onReset, danger: true },
  ];
  const mainActions: GeometryPaletteActionItem[] = [
    { id: "select", label: "Select", icon: MousePointer2, action: onSelectTool, active: !activeObject },
    { id: "pause-rotation", label: autoRotate ? "Pause Rotation" : "Start Rotation", icon: RotateCcw, action: () => onToggleRotate(!autoRotate), active: autoRotate },
  ];

  return (
    <aside className="space3d-tool-palette thin-scrollbar max-h-[clamp(18rem,46vh,32.5rem)] overflow-auto rounded-2xl border border-slate-200 bg-white/90 p-2 shadow-xl shadow-slate-200/40 dark:border-white/10 dark:bg-slate-950/70 dark:shadow-black/20">
      <Space3DPaletteSection title="Basic Tools">
        {mainActions.map((item) => <Space3DPaletteAction key={item.id} item={item} />)}
        {space3dObjectPalette.slice(0, 4).map((item) => <Space3DPaletteButton key={item.id} item={item} active={activeObject === item.id} onClick={() => onObject(item.id)} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Edit">
        {objectActions.map((item) => <Space3DPaletteAction key={item.id} item={item} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Construct">
        {space3dObjectPalette.slice(4).map((item) => <Space3DPaletteButton key={item.id} item={item} active={activeObject === item.id} onClick={() => onObject(item.id)} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Shapes">
        {space3dSolidPalette.map((item) => <Space3DPaletteButton key={item.id} item={item} active={activeSolid === item.id && activeObject === "solid"} onClick={() => onSolid(item.id)} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Curves / Surfaces">
        {space3dSurfacePalette.map((item) => <Space3DPaletteButton key={item.id} item={item} active={activeSurface === item.id || (activeObject === "surface" && activeSurface === item.id)} onClick={() => onSurface(item.id)} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Transform">
        {transformActions.map((item) => <Space3DPaletteAction key={item.id} item={item} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Material">
        {materialActions.map((item) => <Space3DPaletteAction key={item.id} item={item} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Camera">
        {space3dCameraPalette.map((item) => <Space3DPaletteButton key={item.id} item={item} active={cameraPreset === item.id} onClick={() => onCamera(item.id)} />)}
      </Space3DPaletteSection>
      <Space3DPaletteSection title="Scene">
        {sceneActions.map((item) => <Space3DPaletteAction key={item.id} item={item} />)}
      </Space3DPaletteSection>
    </aside>
  );
}

function Space3DPaletteSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-3 last:mb-0">
      <h4 className="mb-1.5 px-1 text-[11px] font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">{title}</h4>
      <div className="grid grid-cols-3 gap-1.5">{children}</div>
    </section>
  );
}

function Space3DPaletteButton<T extends string>({ item, active, onClick }: { item: Space3DPaletteItem<T>; active: boolean; onClick: () => void }) {
  const Icon = item.icon;
  return (
    <button type="button" onClick={onClick} title={item.label} className={`space3d-palette-button ${active ? "space3d-palette-button-active" : ""}`}>
      <Icon className="h-4 w-4" />
      <span>{item.label}</span>
    </button>
  );
}

function Space3DPaletteAction({ item }: { item: GeometryPaletteActionItem }) {
  const Icon = item.icon;
  return (
    <button type="button" onClick={item.action} title={item.disabled ? "Select a 3D object first" : item.label} disabled={item.disabled} className={`space3d-palette-button ${item.active ? "space3d-palette-button-active" : ""} ${item.danger ? "space3d-palette-button-danger" : ""}`}>
      <Icon className="h-4 w-4" />
      <span>{item.label}</span>
    </button>
  );
}

function _Space3DConstructionWorkbench({
  selected,
  transform,
  onPreset,
  onDuplicate,
  onDelete,
  onRestore,
  onToggleVisibility,
}: {
  selected: string;
  transform: Transform3D;
  onPreset: (preset: Preset3DTransform) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onRestore: () => void;
  onToggleVisibility: () => void;
}) {
  const presets: Array<{ id: Preset3DTransform; label: string }> = [
    { id: "center", label: "Center" },
    { id: "ground", label: "Ground" },
    { id: "unit", label: "Unit" },
    { id: "wide", label: "Wide" },
    { id: "tall", label: "Tall" },
    { id: "xy-plane", label: "XY" },
    { id: "xz-plane", label: "XZ" },
    { id: "yz-plane", label: "YZ" },
  ];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/85 p-3 shadow-sm dark:border-white/10 dark:bg-white/5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-[11px] font-black uppercase tracking-wide text-violet-600 dark:text-violet-300">3D Geometry Constructor</p>
          <h3 className="text-sm font-black text-slate-950 dark:text-white">{selected ? transform.name ?? selected : "Select or create an object"}</h3>
        </div>
        <div className="flex flex-wrap gap-1">
          <button type="button" onClick={onDuplicate} disabled={!selected} className="mini-chip">Duplicate</button>
          <button type="button" onClick={onToggleVisibility} disabled={!selected} className="mini-chip">{transform.visible ? "Hide" : "Show"}</button>
          <button type="button" onClick={onRestore} disabled={!selected} className="mini-chip">Restore</button>
          <button type="button" onClick={onDelete} disabled={!selected} className="mini-chip text-rose-700 dark:text-rose-100">Delete</button>
        </div>
      </div>
      <div className="mt-3">
        <div>
          <p className="text-[11px] font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">Modify Selected</p>
          <div className="mt-2 grid grid-cols-2 gap-1.5 sm:grid-cols-4 xl:grid-cols-8">
            {presets.map((item) => (
              <button key={item.id} type="button" onClick={() => onPreset(item.id)} disabled={!selected} className="rounded-lg bg-slate-100 px-2 py-2 text-xs font-black text-slate-700 transition hover:bg-cyan-100 disabled:opacity-45 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-400/15">
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>
      {selected && (
        <div className="mt-3 grid gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 sm:grid-cols-4">
          <Space3DReadout label="Position" value={transform.position.map((value) => roundTo(value, 2)).join(", ")} />
          <Space3DReadout label="Rotation" value={transform.rotation.map((value) => `${roundTo(value, 1)}deg`).join(", ")} />
          <Space3DReadout label="Size" value={`${roundTo(transform.scale, 2)}x`} />
          <Space3DReadout label="Measure" value={measure3dTransform(transform)} />
        </div>
      )}
    </div>
  );
}

function Space3DReadout({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-slate-100 px-2 py-2 dark:bg-white/10">
      <p className="text-[10px] font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">{label}</p>
      <p className="mt-0.5 truncate font-mono text-xs text-slate-800 dark:text-slate-100">{value}</p>
    </div>
  );
}

function measure3dTransform(transform: Transform3D) {
  const dims = transform.dimensions ?? [transform.scale, transform.scale, transform.scale];
  const scaled = dims.map((value) => Math.max(0, value * transform.scale));
  const volume = scaled[0] * scaled[1] * scaled[2];
  const distanceFromOrigin = Math.hypot(...transform.position);
  return `box ${roundTo(volume, 2)}, |p| ${roundTo(distanceFromOrigin, 2)}`;
}

function SyllabusTemplatePanel({ templates, active, onApply }: { templates: SyllabusWorkspaceTemplate[]; active: string; onApply: (template: SyllabusWorkspaceTemplate) => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-bold">Syllabus-Aware Workspace Templates</h3>
        <span className="mini-chip">browser only</span>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {templates.map((template) => (
          <button key={template.id} type="button" onClick={() => onApply(template)} className={`rounded-2xl border p-4 text-left transition hover:-translate-y-0.5 ${active === template.id ? "border-cyan-400 bg-cyan-50 dark:bg-cyan-400/10" : "border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-slate-900/50"}`}>
            <p className="text-xs font-bold uppercase text-cyan-600 dark:text-cyan-300">{template.unit}</p>
            <p className="mt-1 font-bold">{template.title}</p>
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{template.description}</p>
            <p className="mt-3 font-mono text-xs text-slate-500 dark:text-slate-400">{template.command}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

function GuidedActivityPanel({ active, phase, template, journal, onToggle, onPhase, onJournal, onCompletePhase }: { active: boolean; phase: GuidedActivityPhase; template: SyllabusWorkspaceTemplate; journal: Record<string, ActivityJournalEntry>; onToggle: () => void; onPhase: (phase: GuidedActivityPhase) => void; onJournal: (patch: Partial<ActivityJournalEntry>) => void; onCompletePhase: () => void }) {
  const phases: GuidedActivityPhase[] = ["predict", "manipulate", "check", "reflect"];
  const current = template.steps.find((step) => step.phase === phase) ?? template.steps[0];
  const currentEntry = journal[activityJournalKey(template.id, phase)] ?? defaultActivityJournalEntry(template.id, phase);
  const completedCount = phases.filter((item) => journal[activityJournalKey(template.id, item)]?.selfCheck === "got-it").length;
  const progress = Math.round((completedCount / phases.length) * 100);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-bold">Guided Activity Mode</h3>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Prediction, manipulation, check, and reflection stay attached to this browser project.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="mini-chip">{progress}% complete</span>
          <button type="button" onClick={onToggle} className={active ? "action-primary py-2" : "action-secondary py-2"}>{active ? "Guidance on" : "Guidance off"}</button>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {phases.map((item) => {
          const entry = journal[activityJournalKey(template.id, item)];
          return <button key={item} type="button" onClick={() => onPhase(item)} className={`rounded-full px-3 py-2 text-xs font-bold uppercase ${phase === item ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950" : entry?.selfCheck === "got-it" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-400/15 dark:text-emerald-100" : "bg-slate-100 text-slate-700 dark:bg-white/10 dark:text-slate-200"}`}>{item}</button>;
        })}
      </div>
      {active && (
        <div className="mt-3 grid gap-3 xl:grid-cols-[minmax(0,1fr)_260px]">
          <div className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10">
            <p className="text-sm font-bold">{current.title}</p>
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{current.prompt}</p>
            <label className="mt-4 block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
              Student response
              <textarea value={currentEntry.response} onChange={(event) => onJournal({ response: event.target.value })} rows={4} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-white p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-950" placeholder="Write prediction, observation, calculation, or reflection..." />
            </label>
            <div className="mt-3 rounded-xl bg-white p-3 text-sm font-semibold text-slate-700 dark:bg-slate-950 dark:text-slate-100">{current.reveal}</div>
          </div>
          <div className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10">
            <p className="text-sm font-bold">Self Check</p>
            <div className="mt-3 grid gap-2">
              {(["not-started", "revisit", "got-it"] as ActivityJournalEntry["selfCheck"][]).map((item) => <button key={item} type="button" onClick={() => onJournal({ selfCheck: item })} className={`rounded-xl px-3 py-2 text-left text-xs font-bold uppercase ${currentEntry.selfCheck === item ? "bg-cyan-600 text-white" : "bg-white dark:bg-slate-950"}`}>{item.replace("-", " ")}</button>)}
            </div>
            <label className="mt-4 block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
              Confidence {currentEntry.confidence}%
              <input type="range" min="0" max="100" value={currentEntry.confidence} onChange={(event) => onJournal({ confidence: Number(event.target.value) })} className="mt-2 w-full accent-cyan-500" />
            </label>
            <button type="button" onClick={onCompletePhase} className="action-primary mt-4 w-full py-2">Mark and continue</button>
            <p className="mt-3 text-xs leading-5 text-slate-500 dark:text-slate-400">Last saved: {currentEntry.updatedAt ? new Date(currentEntry.updatedAt).toLocaleTimeString() : "not yet"}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function TeacherLessonStudio({
  lesson,
  report,
  responses,
  onLessonChange,
  onStepChange,
  onResponseChange,
  onCheck,
  onLaunchCommand,
  onAddStep,
  onDuplicateStep,
  onRemoveStep,
  onExport,
}: {
  lesson: ClassroomLesson;
  report: ReturnType<typeof computePracticeReport>;
  responses: Record<string, PracticeResponse>;
  onLessonChange: (patch: Partial<ClassroomLesson>) => void;
  onStepChange: (stepId: string, patch: Partial<LessonStep>) => void;
  onResponseChange: (stepId: string, answer: string) => void;
  onCheck: (step: LessonStep, answer: string) => void;
  onLaunchCommand: (command: string) => void;
  onAddStep: (kind?: LessonStep["kind"]) => void;
  onDuplicateStep: (stepId: string) => void;
  onRemoveStep: (stepId: string) => void;
  onExport: () => void;
}) {
  const assessableSteps = lesson.steps.filter(isAssessableStep);
  const launchableCount = lesson.steps.filter((step) => step.command?.trim()).length;
  return (
    <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 dark:border-emerald-300/20 dark:bg-emerald-400/10">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-bold uppercase text-emerald-700 dark:text-emerald-200">Real Teacher Studio</p>
          <h3 className="text-lg font-black text-slate-950 dark:text-white">{lesson.title}</h3>
          <p className="mt-1 text-sm font-semibold text-slate-600 dark:text-slate-300">{lessonSummary(lesson)}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <span className="mini-chip">{practiceStatusLabel(report.status)}</span>
          <span className="mini-chip">{report.score}%</span>
          <span className="mini-chip">{launchableCount} launchable</span>
          <button type="button" onClick={() => onAddStep("explore")} className="action-secondary py-2">Add explore</button>
          <button type="button" onClick={() => onAddStep("check")} className="action-secondary py-2">Add check</button>
          <button type="button" onClick={onExport} className="action-secondary py-2"><Download className="h-4 w-4" />Assessment report</button>
        </div>
      </div>

      <div className="mt-4 grid gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="grid gap-3 md:grid-cols-2">
        <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
          Lesson title
          <input value={lesson.title} onChange={(event) => onLessonChange({ title: event.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm normal-case dark:border-white/10 dark:bg-slate-950" />
        </label>
        <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
          Audience
          <input value={lesson.audience} onChange={(event) => onLessonChange({ audience: event.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm normal-case dark:border-white/10 dark:bg-slate-950" />
        </label>
        <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400 md:col-span-2">
          Objective
          <textarea value={lesson.objective} onChange={(event) => onLessonChange({ objective: event.target.value })} rows={2} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-white p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-950" />
        </label>
        </div>
        <div className="rounded-xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">Assessment</p>
          <div className="mt-2 h-2 rounded-full bg-slate-100 dark:bg-white/10">
            <div className="h-2 rounded-full bg-emerald-500" style={{ width: `${report.score}%` }} />
          </div>
          <p className="mt-2 text-xs font-semibold text-slate-600 dark:text-slate-300">{report.answered}/{report.totalChecks} checked, {report.correct}/{report.totalChecks} passing</p>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs font-black">
            <div className="rounded-lg bg-emerald-50 p-2 text-emerald-800 dark:bg-emerald-400/10 dark:text-emerald-100">{lesson.steps.length}<br />steps</div>
            <div className="rounded-lg bg-cyan-50 p-2 text-cyan-800 dark:bg-cyan-400/10 dark:text-cyan-100">{assessableSteps.length}<br />checks</div>
            <div className="rounded-lg bg-violet-50 p-2 text-violet-800 dark:bg-violet-400/10 dark:text-violet-100">{launchableCount}<br />runs</div>
          </div>
        </div>
      </div>

      <StudentLessonPreview lesson={lesson} responses={responses} onLaunchCommand={onLaunchCommand} />

      <div className="mt-4 grid gap-3">
        {lesson.steps.map((step, index) => {
          const response = responses[step.id];
          const answer = response?.answer ?? "";
          return (
            <div key={step.id} className="rounded-2xl bg-white p-4 shadow-sm dark:bg-slate-950/70">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-black text-emerald-800 dark:bg-emerald-400/20 dark:text-emerald-100">Step {index + 1}</span>
                  <select value={step.kind} onChange={(event) => onStepChange(step.id, { kind: event.target.value as LessonStep["kind"] })} className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-bold dark:border-white/10 dark:bg-slate-900">
                    {lessonStepKinds.map((kind) => <option key={kind} value={kind}>{kind}</option>)}
                  </select>
                  {response?.score !== undefined ? <span className={`rounded-full px-2.5 py-1 text-xs font-black ${response.score >= 70 ? "bg-cyan-100 text-cyan-800 dark:bg-cyan-400/20 dark:text-cyan-100" : "bg-amber-100 text-amber-800 dark:bg-amber-400/20 dark:text-amber-100"}`}>{response.score}%</span> : null}
                </div>
                <div className="flex flex-wrap gap-2">
                  {step.command ? <button type="button" onClick={() => onLaunchCommand(step.command!)} className="action-primary py-2"><Presentation className="h-4 w-4" />Launch</button> : null}
                  <button type="button" onClick={() => onDuplicateStep(step.id)} className="action-secondary py-2">Duplicate</button>
                  <button type="button" onClick={() => onRemoveStep(step.id)} disabled={lesson.steps.length <= 1} className="action-secondary py-2 disabled:cursor-not-allowed disabled:opacity-50">Remove</button>
                </div>
              </div>
              <div className="mt-3 grid gap-3 lg:grid-cols-2">
                <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                  Step title
                  <input value={step.title} onChange={(event) => onStepChange(step.id, { title: event.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm normal-case dark:border-white/10 dark:bg-slate-900" />
                </label>
                <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                  Command
                  <input value={step.command ?? ""} onChange={(event) => onStepChange(step.id, { command: event.target.value })} className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 p-3 font-mono text-sm normal-case dark:border-white/10 dark:bg-slate-900" />
                </label>
              </div>
              <label className="mt-3 block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                Prompt
                <textarea value={step.prompt} onChange={(event) => onStepChange(step.id, { prompt: event.target.value })} rows={2} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-900" />
              </label>
              {isAssessableStep(step) ? (
                <div className="mt-3 grid gap-3 lg:grid-cols-2">
                  <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                    Expected idea
                    <textarea value={step.expected ?? ""} onChange={(event) => onStepChange(step.id, { expected: event.target.value })} rows={3} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-900" />
                  </label>
                  <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                    Student response
                    <textarea value={answer} onChange={(event) => onResponseChange(step.id, event.target.value)} rows={3} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-900" />
                  </label>
                  <div className="lg:col-span-2 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-100 p-3 dark:bg-white/10">
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{response?.feedback ?? "Enter a response and check it against the expected idea."}</p>
                    <button type="button" onClick={() => onCheck(step, answer)} className="action-secondary py-2">Check response</button>
                  </div>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>

      <label className="mt-4 block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
        Teacher notes
        <textarea value={lesson.teacherNotes} onChange={(event) => onLessonChange({ teacherNotes: event.target.value })} rows={3} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-white p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-950" />
      </label>
      {assessableSteps.length === 0 ? <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm font-semibold text-amber-900 dark:bg-amber-400/10 dark:text-amber-100">Add at least one question or check step to produce an assessment score.</p> : null}
    </div>
  );
}

function StudentLessonPreview({ lesson, responses, onLaunchCommand }: { lesson: ClassroomLesson; responses: Record<string, PracticeResponse>; onLaunchCommand: (command: string) => void }) {
  return (
    <div className="mt-4 rounded-2xl border border-cyan-200 bg-white p-4 shadow-sm dark:border-cyan-300/20 dark:bg-slate-950/70">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">Live student preview</p>
          <h4 className="mt-1 text-lg font-black text-slate-950 dark:text-white">{lesson.title}</h4>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">{lesson.objective}</p>
        </div>
        <span className="mini-chip">{lesson.audience}</span>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {lesson.steps.map((step, index) => {
          const response = responses[step.id];
          return (
            <article key={step.id} className="rounded-2xl bg-slate-50 p-3 dark:bg-white/10">
              <div className="flex items-center justify-between gap-2">
                <span className="rounded-full bg-slate-950 px-2.5 py-1 text-xs font-black text-white dark:bg-white dark:text-slate-950">{index + 1}</span>
                <span className="rounded-full bg-cyan-100 px-2.5 py-1 text-[11px] font-black uppercase text-cyan-800 dark:bg-cyan-300/15 dark:text-cyan-100">{step.kind}</span>
              </div>
              <h5 className="mt-3 font-black text-slate-950 dark:text-white">{step.title}</h5>
              <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{step.prompt}</p>
              {step.command ? (
                <button type="button" onClick={() => onLaunchCommand(step.command!)} className="action-secondary mt-3 min-h-9 rounded-lg px-3 py-1.5 text-xs">
                  Run {step.command}
                </button>
              ) : null}
              {response?.score !== undefined ? (
                <p className="mt-3 rounded-lg bg-white p-2 text-xs font-bold text-slate-700 dark:bg-slate-950 dark:text-slate-200">
                  Checked: {response.score}% - {response.feedback}
                </p>
              ) : null}
            </article>
          );
        })}
      </div>
    </div>
  );
}

function _BeyondGeoGebraCockpit({ packageSpec, packages, validation, assessment, tutor, readiness, commandDocs }: { packageSpec: UnitLabPackage; packages: UnitLabPackage[]; validation: ReturnType<typeof validateGuidedTaskResponse>; assessment: ReturnType<typeof assessConstruction>; tutor: ReturnType<typeof objectAwareTutorResponse>; readiness: ReturnType<typeof productionReadinessPlan>; commandDocs: ReturnType<typeof commandDocsForPackages> }) {
  return (
    <div className="rounded-2xl border border-violet-200 bg-violet-50/70 p-4 dark:border-violet-300/20 dark:bg-violet-400/10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-bold">Advanced Teaching Intelligence</h3>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{packages.length} unit labs with guided validation, teacher reveal, assessment, tutor prompts, production readiness, and command discovery.</p>
        </div>
        <span className="mini-chip">{packageSpec.unit}</span>
      </div>
      <div className="mt-3 grid gap-3 xl:grid-cols-4">
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Unit Lab</p>
          <p className="mt-2 font-bold">{packageSpec.title}</p>
          <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400">{packageSpec.interactiveLab}</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">{packageSpec.formulas.slice(0, 3).join(" | ")}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Guided Validation</p>
          <p className={`mt-2 text-lg font-black ${validation.passed ? "text-emerald-600 dark:text-emerald-300" : "text-amber-700 dark:text-amber-200"}`}>{validation.score}%</p>
          <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">{validation.feedback}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Assessment</p>
          <p className={`mt-2 text-lg font-black ${assessment.passed ? "text-emerald-600 dark:text-emerald-300" : "text-amber-700 dark:text-amber-200"}`}>{assessment.score}%</p>
          <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">{packageSpec.assessment.constructionGoal}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Smart Tutor</p>
          <p className="mt-2 text-xs leading-5 text-slate-600 dark:text-slate-300">{tutor.explanation}</p>
          <p className="mt-2 text-xs font-bold text-violet-700 dark:text-violet-200">{tutor.nextChallenge}</p>
        </div>
      </div>
      <div className="mt-3 grid gap-3 xl:grid-cols-3">
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Teacher Presentation</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">Lock: {packageSpec.teacherPresentation.lockWorkspace ? "yes" : "no"}; spotlight: {packageSpec.teacherPresentation.spotlightObject}; share: {packageSpec.teacherPresentation.shareModes.join(", ")}</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">{packageSpec.teacherPresentation.studentPrompt}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Production Plan</p>
          <p className="mt-2 text-xs leading-5 text-slate-500 dark:text-slate-400">Performance: {readiness.performance.slice(0, 2).join(", ")}</p>
          <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">Accessibility: {readiness.accessibility.slice(0, 2).join(", ")}</p>
          <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">UI: {readiness.uiPolish.slice(0, 2).join(", ")}</p>
        </div>
        <div className="rounded-2xl bg-white p-3 dark:bg-slate-950/70">
          <p className="text-xs font-bold uppercase text-violet-700 dark:text-violet-200">Command Discovery</p>
          <div className="mt-2 max-h-28 space-y-1 overflow-auto pr-1">
            {commandDocs.map((doc) => <p key={`${doc.unit}-${doc.tool}`} className="text-xs leading-5 text-slate-500 dark:text-slate-400"><span className="font-bold text-slate-700 dark:text-slate-200">{doc.tool}</span> - {doc.unit}: {doc.example}</p>)}
          </div>
        </div>
      </div>
      <div className="mt-3 grid gap-2 md:grid-cols-3">
        {packageSpec.misconceptions.slice(0, 3).map((item) => <div key={item} className="rounded-xl bg-white p-2 text-xs font-semibold text-slate-600 dark:bg-slate-950/70 dark:text-slate-300">Watch for: {item}</div>)}
      </div>
    </div>
  );
}

function TeacherPresentationPanel({ active, locked, revealStep, lesson, template, notes, responses, report, journal, onToggle, onLock, onReveal, onNotes, onCopyLink }: { active: boolean; locked: boolean; revealStep: number; lesson: ClassroomLesson; template: SyllabusWorkspaceTemplate; notes: string; responses: Record<string, PracticeResponse>; report: ReturnType<typeof computePracticeReport>; journal: Record<string, ActivityJournalEntry>; onToggle: (value: boolean) => void; onLock: (value: boolean) => void; onReveal: (value: number) => void; onNotes: (notes: string) => void; onCopyLink: () => void }) {
  const visibleSteps = lesson.steps.slice(0, revealStep);
  const activeSlide = lesson.steps[Math.min(Math.max(revealStep - 1, 0), Math.max(lesson.steps.length - 1, 0))];
  const phaseSummary = template.steps.map((step) => journal[activityJournalKey(template.id, step.phase)] ?? defaultActivityJournalEntry(template.id, step.phase));
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-black uppercase text-violet-700 dark:text-violet-200">Teacher Presentation Mode</p>
          <h3 className="font-bold">{lesson.title}</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => onToggle(!active)} className={active ? "action-primary py-2" : "action-secondary py-2"}>{active ? "Presenting" : "Start"}</button>
          <button type="button" onClick={() => onLock(!locked)} className={locked ? "action-primary py-2" : "action-secondary py-2"}>{locked ? "Locked" : "Unlocked"}</button>
          <button type="button" onClick={onCopyLink} className="action-secondary py-2">Copy teacher link</button>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" onClick={() => onReveal(Math.max(1, revealStep - 1))} className="action-secondary py-2">Previous reveal</button>
        <button type="button" onClick={() => onReveal(Math.min(lesson.steps.length, revealStep + 1))} className="action-secondary py-2">Next reveal</button>
        <span className="mini-chip">Reveal {revealStep}/{lesson.steps.length}</span>
        <span className="mini-chip">{practiceStatusLabel(report.status)} {report.score}%</span>
      </div>
      {activeSlide ? (
        <div className="mt-3 rounded-3xl bg-slate-950 p-5 text-white shadow-xl shadow-slate-900/15">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="rounded-full bg-cyan-300 px-3 py-1 text-xs font-black uppercase text-slate-950">{activeSlide.kind}</span>
            {activeSlide.command ? <span className="rounded-full bg-white/10 px-3 py-1 font-mono text-xs font-bold text-cyan-50">{activeSlide.command}</span> : null}
          </div>
          <h4 className="mt-5 text-2xl font-black">{activeSlide.title}</h4>
          <p className="mt-3 max-w-3xl text-base leading-7 text-cyan-50/80">{activeSlide.prompt}</p>
          {activeSlide.expected ? <p className="mt-4 rounded-2xl bg-white/10 p-3 text-sm font-semibold leading-6 text-cyan-50">Teacher reveal: {activeSlide.expected}</p> : null}
        </div>
      ) : null}
      <div className="mt-3 grid gap-3 xl:grid-cols-[minmax(0,1fr)_280px]">
        <ol className="space-y-2">
          {visibleSteps.map((step, index) => <li key={step.id} className="rounded-xl bg-slate-100 p-3 text-sm leading-6 dark:bg-white/10"><span className="font-bold text-cyan-600 dark:text-cyan-300">{index + 1}. {step.title}</span> {step.prompt}</li>)}
        </ol>
        <div className="rounded-2xl bg-slate-100 p-3 dark:bg-white/10">
          <h4 className="font-bold">Classroom Pulse</h4>
          <div className="mt-3 space-y-2">
            {lesson.steps.filter(isAssessableStep).map((step) => {
              const response = responses[step.id];
              return (
                <div key={step.id} className="rounded-xl bg-white p-2 text-xs dark:bg-slate-950">
                  <p className="font-bold">{step.title}</p>
                  <p>{response?.score !== undefined ? `${response.score}%` : "not checked"}</p>
                </div>
              );
            })}
            {phaseSummary.map((entry) => <div key={entry.phase} className="rounded-xl bg-white p-2 text-xs dark:bg-slate-950"><p className="font-bold uppercase">{entry.phase}</p><p>Check: {entry.selfCheck.replace("-", " ")}</p><p>Confidence: {entry.confidence}%</p></div>)}
          </div>
        </div>
      </div>
      <label className="mt-3 block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
        Teacher notes
        <textarea value={notes} onChange={(event) => onNotes(event.target.value)} rows={3} className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-white p-3 text-sm normal-case leading-6 dark:border-white/10 dark:bg-slate-950" placeholder="Board prompts, misconceptions, extension questions..." />
      </label>
    </div>
  );
}

function OfflineProjectLibraryPanel({ projects, onSave, onRestore, onDelete, onClear }: { projects: OfflineProjectEntry<WorkspaceSnapshot>[]; onSave: () => void; onRestore: (entry: OfflineProjectEntry<WorkspaceSnapshot>) => void; onDelete: (id: string) => void; onClear: () => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-bold">Offline-First Project Library</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={onSave} className="action-secondary py-2">Save current</button>
          <button type="button" onClick={onClear} className="action-secondary py-2">Clear</button>
        </div>
      </div>
      <div className="mt-3 grid gap-2 md:grid-cols-2">
        {projects.length === 0 ? <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">Saved projects stay in browser storage and can be restored offline.</p> : projects.map((project) => (
          <div key={project.id} className="rounded-xl bg-slate-100 p-3 dark:bg-white/10">
            <p className="font-bold">{project.title}</p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{new Date(project.savedAt).toLocaleString()} - {project.summary}</p>
            <div className="mt-2 flex gap-2">
              <button type="button" onClick={() => onRestore(project)} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-slate-950">Restore</button>
              <button type="button" onClick={() => onDelete(project.id)} className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function _GizmoReadout3D({ selected, transform }: { selected: string; transform: Transform3D }) {
  const mode: TransformMode3 = selected === "slice" || selected === "plane3d" ? "rotate" : selected === "solid" || selected.endsWith("3d") ? "scale" : "translate";
  const handles = createTransformGizmo(mode);
  const measurement = object3Measurement(transformToKernelObject(selected, transform));
  return (
    <CollapsibleSideCard id="workspace-3d-gizmo-panel" title="3D Gizmo And Measurement" subtitle={`${transform.name ?? selected} uses ${mode} handles with snap-ready axes.`} meta={<span className="mini-chip">{handles.length} handles</span>}>
      <div className="mt-3 grid gap-2">
        {handles.map((handle) => (
          <div key={handle.id} className="flex items-center justify-between rounded-xl bg-slate-100 p-2 dark:bg-white/10">
            <span className="font-bold" style={{ color: handle.color }}>{handle.label}</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">snap {handle.snapStep}</span>
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs leading-5 text-slate-500 dark:text-slate-400">
        {measurement.detail}; V={roundTo(measurement.volume, 3)}, SA={roundTo(measurement.surfaceArea, 3)}
      </p>
    </CollapsibleSideCard>
  );
}

function _Readout3D({ surface, surfaceScale, crossSection, zoom }: { surface: SurfaceKind; surfaceScale: number; crossSection: number; zoom: number }) {
  return (
    <CollapsibleSideCard id="workspace-3d-readout-panel" title="3D Readout" meta={<span className="mini-chip">{roundTo(zoom * 100, 0)}%</span>} className="border-transparent bg-slate-100 shadow-none dark:bg-white/10">
      <div className="space-y-1 leading-6 text-slate-600 dark:text-slate-300">
        <p>Surface: {surfaceFormula(surface, surfaceScale)}</p>
        <p>Cross-section plane: z = {roundTo(crossSection, 2)}</p>
        <p>Camera zoom: {roundTo(zoom * 100, 0)}%</p>
      </div>
    </CollapsibleSideCard>
  );
}

function transformToKernelObject(selected: string, transform: Transform3D): Object3 {
  const center = kernelPoint3(transform.position[0], transform.position[1], transform.position[2]);
  const dims = transform.dimensions ?? [transform.scale, transform.scale, transform.scale];
  const name = `${selected} ${transform.name ?? ""}`.toLowerCase();
  if (selected === "sphere3d" || selected === "solid" || name.includes("sphere") || name.includes("cube") || name.includes("prism") || name.includes("pyramid") || name.includes("polyhedron")) return kernelSphere3(center, Math.max(dims[0], dims[1], dims[2]) * transform.scale * 0.5);
  if (selected === "cylinder3d" || name.includes("cylinder")) return kernelCylinder3(center, dims[0] * transform.scale, dims[1] * transform.scale);
  if (selected === "cone3d" || name.includes("cone")) return kernelCone3(center, dims[0] * transform.scale, dims[1] * transform.scale);
  if (selected === "plane3d" || selected === "slice" || name.includes("plane") || name.includes("surface")) return kernelPlane3(center, kernelPoint3(0, 0, 1));
  return kernelLine3(center, kernelPoint3(dims[0] || 1, dims[1] || 0, dims[2] || 0));
}

function downloadText(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  downloadBlob(filename, blob);
}

function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function activityJournalKey(templateId: string, phase: GuidedActivityPhase) {
  return `${templateId}:${phase}`;
}

function defaultActivityJournalEntry(templateId: string, phase: GuidedActivityPhase): ActivityJournalEntry {
  return { templateId, phase, response: "", selfCheck: "not-started", confidence: 50, updatedAt: 0 };
}

function lessonFromTemplate(template: SyllabusWorkspaceTemplate): ClassroomLesson {
  const baseLesson = createDefaultLesson();
  return {
    ...baseLesson,
    id: `lesson-${template.id}`,
    title: template.title,
    audience: template.unit,
    objective: template.outcomes.join(" "),
    teacherNotes: `Launch "${template.command}" for the live workspace. Use the checks to collect student reasoning before exporting the assessment report.`,
    updatedAt: Date.now(),
    steps: template.steps.map((step, index): LessonStep => ({
      id: `${template.id}-${step.phase}-${index}`,
      kind: step.phase === "check" || step.phase === "reflect" ? "check" : step.phase === "predict" ? "question" : "explore",
      title: step.title,
      prompt: step.prompt,
      command: index === 0 || step.phase === "manipulate" || step.phase === "check" ? template.command : undefined,
      expected: step.reveal,
    })),
  };
}

function createLessonPack(template: SyllabusWorkspaceTemplate, lesson: ClassroomLesson, snapshot: WorkspaceSnapshot, journal: Record<string, ActivityJournalEntry>, results: ResultCard[], notes: string) {
  return {
    app: "Math Universe",
    version: "browser-only-lesson-pack",
    exportedAt: new Date().toISOString(),
    template: {
      id: template.id,
      unit: template.unit,
      title: template.title,
      description: template.description,
      command: template.command,
      outcomes: template.outcomes,
      steps: template.steps,
    },
    lesson,
    teacherNotes: notes,
    guidedJournal: Object.values(journal).filter((entry) => entry.templateId === template.id),
    recentResults: results.slice(0, 12).map((result) => ({ input: result.input, interpretation: result.interpretation, result: result.result, detail: result.detail })),
    workspaceSnapshot: snapshot,
  };
}

function activityJournalToCsv(journal: Record<string, ActivityJournalEntry>) {
  const rows = [["Template", "Phase", "Self check", "Confidence", "Response", "Updated"]];
  Object.values(journal).forEach((entry) => rows.push([entry.templateId, entry.phase, entry.selfCheck, String(entry.confidence), entry.response, entry.updatedAt ? new Date(entry.updatedAt).toISOString() : ""]));
  return rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
}

function createWorksheetPdf(lesson: ClassroomLesson, template: SyllabusWorkspaceTemplate, results: ResultCard[]) {
  const lines = [
    `Math Universe Worksheet: ${lesson.audience}`,
    lesson.title,
    "",
    `Objective: ${lesson.objective}`,
    "",
    "Learning outcomes:",
    ...template.outcomes.map((outcome) => `- ${outcome}`),
    "",
    "Lesson activity:",
    ...lesson.steps.flatMap((step, index) => [
      `${index + 1}. ${step.title} (${step.kind})`,
      `Prompt: ${step.prompt}`,
      step.command ? `Command: ${step.command}` : "",
      step.expected ? `Expected idea: ${step.expected}` : "",
      "Student response: ______________________________",
      "",
    ]).filter(Boolean),
    "",
    "Recent workspace results:",
    ...(results.length ? results.slice(0, 6).map((result) => `${result.input}: ${result.result}`) : ["No results exported yet."]),
  ];
  return simplePdf(lines);
}

function simplePdf(lines: string[]) {
  const escapedLines = lines.map((line) => line.replace(/[()\\]/g, "\\$&"));
  const content = escapedLines.map((line, index) => `BT /F1 11 Tf 56 ${780 - index * 18} Td (${line}) Tj ET`).join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
  ];
  let body = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(body.length);
    body += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = body.length;
  body += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach((offset) => { body += `${String(offset).padStart(10, "0")} 00000 n \n`; });
  body += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return body;
}

function buildAlgebraObjects(plots: PlotItem[], construction: Construction, transforms3d: Record<ThreeObjectId, Transform3D>, lockedGeometryIds: string[], added3dObjects: Added3DObject[] = []): AlgebraObjectRow[] {
  const pointName = (id: string) => pointById(construction.points, id)?.label ?? id.slice(0, 4);
  const rows: AlgebraObjectRow[] = plots.map((plot, index) => ({
    ref: { kind: "function", id: plot.id },
    name: plot.name ?? String.fromCharCode(102 + index),
    definition: `${plot.name ?? String.fromCharCode(102 + index)}(x) = ${plot.expression}`,
    visible: plot.visible !== false,
    locked: plot.locked === true,
    trace: plot.trace === true,
    dependencies: dependenciesForExpression(plot.expression),
  }));
  rows.push(...construction.points.map((point) => ({
    ref: { kind: "point" as const, id: point.id },
    name: point.label,
    definition: `${point.label} = (${roundTo(point.x, 2)}, ${roundTo(point.y, 2)})`,
    visible: point.style?.visible !== false,
    locked: lockedGeometryIds.includes(point.id),
    trace: point.style?.trace === true,
    dependencies: [],
  })));
  rows.push(...construction.lines.map((line, index) => ({
    ref: { kind: "line" as const, id: line.id },
    name: lineName(line, construction, index),
    definition: lineEquation(line, construction),
    visible: line.style?.visible !== false,
    locked: lockedGeometryIds.includes(line.id),
    trace: line.style?.trace === true,
    dependencies: [pointName(line.a), pointName(line.b)],
  })));
  rows.push(...construction.circles.map((circle, index) => ({
    ref: { kind: "circle" as const, id: circle.id },
    name: circleName(circle, construction, index),
    definition: circleEquation(circle, construction),
    visible: circle.style?.visible !== false,
    locked: lockedGeometryIds.includes(circle.id),
    trace: circle.style?.trace === true,
    dependencies: [pointName(circle.center), pointName(circle.edge)],
  })));
  rows.push(...construction.polygons.map((polygon, index) => ({
    ref: { kind: "polygon" as const, id: polygon.id },
    name: polygonName(polygon, construction, index),
    definition: `Polygon(${polygon.points.map(pointName).join(", ")})`,
    visible: polygon.style?.visible !== false,
    locked: lockedGeometryIds.includes(polygon.id),
    trace: polygon.style?.trace === true,
    dependencies: polygon.points.map(pointName),
  })));
  rows.push(...construction.arcs.map((arc, index) => ({
    ref: { kind: "arc" as const, id: arc.id },
    name: (arc.style?.label ?? `${arc.sector ? "sector" : "arc"}${index + 1}`),
    definition: `${arc.sector ? "Sector" : "Arc"}(${pointName(arc.center)}, ${pointName(arc.start)}, ${pointName(arc.end)})`,
    visible: arc.style?.visible !== false,
    locked: lockedGeometryIds.includes(arc.id),
    trace: arc.style?.trace === true,
    dependencies: [pointName(arc.center), pointName(arc.start), pointName(arc.end)],
  })));
  rows.push(...construction.loci.map((locus) => ({
    ref: { kind: "locus" as const, id: locus.id },
    name: locus.label,
    definition: locus.mode === "trace" ? traceDefinition(locus.points.length, construction.points.find((point) => point.id === locus.sourcePointId)?.label) : `Locus(${locus.points.length} points)`,
    visible: locus.style?.visible !== false,
    locked: lockedGeometryIds.includes(locus.id),
    trace: locus.style?.trace === true,
    dependencies: locus.sourcePointId ? [pointName(locus.sourcePointId)] : [],
  })));
  rows.push(...(Object.keys(transforms3d) as ThreeObjectId[]).map((id) => ({
    ref: { kind: "3d" as const, id },
    name: transforms3d[id].name ?? id,
    definition: transformDefinition(transforms3d[id]),
    visible: transforms3d[id].visible,
    locked: transforms3d[id].locked === true,
    trace: transforms3d[id].trace === true,
    dependencies: id === "vector" ? [transforms3d.point.name ?? "P"] : [],
  })));
  rows.push(...added3dObjects.map((object) => ({
    ref: { kind: "3d" as const, id: object.id },
    name: object.transform.name ?? object.label,
    definition: transformDefinition(object.transform),
    visible: object.transform.visible,
    locked: object.transform.locked === true,
    trace: object.transform.trace === true,
    dependencies: [object.baseId],
  })));
  return rows;
}

function objectKindForKernel(kind: AlgebraObjectKind): DynamicObjectKind {
  if (kind === "3d") return "solid";
  return kind;
}

function sameRef(a: AlgebraObjectRef | null, b: AlgebraObjectRef) {
  return a?.kind === b.kind && a.id === b.id;
}

function objectDisplayName(objects: AlgebraObjectRow[], ref: AlgebraObjectRef) {
  return objects.find((object) => sameRef(object.ref, ref))?.name ?? ref.id;
}

function nextFunctionName(plots: PlotItem[]) {
  const used = new Set(plots.map((plot) => plot.name).filter(Boolean));
  for (const name of ["f", "g", "h", "p", "q", "r"]) if (!used.has(name)) return name;
  return `f${plots.length + 1}`;
}

function normalizeFunctionDefinition(definition: string) {
  return definition.replace(/^\s*[a-z]\s*\(\s*x\s*\)\s*=\s*/i, "").replace(/^y\s*=\s*/i, "").trim();
}

function dependenciesForExpression(expression: string) {
  return Array.from(new Set((expression.match(/\b[a-z]\b/gi) ?? []).filter((token) => token.toLowerCase() !== "x")));
}

function parsePointDefinition(definition: string) {
  const match = definition.match(/\(?\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)?/);
  return match ? { x: Number(match[1]), y: Number(match[2]) } : null;
}

function parseLineDefinition(definition: string) {
  const compact = definition.replace(/\s+/g, "");
  const match = compact.match(/^y=([-+]?\d*\.?\d*)\*?x([-+]\d+(?:\.\d+)?)?$/i);
  if (!match) return null;
  const rawM = match[1];
  const m = rawM === "" || rawM === "+" ? 1 : rawM === "-" ? -1 : Number(rawM);
  return { m, b: Number(match[2] ?? 0) };
}

function parseCircleDefinition(definition: string) {
  const match = definition.match(/center\s*=\s*\(?\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)?\s*,?\s*r\s*=\s*(\d+(?:\.\d+)?)/i);
  return match ? { x: Number(match[1]), y: Number(match[2]), r: Number(match[3]) } : null;
}

function parse3dDefinition(definition: string): Partial<Transform3D> | null {
  const numbers = definition.match(/-?\d+(?:\.\d+)?/g)?.map(Number) ?? [];
  if (numbers.length < 7) return null;
  return { position: [numbers[0], numbers[1], numbers[2]], rotation: [numbers[3], numbers[4], numbers[5]], scale: numbers[6] };
}

function renameGeometryObject(construction: Construction, ref: AlgebraObjectRef, name: string): Construction {
  if (ref.kind === "point") return { ...construction, points: construction.points.map((point) => point.id === ref.id ? { ...point, label: name.slice(0, 3) } : point) };
  const patch = { style: { ...(geometryObjectBySelection(construction, { type: ref.kind as GeometryObjectType, id: ref.id })?.style ?? {}), label: name } as GeoStyle };
  return patchGeometryObject(construction, { type: ref.kind as GeometryObjectType, id: ref.id }, patch);
}

function updateLineFromEquation(construction: Construction, lineId: string, m: number, b: number) {
  const line = construction.lines.find((item) => item.id === lineId);
  if (!line) return construction;
  const x1 = 100;
  const x2 = 540;
  const y1 = 210 - (m * ((x1 - 320) / 40) + b) * 40;
  const y2 = 210 - (m * ((x2 - 320) / 40) + b) * 40;
  return solveConstruction({ ...construction, points: construction.points.map((point) => point.id === line.a ? { ...point, x: x1, y: y1 } : point.id === line.b ? { ...point, x: x2, y: y2 } : point) });
}

function updateCircleFromDefinition(construction: Construction, circleId: string, next: { x: number; y: number; r: number }) {
  const circle = construction.circles.find((item) => item.id === circleId);
  if (!circle) return construction;
  return solveConstruction({
    ...construction,
    points: construction.points.map((point) => {
      if (point.id === circle.center) return { ...point, x: next.x, y: next.y };
      if (point.id === circle.edge) return { ...point, x: next.x + next.r * 40, y: next.y };
      return point;
    }),
  });
}

function lineName(line: GeoLine, construction: Construction, index: number) {
  const label = (line.style as GeoStyle & { label?: string })?.label;
  const endpointName = `${labelForPoint(construction, line.a)}${labelForPoint(construction, line.b)}`;
  return label ?? (endpointName || `line${index + 1}`);
}

function circleName(circle: GeoCircle, construction: Construction, index: number) {
  const label = (circle.style as GeoStyle & { label?: string })?.label;
  return label ?? `c${index + 1}_${labelForPoint(construction, circle.center)}`;
}

function polygonName(polygon: GeoPolygon, construction: Construction, index: number) {
  const label = (polygon.style as GeoStyle & { label?: string })?.label;
  return label ?? (polygon.points.map((id) => labelForPoint(construction, id)).join("") || `poly${index + 1}`);
}

function lineEquation(line: GeoLine, construction: Construction) {
  const a = pointById(construction.points, line.a), b = pointById(construction.points, line.b);
  if (!a || !b) return "Line(undefined)";
  const x1 = (a.x - 320) / 40;
  const y1 = (210 - a.y) / 40;
  const x2 = (b.x - 320) / 40;
  const y2 = (210 - b.y) / 40;
  if(line.kind==='ray'||line.kind==='vector')return line.kind==='ray'?`P(t) = (${x1},${y1}) + t(${x2-x1},${y2-y1}), t ≥ 0`:`v = (${x2-x1},${y2-y1}), |v| = ${Math.hypot(x2-x1,y2-y1)}`;
  if (Math.abs(x2 - x1) < 0.001) return `x = ${roundTo(x1, 2)}`;
  const m = (y2 - y1) / (x2 - x1);
  const intercept = y1 - m * x1;
  return `y = ${roundTo(m, 3)}*x ${intercept < 0 ? "-" : "+"} ${roundTo(Math.abs(intercept), 3)}`;
}

function circleEquation(circle: GeoCircle, construction: Construction) {
  const center = pointById(construction.points, circle.center), edge = pointById(construction.points, circle.edge);
  if (!center || !edge) return "Circle(undefined)";
  return `center=(${roundTo(center.x, 2)}, ${roundTo(center.y, 2)}), r=${roundTo(distance(center, edge) / 40, 2)}`;
}

function transformDefinition(transform: Transform3D) {
  return `pos=(${transform.position.map((value) => roundTo(value, 2)).join(", ")}), rot=(${transform.rotation.map((value) => roundTo(value, 1)).join(", ")}), scale=${roundTo(transform.scale, 2)}`;
}

function templateConstruction(templateId: string): Construction {
  const point = (id: string, x: number, y: number, label: string): GeoPoint => ({ id, x, y, label });
  if (templateId === "circles") {
    return normalizeConstruction({
      points: [point("a", 320, 210, "O"), point("b", 430, 210, "A"), point("c", 395, 292, "P")],
      lines: [{ id: "r", a: "a", b: "b" }],
      circles: [{ id: "circle", center: "a", edge: "b" }],
      polygons: [],
      arcs: [],
      loci: [],
      constraints: [{ id: "on-circle", type: "on-circle", point: "c", circle: "circle" }],
    });
  }
  if (templateId === "quadrilaterals") {
    return normalizeConstruction({
      points: [point("a", 190, 145, "A"), point("b", 420, 145, "B"), point("c", 490, 300, "C"), point("d", 260, 300, "D")],
      lines: [{ id: "ab", a: "a", b: "b" }, { id: "bc", a: "b", b: "c" }, { id: "cd", a: "c", b: "d" }, { id: "da", a: "d", b: "a" }],
      circles: [],
      polygons: [{ id: "quad", points: ["a", "b", "c", "d"], style: { fill: "rgba(6,182,212,.16)", color: "#06b6d4" } }],
      arcs: [],
      loci: [],
      constraints: [],
    });
  }
  if (templateId === "coordinate-geometry") {
    return normalizeConstruction({
      points: [point("a", 240, 260, "A"), point("b", 420, 140, "B")],
      lines: [{ id: "ab", a: "a", b: "b" }],
      circles: [],
      polygons: [],
      arcs: [],
      loci: [],
      constraints: [],
    });
  }
  return normalizeConstruction({
    points: [point("a", 220, 300, "A"), point("b", 420, 300, "B"), point("c", 330, 130, "C")],
    lines: [{ id: "ab", a: "a", b: "b" }, { id: "bc", a: "b", b: "c" }, { id: "ca", a: "c", b: "a" }],
    circles: [],
    polygons: [{ id: "poly", points: ["a", "b", "c"] }],
    arcs: [],
    loci: [],
    constraints: [],
  });
}

function resultsToCsv(results: ResultCard[]) {
  const rows = [["Input", "Interpretation", "Result", "Detail"], ...results.map((result) => [result.input, result.interpretation, result.result, result.detail ?? ""])];
  return rows.map((row) => row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(",")).join("\n");
}

function Toggle({ checked, label, onChange }: { checked: boolean; label: string; onChange: (checked: boolean) => void }) {
  return (
    <label className="flex items-center gap-2 rounded-2xl bg-slate-100 px-3 py-3 text-sm font-semibold dark:bg-white/10">
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      {label}
    </label>
  );
}

function InfoPill({ title, text }: { title: string; text: string }) {
  return <div className="rounded-2xl bg-slate-100 p-4 dark:bg-white/10"><p className="text-sm font-bold">{title}</p><p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-300">{text}</p></div>;
}

function CollapsibleSideCard({ children, className = "", defaultOpen = true, id, meta, subtitle, title }: { children: ReactNode; className?: string; defaultOpen?: boolean; id: string; meta?: ReactNode; subtitle?: string; title: string }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className={`rounded-2xl border border-slate-200 bg-white/80 p-3 text-sm shadow-sm dark:border-white/10 dark:bg-white/5 ${className}`}>
      <button type="button" onClick={() => setOpen((value) => !value)} className="flex w-full items-start justify-between gap-3 rounded-xl text-left transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-cyan-300 dark:hover:bg-white/5" aria-expanded={open} aria-controls={id}>
        <span className="min-w-0 p-1">
          <span className="block font-bold text-slate-900 dark:text-white">{title}</span>
          {subtitle && <span className="mt-1 block text-xs leading-5 text-slate-500 dark:text-slate-400">{subtitle}</span>}
        </span>
        <span className="flex shrink-0 items-center gap-2 p-1">
          {meta}
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-200">
            <ChevronDown className={`h-4 w-4 transition-transform ${open ? "" : "-rotate-90"}`} />
          </span>
        </span>
      </button>
      {open && <div id={id} className="mt-3">{children}</div>}
    </section>
  );
}

function _HorizontalPanelHeader({ title, side, onCollapse }: { title: string; side: "left" | "right"; onCollapse: () => void }) {
  const Icon = side === "left" ? PanelLeftClose : PanelRightClose;
  return (
    <div className="flex items-center justify-between gap-2 rounded-2xl border border-slate-200 bg-white/85 p-2 shadow-sm dark:border-white/10 dark:bg-white/5">
      <div className="min-w-0 px-2">
        <p className="text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">Horizontal panel</p>
        <h3 className="truncate text-sm font-black">{title}</h3>
      </div>
      <button type="button" onClick={onCollapse} className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-700 transition hover:bg-cyan-100 hover:text-cyan-800 dark:bg-white/10 dark:text-slate-200 dark:hover:bg-cyan-300/15" title={`Collapse ${title}`} aria-label={`Collapse ${title}`}>
        <Icon className="h-5 w-5" />
      </button>
    </div>
  );
}

function _Workspace3DProjectionPane({ view, selected, transform, surfaceScale, solid, solidSize, crossSection, showSurface, showSolid }: { view: "xy" | "xz"; selected: string; transform: Transform3D; surfaceScale: number; solid: SolidKind; solidSize: number; crossSection: number; showSurface: boolean; showSolid: boolean }) {
  const px = 170 + transform.position[0] * 18;
  const py = 150 - transform.position[1] * 18;
  const pz = 150 - transform.position[2] * 18;
  const solidRadius = Math.max(18, Math.min(82, solidSize * 18));
  const surfaceAmp = Math.max(8, Math.min(42, surfaceScale * 20));
  return (
    <section className="min-h-[560px] rounded-2xl border border-slate-200 bg-white p-3 shadow-sm dark:border-white/10 dark:bg-slate-950/55">
      {view === "xy" ? (
        <>
          <div className="flex items-start justify-between gap-3 rounded-xl bg-slate-50 p-3 dark:bg-white/5">
            <div className="min-w-0">
              <p className="text-xs font-black uppercase text-cyan-700 dark:text-cyan-200">2D Pane</p>
              <h3 className="text-sm font-black">Top View X-Y</h3>
            </div>
            <span className="mini-chip">{selected || "none"}</span>
          </div>
          <div id="workspace-xy-projection-pane">
            <svg viewBox="0 0 340 250" className="mt-3 h-[clamp(440px,calc(100vh-320px),760px)] w-full rounded-xl bg-slate-50 dark:bg-slate-900">
              <defs>
                <pattern id="workspace-3d-grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(100,116,139,.28)" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="340" height="250" fill="url(#workspace-3d-grid)" />
              <line x1="20" y1="125" x2="320" y2="125" stroke="#ef4444" strokeWidth="3" />
              <line x1="170" y1="230" x2="170" y2="20" stroke="#22c55e" strokeWidth="3" />
              <text x="300" y="116" fill="#ef4444" fontSize="14" fontWeight="800">x</text>
              <text x="178" y="32" fill="#22c55e" fontSize="14" fontWeight="800">y</text>
              {showSurface && <path d={`M 35 ${125 + surfaceAmp} C 80 ${90 - surfaceAmp}, 125 ${165 + surfaceAmp}, 170 125 S 260 ${85 - surfaceAmp}, 305 ${125 + surfaceAmp}`} fill="none" stroke="#06b6d4" strokeWidth="5" opacity="0.55" />}
              {showSolid && (solid === "cube" || solid === "cuboid" ? <rect x={170 - solidRadius / 2} y={125 - solidRadius / 2} width={solidRadius} height={solidRadius} fill="#f59e0b" opacity="0.42" stroke="#f59e0b" strokeWidth="3" /> : <circle cx="170" cy="125" r={solidRadius / 2} fill="#f59e0b" opacity="0.38" stroke="#f59e0b" strokeWidth="3" />)}
              <line x1="20" y1={125 - crossSection * 18} x2="320" y2={125 - crossSection * 18} stroke="#a855f7" strokeWidth="3" strokeDasharray="8 7" />
              <circle cx={px} cy={py} r="8" fill={transform.color} stroke="#0f172a" strokeWidth="2" />
            </svg>
            <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
              <MiniReadout label="x" value={transform.position[0]} />
              <MiniReadout label="y" value={transform.position[1]} />
              <MiniReadout label="scale" value={transform.scale} />
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="flex items-start justify-between gap-3 rounded-xl bg-slate-50 p-3 dark:bg-white/5">
            <div className="min-w-0">
              <p className="text-xs font-black uppercase text-violet-700 dark:text-violet-200">2D Pane</p>
              <h3 className="text-sm font-black">Side View X-Z</h3>
            </div>
            <span className="mini-chip">z {roundTo(crossSection, 2)}</span>
          </div>
          <div id="workspace-xz-projection-pane">
            <svg viewBox="0 0 340 250" className="mt-3 h-[clamp(440px,calc(100vh-320px),760px)] w-full rounded-xl bg-slate-50 dark:bg-slate-900">
              <defs>
                <pattern id="workspace-3d-grid-xz" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(100,116,139,.28)" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="340" height="250" fill="url(#workspace-3d-grid-xz)" />
              <line x1="20" y1="125" x2="320" y2="125" stroke="#ef4444" strokeWidth="3" />
              <line x1="170" y1="230" x2="170" y2="20" stroke="#38bdf8" strokeWidth="3" />
              <text x="300" y="116" fill="#ef4444" fontSize="14" fontWeight="800">x</text>
              <text x="178" y="32" fill="#38bdf8" fontSize="14" fontWeight="800">z</text>
              {showSurface && <path d={`M 35 ${125 + surfaceAmp} C 92 ${132 - surfaceAmp}, 130 ${82 + surfaceAmp}, 170 ${125 - surfaceAmp} S 255 ${168 - surfaceAmp}, 305 ${105 + surfaceAmp}`} fill="none" stroke="#06b6d4" strokeWidth="5" opacity="0.55" />}
              {showSolid && <rect x={170 - solidRadius / 2} y={125 - solidRadius / 2} width={solidRadius} height={solidRadius} rx="10" fill="#f59e0b" opacity="0.38" stroke="#f59e0b" strokeWidth="3" />}
              <line x1="20" y1={125 - crossSection * 18} x2="320" y2={125 - crossSection * 18} stroke="#a855f7" strokeWidth="3" strokeDasharray="8 7" />
              <circle cx={px} cy={pz} r="8" fill={transform.color} stroke="#0f172a" strokeWidth="2" />
            </svg>
            <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
              <MiniReadout label="x" value={transform.position[0]} />
              <MiniReadout label="z" value={transform.position[2]} />
              <MiniReadout label="size" value={solidSize} />
            </div>
          </div>
        </>
      )}
    </section>
  );
}

function objectStudioMeasurement(selected: string, transform: Transform3D, solid?: SolidKind, nlpCommand?:VisualCommand) {
  if(nlpCommand?.kind==='point')return {label:'point',volume:0,surfaceArea:0,detail:'Zero-dimensional point.'};
  if(nlpCommand&&['line','ray','vector'].includes(nlpCommand.kind)){const [a,b]=outlineVertices(nlpCommand);return {label:nlpCommand.kind,volume:0,surfaceArea:0,detail:nlpCommand.kind==='line'?'Line or segment; no surface area or volume':nlpCommand.kind==='ray'?'Unbounded ray, t ≥ 0':`Vector magnitude ${Math.hypot(...b.map((n,i)=>n-a[i]))}`};}
  if(nlpCommand)return intelligenceMeshMeasurement(nlpCommand,transform.dimensions??commandTransform3d(nlpCommand).dimensions,transform.scale);
  const kernelMeasurement = object3Measurement(transformToKernelObject(selected, transform));
  const dimensions = (transform.dimensions ?? [1, 1, 1]).map((value) => Math.max(0, value * transform.scale));
  const [width, height, depth] = dimensions;
  const result = (label: string, volume: number, surfaceArea: number) => ({ label, volume, surfaceArea, detail: `w=${roundTo(width, 2)}, h=${roundTo(height, 2)}, d=${roundTo(depth, 2)}` });
  if (!solid) return kernelMeasurement;
  if (solid === "cube" || solid === "cuboid") return result(solid, width * height * depth, 2 * (width * height + height * depth + width * depth));
  if (solid === "sphere") {
    const radius = width / 2;
    return result(solid, (4 / 3) * Math.PI * radius ** 3, 4 * Math.PI * radius ** 2);
  }
  if (solid === "ellipsoid") {
    const [a, b, c] = [width / 2, height / 2, depth / 2];
    const p = 1.6075;
    return result(solid, (4 / 3) * Math.PI * a * b * c, 4 * Math.PI * (((a * b) ** p + (a * c) ** p + (b * c) ** p) / 3) ** (1 / p));
  }
  if (solid === "hemisphere") {
    const radius = width / 2;
    return result(solid, (2 / 3) * Math.PI * radius ** 3, 3 * Math.PI * radius ** 2);
  }
  if (solid === "cylinder" || solid === "cone" || solid === "frustum") {
    const radius = width / 2;
    if (solid === "cylinder") return result(solid, Math.PI * radius ** 2 * height, 2 * Math.PI * radius * (radius + height));
    if (solid === "cone") return result(solid, Math.PI * radius ** 2 * height / 3, Math.PI * radius * (radius + Math.hypot(radius, height)));
    const topRadius = radius * (0.32 / 0.55);
    const slant = Math.hypot(radius - topRadius, height);
    return result(solid, Math.PI * height * (radius ** 2 + radius * topRadius + topRadius ** 2) / 3, Math.PI * (radius ** 2 + topRadius ** 2 + (radius + topRadius) * slant));
  }
  if (solid === "torus" || solid === "tube") {
    const size = width;
    const majorRadius = size * (solid === "torus" ? 0.34 : 0.4);
    const minorRadius = size * (solid === "torus" ? 0.12 : 0.06);
    return result(solid, 2 * Math.PI ** 2 * majorRadius * minorRadius ** 2, 4 * Math.PI ** 2 * majorRadius * minorRadius);
  }
  if (solid === "capsule") {
    const radius = width * 0.26;
    const body = height * 0.62;
    return result(solid, Math.PI * radius ** 2 * body + (4 / 3) * Math.PI * radius ** 3, 2 * Math.PI * radius * body + 4 * Math.PI * radius ** 2);
  }
  if (solid === "prism") {
    const side = Math.sqrt(3) * width / 2;
    const baseArea = Math.sqrt(3) * side ** 2 / 4;
    return result(solid, baseArea * height, 2 * baseArea + 3 * side * height);
  }
  if (solid === "pyramid") {
    const side = width / Math.SQRT2;
    const slant = Math.hypot(side / 2, height);
    return result(solid, side ** 2 * height / 3, side ** 2 + 2 * side * slant);
  }
  if (solid === "tetrahedron") {
    const edge = 4 * (width * 0.58) / Math.sqrt(6);
    return result(solid, edge ** 3 / (6 * Math.sqrt(2)), Math.sqrt(3) * edge ** 2);
  }
  if (solid === "octahedron") {
    const edge = width * 0.58 * Math.SQRT2;
    return result(solid, Math.SQRT2 * edge ** 3 / 3, 2 * Math.sqrt(3) * edge ** 2);
  }
  if (solid === "dodecahedron") {
    const edge = 2 * width / (Math.sqrt(3) * (1 + Math.sqrt(5)));
    return result(solid, (15 + 7 * Math.sqrt(5)) * edge ** 3 / 4, 3 * Math.sqrt(25 + 10 * Math.sqrt(5)) * edge ** 2);
  }
  if (solid === "polyhedron") {
    const edge = 2 * width / Math.sqrt(10 + 2 * Math.sqrt(5));
    return result("icosahedron", 5 * (3 + Math.sqrt(5)) * edge ** 3 / 12, 5 * Math.sqrt(3) * edge ** 2);
  }
  if (solid === "wedge") return result(solid, width * height * depth / 2, width * depth + 2 * Math.hypot(height, depth) * width / 2 + height * depth);
  return kernelMeasurement;
}

function workspaceViewForMode(mode: (typeof workspaceModeNavigation)[number]["mode"]): WorkspaceView {
  if (mode === "three-d") return "3d";
  if (mode === "teacher") return "teach";
  if (mode === "graph" || mode === "geometry" || mode === "data") return mode;
  return "graph";
}

function workspaceModeIcon(mode: (typeof workspaceModeNavigation)[number]["mode"]) {
  if (mode === "graph") return <FunctionSquare className="h-4 w-4" />;
  if (mode === "geometry") return <Pentagon className="h-4 w-4" />;
  if (mode === "three-d") return <Box className="h-4 w-4" />;
  if (mode === "data") return <LineChart className="h-4 w-4" />;
  return <Presentation className="h-4 w-4" />;
}

function MiniReadout({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl bg-slate-100 p-2 dark:bg-white/10">
      <p className="font-black uppercase text-slate-500 dark:text-slate-400">{label}</p>
      <p className="mt-1 font-mono font-black text-slate-950 dark:text-white">{roundTo(value, 2)}</p>
    </div>
  );
}

function ImageObjectPanel({ image, onChange, onDelete }: { image: WorkspaceImage | null; onChange: (patch: Partial<WorkspaceImage>) => void; onDelete: () => void }) {
  if (!image) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
        <h3 className="font-bold">Image Layer</h3>
        <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">Use Add Image to place a picture on the geometry board. Click an image to edit size, opacity, and lock state.</p>
      </div>
    );
  }
  return (
    <div className="rounded-2xl border border-cyan-300 bg-cyan-50/70 p-4 dark:border-cyan-300/40 dark:bg-cyan-400/10">
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-bold">Selected Image</h3>
        <button type="button" onClick={onDelete} className="rounded-full bg-rose-100 px-3 py-1.5 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">Delete</button>
      </div>
      <label className="mt-3 block text-xs font-bold uppercase text-slate-500 dark:text-slate-300">
        Name
        <input value={image.name} onChange={(event) => onChange({ name: event.target.value })} className="mt-1 w-full rounded-xl border border-slate-200 bg-white p-2 font-semibold normal-case dark:border-white/10 dark:bg-slate-900" />
      </label>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <MiniNumber label="x" value={roundTo(image.x, 1)} onChange={(x) => onChange({ x })} />
        <MiniNumber label="y" value={roundTo(image.y, 1)} onChange={(y) => onChange({ y })} />
        <MiniNumber label="width" value={roundTo(image.width, 1)} onChange={(width) => onChange({ width: Math.max(20, width) })} />
        <MiniNumber label="height" value={roundTo(image.height, 1)} onChange={(height) => onChange({ height: Math.max(20, height) })} />
      </div>
      <div className="mt-3">
        <SliderControl label="Opacity" value={image.opacity} min={0.1} max={1} step={0.05} onChange={(opacity) => onChange({ opacity })} />
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Toggle checked={image.visible !== false} label="Visible" onChange={(visible) => onChange({ visible })} />
        <Toggle checked={image.locked === true} label="Locked" onChange={(locked) => onChange({ locked })} />
      </div>
    </div>
  );
}

type SceneSetupTabs3DProps = {
  selected3d: string;
  selected3dTransform: Transform3D;
  surface: SurfaceKind;
  solid: SolidKind;
  surfaceExpression: string;
  surfaceScale: number;
  height3d: number;
  crossSection: number;
  sceneAnimationSpeed: number;
  showSurface: boolean;
  showSolid: boolean;
  autoRotate3d: boolean;
  cameraPreset3d: CameraPreset3D;
  onSurface: (value: SurfaceKind) => void;
  onSolid: (value: SolidKind) => void;
  onObject: (id: ThreeObjectId) => void;
  onSurfaceExpression: (value: string) => void;
  onSurfaceScale: (value: number) => void;
  onHeight: (value: number) => void;
  onCrossSection: (value: number) => void;
  onAnimationSpeed: (value: number) => void;
  onShowSurface: (value: boolean) => void;
  onShowSolid: (value: boolean) => void;
  onAutoRotate: (value: boolean) => void;
  onCamera: (preset: CameraPreset3D) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onReset: () => void;
  onSelectTool: () => void;
  onNudge: (axis: number, amount: number) => void;
  onRotateAxis: (axis: number, amount: number) => void;
  onScale: (amount: number) => void;
  onMaterial: (material: Transform3D["material"]) => void;
  onOpacity: (opacity: number) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onRestore: () => void;
  onLock: () => void;
  onTrace: () => void;
  onToggleSelectedVisibility: () => void;
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function SceneSetupTabs3D(props: SceneSetupTabs3DProps) {
  const [openSections, setOpenSections] = useState<Record<"surface" | "solid" | "parameters" | "camera", boolean>>({
    surface: false,
    solid: false,
    parameters: false,
    camera: false,
  });
  const toggleSection = (section: keyof typeof openSections) => setOpenSections((current) => ({ ...current, [section]: !current[section] }));
  return (
    <div className="space-y-3">
      <Space3DToolPalette
        activeObject={props.selected3d}
        selectedTransform={props.selected3dTransform}
        activeSurface={props.surface}
        activeSolid={props.solid}
        cameraPreset={props.cameraPreset3d}
        autoRotate={props.autoRotate3d}
        showSurface={props.showSurface}
        showSolid={props.showSolid}
        onSurface={props.onSurface}
        onSolid={props.onSolid}
        onObject={props.onObject}
        onCamera={props.onCamera}
        onToggleSurface={props.onShowSurface}
        onToggleSolid={props.onShowSolid}
        onToggleRotate={props.onAutoRotate}
        onSelectTool={props.onSelectTool}
        onZoomIn={props.onZoomIn}
        onZoomOut={props.onZoomOut}
        onReset={props.onReset}
        onNudge={props.onNudge}
        onRotateAxis={props.onRotateAxis}
        onScale={props.onScale}
        onMaterial={props.onMaterial}
        onOpacity={props.onOpacity}
        onDuplicate={props.onDuplicate}
        onDelete={props.onDelete}
        onRestore={props.onRestore}
        onLock={props.onLock}
        onTrace={props.onTrace}
        onToggleSelectedVisibility={props.onToggleSelectedVisibility}
      />
      <AccordionSection title="Surface" summary={surfaceFormula(props.surface, props.surfaceScale)} open={openSections.surface} onToggle={() => toggleSection("surface")}>
        <label className="block rounded-xl bg-slate-100 p-3 text-sm font-semibold dark:bg-white/10">
          Surface
          <select className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-slate-900" value={props.surface} onChange={(event) => props.onSurface(event.target.value as SurfaceKind)}>
            <option value="paraboloid">z = scale(x^2 + y^2)</option>
            <option value="saddle">z = scale(x^2 - y^2)</option>
            <option value="wave">z = scale sin(x) cos(y)</option>
            <option value="plane">z = scale(x + y)</option>
            <option value="ripple">z = scale sin(x^2+y^2)</option>
            <option value="cone-surface">z = scale sqrt(x^2+y^2)</option>
            <option value="custom-z">Custom z=f(x,y)</option>
            <option value="parametric">Parametric torus preset</option>
            <option value="implicit">Implicit sphere preset</option>
          </select>
          <input value={props.surfaceExpression} onChange={(event) => props.onSurfaceExpression(event.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 font-mono text-sm dark:border-white/10 dark:bg-slate-900" placeholder="sin(x) * cos(y)" />
        </label>
      </AccordionSection>
      <AccordionSection title="Solid" summary={props.solid} open={openSections.solid} onToggle={() => toggleSection("solid")}>
        <label className="block rounded-xl bg-slate-100 p-3 text-sm font-semibold dark:bg-white/10">
          Solid
          <select className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-slate-900" value={props.solid} onChange={(event) => props.onSolid(event.target.value as SolidKind)}>
            <option value="cube">Cube</option>
            <option value="cuboid">Cuboid</option>
            <option value="sphere">Sphere</option>
            <option value="ellipsoid">Ellipsoid</option>
            <option value="hemisphere">Hemisphere</option>
            <option value="cylinder">Cylinder</option>
            <option value="cone">Cone</option>
            <option value="frustum">Frustum</option>
            <option value="torus">Torus</option>
            <option value="tube">Tube</option>
            <option value="capsule">Capsule</option>
            <option value="prism">Prism</option>
            <option value="pyramid">Pyramid</option>
            <option value="tetrahedron">Tetrahedron</option>
            <option value="octahedron">Octahedron</option>
            <option value="dodecahedron">Dodecahedron</option>
            <option value="wedge">Wedge</option>
            <option value="polyhedron">Polyhedron</option>
          </select>
        </label>
      </AccordionSection>
      <AccordionSection title="3D scene parameters" summary={`scale ${props.surfaceScale}, height ${props.height3d}, z ${props.crossSection}`} open={openSections.parameters} onToggle={() => toggleSection("parameters")}>
        <div className="grid gap-3">
          <div className="rounded-xl border border-slate-200 bg-white/75 p-3 shadow-sm dark:border-white/10 dark:bg-slate-950/40">
            <div className="grid gap-x-4 gap-y-1">
              <SliderControl density="compact" label="Surface scale" value={props.surfaceScale} min={0.2} max={2.5} step={0.1} onChange={props.onSurfaceScale} />
              <SliderControl density="compact" label="Solid height / radius" value={props.height3d} min={0.8} max={5} step={0.1} onChange={props.onHeight} />
              <SliderControl density="compact" label="Cross-section z" value={props.crossSection} min={-3} max={3} step={0.1} onChange={props.onCrossSection} />
              <SliderControl density="compact" label="Scene animation speed" value={props.sceneAnimationSpeed} min={0} max={0.6} step={0.02} onChange={props.onAnimationSpeed} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 content-start">
            <Toggle checked={props.showSurface} label="Surface" onChange={props.onShowSurface} />
            <Toggle checked={props.showSolid} label="Solid" onChange={props.onShowSolid} />
            <Toggle checked={props.autoRotate3d} label="Auto rotate" onChange={props.onAutoRotate} />
            <button type="button" onClick={() => props.onAutoRotate(false)} className="rounded-2xl bg-slate-100 px-3 py-3 text-sm font-semibold dark:bg-white/10">Pause rotation</button>
            <button type="button" onClick={props.onReset} className="col-span-2 rounded-2xl bg-slate-100 px-3 py-3 text-sm font-semibold dark:bg-white/10">Reset view</button>
          </div>
        </div>
      </AccordionSection>
      <AccordionSection title="Camera" summary={props.cameraPreset3d} open={openSections.camera} onToggle={() => toggleSection("camera")}>
        <div className="grid gap-3">
          <CameraPresetPanel preset={props.cameraPreset3d} onPreset={props.onCamera} />
          <div className="grid content-start gap-2">
            <button type="button" onClick={props.onZoomOut} className="action-secondary"><ZoomOut className="h-4 w-4" />Zoom out</button>
            <button type="button" onClick={props.onZoomIn} className="action-secondary"><ZoomIn className="h-4 w-4" />Zoom in</button>
            <button type="button" onClick={props.onReset} className="action-secondary"><RotateCcw className="h-4 w-4" />Reset</button>
          </div>
        </div>
      </AccordionSection>
    </div>
  );
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function InspectorTabs3D({ selected, transform, transforms, addedObjects, onSelect, onTransform, onVector, onRestore, onDelete }: { selected: string; transform: Transform3D; transforms: Record<ThreeObjectId, Transform3D>; addedObjects: Added3DObject[]; onSelect: (id: string) => void; onTransform: (id: string, patch: Partial<Transform3D>) => void; onVector: (id: string, key: "position" | "rotation", index: number, value: number) => void; onRestore: (id: string) => void; onDelete: (id: string) => void }) {
  const [openSections, setOpenSections] = useState<Record<"object" | "transform" | "objects", boolean>>({
    object: true,
    transform: false,
    objects: true,
  });
  const toggleSection = (section: keyof typeof openSections) => setOpenSections((current) => ({ ...current, [section]: !current[section] }));
  return (
    <div className="space-y-2 rounded-2xl border border-slate-200 bg-white/80 p-3 shadow-sm dark:border-white/10 dark:bg-white/5">
      <AccordionSection title="3D scene objects" summary={`${addedObjects.length + 3} objects`} open={openSections.objects} onToggle={() => toggleSection("objects")}>
        <ObjectList3D selected={selected} transforms={transforms} addedObjects={addedObjects} onSelect={onSelect} onRestore={onRestore} onDelete={onDelete} />
      </AccordionSection>
      <AccordionSection title="Selected object" summary={selected || "none"} open={openSections.object} onToggle={() => toggleSection("object")}>
        <Properties3DPanel selected={selected} transform={transform} onTransform={onTransform} onVector={onVector} onRestore={onRestore} onDelete={onDelete} mode="object" />
      </AccordionSection>
      <AccordionSection title="Transform" summary={`x ${transform.position[0]}, y ${transform.position[1]}, z ${transform.position[2]}`} open={openSections.transform} onToggle={() => toggleSection("transform")}>
        <Properties3DPanel selected={selected} transform={transform} onTransform={onTransform} onVector={onVector} onRestore={onRestore} onDelete={onDelete} mode="transform" />
      </AccordionSection>
    </div>
  );
}

function AccordionSection({ title, summary, open, onToggle, children }: { title: string; summary?: string; open: boolean; onToggle: () => void; children: ReactNode }) {
  return (
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white/75 shadow-sm dark:border-white/10 dark:bg-slate-950/30">
      <button type="button" onClick={onToggle} className="flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left transition hover:bg-slate-50 dark:hover:bg-white/5" aria-expanded={open}>
        <span className="min-w-0">
          <span className="block text-sm font-black text-slate-950 dark:text-white">{title}</span>
          {summary && <span className="block truncate text-xs font-semibold text-slate-500 dark:text-slate-400">{summary}</span>}
        </span>
        <ChevronDown className={`h-4 w-4 shrink-0 text-slate-500 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && <div className="border-t border-slate-200 p-3 dark:border-white/10">{children}</div>}
    </section>
  );
}

function _PanelTabs<T extends string>({ active, tabs, onChange }: { active: T; tabs: Array<{ id: T; label: string }>; onChange: (id: T) => void }) {
  return (
    <div className="flex gap-1 overflow-x-auto rounded-xl bg-slate-100 p-1 dark:bg-white/10">
      {tabs.map((item) => (
        <button key={item.id} type="button" onClick={() => onChange(item.id)} className={`whitespace-nowrap rounded-lg px-3 py-2 text-xs font-black transition ${active === item.id ? "bg-white text-slate-950 shadow-sm dark:bg-slate-950 dark:text-white" : "text-slate-600 hover:bg-white/70 dark:text-slate-300 dark:hover:bg-white/10"}`}>
          {item.label}
        </button>
      ))}
    </div>
  );
}

function _ThreeCreationPanel({ onCreate }: { onCreate: (id: ThreeObjectId) => void }) {
  const tools: { id: ThreeObjectId; label: string }[] = [
    { id: "point", label: "Point" },
    { id: "vector", label: "Vector" },
    { id: "line3d", label: "Line" },
    { id: "plane3d", label: "Plane" },
    { id: "sphere3d", label: "Sphere" },
    { id: "cone3d", label: "Cone" },
    { id: "cylinder3d", label: "Cylinder" },
    { id: "prism3d", label: "Prism" },
    { id: "pyramid3d", label: "Pyramid" },
    { id: "polyhedron3d", label: "Polyhedron" },
  ];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/70 p-4 dark:border-white/10 dark:bg-slate-950/40">
      <h3 className="font-bold">3D construction tools</h3>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {tools.map((tool) => <button key={tool.id} type="button" onClick={() => onCreate(tool.id)} className="rounded-2xl bg-slate-100 px-3 py-2 text-sm font-semibold dark:bg-white/10">{tool.label}</button>)}
      </div>
    </div>
  );
}

function CameraPresetPanel({ preset, onPreset }: { preset: CameraPreset3D; onPreset: (preset: CameraPreset3D) => void }) {
  const presets: CameraPreset3D[] = ["top", "front", "right", "isometric", "free"];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/70 p-4 dark:border-white/10 dark:bg-slate-950/40">
      <h3 className="font-bold">Camera presets</h3>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {presets.map((item) => <button key={item} type="button" onClick={() => onPreset(item)} className={`rounded-2xl px-3 py-2 text-xs font-bold uppercase ${preset === item ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950" : "bg-slate-100 dark:bg-white/10"}`}>{item}</button>)}
      </div>
    </div>
  );
}

function ObjectList3D({ selected, transforms, addedObjects, onSelect, onRestore, onDelete }: { selected: string; transforms: Record<ThreeObjectId, Transform3D>; addedObjects: Added3DObject[]; onSelect: (id: string) => void; onRestore: (id: string) => void; onDelete: (id: string) => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-bold">3D Scene Objects</h3>
        <button type="button" onClick={() => { threeBaseIds.forEach(onRestore); addedObjects.forEach((object) => onRestore(object.id)); }} className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold dark:bg-white/10">Restore all</button>
      </div>
      <div className="mt-3 max-h-[28vh] space-y-2 overflow-y-auto pr-1">
        {threeBaseIds.map((id) => (
          <div key={id} className={`rounded-xl border p-3 ${selected === id ? "border-cyan-400 bg-cyan-50 dark:bg-cyan-400/10" : "border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-slate-900/50"}`}>
            <button type="button" onClick={() => onSelect(id)} className="w-full text-left">
              <p className="text-sm font-bold">{threeObjectLabels[id]}</p>
              <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400">pos ({transforms[id].position.map((value) => roundTo(value, 2)).join(", ")}), scale {roundTo(transforms[id].scale, 2)}</p>
            </button>
            <div className="mt-2 flex gap-2">
              <button type="button" onClick={() => onRestore(id)} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-white/10">Restore</button>
              <button type="button" onClick={() => onDelete(id)} className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">{transforms[id].visible ? "Hide" : "Hide"}</button>
            </div>
          </div>
        ))}
        {addedObjects.map((object) => (
          <div key={object.id} className={`rounded-xl border p-3 ${selected === object.id ? "border-cyan-400 bg-cyan-50 dark:bg-cyan-400/10" : "border-slate-200 bg-slate-50 dark:border-white/10 dark:bg-slate-900/50"}`}>
            <button type="button" onClick={() => onSelect(object.id)} className="w-full text-left">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-bold">{object.transform.name ?? object.label}</p>
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-black uppercase text-emerald-800 dark:bg-emerald-400/15 dark:text-emerald-100">Added</span>
              </div>
              <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400">pos ({object.transform.position.map((value) => roundTo(value, 2)).join(", ")}), scale {roundTo(object.transform.scale, 2)}</p>
            </button>
            <div className="mt-2 flex gap-2">
              <button type="button" onClick={() => onRestore(object.id)} className="rounded-full bg-white px-3 py-1 text-xs font-bold dark:bg-white/10">Restore</button>
              <button type="button" onClick={() => onDelete(object.id)} className="rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Properties3DPanel({ selected, transform, onTransform, onVector, onRestore, onDelete, mode = "full" }: { selected: string; transform: Transform3D; onTransform: (id: string, patch: Partial<Transform3D>) => void; onVector: (id: string, key: "position" | "rotation", index: number, value: number) => void; onRestore: (id: string) => void; onDelete: (id: string) => void; mode?: "full" | "object" | "transform" }) {
  if (!selected) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
        <div className="flex items-center justify-between gap-2">
          <h3 className="font-bold">Selected Object</h3>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-white/10 dark:text-slate-300">none</span>
        </div>
        <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Select a 3D object to edit position, rotation, scale, material, opacity, or dimensions. Press Escape to stay deselected.</p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-bold">Selected Object</h3>
        <span className="rounded-full bg-cyan-100 px-3 py-1 text-xs font-bold text-cyan-800 dark:bg-cyan-400/15 dark:text-cyan-100">{selected}</span>
      </div>
      {mode !== "transform" && (
        <>
          <label className="mt-3 block rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
            Name
            <input value={transform.name ?? selected} onChange={(event) => onTransform(selected, { name: event.target.value || selected })} className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-slate-900" />
          </label>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {(["x", "y", "z"] as const).map((axis, index) => <MiniNumber key={`pos-${axis}`} label={axis} value={roundTo(transform.position[index], 2)} onChange={(value) => onVector(selected, "position", index, value)} />)}
          </div>
          <p className="mt-4 text-xs font-bold uppercase text-slate-500 dark:text-slate-400">Rotation</p>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {(["x deg", "y deg", "z deg"] as const).map((axis, index) => <MiniNumber key={`rot-${axis}`} label={axis} value={roundTo(transform.rotation[index], 1)} onChange={(value) => onVector(selected, "rotation", index, value)} />)}
          </div>
          <label className="mt-3 block rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
            Color
            <input type="color" value={transform.color} onChange={(event) => onTransform(selected, { color: event.target.value })} className="mt-2 h-10 w-full rounded-lg border border-slate-200 bg-white dark:border-white/10 dark:bg-slate-900" />
          </label>
          <div className="mt-3 rounded-xl bg-slate-100 p-2 dark:bg-white/10">
            <p className="text-xs font-bold text-slate-600 dark:text-slate-300">Appearance</p>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {(["matte", "glass", "wireframe"] as const).map((material) => (
                <button key={material} type="button" onClick={() => onTransform(selected, { material })} className={`rounded-xl px-2 py-2 text-xs font-black capitalize transition ${(transform.material ?? "glass") === material ? "bg-violet-400 text-slate-950 shadow-sm" : "bg-white text-slate-700 hover:bg-violet-50 dark:bg-slate-950/70 dark:text-slate-200 dark:hover:bg-violet-300/10"}`}>
                  {material}
                </button>
              ))}
            </div>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {[
                { label: "Opacity 100", value: 1 },
                { label: "Opacity 55", value: 0.55 },
                { label: "Opacity 25", value: 0.25 },
              ].map((item) => (
                <button key={item.label} type="button" onClick={() => onTransform(selected, { opacity: item.value })} className={`rounded-xl px-2 py-2 text-xs font-black transition ${roundTo(transform.opacity ?? 0.8, 2) === item.value ? "bg-violet-400 text-slate-950 shadow-sm" : "bg-white text-slate-700 hover:bg-violet-50 dark:bg-slate-950/70 dark:text-slate-200 dark:hover:bg-violet-300/10"}`}>
                  {item.label}
                </button>
              ))}
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => onTransform(selected, { locked: !transform.locked })} className={`rounded-xl px-2 py-2 text-xs font-black transition ${transform.locked ? "bg-violet-400 text-slate-950 shadow-sm" : "bg-white text-slate-700 hover:bg-violet-50 dark:bg-slate-950/70 dark:text-slate-200 dark:hover:bg-violet-300/10"}`}>
                {transform.locked ? "Locked" : "Lock"}
              </button>
              <button type="button" onClick={() => onTransform(selected, { trace: !transform.trace })} className={`rounded-xl px-2 py-2 text-xs font-black transition ${transform.trace ? "bg-violet-400 text-slate-950 shadow-sm" : "bg-white text-slate-700 hover:bg-violet-50 dark:bg-slate-950/70 dark:text-slate-200 dark:hover:bg-violet-300/10"}`}>
                {transform.trace ? "Trace on" : "Trace"}
              </button>
            </div>
          </div>
        </>
      )}
      {mode !== "object" && (
        <>
          <div className="mt-4">
            <SliderControl density="compact" label="Size" value={transform.scale} min={0.2} max={3} step={0.05} onChange={(value) => onTransform(selected, { scale: value })} />
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {(["width", "height", "depth"] as const).map((axis, index) => <MiniNumber key={`dim-${axis}`} label={axis} value={roundTo(transform.dimensions?.[index] ?? 1, 2)} onChange={(value) => {
              const next = [...(transform.dimensions ?? [1, 1, 1])] as [number, number, number];
              next[index] = value;
              onTransform(selected, { dimensions: next });
            }} />)}
          </div>
          <div className="mt-4 grid gap-3">
            <SliderControl density="compact" label="Opacity" value={transform.opacity ?? 0.8} min={0.1} max={1} step={0.05} onChange={(value) => onTransform(selected, { opacity: value })} />
            <label className="rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
              Material
              <select value={transform.material ?? "glass"} onChange={(event) => onTransform(selected, { material: event.target.value as Transform3D["material"] })} className="mt-2 w-full rounded-lg border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-slate-900">
                <option value="matte">Matte</option>
                <option value="glass">Glass</option>
                <option value="wireframe">Wireframe</option>
              </select>
            </label>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <button type="button" onClick={() => onVector(selected, "position", 0, roundTo(transform.position[0] + 0.25, 2))} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">+X</button>
            <button type="button" onClick={() => onVector(selected, "position", 1, roundTo(transform.position[1] + 0.25, 2))} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">+Y</button>
            <button type="button" onClick={() => onVector(selected, "position", 2, roundTo(transform.position[2] + 0.25, 2))} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">+Z</button>
            <button type="button" onClick={() => onVector(selected, "rotation", 1, roundTo(transform.rotation[1] + 15, 1))} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">Rot Y</button>
            <button type="button" onClick={() => onTransform(selected, { scale: roundTo(transform.scale + 0.1, 2) })} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">Scale +</button>
            <button type="button" onClick={() => onTransform(selected, { scale: Math.max(0.1, roundTo(transform.scale - 0.1, 2)) })} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">Scale -</button>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <button type="button" onClick={() => onTransform(selected, { visible: !transform.visible })} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">{transform.visible ? "Hide" : "Show"}</button>
            <button type="button" onClick={() => onRestore(selected)} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">Restore</button>
            <button type="button" onClick={() => onDelete(selected)} className="rounded-2xl bg-rose-100 px-3 py-2 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">Delete</button>
          </div>
        </>
      )}
    </div>
  );
}

function GeometryObjectPanel({ selected, construction, locked, onPointChange, onStyleChange, onRadiusChange, onDuplicate, onDelete, onRestore, onToggleLock }: { selected: SelectedGeometryObject | null; construction: Construction; locked: boolean; onPointChange: (patch: Partial<GeoPoint>) => void; onStyleChange: (patch: GeoStyle) => void; onRadiusChange: (radiusUnits: number) => void; onDuplicate: () => void; onDelete: () => void; onRestore: () => void; onToggleLock: () => void }) {
  const object = selected ? geometryObjectBySelection(construction, selected) : null;
  const style = object?.style ?? {};
  const point = selected?.type === "point" ? pointById(construction.points, selected.id) : null;
  const radius = selected?.type === "circle" ? circleRadiusUnits(construction, selected.id) : null;
  return (
    <div className="geometry-object-properties rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-bold">Object Properties</h3>
        {selected && <span className="rounded-full bg-cyan-100 px-3 py-1 text-xs font-bold text-cyan-800 dark:bg-cyan-400/15 dark:text-cyan-100">{selected.type}</span>}
      </div>
      {!selected || !object ? (
        <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Select a point, line, circle, or polygon to modify x/y, size, color, visibility, lock, duplicate, restore, or delete.</p>
      ) : (
        <div className="mt-3 space-y-3">
          {point && (
            <>
              <label className="block rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
                Label
                <input value={point.label} onChange={(event) => onPointChange({ label: event.target.value.slice(0, 3) || point.label })} className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-slate-900" />
              </label>
              <div className="grid grid-cols-2 gap-2">
                <MiniNumber label="x" value={roundTo(point.x, 1)} onChange={(value) => onPointChange({ x: value })} />
                <MiniNumber label="y" value={roundTo(point.y, 1)} onChange={(value) => onPointChange({ y: value })} />
              </div>
            </>
          )}
          {radius !== null && <SliderControl label="Radius" value={radius} min={0.25} max={8} step={0.05} onChange={onRadiusChange} />}
          <div className="grid grid-cols-1 gap-3">
            <GeometryAppearanceControls value={{...style,lineStyle:style.lineStyle??(style.dashArray?"dashed":"solid")}} onChange={patch=>onStyleChange({...style,...patch,dashArray:patch.lineStyle==="solid"?"":patch.lineStyle==="dashed"?"12 8":patch.lineStyle==="dotted"?"2 7":style.dashArray})}/><SliderControl label="Size / stroke" value={style.size ?? style.strokeWidth ?? 9} min={2} max={24} step={1} onChange={(value) => onStyleChange(selected.type === "point" ? { ...style, size: value } : { ...style, strokeWidth: value })} />
            <label className="rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
              Color
              <input type="color" value={style.color ?? geometryDefaultColor[selected.type]} onChange={(event) => onStyleChange({ ...style, color: event.target.value })} className="mt-2 h-10 w-full rounded-lg border border-slate-200 bg-white dark:border-white/10 dark:bg-slate-900" />
            </label>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <SliderControl label="Opacity" value={style.opacity ?? 1} min={0.1} max={1} step={0.05} onChange={(value) => onStyleChange({ ...style, opacity: value })} />
            <label className="rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
              Fill
              <input type="color" value={normalizeColor(style.fill) ?? "#bae6fd"} onChange={(event) => onStyleChange({ ...style, fill: `${event.target.value}55` })} className="mt-2 h-10 w-full rounded-lg border border-slate-200 bg-white dark:border-white/10 dark:bg-slate-900" />
            </label>
          </div>
          <label className="block rounded-xl bg-slate-100 p-2 text-xs font-bold dark:bg-white/10">
            Label mode
            <select value={style.labelMode ?? "name"} onChange={(event) => onStyleChange({ ...style, labelMode: event.target.value as GeoStyle["labelMode"] })} className="mt-1 w-full rounded-lg border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-slate-900">
              <option value="name">Name</option>
              <option value="value">Value</option>
              <option value="both">Name and value</option>
              <option value="hidden">Hidden</option>
            </select>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => onStyleChange({ ...style, visible: style.visible === false })} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">{style.visible === false ? "Show" : "Hide"}</button>
            <button type="button" onClick={onToggleLock} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">{locked ? "Unlock" : "Lock"}</button>
            <button type="button" onClick={() => onStyleChange({ ...style, trace: !style.trace })} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">{style.trace ? "Trace on" : "Trace"}</button>
            <button type="button" onClick={onDuplicate} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">Duplicate</button>
            <button type="button" onClick={onRestore} className="rounded-2xl bg-slate-100 px-3 py-2 text-xs font-bold dark:bg-white/10">Restore</button>
            <button type="button" onClick={onDelete} className="col-span-2 rounded-2xl bg-rose-100 px-3 py-2 text-xs font-bold text-rose-700 dark:bg-rose-400/15 dark:text-rose-100">Delete</button>
          </div>
        </div>
      )}
    </div>
  );
}

function ObjectContextMenu({ state, onClose, onDuplicate, onDelete, onRestore, onLock, onRename, onTrace }: { state: ContextMenuState; onClose: () => void; onDuplicate: () => void; onDelete: () => void; onRestore: () => void; onLock: () => void; onRename: () => void; onTrace: () => void }) {
  const is3d = state.target.type === "3d";
  const workflowType = workflowTypeForContextTarget(state.target);
  const menuActions = contextMenuForObject(workflowType);
  return (
    <div className="fixed inset-0 z-50" onClick={onClose} onContextMenu={(event) => event.preventDefault()}>
      <div className="absolute min-w-48 rounded-xl border border-slate-200 bg-white p-2 text-sm shadow-2xl shadow-slate-950/20 dark:border-white/10 dark:bg-slate-950" style={{ left: state.x, top: state.y }}>
        <button type="button" onClick={onRename} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Rename</button>
        {menuActions.includes("edit-definition") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Edit definition</button>}
        {menuActions.includes("properties") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Properties</button>}
        <button type="button" onClick={onDuplicate} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Duplicate</button>
        <button type="button" onClick={onRestore} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Restore defaults</button>
        <button type="button" onClick={onLock} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">{is3d ? "Lock object" : "Lock / unlock"}</button>
        {menuActions.includes("trace") && <button type="button" onClick={onTrace} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Trace on</button>}
        {menuActions.includes("animation") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Animate</button>}
        {menuActions.includes("measure") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Measure</button>}
        {menuActions.includes("create-locus") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Create locus</button>}
        {menuActions.includes("attach-note") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Attach note</button>}
        {menuActions.includes("export-selected") && <button type="button" onClick={onClose} className="block w-full rounded-lg px-3 py-2 text-left font-semibold hover:bg-slate-100 dark:hover:bg-white/10">Export selected</button>}
        <button type="button" onClick={onDelete} className="block w-full rounded-lg px-3 py-2 text-left font-semibold text-rose-700 hover:bg-rose-50 dark:text-rose-100 dark:hover:bg-rose-400/15">Delete / hide</button>
      </div>
    </div>
  );
}

function workflowTypeForContextTarget(target: ContextMenuState["target"]): WorkflowObjectType {
  if (target.type === "3d") return "3d";
  if (target.type === "algebra") {
    const kind = target.ref.kind;
    return kind === "3d" ? "3d" : kind === "point" || kind === "line" || kind === "circle" || kind === "polygon" || kind === "arc" || kind === "locus" ? kind : "algebra";
  }
  return target.type;
}

function Workspace3DScene({ surface, surfaceExpression, solid, surfaceScale, solidSize, crossSection, showSurface, showSolid, autoRotate, animationSpeed, zoom, performanceMode, cameraPreset, selected, transforms, addedObjects, dragging, interactionTool, snapStep, vectorWorkbench, onSelect, onDrag, onTransform, onContextMenu }: { surface: SurfaceKind; surfaceExpression: string; solid: SolidKind; surfaceScale: number; solidSize: number; crossSection: number; showSurface: boolean; showSolid: boolean; autoRotate: boolean; animationSpeed: number; zoom: number; performanceMode: boolean; cameraPreset: CameraPreset3D; selected: string; transforms: Record<ThreeObjectId, Transform3D>; addedObjects: Added3DObject[]; dragging: string | null; interactionTool: ObjectStudioTool; snapStep: number; vectorWorkbench: { a: Vector3Tuple; b: Vector3Tuple; view: VectorView3D; visible: boolean; focus: boolean }; onSelect: (id: string) => void; onDrag: (id: string | null) => void; onTransform: (id: string, patch: Partial<Transform3D>) => void; onContextMenu: (event: ThreeEvent<MouseEvent>, id: string) => void }) {
  const groupRef = useRef<THREE.Group>(null);
  const {camera,gl}=useThree();
  useRoboThreeAwareness('geometry3d',id=>{const t=isBase3dId(id)?transforms[id]:addedObjects.find(o=>o.id===id)?.transform;return {label:t?.name??id,kind:isBase3dId(id)?id:addedObjects.find(o=>o.id===id)?.nlpCommand?.kind??'3D object',selected:id===selected};});
  useEffect(()=>registerRoboProjector('geometry3d',p=>{const group=groupRef.current;if(!group)return;group.updateWorldMatrix(true,false);const v=group.localToWorld(new THREE.Vector3(p[0],p[1],p[2]??0)).project(camera);if(v.z < -1 || v.z > 1)return;const r=gl.domElement.getBoundingClientRect();return {x:r.left+(v.x+1)*r.width/2,y:r.top+(1-v.y)*r.height/2};}),[camera,gl]);
  const selectedTarget=useRef<{point:number[]}>({point:[0,0,0]});
  selectedTarget.current.point=(isBase3dId(selected)?transforms[selected]:addedObjects.find(o=>o.id===selected)?.transform)?.position??[0,0,0];
  useEffect(()=>{roboEvents.emit({type:'workspace',kind:'selection',target:()=>{const group=groupRef.current;if(!group)return;group.updateWorldMatrix(true,false);const v=group.localToWorld(new THREE.Vector3(...selectedTarget.current.point as [number,number,number])).project(camera);const r=gl.domElement.getBoundingClientRect();return {x:r.left+(v.x+1)*r.width/2,y:r.top+(1-v.y)*r.height/2};}});},[selected,camera,gl]);
  const manipulationStart = useRef<{ id: string; point: THREE.Vector3; transform: Transform3D } | null>(null);
  useEffect(() => {
    const releaseDrag = () => { manipulationStart.current = null; onDrag(null); };
    window.addEventListener("pointerup", releaseDrag);
    window.addEventListener("pointercancel", releaseDrag);
    window.addEventListener("blur", releaseDrag);
    return () => {
      window.removeEventListener("pointerup", releaseDrag);
      window.removeEventListener("pointercancel", releaseDrag);
      window.removeEventListener("blur", releaseDrag);
    };
  }, [onDrag]);
  useFrame((state) => {
    if (!groupRef.current) return;
    const baseRotation = cameraPresetRotation(cameraPreset);
    groupRef.current.rotation.set(...baseRotation);
    if (autoRotate) groupRef.current.rotation.y = baseRotation[1] + state.clock.getElapsedTime() * animationSpeed;
  });
  const transformForId = (id: string) => isBase3dId(id) ? transforms[id] : addedObjects.find((object) => object.id === id)?.transform;
  const selectProps = (id: string) => ({
    userData: { immersiveId: id },
    onClick: (event: ThreeEvent<MouseEvent>) => { event.stopPropagation(); onSelect(id); },
    onContextMenu: (event: ThreeEvent<MouseEvent>) => onContextMenu(event, id),
    onPointerDown: (event: ThreeEvent<PointerEvent>) => {
      if (!["select", "move", "rotate", "scale"].includes(interactionTool)) return;
      event.stopPropagation();
      onSelect(id);
      if (event.button !== 0 || interactionTool === "select") return;
      const current = transformForId(id);
      if (current?.locked) return;
      if (event.target instanceof Element && "setPointerCapture" in event.target) {
        (event.target as Element & { setPointerCapture: (pointerId: number) => void }).setPointerCapture(event.pointerId);
      }
      if (current) manipulationStart.current = { id, point: event.point.clone(), transform: { ...current, position: [...current.position], rotation: [...current.rotation] } };
      onDrag(id);
    },
    onPointerUp: (event: ThreeEvent<PointerEvent>) => { event.stopPropagation(); manipulationStart.current = null; onDrag(null); },
    onPointerCancel: (event: ThreeEvent<PointerEvent>) => { event.stopPropagation(); manipulationStart.current = null; onDrag(null); },
    onPointerLeave: () => {
      if (dragging === id) onDrag(null);
    },
    onPointerMove: (event: ThreeEvent<PointerEvent>) => {
      if (dragging !== id || id === "vector") return;
      event.stopPropagation();
      const current = transformForId(id);
      const start = manipulationStart.current;
      if (!current || !start || start.id !== id) return;
      if (current.locked || event.buttons !== 1) {
        manipulationStart.current = null;
        onDrag(null);
        return;
      }
      const dx = event.point.x - start.point.x;
      const dz = event.point.z - start.point.z;
      if (interactionTool === "move") {
        const nextX = start.transform.position[0] + dx;
        const nextZ = start.transform.position[2] + dz;
        onTransform(id, { position: [snap3dValue(nextX, snapStep), start.transform.position[1], snap3dValue(nextZ, snapStep)] });
      }
      if (interactionTool === "rotate") {
        const nextRotation = start.transform.rotation[1] + (dx - dz) * 22;
        onTransform(id, { rotation: [start.transform.rotation[0], snap3dValue(nextRotation, snapStep > 0 ? 15 : 0), start.transform.rotation[2]] });
      }
      if (interactionTool === "scale") {
        const nextScale = Math.max(0.1, start.transform.scale * (1 + (dx - dz) * 0.18));
        onTransform(id, { scale: snap3dValue(nextScale, snapStep > 0 ? 0.1 : 0) });
      }
    },
  });

  return (
    <group ref={groupRef} scale={zoom}>
      <Axes3D />
      <gridHelper args={[10, 10, "#334155", "#1e293b"]} rotation={[0, 0, 0]} />
      {vectorWorkbench.visible && <VectorWorkbenchOverlay3D a={vectorWorkbench.a} b={vectorWorkbench.b} view={vectorWorkbench.view} focus={vectorWorkbench.focus} />}
      <group visible={!vectorWorkbench.focus}>
      {showSurface && transforms.surface.visible && <TransformGroup3D transform={transforms.surface} selected={selected === "surface"}><SurfaceMesh surface={surface} expression={surfaceExpression} scaleValue={surfaceScale} transform={transforms.surface} performanceMode={performanceMode} eventProps={selectProps("surface")} /></TransformGroup3D>}
      {showSolid && transforms.solid.visible && <TransformGroup3D transform={transforms.solid} selected={selected === "solid"} yOffset={solidSize / 4}><SolidMesh solid={solid} size={solidSize} transform={transforms.solid} animate={autoRotate} eventProps={selectProps("solid")} /></TransformGroup3D>}
      {transforms.slice.visible && <TransformGroup3D transform={{ ...transforms.slice, position: [transforms.slice.position[0], crossSection + transforms.slice.position[1], transforms.slice.position[2]] }} selected={selected === "slice"}><CrossSectionPlane color={transforms.slice.color} eventProps={selectProps("slice")} /></TransformGroup3D>}
      {transforms.vector.visible && <TransformGroup3D transform={transforms.vector} selected={selected === "vector"}><VectorArrow start={[-3, 0.05, -3]} end={transforms.point.position} color={transforms.vector.color} eventProps={selectProps("vector")} /></TransformGroup3D>}
      {transforms.point.visible && <TransformGroup3D transform={transforms.point} selected={selected === "point"}><Point3D label="P" color={transforms.point.color} eventProps={selectProps("point")} /></TransformGroup3D>}
      {transforms.line3d.visible && <TransformGroup3D transform={transforms.line3d} selected={selected === "line3d"}><Line3D transform={transforms.line3d} eventProps={selectProps("line3d")} /></TransformGroup3D>}
      {transforms.plane3d.visible && <TransformGroup3D transform={transforms.plane3d} selected={selected === "plane3d"}><Plane3D transform={transforms.plane3d} eventProps={selectProps("plane3d")} /></TransformGroup3D>}
      {transforms.sphere3d.visible && <TransformGroup3D transform={transforms.sphere3d} selected={selected === "sphere3d"}><ConstructedSolid3D kind="sphere" transform={transforms.sphere3d} eventProps={selectProps("sphere3d")} /></TransformGroup3D>}
      {transforms.cone3d.visible && <TransformGroup3D transform={transforms.cone3d} selected={selected === "cone3d"}><ConstructedSolid3D kind="cone" transform={transforms.cone3d} eventProps={selectProps("cone3d")} /></TransformGroup3D>}
      {transforms.cylinder3d.visible && <TransformGroup3D transform={transforms.cylinder3d} selected={selected === "cylinder3d"}><ConstructedSolid3D kind="cylinder" transform={transforms.cylinder3d} eventProps={selectProps("cylinder3d")} /></TransformGroup3D>}
      {transforms.prism3d.visible && <TransformGroup3D transform={transforms.prism3d} selected={selected === "prism3d"}><ConstructedSolid3D kind="prism" transform={transforms.prism3d} eventProps={selectProps("prism3d")} /></TransformGroup3D>}
      {transforms.pyramid3d.visible && <TransformGroup3D transform={transforms.pyramid3d} selected={selected === "pyramid3d"}><ConstructedSolid3D kind="pyramid" transform={transforms.pyramid3d} eventProps={selectProps("pyramid3d")} /></TransformGroup3D>}
      {transforms.polyhedron3d.visible && <TransformGroup3D transform={transforms.polyhedron3d} selected={selected === "polyhedron3d"}><ConstructedSolid3D kind="polyhedron" transform={transforms.polyhedron3d} eventProps={selectProps("polyhedron3d")} /></TransformGroup3D>}
      {addedObjects.map((object) => <group key={object.id} userData={{ruhiObjectId:object.id}}><AddedSceneObject3D object={object} selected={selected === object.id} surfaceScale={surfaceScale} solidSize={solidSize} crossSection={crossSection} performanceMode={performanceMode} eventProps={selectProps(object.id)} /></group>)}
      <CinematicThreePreview mode="geometry3d"/>
      <IntersectionOverlays3D transforms={transforms} crossSection={crossSection} />
      <MeasurementOverlays3D transforms={transforms} />
      </group>
    </group>
  );
}

function AddedSceneObject3D({ object, selected, surfaceScale, solidSize, crossSection, performanceMode, eventProps }: { object: Added3DObject; selected: boolean; surfaceScale: number; solidSize: number; crossSection: number; performanceMode: boolean; eventProps: Record<string, unknown> }) {
  if (!object.transform.visible) return null;
  if(object.nlpCommand&&['line','ray','vector'].includes(object.nlpCommand.kind)){const c=object.nlpCommand,ctr=commandTransform3d(c).position;return <TransformGroup3D transform={object.transform} selected={selected}><DirectedObject3D command={{...c,points:c.points.map(p=>p.map((n,i)=>n-ctr[i])),scale:1,rotation:[0,0,0],color:object.transform.color}} eventProps={eventProps}/></TransformGroup3D>;}
  if(object.nlpCommand?.kind==='point')return <TransformGroup3D transform={object.transform} selected={selected}><Point3D label={object.nlpCommand.roboLabel??'P'} color={object.transform.color} eventProps={eventProps}/></TransformGroup3D>;
  if(object.nlpCommand) return <TransformGroup3D transform={object.transform} selected={selected}><IntelligenceShapeMesh command={object.nlpCommand} transform={object.transform} eventProps={eventProps}/></TransformGroup3D>;
  if (object.render === "surface") return <TransformGroup3D transform={object.transform} selected={selected}><SurfaceMesh surface={object.surface ?? "paraboloid"} expression="sin(x) * cos(y)" scaleValue={surfaceScale} transform={object.transform} performanceMode={performanceMode} eventProps={eventProps} /></TransformGroup3D>;
  if (object.render === "slice") return <TransformGroup3D transform={{ ...object.transform, position: [object.transform.position[0], crossSection + object.transform.position[1], object.transform.position[2]] }} selected={selected}><CrossSectionPlane color={object.transform.color} eventProps={eventProps} /></TransformGroup3D>;
  if (object.render === "point") return <TransformGroup3D transform={object.transform} selected={selected}><Point3D label={object.transform.name ?? object.label} color={object.transform.color} eventProps={eventProps} /></TransformGroup3D>;
  if (object.render === "vector") return <TransformGroup3D transform={object.transform} selected={selected}><VectorArrow start={[-2, 0.05, -2]} end={[2, 1.2, 1.5]} color={object.transform.color} eventProps={eventProps} /></TransformGroup3D>;
  if (object.render === "line3d") return <TransformGroup3D transform={object.transform} selected={selected}><Line3D transform={object.transform} eventProps={eventProps} /></TransformGroup3D>;
  if (object.render === "plane3d") return <TransformGroup3D transform={object.transform} selected={selected}><Plane3D transform={object.transform} eventProps={eventProps} /></TransformGroup3D>;
  return <TransformGroup3D transform={object.transform} selected={selected} yOffset={solidSize / 4}><ConstructedSolid3D kind={object.solid ?? "cube"} transform={object.transform} eventProps={eventProps} /></TransformGroup3D>;
}

function TransformGroup3D({ transform, selected, yOffset = 0, children }: { transform: Transform3D; selected: boolean; yOffset?: number; children: JSX.Element }) {
  const [width, height, depth] = transform.dimensions ?? [1.7, 1.7, 1.7];
  const glowSize: [number, number, number] = [
    Math.max(0.34, width + 0.28),
    Math.max(0.34, height + 0.28),
    Math.max(0.34, depth + 0.28),
  ];
  const outerGlowSize: [number, number, number] = glowSize.map((value) => value + 0.22) as [number, number, number];
  return (
    <group position={[transform.position[0], transform.position[1] + yOffset, transform.position[2]]} rotation={transform.rotation.map((value) => THREE.MathUtils.degToRad(value)) as [number, number, number]} scale={transform.scale}>
      {children}
      {selected && (
        <group renderOrder={20}>
          <mesh>
            <boxGeometry args={outerGlowSize} />
            <meshBasicMaterial color="#67e8f9" wireframe transparent opacity={0.22} depthTest={false} />
          </mesh>
          <mesh>
            <boxGeometry args={glowSize} />
            <meshBasicMaterial color="#22d3ee" wireframe transparent opacity={0.92} depthTest={false} />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.16, 16, 12]} />
            <meshBasicMaterial color="#f97316" wireframe transparent opacity={0.95} depthTest={false} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function VectorWorkbenchOverlay3D({ a, b, view, focus }: { a: Vector3Tuple; b: Vector3Tuple; view: VectorView3D; focus: boolean }) {
  const result = vectorWorkbenchResult(a, b, view);
  const scale = Math.min(0.7, 3.8 / Math.max(1, vectorMagnitude3(a), vectorMagnitude3(b), result ? vectorMagnitude3(result) : 0));
  const fit = (vector: Vector3Tuple): Vector3Tuple => {
    return vector.map((value) => value * scale) as Vector3Tuple;
  };
  const av = fit(a);
  const bv = fit(b);
  const rv = result ? fit(result) : null;
  const origin: Vector3Tuple = focus ? [0, 0.25, 0] : [1.8, 0.45, -2.8];
  const tip = (vector: Vector3Tuple): Vector3Tuple => vector.map((value, index) => value + origin[index]) as Vector3Tuple;
  return (
    <group>
      <mesh position={origin}><sphereGeometry args={[0.105, 16, 12]} /><meshBasicMaterial color="#f8fafc" depthTest={false} /></mesh>
      <VectorArrow start={origin} end={tip(av)} color="#22d3ee" thickness={0.07} overlay />
      <VectorArrow start={origin} end={tip(bv)} color="#fb923c" thickness={0.07} overlay />
      {rv && <VectorArrow start={origin} end={tip(rv)} color="#c084fc" thickness={0.085} overlay />}
      {view === "sum" && <VectorArrow start={tip(av)} end={tip([av[0] + bv[0], av[1] + bv[1], av[2] + bv[2]])} color="#fb923c" thickness={0.025} overlay />}
    </group>
  );
}

function Axes3D() {
  return (
    <group>
      <group userData={{gestureName:'X Axis'}}><VectorArrow start={[-5, 0, 0]} end={[5, 0, 0]} color="#ef4444" /></group>
      <group userData={{gestureName:'Y Axis'}}><VectorArrow start={[0, -0.01, -5]} end={[0, -0.01, 5]} color="#22c55e" /></group>
      <group userData={{gestureName:'Z Axis'}}><VectorArrow start={[0, -3, 0]} end={[0, 3, 0]} color="#38bdf8" /></group>
    </group>
  );
}

function VectorArrow({ start, end, color, eventProps, thickness = 0.025, overlay = false }: { start: [number, number, number]; end: [number, number, number]; color: string; eventProps?: Record<string, unknown>; thickness?: number; overlay?: boolean }) {
  const startVector = new THREE.Vector3(...start);
  const endVector = new THREE.Vector3(...end);
  const direction = endVector.clone().sub(startVector);
  const length = direction.length();
  if (length < 1e-8) return null;
  const midpoint = startVector.clone().add(direction.clone().multiplyScalar(0.5));
  const quaternion = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());

  return (
    <group position={midpoint} quaternion={quaternion} {...eventProps}>
      <mesh>
        <cylinderGeometry args={[thickness, thickness, length, 12]} />
        <meshStandardMaterial color={color} emissive={overlay ? color : "#000000"} emissiveIntensity={overlay ? 0.35 : 0} depthTest={!overlay} />
      </mesh>
      <mesh position={[0, length / 2, 0]}>
        <coneGeometry args={[Math.max(0.09, thickness * 2), Math.max(0.25, thickness * 3), 16]} />
        <meshStandardMaterial color={color} emissive={overlay ? color : "#000000"} emissiveIntensity={overlay ? 0.35 : 0} depthTest={!overlay} />
      </mesh>
    </group>
  );
}

function Point3D({ label, color, eventProps }: { label: string; color: string; eventProps?: Record<string, unknown> }) {
  return (
    <group {...eventProps}>
      <mesh>
        <sphereGeometry args={[0.12, 24, 16]} />
        <meshStandardMaterial color={color} emissive="#7c2d12" emissiveIntensity={0.2} />
      </mesh>
      <mesh position={[0.18, 0.18, 0]}>
        <sphereGeometry args={[0.04, 12, 8]} />
        <meshStandardMaterial color={label ? "#f8fafc" : "#f59e0b"} />
      </mesh>
    </group>
  );
}

function SurfaceMesh({ surface, expression, scaleValue, transform, performanceMode, eventProps }: { surface: SurfaceKind; expression: string; scaleValue: number; transform: Transform3D; performanceMode: boolean; eventProps?: Record<string, unknown> }) {
  const geometry = useMemo(() => createSurfaceGeometry(surface, scaleValue, performanceMode, expression), [surface, scaleValue, performanceMode, expression]);
  return (
    <mesh geometry={geometry} position={[0, 0, 0]} {...eventProps}>
      <ObjectMaterial transform={transform} />
    </mesh>
  );
}

function createSurfaceGeometry(surface: SurfaceKind, scaleValue: number, performanceMode = false, expression = "sin(x)*cos(y)") {
  const size = 5;
  const segments = performanceMode ? 18 : 36;
  const geometry = new THREE.BufferGeometry();
  const vertices: number[] = [];
  const indices: number[] = [];
  if (surface === "parametric") return createParametricSurfaceGeometry(segments);
  if (surface === "implicit") {
    const sphere = new THREE.SphereGeometry(2.1, segments, Math.max(12, Math.floor(segments / 2)));
    sphere.computeVertexNormals();
    return sphere;
  }
  for (let iy = 0; iy <= segments; iy += 1) {
    const y = -size / 2 + (iy / segments) * size;
    for (let ix = 0; ix <= segments; ix += 1) {
      const x = -size / 2 + (ix / segments) * size;
      const z = surfaceZ(surface, x, y, scaleValue, expression);
      vertices.push(x, z, y);
    }
  }
  for (let iy = 0; iy < segments; iy += 1) {
    for (let ix = 0; ix < segments; ix += 1) {
      const a = iy * (segments + 1) + ix;
      const b = a + 1;
      const c = a + segments + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function surfaceZ(surface: SurfaceKind, x: number, y: number, scaleValue: number, expression = "") {
  if (surface === "custom-z") return scaleValue * evaluateSurfaceExpression(expression, x, y);
  if (surface === "paraboloid") return scaleValue * 0.25 * (x * x + y * y);
  if (surface === "saddle") return scaleValue * 0.3 * (x * x - y * y);
  if (surface === "wave") return scaleValue * Math.sin(x * 1.4) * Math.cos(y * 1.4);
  if (surface === "ripple") return scaleValue * Math.sin((x * x + y * y) * 1.2);
  if (surface === "cone-surface") return scaleValue * 0.55 * Math.hypot(x, y);
  return scaleValue * 0.35 * (x + y);
}

function evaluateSurfaceExpression(expression: string, x: number, y: number) {
  const safe = expression
    .replace(/\^/g, "**")
    .replace(/\bpi\b/gi, "Math.PI")
    .replace(/\be\b/g, "Math.E")
    .replace(/\bsin\b/gi, "Math.sin")
    .replace(/\bcos\b/gi, "Math.cos")
    .replace(/\btan\b/gi, "Math.tan")
    .replace(/\bsqrt\b/gi, "Math.sqrt")
    .replace(/\babs\b/gi, "Math.abs")
    .replace(/\bln\b/gi, "Math.log")
    .replace(/\blog\b/gi, "Math.log10")
    .replace(/\bexp\b/gi, "Math.exp");
  if (!/^[0-9xy+\-*/().,\s*MATHPIEabceghilnopqrstxyz]+$/i.test(safe) || /[;={}\]'"[]/.test(safe)) return 0;
  try {
    const value = Function("x", "y", `"use strict"; return (${safe});`)(x, y) as number;
    return Number.isFinite(value) ? Math.max(-4, Math.min(4, value)) : 0;
  } catch {
    return 0;
  }
}

function createParametricSurfaceGeometry(segments: number) {
  const geometry = new THREE.BufferGeometry();
  const vertices: number[] = [];
  const indices: number[] = [];
  for (let iv = 0; iv <= segments; iv += 1) {
    const v = (iv / segments) * Math.PI * 2;
    for (let iu = 0; iu <= segments; iu += 1) {
      const u = (iu / segments) * Math.PI * 2;
      const major = 1.7;
      const minor = 0.55;
      vertices.push((major + minor * Math.cos(v)) * Math.cos(u), minor * Math.sin(v), (major + minor * Math.cos(v)) * Math.sin(u));
    }
  }
  for (let iv = 0; iv < segments; iv += 1) {
    for (let iu = 0; iu < segments; iu += 1) {
      const a = iv * (segments + 1) + iu;
      const b = a + 1;
      const c = a + segments + 1;
      const d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function cameraPresetRotation(preset: CameraPreset3D): [number, number, number] {
  if (preset === "top") return [-Math.PI / 2, 0, 0];
  if (preset === "front") return [0, 0, 0];
  if (preset === "right") return [0, -Math.PI / 2, 0];
  if (preset === "isometric") return [-0.52, 0.72, 0];
  return [0, 0, 0];
}

function snap3dValue(value: number, step: number) {
  if (!step) return roundTo(value, 2);
  return roundTo(Math.round(value / step) * step, 2);
}

function SolidMesh({ solid, size, transform, animate, eventProps }: { solid: SolidKind; size: number; transform: Transform3D; animate: boolean; eventProps?: Record<string, unknown> }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (ref.current && animate) ref.current.rotation.y += delta * 0.18;
  });
  return (
    <mesh ref={ref} scale={solid === "ellipsoid" ? [1.45, 0.72, 0.95] : [1, 1, 1]} {...eventProps}>
      {solid === "cube" && <boxGeometry args={[size, size, size]} />}
      {solid === "cuboid" && <boxGeometry args={[size * 1.45, size * 0.78, size]} />}
      {solid === "sphere" && <sphereGeometry args={[size / 2, 48, 28]} />}
      {solid === "ellipsoid" && <sphereGeometry args={[size / 2, 48, 28]} />}
      {solid === "hemisphere" && <sphereGeometry args={[size / 2, 48, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />}
      {solid === "cylinder" && <cylinderGeometry args={[size / 2, size / 2, size, 48]} />}
      {solid === "cone" && <coneGeometry args={[size / 2, size, 48]} />}
      {solid === "frustum" && <cylinderGeometry args={[size * 0.32, size * 0.55, size, 48]} />}
      {solid === "torus" && <torusGeometry args={[size * 0.34, size * 0.12, 18, 64]} />}
      {solid === "tube" && <torusGeometry args={[size * 0.4, size * 0.06, 16, 64]} />}
      {solid === "capsule" && <capsuleGeometry args={[size * 0.26, size * 0.62, 10, 24]} />}
      {solid === "prism" && <cylinderGeometry args={[size / 2, size / 2, size, 3]} />}
      {solid === "pyramid" && <coneGeometry args={[size / 2, size, 4]} />}
      {solid === "tetrahedron" && <tetrahedronGeometry args={[size * 0.58, 0]} />}
      {solid === "octahedron" && <octahedronGeometry args={[size * 0.58, 0]} />}
      {solid === "dodecahedron" && <dodecahedronGeometry args={[size * 0.5, 0]} />}
      {solid === "wedge" && <polyhedronGeometry args={[[0, 0, 0, size, 0, 0, size, 0, size, 0, 0, size, 0, size * 0.75, 0, size, size * 0.75, 0], [0, 1, 2, 0, 2, 3, 0, 4, 5, 0, 5, 1, 1, 5, 2, 3, 2, 5, 3, 5, 4, 0, 3, 4], 0.5, 0]} />}
      {solid === "polyhedron" && <icosahedronGeometry args={[size / 2, 0]} />}
      <ObjectMaterial transform={transform} />
    </mesh>
  );
}

function CrossSectionPlane({ color, eventProps }: { color: string; eventProps?: Record<string, unknown> }) {
  return (
    <mesh {...eventProps}>
      <planeGeometry args={[5.5, 5.5]} />
      <meshStandardMaterial color={color} transparent opacity={0.22} side={THREE.DoubleSide} />
    </mesh>
  );
}

function Line3D({ transform, eventProps }: { transform: Transform3D; eventProps?: Record<string, unknown> }) {
  const length = transform.dimensions?.[0] ?? 4;
  return (
    <group {...eventProps}>
      <mesh rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.035, 0.035, length, 12]} />
        <ObjectMaterial transform={transform} />
      </mesh>
    </group>
  );
}

function IntelligenceShapeMesh({command,transform,eventProps}:{command:VisualCommand;transform:Transform3D;eventProps?:Record<string,unknown>}) {
  const geometry=useMemo(()=>createIntelligenceShapeGeometry(command),[command]);
  useEffect(()=>()=>geometry.dispose(),[geometry]);
  const base=commandTransform3d(command).dimensions;
  const dimensions=transform.dimensions??base;
  return <mesh geometry={geometry} scale={dimensions.map((v,i)=>v/base[i]) as [number,number,number]} {...eventProps}><ObjectMaterial transform={transform}/></mesh>;
}

function Plane3D({ transform, eventProps }: { transform: Transform3D; eventProps?: Record<string, unknown> }) {
  return (
    <mesh {...eventProps}>
      <planeGeometry args={[transform.dimensions?.[0] ?? 4, transform.dimensions?.[1] ?? 4]} />
      <ObjectMaterial transform={transform} />
    </mesh>
  );
}

function ConstructedSolid3D({ kind, transform, eventProps }: { kind: SolidKind; transform: Transform3D; eventProps?: Record<string, unknown> }) {
  const dims = transform.dimensions ?? [1.5, 1.5, 1.5];
  return (
    <mesh scale={kind === "ellipsoid" ? [dims[0] * 1.45, dims[1] * 0.72, dims[2] * 0.95] : [dims[0], dims[1], dims[2]]} {...eventProps}>
      {kind === "cube" && <boxGeometry args={[1, 1, 1]} />}
      {kind === "cuboid" && <boxGeometry args={[1.45, 0.78, 1]} />}
      {kind === "sphere" && <sphereGeometry args={[0.5, 48, 28]} />}
      {kind === "ellipsoid" && <sphereGeometry args={[0.5, 48, 28]} />}
      {kind === "hemisphere" && <sphereGeometry args={[0.5, 48, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />}
      {kind === "cone" && <coneGeometry args={[0.5, 1, 48]} />}
      {kind === "cylinder" && <cylinderGeometry args={[0.5, 0.5, 1, 48]} />}
      {kind === "frustum" && <cylinderGeometry args={[0.32, 0.55, 1, 48]} />}
      {kind === "torus" && <torusGeometry args={[0.34, 0.12, 18, 64]} />}
      {kind === "tube" && <torusGeometry args={[0.4, 0.06, 16, 64]} />}
      {kind === "capsule" && <capsuleGeometry args={[0.26, 0.62, 10, 24]} />}
      {kind === "prism" && <cylinderGeometry args={[0.58, 0.58, 1, 3]} />}
      {kind === "pyramid" && <coneGeometry args={[0.62, 1, 4]} />}
      {kind === "tetrahedron" && <tetrahedronGeometry args={[0.58, 0]} />}
      {kind === "octahedron" && <octahedronGeometry args={[0.58, 0]} />}
      {kind === "dodecahedron" && <dodecahedronGeometry args={[0.5, 0]} />}
      {kind === "wedge" && <polyhedronGeometry args={[[0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0.75, 0, 1, 0.75, 0], [0, 1, 2, 0, 2, 3, 0, 4, 5, 0, 5, 1, 1, 5, 2, 3, 2, 5, 3, 5, 4, 0, 3, 4], 0.5, 0]} />}
      {kind === "polyhedron" && <icosahedronGeometry args={[0.65, 0]} />}
      <ObjectMaterial transform={transform} />
    </mesh>
  );
}

function ObjectMaterial({ transform }: { transform: Transform3D }) {
  const texture=useMemo(()=>{
    if(!transform.paint||transform.paint==='solid'||typeof document==='undefined')return null;
    const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;const ctx=canvas.getContext('2d');if(!ctx)return null;
    const secondary=transform.secondaryColor??'#06b6d4';
    if(transform.paint==='gradient'){const gradient=ctx.createLinearGradient(0,0,256,256);gradient.addColorStop(0,transform.color);gradient.addColorStop(1,secondary);ctx.fillStyle=gradient;ctx.fillRect(0,0,256,256);}
    else{ctx.fillStyle=transform.color;ctx.fillRect(0,0,256,256);ctx.fillStyle=secondary;ctx.strokeStyle=secondary;ctx.lineWidth=8;
      if(transform.pattern==='dots'){for(let x=16;x<256;x+=32)for(let y=16;y<256;y+=32){ctx.beginPath();ctx.arc(x,y,6,0,Math.PI*2);ctx.fill();}}
      else if(transform.pattern==='grid'){for(let v=0;v<256;v+=32){ctx.fillRect(v,0,3,256);ctx.fillRect(0,v,256,3);}}
      else{for(let v=-256;v<512;v+=32){ctx.beginPath();ctx.moveTo(v,0);ctx.lineTo(v+256,256);ctx.stroke();}}
    }
    const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;return map;
  },[transform.paint,transform.pattern,transform.color,transform.secondaryColor]);
  useEffect(()=>()=>{texture?.dispose();},[texture]);
  return <meshStandardMaterial map={texture} color={texture?'#ffffff':transform.color} transparent opacity={transform.opacity ?? 0.8} roughness={transform.material === "glass" ? 0.12 : 0.42} metalness={transform.material === "glass" ? 0.18 : 0.05} wireframe={transform.material === "wireframe"} side={THREE.DoubleSide} />;
}

function IntersectionOverlays3D({ transforms, crossSection }: { transforms: Record<ThreeObjectId, Transform3D>; crossSection: number }) {
  const sphere = transforms.sphere3d;
  const plane = transforms.plane3d;
  const line = transforms.line3d;
  const sphereRadius = ((sphere.dimensions?.[0] ?? 1.4) * sphere.scale) / 2;
  const planeDistance = Math.abs(plane.position[1] - sphere.position[1]);
  const spherePlaneRadius = Math.sqrt(Math.max(0.04, sphereRadius * sphereRadius - planeDistance * planeDistance));
  const linePlanePoint: [number, number, number] = [line.position[0], plane.position[1], line.position[2]];

  return (
    <group>
      {sphere.visible && plane.visible && planeDistance <= sphereRadius + 0.02 && (
        <group position={[sphere.position[0], plane.position[1], sphere.position[2]]} rotation={[Math.PI / 2, 0, 0]}>
          <mesh>
            <torusGeometry args={[spherePlaneRadius, 0.018, 10, 96]} />
            <meshBasicMaterial color="#f8fafc" />
          </mesh>
        </group>
      )}
      {line.visible && plane.visible && (
        <mesh position={linePlanePoint}>
          <sphereGeometry args={[0.09, 18, 12]} />
          <meshBasicMaterial color="#fb7185" />
        </mesh>
      )}
      {plane.visible && transforms.slice.visible && (
        <mesh position={[0, (plane.position[1] + crossSection) / 2, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.018, 0.018, 5.5, 10]} />
          <meshBasicMaterial color="#fde68a" />
        </mesh>
      )}
      {transforms.surface.visible && transforms.slice.visible && (
        <group position={[0, crossSection, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <mesh>
            <torusGeometry args={[2.05, 0.012, 8, 128]} />
            <meshBasicMaterial color="#f59e0b" />
          </mesh>
        </group>
      )}
    </group>
  );
}

function MeasurementOverlays3D({ transforms }: { transforms: Record<ThreeObjectId, Transform3D> }) {
  const point = transforms.point.position;
  const vectorLength = Math.hypot(point[0] + 3, point[1] - 0.05, point[2] + 3);
  return (
    <group>
      <TextSprite position={[point[0] + 0.25, point[1] + 0.25, point[2]]} text={`${transforms.point.name ?? "P"} (${point.map((value) => roundTo(value, 1)).join(", ")})`} />
      <TextSprite position={[-1.5, 0.35, -1.8]} text={`|v|=${roundTo(vectorLength, 2)}`} />
      {transforms.plane3d.visible && transforms.sphere3d.visible && <TextSprite position={[0, 2.8, 0]} text="sphere-plane slice available" />}
      {transforms.line3d.visible && transforms.plane3d.visible && <TextSprite position={[1.2, 2.4, 0]} text="line-plane intersection" />}
    </group>
  );
}

function TextSprite({ position, text }: { position: [number, number, number]; text: string }) {
  const texture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 96;
    const context = canvas.getContext("2d");
    if (context) {
      context.fillStyle = "rgba(15,23,42,.82)";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.fillStyle = "#f8fafc";
      context.font = "700 32px sans-serif";
      context.fillText(text, 24, 58);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
  }, [text]);
  return (
    <sprite position={position} scale={[1.8, 0.34, 1]}>
      <spriteMaterial map={texture} transparent />
    </sprite>
  );
}

function surfaceFormula(surface: SurfaceKind, scaleValue: number) {
  if (surface === "custom-z") return `z = ${roundTo(scaleValue, 2)} * f(x,y)`;
  if (surface === "parametric") return "parametric torus: r(u,v)";
  if (surface === "implicit") return "implicit sphere: x^2+y^2+z^2=r^2";
  if (surface === "paraboloid") return `z = ${roundTo(scaleValue, 2)}(x^2 + y^2)/4`;
  if (surface === "saddle") return `z = ${roundTo(scaleValue, 2)}(x^2 - y^2)/3`;
  if (surface === "wave") return `z = ${roundTo(scaleValue, 2)} sin(1.4x) cos(1.4y)`;
  if (surface === "ripple") return `z = ${roundTo(scaleValue, 2)} sin(1.2(x^2+y^2))`;
  if (surface === "cone-surface") return `z = ${roundTo(scaleValue, 2)} sqrt(x^2+y^2)`;
  return `z = ${roundTo(scaleValue, 2)}(x+y)/3`;
}

type GeometryPaletteToolItem = { id: GeometryTool; label: string; icon: LucideIcon };
type GeometryPaletteActionItem = { id: string; label: string; icon: LucideIcon; action: () => void; danger?: boolean; active?: boolean; disabled?: boolean };

const geometryPaletteGroups: Array<{ title: string; tools: GeometryPaletteToolItem[] }> = [
  {
    title: "Basic Tools",
    tools: [
      { id: "select", label: "Move", icon: MousePointer2 },
      { id: "point", label: "Point", icon: Plus },
      { id: "segment", label: "Segment", icon: Move },
      { id: "line", label: "Line", icon: Slash },
      { id: "ray", label: "Ray", icon: LineChart },
      { id: "vector", label: "Vector", icon: Move },
      { id: "circle", label: "Circle", icon: Circle },
      { id: "polygon", label: "Polygon", icon: Pentagon },
      { id: "angle", label: "Angle", icon: Circle },
    ],
  },
  {
    title: "Edit",
    tools: [
      { id: "freehand", label: "Freehand", icon: Slash },
      { id: "text", label: "Text", icon: Slash },
      { id: "image", label: "Image", icon: Box },
      { id: "move-canvas", label: "Move Canvas", icon: Move },
      { id: "zoom", label: "Zoom", icon: ZoomIn },
    ],
  },
  {
    title: "Construct",
    tools: [
      { id: "parallel", label: "Parallel", icon: Slash },
      { id: "perpendicular", label: "Perp.", icon: Plus },
      { id: "perpendicular-bisector", label: "Perp. Bisector", icon: Slash },
      { id: "angle-bisector", label: "Angle Bisector", icon: Slash },
      { id: "midpoint", label: "Midpoint", icon: Magnet },
      { id: "intersect", label: "Intersect", icon: Plus },
      { id: "fixed-length", label: "Fixed Length", icon: Magnet },
      { id: "on-circle", label: "Point on Circle", icon: Circle },
      { id: "circle-radius", label: "Circle Radius", icon: Circle },
      { id: "circle-3-points", label: "Circle 3 Points", icon: Circle },
    ],
  },
  {
    title: "Shapes",
    tools: [
      { id: "triangle", label: "Triangle", icon: Pentagon },
      { id: "rectangle", label: "Rectangle", icon: Box },
      { id: "shape-circle", label: "Circle Shape", icon: Circle },
      { id: "parabola", label: "Parabola", icon: LineChart },
      { id: "ellipse", label: "Ellipse", icon: Circle },
      { id: "hyperbola", label: "Hyperbola", icon: LineChart },
    ],
  },
  {
    title: "Curves",
    tools: [
      { id: "tangent", label: "Tangent", icon: Circle },
      { id: "polar", label: "Polar", icon: Move },
      { id: "locus", label: "Locus", icon: LineChart },
      { id: "regular-polygon", label: "Regular Polygon", icon: Pentagon },
      { id: "arc", label: "Arc", icon: Circle },
      { id: "sector", label: "Sector", icon: Circle },
      { id: "compass", label: "Compass", icon: Magnet },
    ],
  },
  {
    title: "Transform",
    tools: [
      { id: "mirror", label: "Mirror", icon: Slash },
      { id: "rotate", label: "Rotate 45", icon: RotateCcw },
      { id: "dilate", label: "Dilate 1.5x", icon: ZoomIn },
      { id: "translate", label: "Translate", icon: Move },
    ],
  },
];

function setGeometryTrace(construction: Construction, object: SelectedGeometryObject, enabled: boolean): Construction {
  const styled = patchGeometryObject(construction, object, { style: { ...(geometryObjectBySelection(construction, object)?.style ?? {}), trace: enabled } });
  if (object.type !== "point") return styled;
  const point = pointById(styled.points, object.id);
  if (!point) return styled;
  if (!enabled) {
    return {
      ...styled,
      loci: styled.loci.map((locus) => locus.sourcePointId === object.id && locus.mode === "trace" ? { ...locus, style: { ...(locus.style ?? {}), trace: false } } : locus),
    };
  }
  const existingIndex = styled.loci.findIndex((locus) => locus.sourcePointId === object.id && locus.mode === "trace");
  if (existingIndex >= 0) {
    return {
      ...styled,
      loci: styled.loci.map((locus, index) => index === existingIndex ? {
        ...locus,
        points: appendTraceSample(locus.points, point, { maxSamples: locus.maxSamples }),
        style: { ...(locus.style ?? {}), trace: true, visible: true },
      } : locus),
    };
  }
  const traceLocus: GeoLocus = {
    id: crypto.randomUUID(),
    label: nextTraceLabel(styled.loci.filter((locus) => locus.mode === "trace").length, point.label),
    sourcePointId: point.id,
    mode: "trace",
    maxSamples: DEFAULT_TRACE_MAX_SAMPLES,
    points: seedTraceSamples(point),
    style: { color: point.style?.color ?? "#ec4899", strokeWidth: 4, trace: true, opacity: 0.82 },
  };
  return {
    ...styled,
    loci: [...styled.loci, traceLocus],
  };
}

function recordTraceSampleForPoint(construction: Construction, pointId: string): Construction {
  const point = pointById(construction.points, pointId);
  if (!point?.style?.trace) return construction;
  const traceExists = construction.loci.some((locus) => locus.sourcePointId === pointId && locus.mode === "trace");
  const withTrace = traceExists ? construction : setGeometryTrace(construction, { type: "point", id: pointId }, true);
  return {
    ...withTrace,
    loci: withTrace.loci.map((locus) => locus.sourcePointId === pointId && locus.mode === "trace" && locus.style?.trace !== false ? {
      ...locus,
      points: appendTraceSample(locus.points, point, { maxSamples: locus.maxSamples }),
      style: { ...(locus.style ?? {}), visible: true },
    } : locus),
  };
}

function clearTracePaths(construction: Construction): Construction {
  return {
    ...construction,
    points: construction.points.map((point) => ({ ...point, style: { ...(point.style ?? {}), trace: false } })),
    lines: construction.lines.map((line) => ({ ...line, style: { ...(line.style ?? {}), trace: false } })),
    circles: construction.circles.map((circle) => ({ ...circle, style: { ...(circle.style ?? {}), trace: false } })),
    polygons: construction.polygons.map((polygon) => ({ ...polygon, style: { ...(polygon.style ?? {}), trace: false } })),
    arcs: construction.arcs.map((arc) => ({ ...arc, style: { ...(arc.style ?? {}), trace: false } })),
    loci: construction.loci.filter((locus) => locus.mode !== "trace").map((locus) => ({ ...locus, style: { ...(locus.style ?? {}), trace: false } })),
  };
}

function duplicateGeometryObjectInConstruction(construction: Construction, object: SelectedGeometryObject) {
  const sourcePointIds = pointIdsForObject(construction, object);
  const pointMap = new Map<string, string>();
  const copiedPoints = sourcePointIds.map((id, index) => {
    const point = pointById(construction.points, id);
    if (!point) return null;
    const nextId = crypto.randomUUID();
    pointMap.set(id, nextId);
    return { ...point, id: nextId, x: point.x + 28, y: point.y + 28, label: nextPointLabel(construction.points, index), style: { ...(point.style ?? {}) } };
  }).filter(Boolean) as GeoPoint[];
  if (object.type === "point") return solveConstruction({ ...construction, points: [...construction.points, ...copiedPoints] });
  if (object.type === "line") {
    const line = construction.lines.find((item) => item.id === object.id);
    if (!line) return construction;
    return solveConstruction({ ...construction, points: [...construction.points, ...copiedPoints], lines: [...construction.lines, { ...line, id: crypto.randomUUID(), a: pointMap.get(line.a) ?? line.a, b: pointMap.get(line.b) ?? line.b, style: { ...(line.style ?? {}) } }] });
  }
  if (object.type === "circle") {
    const circle = construction.circles.find((item) => item.id === object.id);
    if (!circle) return construction;
    return solveConstruction({ ...construction, points: [...construction.points, ...copiedPoints], circles: [...construction.circles, { ...circle, id: crypto.randomUUID(), center: pointMap.get(circle.center) ?? circle.center, edge: pointMap.get(circle.edge) ?? circle.edge, style: { ...(circle.style ?? {}) } }] });
  }
  if (object.type === "arc") {
    const arc = construction.arcs.find((item) => item.id === object.id);
    if (!arc) return construction;
    return solveConstruction({ ...construction, points: [...construction.points, ...copiedPoints], arcs: [...construction.arcs, { ...arc, id: crypto.randomUUID(), center: pointMap.get(arc.center) ?? arc.center, start: pointMap.get(arc.start) ?? arc.start, end: pointMap.get(arc.end) ?? arc.end, style: { ...(arc.style ?? {}) } }] });
  }
  if (object.type === "locus") {
    const locus = construction.loci.find((item) => item.id === object.id);
    const copiedLocus: GeoLocus | null = locus ? {
      ...locus,
      id: crypto.randomUUID(),
      label: `${locus.label}'`,
      mode: "static",
      sourcePointId: undefined,
      points: locus.points.map((point) => ({ x: point.x + 24, y: point.y + 24 })),
      style: { ...(locus.style ?? {}), trace: false },
    } : null;
    return locus ? {
      ...construction,
      loci: copiedLocus ? [...construction.loci, copiedLocus] : construction.loci,
    } : construction;
  }
  const polygon = construction.polygons.find((item) => item.id === object.id);
  if (!polygon) return construction;
  return solveConstruction({ ...construction, points: [...construction.points, ...copiedPoints], polygons: [...construction.polygons, { ...polygon, id: crypto.randomUUID(), points: polygon.points.map((id) => pointMap.get(id) ?? id), style: { ...(polygon.style ?? {}) } }] });
}

function circleRadiusUnits(construction: Construction, circleId: string) {
  const circle = construction.circles.find((item) => item.id === circleId);
  const center = circle ? pointById(construction.points, circle.center) : null;
  const edge = circle ? pointById(construction.points, circle.edge) : null;
  return center && edge ? roundTo(distance(center, edge) / 40, 2) : null;
}

function resizeGeometryObjectInConstruction(construction: Construction, object: SelectedGeometryObject, factor: number): Construction {
  const pointIds = pointIdsForObject(construction, object);
  if (!pointIds.length) {
    if (object.type !== "locus") return construction;
    return {
      ...construction,
      loci: construction.loci.map((locus) => {
        if (locus.id !== object.id || !locus.points.length) return locus;
        const center = centroid(locus.points);
        return { ...locus, points: locus.points.map((point) => scalePointAround(point, center, factor)) };
      }),
    };
  }
  const points = pointIds.map((id) => pointById(construction.points, id)).filter((point): point is GeoPoint => Boolean(point));
  if (!points.length) return construction;
  const center = object.type === "circle" || object.type === "arc"
    ? points[0]
    : centroid(points);
  const anchorId = object.type === "circle" || object.type === "arc" ? points[0].id : "";
  return solveConstruction({
    ...construction,
    points: construction.points.map((point) => {
      if (!pointIds.includes(point.id) || point.id === anchorId) return point;
      return { ...point, ...scalePointAround(point, center, factor) };
    }),
  });
}

function centroid(points: Array<{ x: number; y: number }>) {
  const total = points.reduce((sum, point) => ({ x: sum.x + point.x, y: sum.y + point.y }), { x: 0, y: 0 });
  return { x: total.x / points.length, y: total.y / points.length };
}

function scalePointAround(point: { x: number; y: number }, center: { x: number; y: number }, factor: number) {
  return { x: center.x + (point.x - center.x) * factor, y: center.y + (point.y - center.y) * factor };
}

function ConstraintPanel({ construction }: { construction: Construction }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <h3 className="font-bold">Constraint Engine</h3>
      <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">Draggable points now recompute dependent objects: parallel, perpendicular, midpoint, fixed length, point-on-circle, and line intersections.</p>
      {construction.constraints.length ? (
        <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
          {construction.constraints.map((constraint) => <li key={constraint.id} className="rounded-xl bg-slate-100 p-2 dark:bg-white/10">{constraintLabel(constraint, construction)}</li>)}
        </ul>
      ) : <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">Add a constraint tool to see live dependencies here.</p>}
    </div>
  );
}

function ConstructionProtocolPanel({ protocol, onReplay }: { protocol: ConstructionStep[]; onReplay: (step: ConstructionStep) => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-bold">Construction Protocol</h3>
        <span className="mini-chip">{protocol.length} steps</span>
      </div>
      {protocol.length ? (
        <ol className="mt-3 max-h-72 space-y-2 overflow-auto pr-1 text-sm text-slate-600 dark:text-slate-300">
          {protocol.slice(0, 24).map((step, index) => (
            <li key={step.id} className="rounded-xl bg-slate-100 p-2 dark:bg-white/10">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-bold text-slate-900 dark:text-white">{protocol.length - index}. {step.label}</p>
                  <p className="mt-1 truncate text-xs">{step.detail}</p>
                </div>
                <button type="button" className="mini-chip shrink-0" onClick={() => onReplay(step)}>
                  Replay
                </button>
              </div>
            </li>
          ))}
        </ol>
      ) : (
        <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Create or edit objects to build a replayable construction history.</p>
      )}
    </div>
  );
}

function ConstructionHelp({ tool }: { tool: GeometryTool }) {
  const instructions: Record<GeometryTool, string> = {
    select: "Drag existing points to update every connected line, circle, and polygon.",
    point: "Click the board to create labeled points.",
    segment: "Click two points to create a measured segment.",
    ray: "Click start point, then a direction point to create a ray-style object.",
    vector: "Click tail point, then head point to create a vector-style object.",
    line: "Click two points to create a line.",
    circle: "Click a center point, then a radius point.",
    polygon: "Click three or more vertices, then click the first vertex again to close the polygon.",
    angle: "Click side point, vertex, side point. The second click is the vertex; a live preview arc appears before the final click.",
    "show-hide": "Use the selected-object section to show or hide the selected object.",
    lock: "Use the selected-object section to lock or unlock the selected object.",
    freehand: "Press and drag across the board to draw a real freehand path.",
    text: "Click the board to place a draggable text note point.",
    image: "Opens the image picker and places the image on the geometry board.",
    "move-canvas": "Move-canvas mode keeps construction objects unchanged while you inspect the board.",
    zoom: "Use the dedicated plus and minus controls or the mouse wheel to zoom without changing the construction.",
    triangle: "Click the board to insert an editable triangle.",
    rectangle: "Click the board to insert an editable rectangle.",
    square: "Click the board to insert an editable square.",
    "pentagon-shape": "Click the board to insert an editable regular pentagon.",
    hexagon: "Click the board to insert an editable regular hexagon.",
    parallelogram: "Click the board to insert an editable parallelogram.",
    trapezoid: "Click the board to insert an editable trapezoid.",
    rhombus: "Click the board to insert an editable rhombus.",
    kite: "Click the board to insert an editable kite.",
    "shape-circle": "Click the board to insert a ready circle with center and edge points.",
    semicircle: "Click the board to insert a semicircle visualization curve.",
    parabola: "Click the board to insert a parabola visualization curve.",
    ellipse: "Click the board to insert an ellipse visualization curve.",
    hyperbola: "Click the board to insert a hyperbola visualization curve.",
    parallel: "Pick an existing line and then a through-point, or click two points for a source direction and a third point.",
    perpendicular: "Pick an existing line and then a through-point, or click two points for a source direction and a third point.",
    midpoint: "Click two points. A midpoint is created and stays locked halfway between them.",
    "fixed-length": "Click an anchor point and a second point. The second point keeps its current distance from the anchor while dragged.",
    "circle-radius": "Click center and edge points to create a radius-driven circle.",
    "circle-3-points": "Click three points to create the circle passing through them.",
    "on-circle": "Pick a circle, then a point. The point snaps to that circle and stays on it.",
    intersect: "Pick two existing lines/circles for exact intersections, or click any point to add all current intersections.",
    "perpendicular-bisector": "Click two points to create their midpoint and a perpendicular bisector.",
    "angle-bisector": "Click side point, vertex, side point to create an angle bisector ray.",
    tangent: "Pick a circle, then a point near/on it to create the tangent line at that point.",
    polar: "Pick a circle, then a point to create its polar line with respect to that circle.",
    locus: "Click a point to start a live locus trace; drag the point to record its path.",
    "regular-polygon": "Click two adjacent vertices to create a regular pentagon.",
    arc: "Click center, start, and end points to create an arc.",
    sector: "Click center, start, and end points to create a sector.",
    compass: "Click two points for radius, then a center point for a compass circle.",
    mirror: "Click Mirror to flip the selected shape across a vertical axis through its center. With no selection, the whole figure is mirrored. Or pick a point and two axis points to copy one mirrored point.",
    reflect: "Click Reflect to flip the selected shape across a vertical axis through its center.",
    rotate: "Click Rotate 45 to rotate the selected shape 45° around its center. With no selection, the whole figure rotates. Or pick a point, then a center, to copy one rotated point.",
    dilate: "Click Dilate 1.5x to enlarge the selected shape from its center. With no selection, the whole figure scales. Or pick a point, then a center, to copy one dilated point.",
    translate: "Click Translate to nudge the selected shape. With no selection, the whole figure moves. Or pick a point and a vector to copy one translated point.",
    trace: "Turns trace on for the selected object and records point motion as a locus.",
    "stop-trace": "Stops recording while keeping the visible trace path.",
    "clear-trace": "Removes generated trace paths and clears trace flags.",
    delete: "Deletes the selected geometry object.",
    redo: "Reapplies the last undone workspace change.",
    reset: "Resets the current geometry construction.",
    save: "Saves the current construction in browser storage.",
    load: "Loads the saved browser construction.",
  };
  return (
    <div className="rounded-2xl bg-cyan-50 p-4 text-sm leading-6 text-slate-700 dark:bg-cyan-400/10 dark:text-cyan-50">
      <p className="font-bold">Current tool: {tool}</p>
      <p className="mt-2">{instructions[tool]}</p>
      {tool === "angle" && (
        <div className="mt-3 rounded-xl border border-cyan-200 bg-white/70 p-3 text-xs leading-5 text-cyan-950 dark:border-cyan-300/20 dark:bg-slate-950/40 dark:text-cyan-50" data-testid="angle-tool-geogebra-plus-help">
          <p className="font-black">Better angle workflow</p>
          <p className="mt-1">Use three points with the vertex second. The workspace previews the arc, labels ∠ABC live, and shows the reflex complement for teaching orientation.</p>
        </div>
      )}
    </div>
  );
}

function geometryToolLabel(tool: GeometryTool) {
  return geometryPaletteGroups.flatMap((group) => group.tools).find((item) => item.id === tool)?.label ?? tool.replace(/-/g, " ");
}

function geometryTransformToolMode(tool: GeometryTool): GeometryTransformMode | null {
  if (tool === "rotate") return "rotate";
  if (tool === "dilate") return "dilate";
  if (tool === "translate") return "translate";
  if (tool === "mirror" || tool === "reflect") return "mirror";
  return null;
}

function geometryToolExpectedPick(tool: GeometryTool) {
  if (tool === "intersect") return "line or circle";
  if (tool === "parallel" || tool === "perpendicular") return "line, then point";
  if (tool === "on-circle" || tool === "tangent" || tool === "polar") return "circle, then point";
  return "point or supported object";
}

function geometryObjectLabel(construction: Construction, object: SelectedGeometryObject) {
  if (object.type === "point") return labelForPoint(construction, object.id);
  if (object.type === "line") return lineName(construction.lines.find((line) => line.id === object.id) ?? { id: object.id, a: "", b: "" }, construction, Math.max(0, construction.lines.findIndex((line) => line.id === object.id)));
  if (object.type === "circle") return circleName(construction.circles.find((circle) => circle.id === object.id) ?? { id: object.id, center: "", edge: "" }, construction, Math.max(0, construction.circles.findIndex((circle) => circle.id === object.id)));
  if (object.type === "polygon") return polygonName(construction.polygons.find((polygon) => polygon.id === object.id) ?? { id: object.id, points: [] }, construction, Math.max(0, construction.polygons.findIndex((polygon) => polygon.id === object.id)));
  if (object.type === "arc") return "arc";
  return "locus";
}

function Measurements({ construction }: { construction: Construction }) {
  const lineLengths = construction.lines.map((line) => {
    const a = pointById(construction.points, line.a), b = pointById(construction.points, line.b);
    return a && b ? line.kind === "ray" ? `${a.label}${b.label}: unbounded ray` : `${line.kind === "vector" ? "|v| " : ""}${a.label}${b.label} = ${roundTo(distance(a, b) / 40, 2)}` : "";
  }).filter(Boolean);
  const lineEquations = construction.lines.map((line) => `${lineName(line, construction, 0)}: ${lineEquation(line, construction)}`);
  const lineSlopes = construction.lines.map((line) => {
    const a = pointById(construction.points, line.a), b = pointById(construction.points, line.b);
    return a && b ? `slope ${a.label}${b.label} = ${Math.abs(b.x - a.x) < 0.001 ? "undefined" : roundTo((a.y - b.y) / (b.x - a.x), 3)}` : "";
  }).filter(Boolean);
  const circleRadii = construction.circles.map((circle) => {
    const center = pointById(construction.points, circle.center), edge = pointById(construction.points, circle.edge);
    return center && edge ? `Circle ${center.label}: r = ${roundTo(distance(center, edge) / 40, 2)}, ${circleEquation(circle, construction)}` : "";
  }).filter(Boolean);
  const polygonAreas = construction.polygons.map((polygon, index) => {
    const points = polygon.points.map((id) => pointById(construction.points, id)).filter(Boolean) as GeoPoint[];
    return points.length >= 3 ? `Polygon ${index + 1}: area = ${roundTo(polygonArea(points) / 1600, 2)}, perimeter = ${roundTo(polygonPerimeter(points) / 40, 2)}` : "";
  }).filter(Boolean);
  const angles = construction.polygons.flatMap((polygon) => polygon.points.map((id, index, ids) => {
    const prev = pointById(construction.points, ids[(index - 1 + ids.length) % ids.length]);
    const vertex = pointById(construction.points, id);
    const next = pointById(construction.points, ids[(index + 1) % ids.length]);
    return prev && vertex && next ? `angle ${vertex.label} = ${roundTo(angleBetween(prev, vertex, next), 1)} deg` : "";
  })).filter(Boolean);
  const arcLengths = construction.arcs.map((arc, index) => {
    const center = pointById(construction.points, arc.center), start = pointById(construction.points, arc.start), end = pointById(construction.points, arc.end);
    return center && start && end ? `${arc.sector ? "Sector" : "Arc"} ${index + 1}: arc length = ${roundTo(arcLength(center, start, end) / 40, 2)}` : "";
  }).filter(Boolean);
  const entries = [...lineLengths, ...lineSlopes, ...lineEquations, ...circleRadii, ...polygonAreas, ...angles, ...arcLengths];
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 dark:border-white/10 dark:bg-white/5">
      <h3 className="font-bold">Live Measurements</h3>
      {entries.length ? <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">{entries.map((entry) => <li key={entry}>{entry}</li>)}</ul> : <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Create lines, circles, or polygons to see measurements.</p>}
    </div>
  );
}

function distance(a: GeoPoint, b: GeoPoint) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function polygonPerimeter(points: GeoPoint[]) {
  return points.reduce((sum, point, index) => sum + distance(point, points[(index + 1) % points.length]), 0);
}

function angleBetween(a: GeoPoint, vertex: GeoPoint, b: GeoPoint) {
  const va = normalize(a.x - vertex.x, a.y - vertex.y);
  const vb = normalize(b.x - vertex.x, b.y - vertex.y);
  return THREE.MathUtils.radToDeg(Math.acos(Math.max(-1, Math.min(1, va.x * vb.x + va.y * vb.y))));
}

function arcLength(center: GeoPoint, start: GeoPoint, end: GeoPoint) {
  const radius = distance(center, start);
  const a = Math.atan2(start.y - center.y, start.x - center.x);
  const b = Math.atan2(end.y - center.y, end.x - center.x);
  return radius * ((b - a + Math.PI * 2) % (Math.PI * 2));
}

function snapBoardPoint(
  point: { x: number; y: number },
  construction: Construction,
  settings: Pick<GeometryGraphSettings, "snapToGrid" | "snapToObjects" | "gridSpacing" | "pointCapture" | "snapStrength"> = defaultGeometryGraphSettings,
) {
  const capture = settings.pointCapture ?? (settings.snapToGrid ? "snap" : "off");
  if (capture === "off") return { x: roundTo(point.x, 2), y: roundTo(point.y, 2) };
  const gridUnit = settings.gridSpacing ?? 40;
  const snapStrength = settings.snapStrength ?? 18;
  const gridOrigin = { x: 320, y: 220 };
  const grid = {
    x: gridOrigin.x + Math.round((point.x - gridOrigin.x) / gridUnit) * gridUnit,
    y: gridOrigin.y + Math.round((point.y - gridOrigin.y) / gridUnit) * gridUnit,
  };
  const gridScore = Math.hypot(point.x - grid.x, point.y - grid.y);
  let best = settings.snapToGrid ? { ...grid, score: gridScore } : { ...point, score: Number.POSITIVE_INFINITY };
  const candidates = settings.snapToObjects ? [
    ...construction.points.map((p) => ({ x: p.x, y: p.y })),
    ...allIntersections(construction),
    ...construction.lines.map((line) => projectPointToLine(point, line, construction.points)).filter(Boolean) as { x: number; y: number }[],
    ...construction.circles.map((circle) => projectPointToCircle(point, circle, construction.points)).filter(Boolean) as { x: number; y: number }[],
  ] : [];
  for (const candidate of candidates) {
    const score = Math.hypot(point.x - candidate.x, point.y - candidate.y);
    if (score < best.score && (capture === "automatic" || score < snapStrength)) best = { ...candidate, score };
  }
  if (capture === "fixed") return grid;
  if (!settings.snapToGrid && !settings.snapToObjects) return { x: roundTo(point.x, 2), y: roundTo(point.y, 2) };
  if (best.score > snapStrength) return { x: roundTo(point.x, 2), y: roundTo(point.y, 2) };
  return { x: best.x, y: best.y };
}

function createGeometryObjectForTool(construction: Construction, tool: GeometryTool, x: number, y: number) {
  const base = construction.points.length;
  const makePoint = (dx: number, dy: number, offset: number, style?: GeoStyle): GeoPoint => ({
    id: crypto.randomUUID(),
    x: roundTo(x + dx, 2),
    y: roundTo(y + dy, 2),
    label: nextPointLabel(construction.points, offset),
    style,
  });
  const withPoints = (...points: GeoPoint[]) => ({ ...construction, points: [...construction.points, ...points] });
  const labelOffset = (index: number) => base + index - construction.points.length;

  if (tool === "move-canvas" || tool === "zoom") return construction;
  if (tool === "freehand") {
    const points = Array.from({ length: 22 }, (_, index) => {
      const t = index / 21;
      return { x: x - 110 + t * 220, y: y + Math.sin(t * Math.PI * 3) * 28 };
    });
    return { ...construction, loci: [...construction.loci, { id: crypto.randomUUID(), label: "freehand", points, style: { color: "#f97316", strokeWidth: 4 } }] };
  }
  if (tool === "segment" || tool === "line" || tool === "ray" || tool === "vector") {
    const a = makePoint(-72, 0, labelOffset(0));
    const b = makePoint(72, 0, labelOffset(1));
    const style: GeoStyle = tool === "segment" ? { label: "segment", color: "#22d3ee" } : tool === "ray" ? { label: "ray", color: "#a78bfa" } : tool === "vector" ? { label: "vector", color: "#10b981", strokeWidth: 5 } : { label: "line", color: "#8b5cf6" };
    return solveConstruction({ ...withPoints(a, b), lines: [...construction.lines, { id: crypto.randomUUID(), a: a.id, b: b.id, kind: tool === "ray" ? "ray" : tool === "vector" ? "vector" : "line", style }] });
  }
  if (tool === "circle" || tool === "circle-radius") {
    const center = makePoint(0, 0, labelOffset(0));
    const edge = makePoint(78, 0, labelOffset(1));
    return solveConstruction({ ...withPoints(center, edge), circles: [...construction.circles, { id: crypto.randomUUID(), center: center.id, edge: edge.id }] });
  }
  if (tool === "polygon") {
    const points = [makePoint(0, -74, labelOffset(0)), makePoint(-78, 54, labelOffset(1)), makePoint(82, 54, labelOffset(2))];
    return solveConstruction({ ...withPoints(...points), polygons: [...construction.polygons, { id: crypto.randomUUID(), points: points.map((point) => point.id) }] });
  }
  if (tool === "angle") {
    const a = makePoint(-86, -18, labelOffset(0));
    const vertex = makePoint(0, 42, labelOffset(1));
    const c = makePoint(82, -48, labelOffset(2));
    return solveConstruction(addArcOrSector(withPoints(a, vertex, c), vertex.id, a.id, c.id, false));
  }
  if (tool === "parallel" || tool === "perpendicular") {
    const a = makePoint(-92, 34, labelOffset(0));
    const b = makePoint(46, -36, labelOffset(1));
    const through = makePoint(12, 54, labelOffset(2), { color: "#f59e0b" });
    return solveConstruction(buildParallelPerpendicularFromPoints(withPoints(a, b, through), tool, [a.id, b.id, through.id]).construction);
  }
  if (tool === "midpoint" || tool === "fixed-length") {
    const a = makePoint(-84, 0, labelOffset(0));
    const b = makePoint(84, 0, labelOffset(1));
    const result = tool === "midpoint"
      ? buildMidpointConstruction(withPoints(a, b), [a.id, b.id])
      : buildFixedLengthSegmentConstruction(withPoints(a, b), a.id, b.id);
    return solveConstruction(result.construction);
  }
  if (tool === "circle-3-points") {
    const a = makePoint(-76, 26, labelOffset(0));
    const b = makePoint(2, -82, labelOffset(1));
    const c = makePoint(84, 34, labelOffset(2));
    return solveConstruction(buildCircleThroughThreePoints(withPoints(a, b, c), [a.id, b.id, c.id]).construction);
  }
  if (tool === "on-circle") {
    const center = makePoint(0, 0, labelOffset(0));
    const edge = makePoint(86, 0, labelOffset(1));
    const point = makePoint(44, 44, labelOffset(2), { color: "#8b5cf6" });
    const circle: GeoCircle = { id: crypto.randomUUID(), center: center.id, edge: edge.id };
    const seeded = solveConstruction({ ...withPoints(center, edge, point), circles: [...construction.circles, circle] });
    return solveConstruction(buildPointOnCircleConstraint(seeded, point.id).construction, point.id);
  }
  if (tool === "intersect") {
    const a = makePoint(-92, -62, labelOffset(0));
    const b = makePoint(92, 62, labelOffset(1));
    const c = makePoint(-92, 62, labelOffset(2));
    const d = makePoint(92, -62, labelOffset(3));
    const lineOne: GeoLine = { id: crypto.randomUUID(), a: a.id, b: b.id };
    const lineTwo: GeoLine = { id: crypto.randomUUID(), a: c.id, b: d.id };
    return solveConstruction(buildIntersectionConstruction(solveConstruction({ ...withPoints(a, b, c, d), lines: [...construction.lines, lineOne, lineTwo] })).construction);
  }
  if (tool === "perpendicular-bisector") {
    const a = makePoint(-82, 0, labelOffset(0));
    const b = makePoint(82, 0, labelOffset(1));
    return addPerpendicularBisector(withPoints(a, b), a.id, b.id);
  }
  if (tool === "angle-bisector") {
    const a = makePoint(-78, -22, labelOffset(0));
    const vertex = makePoint(0, 52, labelOffset(1));
    const c = makePoint(82, -54, labelOffset(2));
    return addAngleBisector(addArcOrSector(withPoints(a, vertex, c), vertex.id, a.id, c.id, false), a.id, vertex.id, c.id);
  }
  if (tool === "tangent" || tool === "polar") {
    const center = makePoint(0, 0, labelOffset(0));
    const edge = makePoint(70, 0, labelOffset(1));
    const point = makePoint(tool === "tangent" ? 70 : 128, tool === "tangent" ? 0 : -48, labelOffset(2), { color: "#f97316" });
    const next = solveConstruction({ ...withPoints(center, edge, point), circles: [...construction.circles, { id: crypto.randomUUID(), center: center.id, edge: edge.id }] });
    return tool === "tangent" ? addTangentAtPoint(next, point.id) : addPolarLine(next, point.id);
  }
  if (tool === "locus") {
    const point = makePoint(0, 0, labelOffset(0), { color: "#ec4899", trace: true });
    return addLocusForPoint(withPoints(point), point.id);
  }
  if (tool === "regular-polygon") {
    const a = makePoint(-58, 38, labelOffset(0));
    const b = makePoint(42, 38, labelOffset(1));
    return solveConstruction(buildRegularPolygonConstruction(withPoints(a, b), [a.id, b.id], 5).construction);
  }
  if (tool === "arc" || tool === "sector") {
    const center = makePoint(0, 0, labelOffset(0));
    const start = makePoint(82, 0, labelOffset(1));
    const end = makePoint(16, -82, labelOffset(2));
    return solveConstruction(addArcOrSector(withPoints(center, start, end), center.id, start.id, end.id, tool === "sector"));
  }
  if (tool === "compass") {
    const a = makePoint(-90, 58, labelOffset(0));
    const b = makePoint(-18, 58, labelOffset(1));
    const center = makePoint(24, -18, labelOffset(2));
    return solveConstruction(buildCompassCopyConstruction(withPoints(a, b, center), a.id, b.id, center.id).construction);
  }
  if (tool === "mirror") {
    const point = makePoint(54, -48, labelOffset(0), { color: "#ec4899" });
    const a = makePoint(-56, -70, labelOffset(1));
    const b = makePoint(-56, 72, labelOffset(2));
    return solveConstruction(buildMirrorTransformPayload(withPoints(point, a, b), point.id, a.id, b.id).construction);
  }
  if (tool === "rotate" || tool === "dilate") {
    const center = makePoint(-36, 40, labelOffset(0), { color: "#f59e0b" });
    const point = makePoint(72, -44, labelOffset(1));
    const result = tool === "rotate"
      ? buildRotateTransformPayload(withPoints(center, point), point.id, center.id, 45)
      : buildDilateTransformPayload(withPoints(center, point), point.id, center.id, 1.5);
    return solveConstruction(result.construction);
  }
  if (tool === "translate") {
    const from = makePoint(-86, 52, labelOffset(0));
    const to = makePoint(-18, 4, labelOffset(1));
    const point = makePoint(64, -42, labelOffset(2));
    return solveConstruction(buildTranslateTransformPayload(withPoints(from, to, point), point.id, from.id, to.id).construction);
  }
  return construction;
}

function addPerpendicularBisector(construction: Construction, aId: string, bId: string) {
  const a = pointById(construction.points, aId), b = pointById(construction.points, bId);
  if (!a || !b) return construction;
  const mid: GeoPoint = { id: crypto.randomUUID(), x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, label: nextPointLabel(construction.points) };
  const vector = unitVector(a, b, true);
  const end: GeoPoint = { id: crypto.randomUUID(), x: mid.x + vector.x * 140, y: mid.y + vector.y * 140, label: nextPointLabel([...construction.points, mid]) };
  return solveConstruction({ ...construction, points: [...construction.points, mid, end], lines: [...construction.lines, { id: crypto.randomUUID(), a: mid.id, b: end.id }], constraints: [...construction.constraints, { id: crypto.randomUUID(), type: "midpoint", a: aId, b: bId, point: mid.id }] });
}

function addAngleBisector(construction: Construction, aId: string, vertexId: string, cId: string) {
  const a = pointById(construction.points, aId), v = pointById(construction.points, vertexId), c = pointById(construction.points, cId);
  if (!a || !v || !c) return construction;
  const va = normalize(a.x - v.x, a.y - v.y);
  const vc = normalize(c.x - v.x, c.y - v.y);
  const direction = normalize(va.x + vc.x, va.y + vc.y);
  const end: GeoPoint = { id: crypto.randomUUID(), x: v.x + direction.x * 150, y: v.y + direction.y * 150, label: nextPointLabel(construction.points) };
  return solveConstruction({ ...construction, points: [...construction.points, end], lines: [...construction.lines, { id: crypto.randomUUID(), a: vertexId, b: end.id }] });
}

function addTangentAtPoint(construction: Construction, pointId: string, circleId?: string) {
  const circle = circleId ? construction.circles.find((item) => item.id === circleId) : construction.circles[0];
  const point = pointById(construction.points, pointId);
  const center = circle ? pointById(construction.points, circle.center) : null;
  if (!circle || !point || !center) return construction;
  const tangentPoint = projectPointToCircle(point, circle, construction.points) ?? point;
  const normalizedPoint: GeoPoint = { ...point, x: tangentPoint.x, y: tangentPoint.y };
  const direction = normalize(-(normalizedPoint.y - center.y), normalizedPoint.x - center.x);
  const end: GeoPoint = { id: crypto.randomUUID(), x: normalizedPoint.x + direction.x * 150, y: normalizedPoint.y + direction.y * 150, label: nextPointLabel(construction.points) };
  return solveConstruction({
    ...construction,
    points: construction.points.map((item) => item.id === pointId ? normalizedPoint : item).concat(end),
    lines: [...construction.lines, { id: crypto.randomUUID(), a: pointId, b: end.id, style: { color: "#f97316", label: "tangent" } }],
  }, pointId);
}

function addPolarLine(construction: Construction, pointId: string, circleId?: string) {
  const circle = circleId ? construction.circles.find((item) => item.id === circleId) : construction.circles[0];
  const point = pointById(construction.points, pointId);
  const center = circle ? pointById(construction.points, circle.center) : null;
  const edge = circle ? pointById(construction.points, circle.edge) : null;
  if (!circle || !point || !center || !edge) return construction;
  const radius = distance(center, edge);
  const cp = distance(center, point) || 1;
  const foot = { x: center.x + ((point.x - center.x) * radius * radius) / (cp * cp), y: center.y + ((point.y - center.y) * radius * radius) / (cp * cp) };
  const direction = normalize(-(point.y - center.y), point.x - center.x);
  const a: GeoPoint = { id: crypto.randomUUID(), x: foot.x - direction.x * 100, y: foot.y - direction.y * 100, label: nextPointLabel(construction.points) };
  const b: GeoPoint = { id: crypto.randomUUID(), x: foot.x + direction.x * 100, y: foot.y + direction.y * 100, label: nextPointLabel([...construction.points, a]) };
  return solveConstruction({ ...construction, points: [...construction.points, a, b], lines: [...construction.lines, { id: crypto.randomUUID(), a: a.id, b: b.id, style: { color: "#ec4899" } }] });
}

function addLocusForPoint(construction: Construction, pointId: string) {
  const point = pointById(construction.points, pointId);
  if (!point) return construction;
  return setGeometryTrace(construction, { type: "point", id: pointId }, true);
}

function addArcOrSector(construction: Construction, center: string, start: string, end: string, sector: boolean) {
  return { ...construction, arcs: [...construction.arcs, { id: crypto.randomUUID(), center, start, end, sector, style: { color: sector ? "#f59e0b" : "#14b8a6", fill: sector ? "rgba(245,158,11,.18)" : "none" } }] };
}

function projectPointToLine(point: { x: number; y: number }, line: GeoLine, points: GeoPoint[]) {
  const a = pointById(points, line.a), b = pointById(points, line.b);
  return a && b ? projectRawPointToLine(point, a, b) : null;
}

function projectRawPointToLine(point: { x: number; y: number }, a: GeoPoint, b: GeoPoint) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const length2 = dx * dx + dy * dy || 1;
  const t = ((point.x - a.x) * dx + (point.y - a.y) * dy) / length2;
  return { x: a.x + t * dx, y: a.y + t * dy };
}

function projectPointToCircle(point: { x: number; y: number }, circle: GeoCircle, points: GeoPoint[]) {
  const center = pointById(points, circle.center), edge = pointById(points, circle.edge);
  if (!center || !edge) return null;
  const radius = distance(center, edge);
  const vector = normalize(point.x - center.x, point.y - center.y);
  return { x: center.x + vector.x * radius, y: center.y + vector.y * radius };
}

function allIntersections(construction: Construction) {
  const output: { x: number; y: number }[] = [];
  for (let i = 0; i < construction.lines.length; i += 1) {
    for (let j = i + 1; j < construction.lines.length; j += 1) {
      const hit = lineIntersection(construction.lines[i], construction.lines[j], construction.points);
      if (hit) output.push(hit);
    }
    for (const circle of construction.circles) output.push(...lineCircleIntersections(construction.lines[i], circle, construction.points));
  }
  for (let i = 0; i < construction.circles.length; i += 1) {
    for (let j = i + 1; j < construction.circles.length; j += 1) output.push(...circleCircleIntersections(construction.circles[i], construction.circles[j], construction.points));
  }
  return uniqueBoardPoints(output);
}

function uniqueBoardPoints(points: { x: number; y: number }[]) {
  return points.filter((point, index) => points.findIndex((other) => Math.hypot(other.x - point.x, other.y - point.y) < 2) === index);
}

function lineCircleIntersections(line: GeoLine, circle: GeoCircle, points: GeoPoint[]) {
  const a = pointById(points, line.a), b = pointById(points, line.b), center = pointById(points, circle.center), edge = pointById(points, circle.edge);
  if (!a || !b || !center || !edge) return [];
  if(line.kind==='ray'||line.kind==='vector')return kernelIntersectObjects((line.kind==='ray'?kernelRay:kernelSegment)(kernelPoint(a.x,a.y),kernelPoint(b.x,b.y)),kernelCircle(kernelPoint(center.x,center.y),distance(center,edge)));
  const dx = b.x - a.x, dy = b.y - a.y;
  const fx = a.x - center.x, fy = a.y - center.y;
  const radius = distance(center, edge);
  const qa = dx * dx + dy * dy;
  const qb = 2 * (fx * dx + fy * dy);
  const qc = fx * fx + fy * fy - radius * radius;
  const disc = qb * qb - 4 * qa * qc;
  if (disc < -0.001) return [];
  const root = Math.sqrt(Math.max(0, disc));
  return [(-qb - root) / (2 * qa), (-qb + root) / (2 * qa)].map((t) => ({ x: a.x + t * dx, y: a.y + t * dy }));
}

function circleCircleIntersections(first: GeoCircle, second: GeoCircle, points: GeoPoint[]) {
  const c1 = pointById(points, first.center), e1 = pointById(points, first.edge), c2 = pointById(points, second.center), e2 = pointById(points, second.edge);
  if (!c1 || !e1 || !c2 || !e2) return [];
  const r1 = distance(c1, e1), r2 = distance(c2, e2), d = distance(c1, c2);
  if (d > r1 + r2 || d < Math.abs(r1 - r2) || d < 0.001) return [];
  const a = (r1 * r1 - r2 * r2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, r1 * r1 - a * a));
  const x = c1.x + (a * (c2.x - c1.x)) / d;
  const y = c1.y + (a * (c2.y - c1.y)) / d;
  const rx = -(c2.y - c1.y) * (h / d);
  const ry = (c2.x - c1.x) * (h / d);
  return [{ x: x + rx, y: y + ry }, { x: x - rx, y: y - ry }];
}

function normalizeConstruction(value: Partial<Construction>): Construction {
  return solveConstruction({
    points: value.points ?? [],
    lines: value.lines ?? [],
    circles: value.circles ?? [],
    polygons: value.polygons ?? [],
    arcs: value.arcs ?? [],
    loci: value.loci ?? [],
    constraints: value.constraints ?? [],
  });
}

function intersectionsForSelectedObjects(construction: Construction, first: SelectedGeometryObject, second: SelectedGeometryObject) {
  if (first.type === "line" && second.type === "line") {
    const firstLine = construction.lines.find((line) => line.id === first.id);
    const secondLine = construction.lines.find((line) => line.id === second.id);
    const hit = firstLine && secondLine ? lineIntersection(firstLine, secondLine, construction.points) : null;
    return hit ? [hit] : [];
  }
  if (first.type === "line" && second.type === "circle") {
    const line = construction.lines.find((item) => item.id === first.id);
    const circle = construction.circles.find((item) => item.id === second.id);
    return line && circle ? lineCircleIntersections(line, circle, construction.points) : [];
  }
  if (first.type === "circle" && second.type === "line") return intersectionsForSelectedObjects(construction, second, first);
  if (first.type === "circle" && second.type === "circle") {
    const firstCircle = construction.circles.find((item) => item.id === first.id);
    const secondCircle = construction.circles.find((item) => item.id === second.id);
    return firstCircle && secondCircle ? circleCircleIntersections(firstCircle, secondCircle, construction.points) : [];
  }
  return [];
}

function solveConstruction(construction: Construction, draggedPointId?: string): Construction {
  let points = construction.points;
  for (let iteration = 0; iteration < 3; iteration += 1) {
    for (const constraint of construction.constraints) {
      if (constraint.type === "affine") {
        const next = affineConstraintPoint(constraint, points);
        if (next) points = updatePoint(points, constraint.point, next);
      }
      if (constraint.type === "midpoint") {
        const a = pointById(points, constraint.a), b = pointById(points, constraint.b);
        if (a && b) points = updatePoint(points, constraint.point, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
      }
      if (constraint.type === "fixed-length" && draggedPointId === constraint.point) {
        const anchor = pointById(points, constraint.anchor), point = pointById(points, constraint.point);
        if (anchor && point) {
          const vector = normalize(point.x - anchor.x, point.y - anchor.y);
          points = updatePoint(points, constraint.point, { x: anchor.x + vector.x * constraint.length, y: anchor.y + vector.y * constraint.length });
        }
      }
      if (constraint.type === "on-circle") {
        const circle = construction.circles.find((item) => item.id === constraint.circle);
        const point = pointById(points, constraint.point);
        const center = circle ? pointById(points, circle.center) : null;
        const edge = circle ? pointById(points, circle.edge) : null;
        if (point && center && edge) {
          const vector = normalize(point.x - center.x, point.y - center.y);
          const radius = distance(center, edge);
          points = updatePoint(points, constraint.point, { x: center.x + vector.x * radius, y: center.y + vector.y * radius });
        }
      }
      if (constraint.type === "parallel" || constraint.type === "perpendicular") {
        const source = construction.lines.find((item) => item.id === constraint.sourceLine);
        const line = construction.lines.find((item) => item.id === constraint.line);
        const sourceA = source ? pointById(points, source.a) : null;
        const sourceB = source ? pointById(points, source.b) : null;
        const through = pointById(points, constraint.throughPoint);
        const end = line ? pointById(points, line.b) : null;
        if (sourceA && sourceB && through && end) {
          const vector = unitVector(sourceA, sourceB, constraint.type === "perpendicular");
          const length = Math.max(80, distance(through, end));
          points = updatePoint(points, end.id, { x: through.x + vector.x * length, y: through.y + vector.y * length });
        }
      }
      if (constraint.type === "intersection") {
        const firstType = constraint.firstType ?? "line";
        const secondType = constraint.secondType ?? "line";
        const hits = intersectionsForSelectedObjects({ ...construction, points }, { type: firstType, id: constraint.first }, { type: secondType, id: constraint.second });
        const intersection = hits[constraint.index ?? 0] ?? null;
        if (intersection) points = updatePoint(points, constraint.point, intersection);
      }
    }
  }
  return { ...construction, points };
}

function updatePoint(points: GeoPoint[], id: string, next: { x: number; y: number }) {
  return points.map((point) => point.id === id ? { ...point, x: next.x, y: next.y } : point);
}

function unitVector(a: GeoPoint, b: GeoPoint, perpendicular = false) {
  const vector = normalize(b.x - a.x, b.y - a.y);
  return perpendicular ? { x: -vector.y, y: vector.x } : vector;
}

function normalize(x: number, y: number) {
  const length = Math.hypot(x, y) || 1;
  return { x: x / length, y: y / length };
}

function lineIntersection(first: GeoLine, second: GeoLine, points: GeoPoint[]) {
  const a = pointById(points, first.a), b = pointById(points, first.b), c = pointById(points, second.a), d = pointById(points, second.b);
  if (!a || !b || !c || !d) return null;
  if(first.kind==='ray'||first.kind==='vector'||second.kind==='ray'||second.kind==='vector'){const object=(line:GeoLine,u:GeoPoint,v:GeoPoint)=>(line.kind==='ray'?kernelRay:line.kind==='vector'?kernelSegment:kernelLine)(kernelPoint(u.x,u.y),kernelPoint(v.x,v.y));return kernelIntersectObjects(object(first,a,b),object(second,c,d))[0]??null;}
  const denominator = (a.x - b.x) * (c.y - d.y) - (a.y - b.y) * (c.x - d.x);
  if (Math.abs(denominator) < 0.001) return null;
  const px = ((a.x * b.y - a.y * b.x) * (c.x - d.x) - (a.x - b.x) * (c.x * d.y - c.y * d.x)) / denominator;
  const py = ((a.x * b.y - a.y * b.x) * (c.y - d.y) - (a.y - b.y) * (c.x * d.y - c.y * d.x)) / denominator;
  return { x: px, y: py };
}

function nextPointLabel(points: GeoPoint[], offset = 0) {
  return String.fromCharCode(65 + points.length + offset);
}

function constraintLabel(constraint: GeoConstraint, construction: Construction) {
  if (constraint.type === "midpoint") return `${labelForPoint(construction, constraint.point)} is midpoint of ${labelForPoint(construction, constraint.a)}${labelForPoint(construction, constraint.b)}`;
  if (constraint.type === "fixed-length") return `${labelForPoint(construction, constraint.anchor)}${labelForPoint(construction, constraint.point)} fixed at ${roundTo(constraint.length / 40, 2)} units`;
  if (constraint.type === "on-circle") return `${labelForPoint(construction, constraint.point)} stays on first circle`;
  if (constraint.type === "intersection") return `${labelForPoint(construction, constraint.point)} is line intersection`;
  return `${constraint.type} constrained line`;
}

function labelForPoint(construction: Construction, id: string) {
  return pointById(construction.points, id)?.label ?? "?";
}

function polygonArea(points: GeoPoint[]) {
  return Math.abs(points.reduce((sum, point, index) => {
    const next = points[(index + 1) % points.length];
    return sum + point.x * next.y - next.x * point.y;
  }, 0) / 2);
}


export default function MathWorkspace(props: { initialView?: WorkspaceView; singleView?: boolean; dataPage?: DataWorkspacePage; embedded?: EmbeddedMathWorkspace }) { return <ImmersiveBoundary><MathWorkspaceContent {...props} /></ImmersiveBoundary>; }
